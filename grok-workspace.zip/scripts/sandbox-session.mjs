import { createRequire } from "node:module";
import readline from "node:readline";

const require = createRequire(import.meta.url);

async function loadChromium() {
  try {
    const mod = await import("playwright");
    if (mod.chromium) return mod.chromium;
    if (mod.default?.chromium) return mod.default.chromium;
  } catch {
    /* playwright is not installed in this runtime */
  }
  const loaded = require("playwright-core");
  return loaded.chromium || loaded.default?.chromium;
}

const chromium = await loadChromium();
const browser = await chromium.launch({
  headless: true,
  executablePath: process.env.QUAY_CHROMIUM || undefined,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({ viewport: { width: 390, height: 844 } });

async function screen() {
  const data = await page.evaluate(() => {
    const viewH = window.innerHeight;
    const viewW = window.innerWidth;
    const visible = (el) => {
      const style = window.getComputedStyle(el);
      if (style.visibility === "hidden" || style.display === "none") return false;
      const box = el.getBoundingClientRect();
      return box.bottom > 4 && box.top < viewH - 4 && box.right > 4 && box.left < viewW - 4 && box.width > 8 && box.height > 8;
    };
    const raw = (el) =>
      (el.getAttribute("aria-label") || el.getAttribute("title") || el.getAttribute("alt") || el.innerText || el.textContent || el.getAttribute("placeholder") || el.getAttribute("name") || "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 80);
    const nodes = document.querySelectorAll("a[href], button, input, textarea, select, summary, [role=button], [role=link], [role=menuitem], [role=tab], [aria-label]");
    const options = [];
    const seen = new Set();
    for (const el of nodes) {
      if (!(el instanceof HTMLElement) || !visible(el)) continue;
      const label = raw(el);
      if (!label) continue;
      const tag = el.tagName.toLowerCase();
      let kind = "link";
      if (tag === "input" || tag === "textarea" || tag === "select") kind = "form";
      else if (el.getAttribute("role") === "menuitem" || el.closest("nav, [role=menu], [role=menubar]")) kind = "menu";
      else if (tag === "button" || el.getAttribute("role") === "button" || tag === "summary") kind = "button";
      else if ((el.querySelector("svg, img") && label.length < 24) || (el.getAttribute("aria-label") && !(el.innerText || "").trim())) kind = "icon";
      const key = `${kind}:${label.toLowerCase()}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const box = el.getBoundingClientRect();
      const id = String(options.length + 1);
      el.setAttribute("data-quay", id);
      options.push({
        id,
        kind,
        label,
        x: Math.round(((box.left + box.width / 2) / viewW) * 100),
        y: Math.round(((box.top + box.height / 2) / viewH) * 100),
      });
      if (options.length >= 16) break;
    }
    const bits = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node = walker.nextNode();
    while (node) {
      const parent = node.parentElement;
      if (parent && visible(parent)) {
        const bit = (node.textContent || "").replace(/\s+/g, " ").trim();
        if (bit.length > 1) bits.push(bit);
      }
      if (bits.join(" ").length > 1400) break;
      node = walker.nextNode();
    }
    const fields = [...document.querySelectorAll("input, textarea")]
      .filter((el) => el instanceof HTMLElement && visible(el))
      .map((el) => el.value || "")
      .filter(Boolean);
    const height = Math.max(document.body?.scrollHeight ?? 0, document.documentElement?.scrollHeight ?? 0);
    return {
      url: location.href,
      title: document.title || "Page",
      text: `${bits.join(" ")} ${fields.join(" ")}`.replace(/\s+/g, " ").trim().slice(0, 1400),
      moreBelow: window.scrollY + viewH < height - 24,
      moreAbove: window.scrollY > 24,
      options,
    };
  });
  const shot = Buffer.from(await page.screenshot({ type: "jpeg", quality: 32 })).toString("base64");
  return { ...data, shot };
}

function send(payload) {
  process.stdout.write(`${JSON.stringify(payload)}\n`);
}

const lines = readline.createInterface({ input: process.stdin });
for await (const line of lines) {
  let cmd = {};
  try {
    cmd = JSON.parse(line);
  } catch {
    send({ ok: false, error: "bad command" });
    continue;
  }
  try {
    if (cmd.cmd === "close") break;
    if (cmd.cmd === "open") {
      await page.goto(String(cmd.url || ""), { waitUntil: "domcontentloaded", timeout: 0 });
      await page.waitForTimeout(500);
      send({ ok: true, screen: await screen() });
      continue;
    }
    if (cmd.cmd === "click") {
      const id = String(cmd.id || "");
      const target = page.locator(`[data-quay="${id}"]`).first();
      const point = await target.boundingBox();
      const view = page.viewportSize() || { width: 390, height: 844 };
      const click = point
        ? {
            x: Math.round(((point.x + point.width / 2) / view.width) * 100),
            y: Math.round(((point.y + point.height / 2) / view.height) * 100),
          }
        : null;
      await target.click({ timeout: 10000 });
      await page.waitForTimeout(500);
      send({ ok: true, screen: await screen(), click });
      continue;
    }
    if (cmd.cmd === "type") {
      const field = page.locator(`[data-quay="${String(cmd.id || "")}"]`).first();
      await field.fill(String(cmd.text || "").slice(0, 160));
      await page.waitForTimeout(200);
      send({ ok: true, screen: await screen() });
      continue;
    }
    if (cmd.cmd === "scroll") {
      const dir = String(cmd.dir || "down");
      await page.mouse.wheel(0, dir === "up" ? -700 : 700);
      await page.waitForTimeout(250);
      send({ ok: true, screen: await screen() });
      continue;
    }
    if (cmd.cmd === "wait") {
      await page.waitForTimeout(800);
      send({ ok: true, screen: await screen() });
      continue;
    }
    if (cmd.cmd === "back") {
      await page.goBack({ waitUntil: "domcontentloaded", timeout: 0 });
      await page.waitForTimeout(300);
      send({ ok: true, screen: await screen() });
      continue;
    }
    send({ ok: false, error: "unknown command", screen: await screen().catch(() => null) });
  } catch (error) {
    let failed = null;
    try {
      failed = await screen();
    } catch {
      failed = null;
    }
    send({ ok: false, error: error instanceof Error ? error.message.slice(0, 160) : "action failed", screen: failed });
  }
}

lines.close();
await browser.close();
