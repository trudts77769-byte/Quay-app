import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

export async function resolve(specifier, context, nextResolve) {
  if (specifier.startsWith("@/")) {
    const url = new URL(`../src/${specifier.slice(2)}.ts`, import.meta.url);
    return nextResolve(url.href, context);
  }
  if (specifier.endsWith(".server")) {
    return nextResolve(`${specifier}.ts`, context);
  }
  if (specifier.includes("?raw")) {
    const resolved = await nextResolve(specifier.slice(0, specifier.indexOf("?")), context);
    return { url: `${resolved.url}?raw`, shortCircuit: true };
  }
  return nextResolve(specifier, context);
}

export async function load(url, context, nextLoad) {
  if (url.includes("?raw")) {
    const text = readFileSync(fileURLToPath(url.slice(0, url.indexOf("?"))), "utf8");
    return { format: "module", source: `export default ${JSON.stringify(text)};`, shortCircuit: true };
  }
  return nextLoad(url, context);
}
