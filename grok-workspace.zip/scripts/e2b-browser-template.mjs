import { Sandbox, Template, defaultBuildLogger } from "e2b";

const NAME = "quay-reader-chromium";
const EXAMPLE = "https://example.com";

function key() {
  const value = process.env.E2B_API_KEY?.trim() ?? "";
  if (!value) {
    console.error("E2B_API_KEY is not set. Refusing to continue.");
    process.exit(1);
  }
  return value;
}

function redact(value) {
  const secret = process.env.E2B_API_KEY?.trim() ?? "";
  let text = value instanceof Error ? value.message : String(value ?? "");
  if (secret) text = text.split(secret).join("[redacted]");
  return text.replace(/e2b_[A-Za-z0-9]+/g, "[redacted]");
}

async function build() {
  const apiKey = key();
  const template = Template()
    .fromImage("mcr.microsoft.com/playwright:v1.55.0-noble")
    .runCmd("apt-get update && apt-get install -y curl && rm -rf /var/lib/apt/lists/*", { user: "root" })
    .runCmd(
      `chrome=$(find /ms-playwright -type f -path '*/chrome-linux*/chrome' ! -path '*/headless_shell' | head -n 1); test -n "$chrome" && ln -sfn "$chrome" /usr/local/bin/chromium`,
      { user: "root" },
    );
  await Template.build(template, NAME, {
    apiKey,
    cpuCount: 2,
    memoryMB: 2048,
    onBuildLogs: defaultBuildLogger(),
  });
  console.log(`Registered template ${NAME}.`);
}

async function check() {
  const apiKey = key();
  const sandbox = await Sandbox.create(NAME, { apiKey, timeoutMs: 120_000, allowInternetAccess: true });
  try {
    const ua = "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)";
    const chromium = await sandbox.commands.run(
      `chromium --headless --no-sandbox --disable-dev-shm-usage --user-agent=${JSON.stringify(ua)} --virtual-time-budget=15000 --dump-dom ${JSON.stringify(EXAMPLE)}`,
      { timeoutMs: 40_000 },
    );
    const curled =
      (chromium.stdout ?? "").length >= 40
        ? chromium
        : await sandbox.commands.run(`curl -fsSL -A ${JSON.stringify(ua)} --max-time 20 ${JSON.stringify(EXAMPLE)}`, {
            timeoutMs: 25_000,
          });
    const bytes = (curled.stdout ?? "").length;
    console.log(bytes >= 40 ? `Loaded ${EXAMPLE} (${bytes} bytes).` : `Did not load ${EXAMPLE}.`);
    if (bytes < 40) process.exitCode = 1;
  } finally {
    await sandbox.kill();
  }
}

const command = process.argv[2] || "";
try {
  if (command === "check") await check();
  else if (command === "build") await build();
  else {
    console.error("Use check or build.");
    process.exit(1);
  }
} catch (error) {
  console.error(redact(error));
  process.exit(1);
}
