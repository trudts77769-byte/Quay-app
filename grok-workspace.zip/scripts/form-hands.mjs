import readline from "node:readline";
import { chromium } from "playwright";

const rl = readline.createInterface({ input: process.stdin });
const queued = [];
const waiting = [];
rl.on("line", (line) => {
  if (waiting.length) waiting.shift()(line);
  else queued.push(line);
});

function nextLine() {
  if (queued.length) return Promise.resolve(queued.shift());
  return new Promise((resolve) => waiting.push(resolve));
}

function say(payload) {
  process.stdout.write(`${JSON.stringify(payload)}\n`);
}

const start = JSON.parse(await nextLine());
const secrets = start.secrets && typeof start.secrets === "object" ? start.secrets : {};
const secretValues = Object.values(secrets).map(String).filter((value) => value.length > 2);

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
page.setDefaultTimeout(20000);

function swapped(text) {
  return String(text).replace(/\{([A-Z0-9_]+)\}/g, (_, key) => (key in secrets ? String(secrets[key]) : `{${key}}`));
}

async function screen() {
  await page.evaluate((values) => {
    const hit = (text) => values.some((item) => item && text.includes(item));
    for (const el of document.querySelectorAll("input, textarea, select, option")) {
      const value = "value" in el ? String(el.value || "") : "";
      const text = el.innerText || el.textContent || "";
      if (!hit(value) && !hit(text)) continue;
      if (el.tagName === "INPUT" && !el.getAttribute("data-quay-type")) el.setAttribute("data-quay-type", el.type || "text");
      if (el.tagName === "INPUT") el.type = "password";
      el.style.filter = "blur(12px)";
      el.setAttribute("data-quay-filter", "1");
    }
  }, secretValues);
  const shot = (await page.screenshot({ type: "png" })).toString("base64");
  const small = (await page.screenshot({ type: "jpeg", quality: 28 })).toString("base64");
  await page.evaluate(() => {
    for (const el of document.querySelectorAll("[data-quay-type]")) {
      el.type = el.getAttribute("data-quay-type") || "text";
    }
    for (const el of document.querySelectorAll("[data-quay-filter]")) {
      el.style.filter = "";
      el.removeAttribute("data-quay-filter");
    }
  });
  const elements = await page.evaluate((values) => {
    const clean = (value) => (value || "").replace(/\s+/g, " ").trim();
    const found = [];
    const nodes = [...document.querySelectorAll("button, a, input, select, textarea, [role=button], [role=combobox]")];
    for (const el of nodes) {
      const rect = el.getBoundingClientRect();
      if (rect.width < 4 || rect.height < 4 || rect.bottom < 0 || rect.top > window.innerHeight) continue;
      let label = clean(el.getAttribute("aria-label") || el.getAttribute("placeholder") || el.innerText || "");
      if (!label && el.id) {
        const owner = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
        if (owner) label = clean(owner.textContent || "");
      }
      if (!label) label = clean(el.getAttribute("name") || "");
      if (!label) continue;
      const kind = el.tagName === "SELECT" ? "select" : el.tagName === "INPUT" || el.tagName === "TEXTAREA" ? "field" : "button";
      let value = "value" in el ? String(el.value || "") : "";
      if (values.some((item) => value.includes(item))) value = "{set}";
      const options = el.tagName === "SELECT"
        ? [...el.options].map((option) => clean(option.textContent || "")).filter(Boolean).slice(0, 12)
        : [];
      found.push({
        label: label.slice(0, 80),
        kind,
        x: Math.round(rect.x + rect.width / 2),
        y: Math.round(rect.y + rect.height / 2),
        value: value.slice(0, 40),
        options,
      });
      if (found.length >= 40) break;
    }
    return found;
  }, secretValues);
  const text = await page.evaluate((values) => {
    let body = (document.body?.innerText || "").replace(/\s+/g, " ").trim().slice(0, 2000);
    for (const value of values) {
      if (value) body = body.split(value).join("{set}");
    }
    return body;
  }, secretValues);
  say({ ok: true, url: page.url(), title: await page.title(), shot, small, elements, text });
}

try {
  await page.goto(start.url, { waitUntil: "domcontentloaded", timeout: 25000 });
  await page.waitForTimeout(600);
  const accept = page.getByRole("button", { name: /accept all|i agree|got it|allow all/i }).first();
  if (await accept.isVisible().catch(() => false)) await accept.click().catch(() => undefined);
  await screen();
  for (;;) {
    const message = JSON.parse(await nextLine());
    if (message.cmd === "stop") break;
    if (message.cmd === "click" && Number.isFinite(message.x)) await page.mouse.click(message.x, message.y);
    if (message.cmd === "click" && message.label) {
      const spot = await findLabel(message.label);
      if (spot?.href && /^https?:/i.test(spot.href)) await page.goto(spot.href, { waitUntil: "domcontentloaded", timeout: 20000 });
      else if (spot) await page.mouse.click(spot.x, spot.y);
    }
    if (message.cmd === "type" && message.label) {
      const spot = await findLabel(message.label);
      if (spot) {
        await page.mouse.click(spot.x, spot.y);
        await page.keyboard.press("Control+A");
        await page.keyboard.type(swapped(message.text || ""), { delay: 10 });
      }
    }
    if (message.cmd === "select" && message.label) {
      const chosen = swapped(message.text || "");
      const native = await page.evaluate(({ label, chosen }) => {
        const clean = (value) => (value || "").replace(/\s+/g, " ").trim().toLowerCase();
        const selects = [...document.querySelectorAll("select")];
        const wanted = clean(label);
        const pool = selects.filter((el) => {
          const blob = clean(`${el.getAttribute("aria-label") || ""} ${el.getAttribute("name") || ""} ${el.id || ""} ${el.parentElement?.innerText || ""}`);
          if (wanted.includes("county")) return blob.includes("county");
          return !wanted || blob.includes(wanted) || wanted.includes(blob.slice(0, 24));
        });
        const list = pool.length ? pool : selects.slice(0, 1);
        for (const el of list) {
          const option = [...el.options].find((item) => clean(item.textContent).includes(clean(chosen)));
          if (!option) continue;
          el.value = option.value;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          return true;
        }
        return false;
      }, { label: message.label, chosen });
      if (!native) {
        const spot = await findLabel(message.label);
        if (spot?.href && /^https?:/i.test(spot.href)) await page.goto(spot.href, { waitUntil: "domcontentloaded", timeout: 20000 });
        else if (spot) await page.mouse.click(spot.x, spot.y);
        await page.waitForTimeout(300);
        await page.keyboard.type(chosen, { delay: 20 });
        await page.keyboard.press("Enter");
        const option = await findLabel(chosen);
        if (option && !option.href) await page.mouse.click(option.x, option.y);
      }
    }
    if (message.cmd === "read" && /^https?:/i.test(message.url || "")) {
      await page.goto(message.url, { waitUntil: "domcontentloaded", timeout: 20000 });
    }
    if (message.cmd === "scroll") await page.mouse.wheel(0, 700);
    await page.waitForTimeout(700);
    await screen();
  }
} catch (error) {
  say({ ok: false, error: "The screen did not answer." });
} finally {
  await browser.close();
}

async function findLabel(label) {
  return page.evaluate((wanted) => {
    const clean = (value) => (value || "").replace(/\s+/g, " ").trim().toLowerCase();
    const want = clean(wanted);
    let best = null;
    for (const el of document.querySelectorAll("a, button, input, select, textarea, [role=button]")) {
      const text = clean(el.getAttribute("aria-label") || el.getAttribute("placeholder") || el.innerText || el.getAttribute("name") || "");
      if (!text || (!text.includes(want) && !want.includes(text))) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width < 2 || rect.height < 2) continue;
      const href = el.href || "";
      const score = (text === want ? 8 : 0) + (href ? 3 : 0) + Math.min(rect.width, 240) / 80;
      if (!best || score > best.score) best = { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2, href, score };
    }
    return best;
  }, label);
}
