import { chromium } from "playwright";

const url = process.argv[2];
if (!url) {
  process.stderr.write("missing url\n");
  process.exit(1);
}

const walk = process.argv.includes("--walk");
const shotOnly = process.argv.includes("--shot");
const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});

try {
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 0 });
  await page.waitForTimeout(800);
  if (walk) {
    const result = await page.evaluate(async () => {
      const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
      const textOf = (node) => (node?.innerText || node?.textContent || "").replace(/\s+/g, " ").trim();
      let scrolls = 0;
      let last = -1;
      for (let step = 0; step < 40; step += 1) {
        const height = Math.max(document.body?.scrollHeight ?? 0, document.documentElement?.scrollHeight ?? 0);
        const here = window.scrollY;
        if (here + window.innerHeight >= height - 8) break;
        window.scrollBy(0, Math.max(200, window.innerHeight));
        scrolls += 1;
        await sleep(150);
        if (window.scrollY === last) break;
        last = window.scrollY;
      }
      window.scrollTo(0, 0);
      const want = /contact|about|services?|footer/i;
      const seen = new Set();
      const links = [];
      for (const anchor of document.querySelectorAll("a[href]")) {
        const label = textOf(anchor).slice(0, 80);
        const footer = anchor.closest("footer");
        if (!want.test(label) && !footer) continue;
        let href = "";
        try {
          href = new URL(anchor.getAttribute("href") || "", location.href).href;
        } catch {
          href = "";
        }
        if (!href || seen.has(href) || new URL(href).host !== location.host) continue;
        seen.add(href);
        links.push(href);
        if (links.length >= 4) break;
      }
      const headings = [...document.querySelectorAll("h1,h2,h3")].map((node) => textOf(node)).filter(Boolean).slice(0, 12);
      return {
        scrolls,
        links,
        title: document.title || "Page",
        headings,
        text: textOf(document.body).slice(0, 4000),
        length: textOf(document.body).length,
      };
    });
    const shots = [];
    const pages = [{ url: page.url(), text: result.text, headings: result.headings, length: result.length }];
    let clicks = 0;
    for (const link of result.links) {
      try {
        await page.goto(link, { waitUntil: "domcontentloaded", timeout: 0 });
        clicks += 1;
        const body = await page.evaluate(() => ({
          title: document.title || "Page",
          text: (document.body?.innerText || "").replace(/\s+/g, " ").trim().slice(0, 2000),
          headings: [...document.querySelectorAll("h1,h2,h3")].map((node) => (node.textContent || "").replace(/\s+/g, " ").trim()).filter(Boolean).slice(0, 8),
          length: (document.body?.innerText || "").length,
        }));
        pages.push({ url: page.url(), ...body });
        shots.push(Buffer.from(await page.screenshot({ type: "jpeg", quality: 40 })).toString("base64"));
      } catch {
        /* the next link still runs */
      }
    }
    const homeShot = shots.length === 0 ? Buffer.from(await page.screenshot({ type: "jpeg", quality: 40 })).toString("base64") : shots[0];
    const text = pages
      .map((item) =>
        [`source: ${item.url}`, `length: ${item.length}`, item.headings?.length ? `headings: ${item.headings.join(" | ")}` : "", item.text]
          .filter(Boolean)
          .join("\n"),
      )
      .join("\n\n");
    process.stdout.write(
      JSON.stringify({
        text: text.slice(0, 8000),
        pages: pages.length,
        clicks,
        scrolls: result.scrolls,
        shots: Math.max(shots.length, homeShot ? 1 : 0),
        shot: homeShot || "",
      }),
    );
  } else {
  const shot = Buffer.from(await page.screenshot({ type: "jpeg", quality: 40 })).toString("base64");
  if (shotOnly) {
    const text = await page.locator("body").innerText({ timeout: 0 }).catch(() => "");
    process.stdout.write(JSON.stringify({ html: String(text).slice(0, 8000), shot, widgets: 0, options: 0 }));
  } else {
  const extras = await page.evaluate(async () => {
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const text = (node) => (node?.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 80);
    const labelFor = (el) => {
      const id = el.getAttribute("id") ?? "";
      if (id) {
        const match = document.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (match) return text(match);
      }
      return el.getAttribute("aria-label") || el.getAttribute("name") || "choice";
    };
    const widgets = [...document.querySelectorAll("[role=combobox], [aria-haspopup=listbox], [aria-haspopup=true]")].slice(0, 8);
    const found = [];
    for (const widget of widgets) {
      if (widget instanceof HTMLElement) widget.click();
      await sleep(250);
      const options = [...new Set(
        [...document.querySelectorAll("[role=option], [role=menuitem], [role=listbox] li")]
          .map((option) => text(option))
          .filter((option) => option && !/^(select|choose|please)\b/i.test(option)),
      )].slice(0, 12);
      if (options.length > 0) {
        found.push({ caption: labelFor(widget), name: widget.getAttribute("name") || "choice", options });
      }
    }
    return { found, widgets: widgets.length };
  });
  let html = await page.content();
  const block = extras.found
    .map((choice) => {
      const options = choice.options.map((option) => `<option>${option.replace(/[<>]/g, "")}</option>`).join("");
      const caption = String(choice.caption).replace(/[<>"]/g, "").slice(0, 80);
      const name = String(choice.name).replace(/[^a-z0-9_-]/gi, "").slice(0, 40) || "choice";
      return `<label>${caption}</label><select aria-label="${caption}" name="${name}">${options}</select>`;
    })
    .join("");
  html += block;
  const options = extras.found.reduce((sum, choice) => sum + choice.options.length, 0);
  process.stdout.write(JSON.stringify({ html, shot, widgets: extras.widgets, options }));
  }
  }
} finally {
  await browser.close();
}
