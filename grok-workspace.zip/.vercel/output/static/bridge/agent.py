#!/usr/bin/env python3
"""Drive the Quay pointer with any OpenAI-compatible model.

The Quay API replays the whole tape from the start on every call, so this
script keeps one tape and appends the model's next move.

  export OPENAI_API_KEY=sk-...
  # Grok, or any other compatible host:
  export OPENAI_BASE_URL=https://api.x.ai/v1
  export OPENAI_MODEL=grok-4.5

  pip install -r requirements.txt
  python agent.py --url https://example.com --goal "What is this page for?"
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

TOKEN = re.compile(r"\b(up|down|left|right|click)(?:\*(\d+))?\b", re.I)
DONE = re.compile(r"\bdone\b", re.I)
MOVE = re.compile(r"\b(up|down|left|right|click)\b", re.I)
DEFAULT_API = "https://llmsandy.grok.me/api/quay-agent"
TAPE_LIMIT = 24
STEP_LIMIT = 4

SYSTEM = """The person gave you one task. They will not type another command. You keep moving until that task is finished.
Reply with commands only. Allowed words: up down left right click. A star repeats a move: right*2.
To fill the field under the pointer, reply: type "the words"
Send at most 4 commands. click opens the link in the current cell. click on a submit button sends the form.
If a popup is still listed, click Accept or Close and keep going. Do not stop to ask the person.
If TRANSCRIPT already finishes the task, reply with the single word done.
Otherwise move onto the next useful cell and click it. Do not answer in a sentence."""


class BridgeError(Exception):
    pass


def expand(tape: str) -> list[str]:
    commands: list[str] = []
    for match in TOKEN.finditer(tape):
        word = match.group(1).lower()
        count = int(match.group(2) or "1")
        count = max(1, min(16, count))
        commands.extend([word] * count)
        if len(commands) >= TAPE_LIMIT:
            return commands[:TAPE_LIMIT]
    return commands


def take_commands(text: str, already: int) -> str | None:
    """Pull a legal command string out of a model reply.

    Returns None when the model says it is done, or when nothing legal remains.
    """
    if DONE.search(text) and not MOVE.search(text) and not re.search(r"\btype\b", text, re.I):
        return None
    room = TAPE_LIMIT - already
    if room <= 0:
        return None
    pieces: list[str] = []
    used = 0
    pattern = re.compile(
        r'type\s+"([^"]*)"|type\s+\'([^\']*)\'|(up|down|left|right|click)(?:\*(\d+))?',
        re.I,
    )
    for match in pattern.finditer(text):
        if used >= room or used >= STEP_LIMIT:
            break
        typed = match.group(1) if match.group(1) is not None else match.group(2)
        if typed is not None:
            words = " ".join(typed.split())[:80]
            if not words:
                continue
            pieces.append(f'type "{words}"')
            used += 1
            continue
        word = match.group(3).lower()
        count = int(match.group(4) or "1")
        count = max(1, min(16, count, room - used, STEP_LIMIT - used))
        if count < 1:
            break
        pieces.append(word if count == 1 else f"{word}*{count}")
        used += count
    return " ".join(pieces) if pieces else None


def format_cells(cells: object) -> str:
    if not isinstance(cells, list) or not cells:
        return "(No links, buttons, or fields are on screen.)"
    lines: list[str] = []
    for cell in cells:
        if not isinstance(cell, dict):
            continue
        items = cell.get("items")
        if not isinstance(items, list):
            continue
        rendered = []
        for item in items:
            if not isinstance(item, dict):
                continue
            kind = str(item.get("kind") or "control")
            label = str(item.get("label") or "").replace('"', "'")
            rendered.append(f'{kind} "{label}"')
        if rendered:
            lines.append(f"- column {cell.get('c')}, row {cell.get('r')}: " + "; ".join(rendered))
    return "\n".join(lines) if lines else "(No links, buttons, or fields are on screen.)"


def fetch_state(api: str, url: str, tape: str, timeout: float) -> tuple[int, dict]:
    query = urllib.parse.urlencode({"url": url, "tape": tape})
    request = urllib.request.Request(
        f"{api}?{query}",
        headers={"Accept": "application/json", "User-Agent": "quay-bridge/1.0"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            status = response.status
            body = response.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as err:
        status = err.code
        body = err.read().decode("utf-8", "replace")
    except TimeoutError as err:
        raise BridgeError("The Quay API timed out.") from err
    except urllib.error.URLError as err:
        raise BridgeError(f"Could not reach Quay: {err.reason}") from err
    try:
        data = json.loads(body)
    except json.JSONDecodeError as err:
        raise BridgeError(f"Quay did not return JSON (HTTP {status}).") from err
    if not isinstance(data, dict):
        raise BridgeError("Quay returned JSON that was not an object.")
    return status, data


def prompt_for(goal: str, state: dict) -> str:
    pointer = state.get("pointer") if isinstance(state.get("pointer"), dict) else {}
    transcript = str(state.get("transcript") or "")[:3500]
    return "\n".join(
        [
            f"GOAL {goal}",
            f"PAGE {state.get('url') or '(none)'}",
            f"TITLE {state.get('title') or '(none)'}",
            f"POINTER column {pointer.get('c', 0)}, row {pointer.get('r', 0)}",
            "TRANSCRIPT",
            transcript or "(empty)",
            "CELLS",
            format_cells(state.get("cells")),
        ]
    )


def ask_model(client: object, model: str, goal: str, state: dict) -> str:
    try:
        response = client.chat.completions.create(
            model=model,
            temperature=0,
            max_tokens=40,
            messages=[
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": prompt_for(goal, state)},
            ],
        )
    except Exception as err:
        raise BridgeError(f"The model did not answer: {err}") from err
    choice = response.choices[0].message.content if response.choices else ""
    return choice or ""


def log(step: int, steps: int, tape: str, state: dict) -> None:
    pointer = state.get("pointer") if isinstance(state.get("pointer"), dict) else {}
    transcript = " ".join(str(state.get("transcript") or "").split())
    print(f"\n— step {step}/{steps}")
    print(f"page: {state.get('url') or '(none)'}")
    print(f"title: {state.get('title') or '(none)'}")
    print(f"pointer: {pointer.get('c', 0)},{pointer.get('r', 0)}")
    print(f"tape: {tape or '(empty)'}")
    if state.get("error"):
        print(f"error: {state.get('error')}")
    print(f"writing: {transcript[:500]}")
    print(format_cells(state.get("cells")))


def run(args: argparse.Namespace) -> int:
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        print("Set OPENAI_API_KEY. For Grok, also set OPENAI_BASE_URL=https://api.x.ai/v1 and OPENAI_MODEL=grok-4.5.", file=sys.stderr)
        return 2
    try:
        from openai import OpenAI
    except ImportError:
        print("Install the client first: pip install -r requirements.txt", file=sys.stderr)
        return 2

    base_url = os.environ.get("OPENAI_BASE_URL", "").strip() or None
    model = args.model or os.environ.get("OPENAI_MODEL", "").strip() or "gpt-4o-mini"
    client = OpenAI(api_key=api_key, base_url=base_url, timeout=args.timeout)
    tape = ""
    seen: set[str] = set()

    print(f"Quay: {args.api}")
    print(f"Site: {args.url}")
    print(f"Goal: {args.goal}")
    print(f"Model: {model}")

    for step in range(1, args.steps + 1):
        try:
            status, state = fetch_state(args.api, args.url, tape, args.timeout)
        except BridgeError as err:
            print(f"\nStopped. {err}", file=sys.stderr)
            return 1
        log(step, args.steps, tape, state)
        if status == 400 or str(state.get("error") or "").startswith("That address cannot"):
            print("\nStopped. That address cannot be opened.", file=sys.stderr)
            return 1
        if status >= 400 and not state.get("transcript"):
            print(f"\nStopped. Quay returned HTTP {status}.", file=sys.stderr)
            return 1

        signature = f"{state.get('url')}|{state.get('pointer')}|{str(state.get('transcript') or '')[:240]}"
        if signature in seen:
            print("\nStopped. The page did not change.")
            break
        seen.add(signature)

        try:
            reply = ask_model(client, model, args.goal, state)
        except BridgeError as err:
            print(f"\nStopped. {err}", file=sys.stderr)
            return 1
        print(f"model: {reply.strip() or '(empty)'}")
        nxt = take_commands(reply, len(expand(tape)))
        if not nxt:
            print("\nDone. The model stopped.")
            break
        tape = f"{tape} {nxt}".strip()
        print(f"accepted: {nxt}")
        if len(expand(tape)) >= TAPE_LIMIT:
            print("\nStopped. The tape is full (24 commands).")
            break
    else:
        print("\nStopped. Reached the step limit.")

    try:
        _status, final = fetch_state(args.api, args.url, tape, args.timeout)
    except BridgeError as err:
        print(f"Final read failed: {err}", file=sys.stderr)
        return 1
    print("\nFinal page:", final.get("url") or "(none)")
    print("Final tape:", tape or "(empty)")
    print("Transcript:")
    print(str(final.get("transcript") or "").strip() or "(empty)")
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Let any OpenAI-compatible model drive Quay.")
    parser.add_argument("--url", required=True, help="Public http or https page to open.")
    parser.add_argument("--goal", required=True, help="What the model should find or do.")
    parser.add_argument("--api", default=os.environ.get("QUAY_API", DEFAULT_API), help="Quay agent endpoint.")
    parser.add_argument("--steps", type=int, default=16, help="Safety stop. Default 16, maximum 20.")
    parser.add_argument("--timeout", type=float, default=30, help="Seconds for each API call.")
    parser.add_argument("--model", default="", help="Overrides OPENAI_MODEL.")
    args = parser.parse_args()
    args.steps = max(1, min(20, args.steps))
    args.timeout = max(5, min(60, args.timeout))
    return args


if __name__ == "__main__":
    sys.exit(run(parse_args()))
