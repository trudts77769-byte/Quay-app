import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
//#region node_modules/.nitro/vite/services/ssr/assets/secrets-C8jEd3tJ.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var secrets_exports = /* @__PURE__ */ __exportAll({
	readHfToken: () => readHfToken,
	readSecret: () => readSecret,
	readServerOnly: () => readServerOnly,
	scrubSecrets: () => scrubSecrets
});
var ENV_ONLY = /* @__PURE__ */ new Set([
	"E2B_API_KEY",
	"GEMINI_API_KEY",
	"OPENROUTER_API_KEY",
	"HF_TOKEN"
]);
function readServerOnly(name) {
	if (!ENV_ONLY.has(name)) return "";
	return process.env[name]?.trim() ?? "";
}
function readSecret(name) {
	const fromEnv = process.env[name]?.trim();
	if (fromEnv) return fromEnv;
	if (ENV_ONLY.has(name)) return "";
	const dir = process.env.QUAY_SECRETS_DIR || join(process.cwd(), "secrets");
	const file = join(dir, name);
	if (!existsSync(file)) return "";
	return readFileSync(file, "utf8").trim();
}
function readHfToken() {
	return readServerOnly("HF_TOKEN");
}
function scrubSecrets(text) {
	let out = text;
	for (const name of ENV_ONLY) {
		const value = process.env[name]?.trim();
		if (value && value.length >= 8) out = out.split(value).join("[redacted]");
	}
	return out;
}
//#endregion
export { secrets_exports as i, readSecret as n, scrubSecrets as r, readHfToken as t };
