import { g as toUrl, h as submitPublic, o as documentFromHtml, p as readPublicDocument } from "./read-page-BfummKTD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/agent-CGUX9xtu.js
function emptyAgent() {
	return {
		ok: false,
		error: "",
		url: "",
		title: "",
		transcript: "",
		pointer: {
			c: 0,
			r: 0
		},
		scroll: 0,
		cols: 8,
		rows: 32,
		cells: [],
		shot: "",
		note: ""
	};
}
function agentPath(target) {
	return `/api/quay-agent?${new URLSearchParams({
		url: target,
		format: "text"
	}).toString()}`;
}
function tapeBetween(from, to) {
	const parts = [];
	const dc = to.c - from.c;
	const dr = to.r - from.r;
	if (dr < 0) parts.push(dr === -1 ? "up" : `up*${-dr}`);
	if (dr > 0) parts.push(dr === 1 ? "down" : `down*${dr}`);
	if (dc < 0) parts.push(dc === -1 ? "left" : `left*${-dc}`);
	if (dc > 0) parts.push(dc === 1 ? "right" : `right*${dc}`);
	parts.push("click");
	return parts.join(" ");
}
var AGENT_HAND = [
	"You drive a real browser pointer. The person already asked you to drive it.",
	"Reply with commands only. No sentences, no labels, no markdown, no code fences.",
	"Allowed words: up down left right click. A star repeats: right*3. One star cannot exceed 16. Send at most 16 commands.",
	"The page is 8 columns by 6 rows. Column 0, row 0 is the top-left. The pointer is listed under POINTER.",
	"up, down, left, and right move one cell. On row 0, up scrolls the controls up. On row 5, down scrolls them down. click opens the link in that cell.",
	"Read CELLS. Move onto the cell you need, then click. Do the next useful click only.",
	"A correct reply looks like this: right*2 down click"
].join("\n");
function formatAgent(state) {
	const lines = [
		"You are the bot. Call this same address again with the same url and the whole tape. Commands: up down left right click, and type \"words\". On a choice, type one listed option. At most 24. Do not ask the person for the next command.",
		state.error ? `ERROR ${state.error}` : "OK",
		`PAGE ${state.url || "(none)"}`,
		`TITLE ${state.title || "(none)"}`,
		`POINTER column ${state.pointer.c}, row ${state.pointer.r}`,
		"TRANSCRIPT",
		state.transcript || "(The page has no readable text yet. Open a public site.)",
		"CELLS"
	];
	if (state.cells.length === 0) lines.push("(No links, buttons, or fields are on screen.)");
	else for (const cell of state.cells) {
		const items = cell.items.map((item) => `${item.kind} "${item.label}"`).join("; ");
		lines.push(`- column ${cell.c}, row ${cell.r}: ${items}`);
	}
	if (state.note) lines.push(`NOTE ${state.note}`);
	lines.push("If a HELPER line lists options, type one of those options. Do not stop because the menu was drawn late.", "If TRANSCRIPT finishes the task, stop and answer the person in ordinary sentences. If it does not, send the next tape. The person will not type another command.");
	return lines.join("\n");
}
var TAPE_LIMIT = 24;
var NAG = /(cookie|newsletter|subscribe|sign up|no thanks|not now|accept all|i agree|got it|dismiss|advertisement)/i;
var KEEP = /(help|menu|date|calendar|picker|confirm|required|\?)/i;
function movesFromReply(reply, limit = 4) {
	return readTape(reply, limit).map((step) => step.kind === "type" ? `type "${step.text.replace(/"/g, "")}"` : step.kind === "select" ? `select "${step.text.replace(/"/g, "")}"` : step.command).join(" ");
}
function planFromReply(reply) {
	const marked = reply.match(/(?:^|\n)\s*TAPE\s*:\s*(.+)$/im);
	const tape = marked ? movesFromReply(marked[1], 24) : "";
	const start = reply.search(/(?:^|\n)LINE AI-ONE \/ AI-TWO\s*(?:\n|$)/);
	let packet = "";
	if (start >= 0) {
		const rest = reply.slice(start).replace(/^\n/, "");
		const end = rest.search(/\nNEXT\s+(?:WAIT|REPLY|DONE)\s*(?:\n|$)/);
		packet = end >= 0 ? rest.slice(0, end + (rest.slice(end).match(/\nNEXT\s+(?:WAIT|REPLY|DONE)/)?.[0].length ?? 0)) : "";
	}
	return {
		tape,
		packet: packet.trim()
	};
}
function readTape(raw, limit = TAPE_LIMIT) {
	const steps = [];
	for (const match of raw.matchAll(/select\s+"([^"]*)"|select\s+'([^']*)'|type\s+"([^"]*)"|type\s+'([^']*)'|type:(\S+)|(up|down|left|right|click)(?:\*(\d+))?/gi)) {
		if (steps.length >= limit) break;
		const selected = match[1] ?? match[2];
		if (selected != null) {
			const text = selected.replace(/\+/g, " ").trim().slice(0, 80);
			if (text) steps.push({
				kind: "select",
				text
			});
			continue;
		}
		const typed = match[3] ?? match[4] ?? match[5];
		if (typed != null) {
			const text = typed.replace(/\+/g, " ").trim().slice(0, 80);
			if (text) steps.push({
				kind: "type",
				text
			});
			continue;
		}
		const word = (match[6] ?? "").toLowerCase();
		if (!word) continue;
		let count = Math.min(16, Math.max(1, Number(match[7] || 1)));
		while (count > 0 && steps.length < limit) {
			steps.push({
				kind: "move",
				command: word
			});
			count -= 1;
		}
	}
	return steps;
}
function fail(error, pointer = {
	c: 0,
	r: 0
}, scroll = 0) {
	return {
		...emptyAgent(),
		error,
		pointer,
		scroll
	};
}
function attr(source, name) {
	const match = source.match(new RegExp(`${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s>]+))`, "i"));
	return (match?.[2] ?? match?.[3] ?? match?.[4] ?? "").trim();
}
function innerText(chunk) {
	return chunk.replace(/<[^>]+>/g, " ").replace(/&nbsp;|&#160;/gi, " ").replace(/&/gi, "&").replace(/"|&#34;/gi, "\"").replace(/&#39;|'/gi, "'").replace(/\s+/g, " ").trim().slice(0, 60);
}
function controlsFromHtml(html, base) {
	const cleaned = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<noscript[\s\S]*?<\/noscript>/gi, " ");
	const found = [];
	const push = (label, kind, href, name = "", value = "", caption = "", options = []) => {
		const text = label.replace(/\s+/g, " ").trim().slice(0, kind === "choice" ? 160 : 60);
		if (!text && !href) return;
		if (found.some((item) => item.label === text && item.href === href && item.name === name)) return;
		found.push({
			label: text || kind,
			kind,
			href,
			name,
			value,
			caption,
			options
		});
	};
	const forLabel = (id) => {
		if (!id) return "";
		const match = cleaned.match(new RegExp(`<label\\b[^>]*\\bfor\\s*=\\s*["']${id}["'][^>]*>([\\s\\S]*?)<\\/label>`, "i"));
		return match ? innerText(match[1] ?? "") : "";
	};
	const captionBefore = (index) => {
		const before = cleaned.slice(Math.max(0, index - 600), index);
		const labeled = [...before.matchAll(/<label\b[^>]*>([\s\S]*?)<\/label>/gi)].at(-1);
		const legend = [...before.matchAll(/<legend\b[^>]*>([\s\S]*?)<\/legend>/gi)].at(-1);
		return innerText(labeled?.[1] ?? "") || innerText(legend?.[1] ?? "");
	};
	for (const match of cleaned.matchAll(/<a\b([^>]*?)>([\s\S]*?)<\/a>/gi)) {
		const href = attr(match[1] ?? "", "href");
		if (!href || href.startsWith("#") || /^javascript:/i.test(href)) continue;
		let absolute = "";
		try {
			absolute = toUrl(new URL(href, base).toString()) ?? "";
		} catch {
			absolute = "";
		}
		if (!absolute) continue;
		push(innerText(match[2] ?? "") || attr(match[1] ?? "", "aria-label"), "link", absolute);
	}
	for (const match of cleaned.matchAll(/<label\b[^>]*>([\s\S]*?)<\/label>/gi)) {
		const inner = match[1] ?? "";
		const input = inner.match(/<(input|textarea)\b([^>]*)>/i);
		if (!input) continue;
		const name = attr(input[2] ?? "", "name");
		const type = attr(input[2] ?? "", "type").toLowerCase();
		if (type === "hidden" || type === "radio" || type === "checkbox") continue;
		push(innerText(inner.replace(/<(input|textarea)\b[^>]*>/gi, " ")) || name || "field", type === "submit" ? "submit" : "field", "", name);
	}
	for (const match of cleaned.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/gi)) {
		const label = innerText(match[2] ?? "") || attr(match[1] ?? "", "aria-label") || "button";
		push(label, attr(match[1] ?? "", "type").toLowerCase() === "submit" || /submit|search|send|sign in|log in/i.test(label) ? "submit" : "button", "");
	}
	for (const match of cleaned.matchAll(/<input\b([^>]*)>/gi)) {
		const type = attr(match[1] ?? "", "type").toLowerCase();
		if (type === "hidden" || type === "radio" || type === "checkbox") continue;
		const name = attr(match[1] ?? "", "name");
		if (name && found.some((item) => item.name === name)) continue;
		push(attr(match[1] ?? "", "aria-label") || attr(match[1] ?? "", "placeholder") || name || type || "field", type === "submit" ? "submit" : "field", "", name, attr(match[1] ?? "", "value"));
	}
	for (const match of cleaned.matchAll(/<textarea\b([^>]*)>/gi)) {
		const name = attr(match[1] ?? "", "name");
		if (name && found.some((item) => item.name === name)) continue;
		push(name || "notes", "field", "", name);
	}
	for (const match of cleaned.matchAll(/<select\b([^>]*)>([\s\S]*?)<\/select>/gi)) {
		const attrs = match[1] ?? "";
		const name = attr(attrs, "name");
		const id = attr(attrs, "id");
		const options = [...(match[2] ?? "").matchAll(/<option\b([^>]*)>([\s\S]*?)<\/option>/gi)].map((option) => ({
			label: innerText(option[2] ?? "") || attr(option[1] ?? "", "value"),
			value: attr(option[1] ?? "", "value") || innerText(option[2] ?? "")
		})).filter((option) => option.label && !/^(select|choose|please)\b/i.test(option.label));
		if (options.length === 0) continue;
		const caption = forLabel(id) || attr(attrs, "aria-label") || captionBefore(match.index ?? 0) || name || "choice";
		push(`${caption}: ${options.map((option) => option.label).join(" | ")}`, "choice", "", name, "", caption, options);
	}
	const radios = /* @__PURE__ */ new Map();
	for (const match of cleaned.matchAll(/<label\b[^>]*>([\s\S]*?)<\/label>/gi)) {
		const input = (match[1] ?? "").match(/<input\b([^>]*)>/i);
		if (!input || attr(input[1] ?? "", "type").toLowerCase() !== "radio") continue;
		const name = attr(input[1] ?? "", "name");
		if (!name) continue;
		const label = innerText((match[1] ?? "").replace(/<input\b[^>]*>/gi, " "));
		const value = attr(input[1] ?? "", "value") || label;
		const group = radios.get(name) ?? [];
		group.push({
			label: label || value,
			value,
			index: match.index ?? 0
		});
		radios.set(name, group);
	}
	for (const [name, group] of radios) {
		if (found.some((item) => item.name === name)) continue;
		const caption = captionBefore(group[0]?.index ?? 0) || name || "choice";
		const options = group.filter((option) => option.label);
		if (options.length === 0) continue;
		push(`${caption}: ${options.map((option) => option.label).join(" | ")}`, "choice", "", name, "", caption, options);
	}
	return found.slice(0, 200);
}
function neededForTask(label, task) {
	const job = task.toLowerCase();
	if (!job) return false;
	const text = label.toLowerCase().replace(/\s+/g, " ").trim();
	if (text.length > 2 && job.includes(text.slice(0, 40))) return true;
	return text.split(/[^a-z0-9]+/).filter((word) => word.length > 3 && !/cookie|newsletter|subscribe|accept|dismiss|advertisement|thanks/.test(word)).some((word) => job.includes(word));
}
function clearPopups(controls, enabled, task = "") {
	if (!enabled) return {
		controls,
		note: ""
	};
	const blockers = controls.filter((item) => NAG.test(item.label) && !KEEP.test(item.label) && !neededForTask(item.label, task));
	if (blockers.length === 0 || blockers.length === controls.length) return {
		controls,
		note: ""
	};
	const gone = new Set(blockers);
	return {
		controls: controls.filter((item) => !gone.has(item)),
		note: `Cleared a blocking popup (${blockers[0]?.label ?? "dialog"}) so the page could be used.`
	};
}
function formOf(html, base) {
	const form = html.match(/<form\b([^>]*)>/i);
	if (!form) return {
		action: base,
		method: "get"
	};
	const method = (attr(form[1] ?? "", "method") || "get").toLowerCase() === "post" ? "post" : "get";
	const raw = attr(form[1] ?? "", "action");
	if (!raw) return {
		action: base,
		method
	};
	try {
		return {
			action: toUrl(new URL(raw, base).toString()) ?? base,
			method
		};
	} catch {
		return {
			action: base,
			method
		};
	}
}
function cellsFor(controls, scroll) {
	const start = scroll * 8;
	return controls.slice(start, start + 256).map((control, index) => ({
		c: index % 8,
		r: Math.floor(index / 8),
		items: [{
			label: control.label,
			kind: control.kind
		}]
	}));
}
function maxScroll(count) {
	return Math.max(0, Math.ceil(count / 8) - 32);
}
function addedChoices(html) {
	return [...html.matchAll(/<select\b[\s\S]*?<\/select>/gi)].map((match) => match[0]).join("");
}
async function load(url, tape = "", closePopups = true, task = "") {
	let page = await readPublicDocument(url);
	let shot = "";
	let helper = "";
	if (typeof window === "undefined") try {
		const viewed = await (await import("./live-page-CvwyhLgH.mjs")).renderLive(url, tape);
		if (viewed && viewed.html.length > 80) {
			shot = viewed.shot;
			helper = viewed.helper;
			const rendered = documentFromHtml(url, viewed.html);
			if (page.detail.trim().length < 40 && rendered.detail.trim().length > page.detail.trim().length) page = rendered;
			else if (page.html) page = {
				...page,
				html: `${page.html}${addedChoices(viewed.html)}`
			};
			else page = rendered;
		}
	} catch {}
	if (!page.ok && page.error) return {
		url: page.address,
		title: page.title,
		transcript: page.detail,
		controls: [],
		error: page.error,
		formAction: page.address,
		formMethod: "get",
		popup: "",
		shot,
		helper
	};
	const form = formOf(page.html, page.address);
	const cleared = clearPopups(controlsFromHtml(page.html, page.address), closePopups, task);
	return {
		url: page.address,
		title: page.title,
		transcript: page.links.length ? `${page.detail}\nLINKS\n${page.links.map((link) => `- ${link.text}: ${link.url}`).join("\n")}` : page.detail,
		controls: cleared.controls,
		error: "",
		formAction: form.action,
		formMethod: form.method,
		popup: cleared.note,
		shot,
		helper
	};
}
async function send(loaded, closePopups = true, task = "") {
	const fields = {};
	for (const control of loaded.controls) {
		if (!control.name || !control.value) continue;
		if (control.kind === "field" || control.kind === "submit" || control.kind === "choice") fields[control.name] = control.value;
	}
	const page = await submitPublic(loaded.formAction || loaded.url, loaded.formMethod, fields);
	if (!page.ok && !page.detail) return null;
	const form = formOf(page.html, page.address);
	const cleared = clearPopups(controlsFromHtml(page.html, page.address), closePopups, task);
	return {
		url: page.address,
		title: page.title,
		transcript: page.detail,
		controls: cleared.controls,
		error: page.error,
		formAction: form.action,
		formMethod: form.method,
		popup: cleared.note,
		shot: loaded.shot,
		helper: loaded.helper
	};
}
function view(loaded, pointer, scroll, note) {
	return {
		ok: !loaded.error,
		error: loaded.error,
		url: loaded.url,
		title: loaded.title,
		transcript: loaded.transcript,
		pointer,
		scroll,
		cols: 8,
		rows: 32,
		cells: cellsFor(loaded.controls, scroll),
		shot: loaded.shot,
		note
	};
}
async function runAgent(input) {
	const rawUrl = input.url?.trim() ?? "";
	const tape = input.tape?.trim() ?? "";
	const closePopups = input.closePopups !== false;
	const task = input.task?.trim() ?? "";
	const safe = rawUrl ? toUrl(rawUrl) : null;
	if (rawUrl && !safe) return fail("That address cannot be opened. Use a public http or https site.");
	if (!safe) return fail("Open a public site first.");
	let loaded = await load(safe, tape, closePopups, task);
	if (loaded.error && !loaded.transcript) return fail(loaded.error);
	let pointer = {
		c: Math.min(7, Math.max(0, Math.floor(input.column ?? 0))),
		r: Math.min(31, Math.max(0, Math.floor(input.row ?? 0)))
	};
	let scroll = Math.max(0, Math.floor(input.scroll ?? 0));
	scroll = Math.min(scroll, maxScroll(loaded.controls.length));
	const steps = readTape(tape);
	let moved = false;
	for (const step of steps) {
		moved = true;
		if (step.kind === "type" || step.kind === "select") {
			const index = scroll * 8 + pointer.r * 8 + pointer.c;
			const control = loaded.controls[index];
			if (control?.options.length) {
				const want = step.text.trim().toLowerCase();
				const hit = control.options.find((option) => option.label.toLowerCase() === want || option.value.toLowerCase() === want) ?? control.options.find((option) => option.label.toLowerCase().includes(want) || want.includes(option.label.toLowerCase()));
				const caption = control.caption || "choice";
				if (hit) {
					control.value = hit.value || hit.label;
					control.label = `${caption}: ${hit.label}`.slice(0, 160);
				} else control.label = `${caption}: no match for ${step.text}`.slice(0, 160);
			} else if (control && (control.kind === "field" || control.kind === "submit")) {
				control.value = step.text;
				control.label = `${control.label.replace(/: .*$/, "")}: ${step.text}`.slice(0, 60);
			}
			continue;
		}
		if (step.command === "left") pointer = {
			c: Math.max(0, pointer.c - 1),
			r: pointer.r
		};
		else if (step.command === "right") pointer = {
			c: Math.min(7, pointer.c + 1),
			r: pointer.r
		};
		else if (step.command === "up") {
			if (pointer.r === 0) scroll = Math.max(0, scroll - 1);
			else pointer = {
				c: pointer.c,
				r: pointer.r - 1
			};
		} else if (step.command === "down") {
			if (pointer.r === 31) scroll = Math.min(maxScroll(loaded.controls.length), scroll + 1);
			else pointer = {
				c: pointer.c,
				r: pointer.r + 1
			};
		} else {
			const index = scroll * 8 + pointer.r * 8 + pointer.c;
			const control = loaded.controls[index];
			if (control?.href && control.href !== loaded.url) {
				const next = await load(control.href, "", closePopups, task);
				if (!next.error || next.transcript) {
					loaded = next;
					pointer = {
						c: 0,
						r: 0
					};
					scroll = 0;
				}
			} else if (control && (control.kind === "submit" || control.kind === "button") && !/\b(pay|purchase|buy|checkout)\b/i.test(control.label)) {
				const next = await send(loaded, closePopups, task);
				if (next && (!next.error || next.transcript)) {
					loaded = next;
					pointer = {
						c: 0,
						r: 0
					};
					scroll = 0;
				}
			} else if (!control) loaded.helper = `Clicked column ${pointer.c}, row ${pointer.r}.`;
		}
	}
	const note = [
		loaded.popup,
		loaded.helper,
		`Opened ${loaded.url}`,
		moved ? `Ran ${steps.length} commands` : "",
		`Pointer at ${pointer.c},${pointer.r}`
	].filter(Boolean).join(". ");
	return view(loaded, pointer, scroll, note);
}
//#endregion
export { movesFromReply as a, tapeBetween as c, formatAgent as i, agentPath as n, planFromReply as o, emptyAgent as r, runAgent as s, AGENT_HAND as t };
