import { existsSync } from "node:fs";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
//#region node_modules/.nitro/vite/services/ssr/assets/live-page-CvwyhLgH.js
var scriptPath = fileURLToPath(new URL("../../../scripts/render-page.mjs", import.meta.url));
function renderWithBrowser(url, mode = "page") {
	if (!existsSync(scriptPath)) return Promise.resolve(null);
	return new Promise((resolve) => {
		const args = [scriptPath, url];
		if (mode === "shot") args.push("--shot");
		if (mode === "walk") args.push("--walk");
		const child = spawn(process.execPath, args, { stdio: [
			"ignore",
			"pipe",
			"ignore"
		] });
		const chunks = [];
		child.stdout.on("data", (chunk) => chunks.push(chunk));
		child.on("error", () => resolve(null));
		child.on("close", () => {
			try {
				const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8"));
				if (!parsed.shot && !parsed.html && !parsed.text) {
					resolve(null);
					return;
				}
				resolve(parsed);
			} catch {
				resolve(null);
			}
		});
	});
}
async function capturePage(url) {
	const opened = await renderWithBrowser(url, "shot");
	if (!opened) return null;
	return {
		text: String(opened.html ?? ""),
		shot: String(opened.shot ?? "")
	};
}
async function walkSandbox(url) {
	const opened = await renderWithBrowser(url, "walk");
	if (!opened) return null;
	return {
		text: String(opened.text ?? ""),
		pages: Number(opened.pages ?? 0),
		clicks: Number(opened.clicks ?? 0),
		scrolls: Number(opened.scrolls ?? 0),
		shots: Number(opened.shots ?? 0),
		shot: String(opened.shot ?? "")
	};
}
async function renderLive(url, tape = "") {
	const opened = await renderWithBrowser(url, "page");
	if (!opened) return null;
	let html = String(opened.html ?? "");
	const widgets = Number(opened.widgets ?? 0);
	const optionsCount = Number(opened.options ?? 0);
	const shot = String(opened.shot ?? "");
	if ((html.match(/<option\b/gi) ?? []).length > 0 || optionsCount > 0 || widgets === 0 || !shot) return {
		html,
		shot,
		helper: ""
	};
	const { askMenu } = await import("./menu-help-C6Q5WIbT.mjs");
	const help = await askMenu(shot, tape);
	const options = help.options.map((option) => `<option>${option.replace(/[<>]/g, "")}</option>`).join("");
	if (options) html += `<label>Menu</label><select aria-label="Menu" name="menu">${options}</select>`;
	return {
		html,
		shot,
		helper: `${help.source} OPTIONS: ${help.options.join(" | ") || "(none)"}. TAPE: ${help.tape}`
	};
}
//#endregion
export { capturePage, renderLive, walkSandbox };
