import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { n as readSecret } from "./secrets-C8jEd3tJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/drive-BGo5q8Xk.js
var SYSTEM = [
	"You drive the pointer on Quay.",
	"The user message is the manual plus the live floor. Obey that manual.",
	"Reply with commands only. No sentences, no labels, no markdown.",
	"Allowed tokens: up down left right click. A star repeats: up*4.",
	"At most 16 commands. Never invent any other command."
].join(" ");
var driveMachine_createServerFn_handler = createServerRpc({
	id: "13712969926be4ff339fc5361825426b48db9c78067c8498f109c26a1f37b1bb",
	name: "driveMachine",
	filename: "src/lib/quay/drive.ts"
}, (opts) => driveMachine.__executeServer(opts));
var driveMachine = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Missing brief");
	const brief = input.brief;
	if (typeof brief !== "string" || brief.trim().length < 1 || brief.length > 8e3) throw new Error("Missing brief");
	return { brief };
}).handler(driveMachine_createServerFn_handler, async ({ data }) => {
	const apiKey = readSecret("XAI_API_KEY");
	if (!apiKey) return {
		ok: false,
		commands: "",
		error: "No model is wired into this sandbox. Paste commands from any language model.",
		spent: false
	};
	let response;
	try {
		response = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .2,
				max_tokens: 80,
				messages: [{
					role: "system",
					content: SYSTEM
				}, {
					role: "user",
					content: data.brief
				}]
			})
		});
	} catch {
		return {
			ok: false,
			commands: "",
			error: "The model link did not answer. Try again.",
			spent: true
		};
	}
	if (!response.ok) return {
		ok: false,
		commands: "",
		error: `The model link failed (${response.status}). The tape still works.`,
		spent: true
	};
	const text = (await response.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		commands: "",
		error: "The model returned an empty hand.",
		spent: true
	};
	return {
		ok: true,
		commands: text,
		error: "",
		spent: true
	};
});
//#endregion
export { driveMachine_createServerFn_handler };
