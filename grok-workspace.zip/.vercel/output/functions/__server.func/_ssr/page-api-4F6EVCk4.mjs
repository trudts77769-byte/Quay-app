import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { g as toUrl, p as readPublicDocument } from "./read-page-BfummKTD.mjs";
import { r as scrubSecrets } from "./secrets-C8jEd3tJ.mjs";
import { B as statusBoard, C as openTask, E as postBotText, F as registerMissing, H as taskKind, L as runPlan, N as readTrace, P as readWorking, R as sandboxFailed, S as openChief, T as pinModel, V as taskIdFor, W as updateTask, _ as latestView, c as clearAudit, h as freeModels, i as bindPageTask, j as readLive, k as putStanding, l as clearPin, m as finishTrace, n as beginJobShared, r as beginTrace, s as chiefById, t as absorbAccounts, w as pageTaskId, x as noteTask, z as standingShared } from "./plan-DwQopg9_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-api-4F6EVCk4.js
var jobs = [];
function sweep(now = Date.now()) {
	for (let index = jobs.length - 1; index >= 0; index -= 1) {
		const row = jobs[index];
		if (!row || now - row.at >= row.ttl) jobs.splice(index, 1);
	}
}
function fromVeil(text) {
	return /infoveil|KIND\s+(open|hire|form|approve)/i.test(text);
}
function rememberJob(order, answer, hours) {
	sweep();
	if (hours <= 0) return;
	const ttlHours = Math.min(24, hours);
	if (fromVeil(order) || fromVeil(answer)) return;
	jobs.push({
		at: Date.now(),
		order: order.slice(0, 500),
		answer: answer.slice(0, 2e3),
		ttl: ttlHours * 60 * 60 * 1e3
	});
	if (jobs.length > 40) jobs.splice(0, jobs.length - 40);
}
function recentJobs() {
	sweep();
	return jobs.map((row) => ({
		order: row.order,
		answer: row.answer,
		at: row.at
	}));
}
function urlsIn(text) {
	const found = [];
	for (const match of text.matchAll(/https?:\/\/[^\s<>"']+/gi)) {
		const url = toUrl(match[0].replace(/[),.;]+$/, ""));
		if (url && !found.includes(url)) found.push(url);
	}
	return found;
}
function asRead(page) {
	const detail = page.detail || page.error || "The page had no readable text.";
	return {
		url: page.address,
		title: page.title.slice(0, 180),
		transcript: detail.slice(0, 1800),
		links: page.links.slice(0, 48).map((link) => ({
			text: link.text || link.url,
			url: link.url
		}))
	};
}
function plainAnswer(answer, accepted) {
	if (!accepted) return "";
	return absorbAccounts(scrubSecrets(answer)).replace(/\s+/g, " ").trim().slice(0, 2e3);
}
var readPageBoard_createServerFn_handler = createServerRpc({
	id: "32bc614baf198e95c68f9991fd44352746cfbe1aa34c539f8092f27147e656f8",
	name: "readPageBoard",
	filename: "src/lib/quay/page-api.ts"
}, (opts) => readPageBoard.__executeServer(opts));
var readPageBoard = createServerFn({ method: "GET" }).handler(readPageBoard_createServerFn_handler, async () => {
	const board = statusBoard();
	const view = latestView();
	const live = readLive("page");
	return {
		note: readWorking("page"),
		shot: live?.active ? view.shot : view.shot,
		page: live?.url || view.page,
		crew: view.crew || "page",
		sandbox: live,
		trace: readTrace("page"),
		taskId: pageTaskId(),
		steps: board.steps.slice(-12).map((row) => ({
			id: row.id,
			step: row.step,
			fn: row.fn,
			status: row.status,
			follower: row.follower,
			page: row.page ?? "",
			detail: (row.detail ?? "").slice(0, 240)
		}))
	};
});
var listPageJobs_createServerFn_handler = createServerRpc({
	id: "9e813760b4c091ec07ddd61503e304f0ba93d87450a4bf727b036657cff1ba5b",
	name: "listPageJobs",
	filename: "src/lib/quay/page-api.ts"
}, (opts) => listPageJobs.__executeServer(opts));
var listPageJobs = createServerFn({ method: "GET" }).handler(listPageJobs_createServerFn_handler, async () => recentJobs());
var readPageLink_createServerFn_handler = createServerRpc({
	id: "8804e720cf7be32a3415943a9c21ed317c7af4e1c68ccdf1f986a3aa9ef74dc7",
	name: "readPageLink",
	filename: "src/lib/quay/page-api.ts"
}, (opts) => readPageLink.__executeServer(opts));
var readPageLink = createServerFn({ method: "POST" }).validator((input) => {
	const url = toUrl(typeof input?.url === "string" ? input.url : "");
	if (!url) throw new Error("That address cannot be opened. Use a public http or https site.");
	return { url };
}).handler(readPageLink_createServerFn_handler, async ({ data }) => {
	try {
		const page = await readPublicDocument(data.url);
		if (!page.ok && page.error) throw new Error(page.error);
		return asRead(page);
	} catch (error) {
		const message = error instanceof Error ? scrubSecrets(error.message) : "The page did not open.";
		throw new Error(message || "The page did not open.");
	}
});
var saveSharedSheet_createServerFn_handler = createServerRpc({
	id: "862750e57b38eb25e47dea5e66ece20e8d24a26c58114cf5e47bda3fc6a5dcab",
	name: "saveSharedSheet",
	filename: "src/lib/quay/page-api.ts"
}, (opts) => saveSharedSheet.__executeServer(opts));
var saveSharedSheet = createServerFn({ method: "POST" }).validator((input) => {
	return { text: (typeof input?.text === "string" ? input.text : "").slice(0, 2e5) };
}).handler(saveSharedSheet_createServerFn_handler, async ({ data }) => {
	putStanding(data.text);
	return { ok: true };
});
var readSharedSheet_createServerFn_handler = createServerRpc({
	id: "41e25d16b0842ca273b412ffe15624c472bde6089407822145039c5b528c8f1a",
	name: "readSharedSheet",
	filename: "src/lib/quay/page-api.ts"
}, (opts) => readSharedSheet.__executeServer(opts));
var readSharedSheet = createServerFn({ method: "GET" }).handler(readSharedSheet_createServerFn_handler, async () => {
	return { text: standingShared() };
});
var listFreeModels_createServerFn_handler = createServerRpc({
	id: "61891dda4939c2c8d2c298a7e0045e83b293199a178ccff276b314b74fde7580",
	name: "listFreeModels",
	filename: "src/lib/quay/page-api.ts"
}, (opts) => listFreeModels.__executeServer(opts));
var listFreeModels = createServerFn({ method: "GET" }).handler(listFreeModels_createServerFn_handler, async () => {
	const rows = freeModels();
	registerMissing(rows.map((row) => ({
		id: row.id,
		label: row.label
	})));
	return rows;
});
var runPageJob_createServerFn_handler = createServerRpc({
	id: "05b05e3a9ab008ff17eacc762d16318ac6af1d51de8d699796d07350a230697f",
	name: "runPageJob",
	filename: "src/lib/quay/page-api.ts"
}, (opts) => runPageJob.__executeServer(opts));
var runPageJob = createServerFn({ method: "POST" }).validator((input) => {
	const raw = input ?? {};
	const order = typeof raw.order === "string" ? raw.order.trim().slice(0, 2e3) : "";
	if (order.length < 2) throw new Error("Say the job in plain English.");
	const keep = raw.keep === 24 ? 24 : raw.keep === 0 ? 0 : 1;
	const shared = typeof raw.shared === "string" ? raw.shared.slice(0, 2e5) : "";
	const asked = typeof raw.model === "string" ? raw.model : "";
	const row = freeModels().find((item) => item.id === asked);
	if (asked && !row) throw new Error("That model is not in the repository.");
	if (row?.status === "Key missing") throw new Error("That model has no key.");
	return {
		order,
		keep,
		shared,
		model: row?.id ?? ""
	};
}).handler(runPageJob_createServerFn_handler, async ({ data }) => {
	beginJobShared("page", data.shared);
	const taskId = taskIdFor("page", data.order);
	bindPageTask(taskId);
	openTask({
		task_id: taskId,
		channel_id: "page",
		task: data.order,
		task_type: taskKind(data.order),
		source: "quay"
	});
	noteTask(taskId, "Task created");
	updateTask(taskId, { status: "ACKNOWLEDGED" });
	const chief = openChief("page", data.order);
	const label = freeModels().find((row) => row.id === data.model)?.label ?? "";
	if (data.model) {
		pinModel("page", data.model);
		beginTrace("page", label);
	}
	try {
		const run = await runPlan("page", data.order);
		const state = chiefById("page");
		const crew = typeof state?.crew === "string" && state.crew ? state.crew : chief.crew || "page";
		const blocked = sandboxFailed("page");
		const result = blocked ? "" : plainAnswer(run?.answer || "", Boolean(run?.accepted));
		if (result) {
			rememberJob(data.order, result, data.keep);
			updateTask(taskId, {
				status: "COMPLETED",
				final_result: result,
				lease_expires_at: ""
			});
			noteTask(taskId, "Completed");
		} else {
			updateTask(taskId, {
				status: blocked ? "SANDBOX_FAILED" : "EXHAUSTED",
				error: blocked ? "sandbox was not operated" : "no validated result"
			});
			noteTask(taskId, blocked ? "Sandbox failed" : "Exhausted");
		}
		const report = data.model ? finishTrace("page", Boolean(run?.accepted) && !blocked) : "";
		if (report) postBotText("quay-jobs", `QUAY TEST REPORT: ${label}\n${report}`);
		const reads = [];
		const urls = urlsIn(`${result}\n${(run?.steps ?? []).map((step) => step.text).join("\n")}`).slice(0, 3);
		for (const url of urls) try {
			const page = await readPublicDocument(url);
			if (page.ok || page.detail) reads.push(asRead(page));
		} catch (error) {
			reads.push({
				url,
				title: "Page",
				transcript: error instanceof Error ? scrubSecrets(error.message).slice(0, 300) : "The page did not open.",
				links: []
			});
		}
		return {
			crew,
			result,
			status: 200,
			reads,
			report
		};
	} catch {
		updateTask(taskId, {
			status: "WORKER_FAILED",
			error: "the job stopped"
		});
		noteTask(taskId, "Worker failed");
		const state = chiefById("page");
		const report = data.model ? finishTrace("page", false) : "";
		if (report) postBotText("quay-jobs", `QUAY TEST REPORT: ${label}\n${report}`);
		return {
			crew: state?.crew || "page",
			result: "",
			status: 500,
			reads: [],
			report
		};
	} finally {
		clearPin("page");
		clearAudit("page");
	}
});
//#endregion
export { listFreeModels_createServerFn_handler, listPageJobs_createServerFn_handler, readPageBoard_createServerFn_handler, readPageLink_createServerFn_handler, readSharedSheet_createServerFn_handler, runPageJob_createServerFn_handler, saveSharedSheet_createServerFn_handler };
