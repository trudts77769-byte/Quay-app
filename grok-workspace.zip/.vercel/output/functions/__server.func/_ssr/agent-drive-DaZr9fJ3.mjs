import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { s as runAgent } from "./agent-CGUX9xtu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/agent-drive-DaZr9fJ3.js
var driveAgent_createServerFn_handler = createServerRpc({
	id: "90f0684d0f2415659836acd0114044085c8850286a56f3ed5bd86bb7ff07189b",
	name: "driveAgent",
	filename: "src/lib/quay/agent-drive.ts"
}, (opts) => driveAgent.__executeServer(opts));
var driveAgent = createServerFn({ method: "POST" }).validator((input) => {
	const raw = input ?? {};
	const url = typeof raw.url === "string" ? raw.url.trim().slice(0, 500) : "";
	const tape = typeof raw.tape === "string" ? raw.tape.trim().slice(0, 800) : "";
	const number = (value) => typeof value === "number" && Number.isFinite(value) ? value : 0;
	if (!url && !tape) throw new Error("Say a site or a tape.");
	return {
		url,
		tape,
		column: number(raw.column),
		row: number(raw.row),
		scroll: number(raw.scroll),
		closePopups: raw.closePopups !== false,
		task: typeof raw.task === "string" ? raw.task.slice(0, 500) : ""
	};
}).handler(driveAgent_createServerFn_handler, async ({ data }) => {
	return runAgent(data);
});
//#endregion
export { driveAgent_createServerFn_handler };
