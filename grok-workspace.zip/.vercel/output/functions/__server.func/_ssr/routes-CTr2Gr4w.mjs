import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as createServerFn } from "./ssr.mjs";
import { a as createRack, c as hotspotAt, d as packetFor, f as parseCommands, g as toUrl, i as createMachine, l as hotspots, m as step, n as PROTOCOL, r as briefFor, s as floorCaption, u as isGoogleHome } from "./read-page-BfummKTD.mjs";
import { c as tapeBetween, i as formatAgent, n as agentPath, o as planFromReply, r as emptyAgent, t as AGENT_HAND } from "./agent-CGUX9xtu.mjs";
import { f as deliverChiefPacket, h as freeModels, u as createSsrRpc } from "./plan-DwQopg9_.mjs";
import { _ as ArrowRight, a as Search, b as Archive, c as Radar, d as Globe, f as DoorOpen, g as ArrowUp, h as BookOpen, i as Send, l as Mail, m as CircleCheck, n as Trash2, o as RotateCcw, p as Copy, r as SquareTerminal, s as Reply, u as Lamp, v as ArrowLeft, y as ArrowDown } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CTr2Gr4w.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var driveAgent = createServerFn({ method: "POST" }).validator((input) => {
	const raw = input ?? {};
	const url = typeof raw.url === "string" ? raw.url.trim().slice(0, 500) : "";
	const tape = typeof raw.tape === "string" ? raw.tape.trim().slice(0, 800) : "";
	const number = (value) => typeof value === "number" && Number.isFinite(value) ? value : 0;
	if (!url && !tape) throw new Error("Say a site or a tape.");
	return {
		url,
		tape,
		column: number(raw.column),
		row: number(raw.row),
		scroll: number(raw.scroll),
		closePopups: raw.closePopups !== false,
		task: typeof raw.task === "string" ? raw.task.slice(0, 500) : ""
	};
}).handler(createSsrRpc("90f0684d0f2415659836acd0114044085c8850286a56f3ed5bd86bb7ff07189b"));
[
	"The person gave you one task. They will not type another command. You keep moving until that task is finished.",
	"Reply with commands only: up down left right click. A star repeats: right*2. At most 4 commands.",
	"click opens the link in the current cell.",
	"If TRANSCRIPT already finishes the task, reply with the single word done.",
	"Close only a popup that is not needed for the task. Do not stop to ask the person.",
	"To fill a field, move onto it and reply type \"the words\". Then click the submit button."
].join(" ");
["The pointer already moved. Answer the person in one or two ordinary sentences.", "Use only the transcript. Quote the useful line. Do not reply with only up, down, left, right, or click."].join(" ");
var steerWeb = createServerFn({ method: "POST" }).validator((input) => {
	const raw = input ?? {};
	const url = typeof raw.url === "string" ? raw.url.trim().slice(0, 500) : "";
	const goal = typeof raw.goal === "string" ? raw.goal.trim().slice(0, 400) : "";
	if (!toUrl(url)) throw new Error("That address cannot be opened.");
	if (goal.length < 2) throw new Error("Tell the model what to open.");
	return {
		url,
		goal
	};
}).handler(createSsrRpc("e1403f262ad3bd2c8f72c555aa29555384e00036cee2cb2736ac805a1a13b39d"));
var driveMachine = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Missing brief");
	const brief = input.brief;
	if (typeof brief !== "string" || brief.trim().length < 1 || brief.length > 8e3) throw new Error("Missing brief");
	return { brief };
}).handler(createSsrRpc("13712969926be4ff339fc5361825426b48db9c78067c8498f109c26a1f37b1bb"));
var readPageBoard = createServerFn({ method: "GET" }).handler(createSsrRpc("32bc614baf198e95c68f9991fd44352746cfbe1aa34c539f8092f27147e656f8"));
var listPageJobs = createServerFn({ method: "GET" }).handler(createSsrRpc("9e813760b4c091ec07ddd61503e304f0ba93d87450a4bf727b036657cff1ba5b"));
var readPageLink = createServerFn({ method: "POST" }).validator((input) => {
	const url = toUrl(typeof input?.url === "string" ? input.url : "");
	if (!url) throw new Error("That address cannot be opened. Use a public http or https site.");
	return { url };
}).handler(createSsrRpc("8804e720cf7be32a3415943a9c21ed317c7af4e1c68ccdf1f986a3aa9ef74dc7"));
var saveSharedSheet = createServerFn({ method: "POST" }).validator((input) => {
	return { text: (typeof input?.text === "string" ? input.text : "").slice(0, 2e5) };
}).handler(createSsrRpc("862750e57b38eb25e47dea5e66ece20e8d24a26c58114cf5e47bda3fc6a5dcab"));
var readSharedSheet = createServerFn({ method: "GET" }).handler(createSsrRpc("41e25d16b0842ca273b412ffe15624c472bde6089407822145039c5b528c8f1a"));
var listFreeModels = createServerFn({ method: "GET" }).handler(createSsrRpc("61891dda4939c2c8d2c298a7e0045e83b293199a178ccff276b314b74fde7580"));
var runPageJob = createServerFn({ method: "POST" }).validator((input) => {
	const raw = input ?? {};
	const order = typeof raw.order === "string" ? raw.order.trim().slice(0, 2e3) : "";
	if (order.length < 2) throw new Error("Say the job in plain English.");
	const keep = raw.keep === 24 ? 24 : raw.keep === 0 ? 0 : 1;
	const shared = typeof raw.shared === "string" ? raw.shared.slice(0, 2e5) : "";
	const asked = typeof raw.model === "string" ? raw.model : "";
	const row = freeModels().find((item) => item.id === asked);
	if (asked && !row) throw new Error("That model is not in the repository.");
	if (row?.status === "Key missing") throw new Error("That model has no key.");
	return {
		order,
		keep,
		shared,
		model: row?.id ?? ""
	};
}).handler(createSsrRpc("05b05e3a9ab008ff17eacc762d16318ac6af1d51de8d699796d07350a230697f"));
var rack = createRack();
var useQuay = create()(persist((set, get) => ({
	machines: rack,
	activeId: "web",
	tape: rack[0]?.rehearsal ?? "",
	trace: [],
	seq: 1,
	papers: [],
	setActive: (id) => set({ activeId: id }),
	setTape: (tape) => set({ tape }),
	toggleLink: (id) => set((state) => ({ machines: state.machines.map((machine) => machine.id === id ? {
		...machine,
		attached: !machine.attached
	} : machine) })),
	link: (id) => set((state) => ({ machines: state.machines.map((machine) => machine.id === id ? {
		...machine,
		attached: true
	} : machine) })),
	resetMachine: (id) => set((state) => ({ machines: state.machines.map((machine) => machine.id === id ? createMachine(machine.kind, machine.attached) : machine) })),
	applyTo: (id, command) => {
		const current = get().machines.find((machine) => machine.id === id);
		if (!current) return;
		const result = step(current, command);
		const seq = get().seq + 1;
		set((state) => ({
			seq,
			machines: state.machines.map((machine) => machine.id === id ? result.machine : machine),
			trace: [...state.trace, {
				id: seq,
				text: result.note,
				tone: result.tone
			}].slice(-40)
		}));
	},
	placeCursor: (id, col, row) => {
		const current = get().machines.find((machine) => machine.id === id);
		if (!current) return;
		if (current.cursor.c === col && current.cursor.r === row) return;
		const seq = get().seq + 1;
		set((state) => ({
			seq,
			machines: state.machines.map((machine) => machine.id === id ? {
				...machine,
				cursor: {
					c: col,
					r: row
				}
			} : machine),
			trace: [...state.trace, {
				id: seq,
				text: `Pointer placed at ${col},${row}`,
				tone: "move"
			}].slice(-40)
		}));
	},
	pushTrace: (text, tone) => {
		const seq = get().seq + 1;
		set((state) => ({
			seq,
			trace: [...state.trace, {
				id: seq,
				text,
				tone
			}].slice(-40)
		}));
	},
	savePaper: (paper) => {
		const seq = get().seq + 1;
		set((state) => ({
			seq,
			papers: [{
				...paper,
				id: seq
			}, ...state.papers].slice(0, 8)
		}));
	},
	clearPapers: () => set({ papers: [] }),
	noteReading: (id, url, title, transcript) => set((state) => ({ machines: state.machines.map((machine) => {
		if (machine.id !== id || !machine.web || machine.web.url !== url) return machine;
		return {
			...machine,
			web: {
				...machine.web,
				title,
				transcript: transcript.slice(0, 5e3)
			}
		};
	}) })),
	openAddress: (id, url) => set((state) => ({ machines: state.machines.map((machine) => {
		if (machine.id !== id || !machine.web) return machine;
		let host = url;
		try {
			host = new URL(url).hostname;
		} catch {
			host = url;
		}
		return {
			...machine,
			web: {
				address: host,
				url,
				title: "Page",
				transcript: ""
			}
		};
	}) }))
}), {
	name: "quay-v3",
	skipHydration: true,
	partialize: (state) => ({
		machines: state.machines,
		activeId: state.activeId,
		tape: state.tape,
		trace: state.trace,
		seq: state.seq,
		papers: state.papers
	}),
	merge: (persisted, current) => {
		const saved = persisted;
		return {
			...current,
			...saved,
			papers: Array.isArray(saved.papers) ? saved.papers.slice(0, 8) : []
		};
	}
}));
var GAP = 2;
var DAILY_LOOKS = 8;
var LOOKS_KEY = "quay-looks";
var SAMPLE = "https://selfdefenseartllc.com";
var ICONS = {
	beacon: Lamp,
	terminal: SquareTerminal,
	ledger: BookOpen,
	hatch: DoorOpen,
	probe: Radar,
	status: CircleCheck,
	file: Archive,
	breaker: CircleCheck,
	check: CircleCheck,
	inbox: Mail,
	reply: Reply,
	send: Send,
	trash: Trash2,
	search: Search,
	page: Globe,
	key: Search,
	del: RotateCcw
};
function todayKey() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function readLooks() {
	try {
		const raw = localStorage.getItem(LOOKS_KEY);
		if (!raw) return DAILY_LOOKS;
		const parsed = JSON.parse(raw);
		if (parsed.day !== todayKey() || typeof parsed.left !== "number") return DAILY_LOOKS;
		return Math.max(0, Math.min(DAILY_LOOKS, parsed.left));
	} catch {
		return DAILY_LOOKS;
	}
}
function writeLooks(left) {
	localStorage.setItem(LOOKS_KEY, JSON.stringify({
		day: todayKey(),
		left
	}));
}
function plain(value) {
	let current = value;
	for (let pass = 0; pass < 3; pass += 1) {
		const next = current.replace(/\u0026nbsp;/gi, " ").replace(/\u0026quot;/gi, "\"").replace(/&#0*34;/g, "\"").replace(/\u0026apos;/gi, "'").replace(/&#0*39;/g, "'").replace(/\u0026amp;/gi, "&");
		if (next === current) return current;
		current = next;
	}
	return current;
}
function toneClass(tone, active) {
	if (active) return "border-brass text-brass bg-raised";
	if (tone === "live" || tone === "done") return "border-brass/70 text-brass bg-surface";
	if (tone === "locked") return "border-line text-muted bg-bg";
	return "border-line text-fg bg-surface";
}
function QuayApp() {
	const machines = useQuay((state) => state.machines);
	const activeId = useQuay((state) => state.activeId);
	const tape = useQuay((state) => state.tape);
	const trace = useQuay((state) => state.trace);
	const setActive = useQuay((state) => state.setActive);
	const setTape = useQuay((state) => state.setTape);
	const toggleLink = useQuay((state) => state.toggleLink);
	const link = useQuay((state) => state.link);
	const resetMachine = useQuay((state) => state.resetMachine);
	const applyTo = useQuay((state) => state.applyTo);
	const placeCursor = useQuay((state) => state.placeCursor);
	const pushTrace = useQuay((state) => state.pushTrace);
	const papers = useQuay((state) => state.papers);
	const savePaper = useQuay((state) => state.savePaper);
	const clearPapers = useQuay((state) => state.clearPapers);
	const noteReading = useQuay((state) => state.noteReading);
	const openAddress = useQuay((state) => state.openAddress);
	const machine = machines.find((item) => item.id === activeId) ?? machines[0];
	const [ready, setReady] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [asking, setAsking] = (0, import_react.useState)(false);
	const [looks, setLooks] = (0, import_react.useState)(DAILY_LOOKS);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [looked, setLooked] = (0, import_react.useState)(false);
	const [task, setTask] = (0, import_react.useState)("What does selfdefenseartllc.com offer, and how do I reach them?");
	const [gathering, setGathering] = (0, import_react.useState)(false);
	const [openPaper, setOpenPaper] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("selfdefenseartllc.com");
	const [agentHref, setAgentHref] = (0, import_react.useState)(agentPath(SAMPLE));
	const [botHref, setBotHref] = (0, import_react.useState)("/api/bot");
	const [modelReply, setModelReply] = (0, import_react.useState)("");
	const [modelResult, setModelResult] = (0, import_react.useState)("");
	const [glass, setGlass] = (0, import_react.useState)(null);
	const [driving, setDriving] = (0, import_react.useState)(false);
	const [jobOrder, setJobOrder] = (0, import_react.useState)("What does selfdefenseartllc.com offer, and how do I reach them?");
	const [shared, setShared] = (0, import_react.useState)("");
	const sharedDirty = (0, import_react.useRef)(false);
	const [jobRunning, setJobRunning] = (0, import_react.useState)(false);
	const [jobSteps, setJobSteps] = (0, import_react.useState)([]);
	const [taskTrace, setTaskTrace] = (0, import_react.useState)([]);
	const [taskId, setTaskId] = (0, import_react.useState)("");
	const [jobResult, setJobResult] = (0, import_react.useState)("");
	const [jobCrew, setJobCrew] = (0, import_react.useState)("");
	const [jobNote, setJobNote] = (0, import_react.useState)("");
	const [jobLinks, setJobLinks] = (0, import_react.useState)({});
	const [showGrid, setShowGrid] = (0, import_react.useState)(true);
	const [closePopups, setClosePopups] = (0, import_react.useState)(true);
	const [jobKeep, setJobKeep] = (0, import_react.useState)(1);
	const [command, setCommand] = (0, import_react.useState)("");
	const [recent, setRecent] = (0, import_react.useState)([]);
	const [copiedAnswer, setCopiedAnswer] = (0, import_react.useState)(false);
	const [single, setSingle] = (0, import_react.useState)(false);
	const [models, setModels] = (0, import_react.useState)([]);
	const [model, setModel] = (0, import_react.useState)("");
	const [report, setReport] = (0, import_react.useState)("");
	const [sandboxLive, setSandboxLive] = (0, import_react.useState)(null);
	const [copiedReport, setCopiedReport] = (0, import_react.useState)(false);
	const jobRunningRef = (0, import_react.useRef)(false);
	const openUrl = machine?.web?.url ?? "";
	const seenPages = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const playing = (0, import_react.useRef)(false);
	const queue = (0, import_react.useRef)([]);
	const timer = (0, import_react.useRef)(null);
	const activeRef = (0, import_react.useRef)(activeId);
	activeRef.current = machine?.id ?? activeId;
	(0, import_react.useEffect)(() => {
		let cancel = false;
		Promise.resolve(useQuay.persist.rehydrate()).then(() => {
			if (cancel) return;
			setLooks(readLooks());
			setReady(true);
		});
		return () => {
			cancel = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		readSharedSheet().then((row) => {
			if (cancel || sharedDirty.current) return;
			if (row?.text) setShared(row.text);
		}).catch(() => {});
		return () => {
			cancel = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!sharedDirty.current) return;
		const timer = window.setTimeout(() => {
			saveSharedSheet({ data: { text: shared } }).catch(() => {});
		}, 400);
		return () => window.clearTimeout(timer);
	}, [shared]);
	(0, import_react.useEffect)(() => {
		const target = openUrl && !isGoogleHome(openUrl) ? openUrl : SAMPLE;
		const origin = window.location.origin;
		setAgentHref(`${origin}${agentPath(target)}`);
		setBotHref(`${origin}/api/bot`);
	}, [openUrl]);
	const stop = () => {
		queue.current = [];
		playing.current = false;
		setBusy(false);
		if (timer.current !== null) window.clearTimeout(timer.current);
	};
	(0, import_react.useEffect)(() => {
		queue.current = [];
		playing.current = false;
		setBusy(false);
		return () => {
			queue.current = [];
			playing.current = false;
			if (timer.current !== null) window.clearTimeout(timer.current);
		};
	}, [activeId]);
	const pump = (0, import_react.useRef)(() => {});
	pump.current = () => {
		const command = queue.current.shift();
		if (!command) {
			playing.current = false;
			setBusy(false);
			return;
		}
		applyTo(activeRef.current, command);
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		timer.current = window.setTimeout(() => pump.current(), reduce ? 0 : 120);
	};
	const play = (commands) => {
		if (commands.length === 0) return;
		queue.current.push(...commands);
		if (playing.current) return;
		playing.current = true;
		setBusy(true);
		pump.current();
	};
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target instanceof HTMLTextAreaElement || target instanceof HTMLInputElement) return;
			if (playing.current) return;
			const command = {
				ArrowUp: "up",
				ArrowDown: "down",
				ArrowLeft: "left",
				ArrowRight: "right"
			}[event.key];
			if (command) {
				event.preventDefault();
				applyTo(activeRef.current, command);
				return;
			}
			if (event.key === "Enter" && !(target instanceof HTMLButtonElement)) {
				event.preventDefault();
				applyTo(activeRef.current, "click");
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [applyTo]);
	const pullRef = (0, import_react.useRef)(async () => {});
	jobRunningRef.current = jobRunning;
	(0, import_react.useEffect)(() => {
		if (!jobRunning) return;
		const timer = window.setInterval(() => void pullRef.current(), 1e3);
		return () => window.clearInterval(timer);
	}, [jobRunning]);
	(0, import_react.useEffect)(() => {
		listPageJobs().then(setRecent).catch(() => void 0);
		listFreeModels().then((rows) => {
			const list = Array.isArray(rows) ? rows : [];
			setModels(list);
			setModel((current) => current || list.find((item) => item.status !== "Key missing")?.id || "");
		}).catch(() => void 0);
	}, []);
	if (!machine) return null;
	const spots = hotspots(machine);
	const under = hotspotAt(machine, machine.cursor.c, machine.cursor.r);
	const captions = floorCaption(machine);
	const publish = (id, result) => {
		setJobLinks({});
		setGlass(result);
		if (result.url && toUrl(result.url)) {
			openAddress(id, result.url);
			noteReading(id, result.url, result.title || "Page", result.transcript);
		}
		pushTrace(result.error || result.note || `Pointer at ${result.pointer.c},${result.pointer.r}`, result.error ? "warn" : "model");
	};
	const runWeb = async (script, url = "") => {
		if (driving) return;
		const fresh = Boolean(url);
		const open = url || glass?.url || "";
		if (!open) {
			pushTrace("Open a public site first.", "warn");
			return;
		}
		setDriving(true);
		const id = machine.id;
		try {
			const result = await driveAgent({ data: {
				url: open,
				tape: script,
				column: fresh ? 0 : glass?.pointer.c ?? 0,
				row: fresh ? 0 : glass?.pointer.r ?? 0,
				scroll: fresh ? 0 : glass?.scroll ?? 0,
				closePopups,
				task: jobOrder
			} });
			publish(id, result);
		} catch {
			pushTrace("The browser did not answer. Try Open again.", "warn");
		} finally {
			setDriving(false);
		}
	};
	const openTyped = () => {
		const url = toUrl(draft);
		if (!url) {
			pushTrace("That address cannot be opened. Use a public site.", "warn");
			return;
		}
		runWeb("", url);
	};
	const runModelReply = async () => {
		const plan = planFromReply(modelReply);
		if (!plan.tape && !plan.packet) {
			setModelResult("No TAPE line. The model must write one line like: TAPE: right click");
			return;
		}
		const open = glass?.url || toUrl(draft) || "";
		if (plan.tape && !open) {
			setModelResult("Open a public site first, then paste the model's reply.");
			return;
		}
		let page = glass;
		if (plan.tape && open) {
			setDriving(true);
			try {
				page = await driveAgent({ data: {
					url: open,
					tape: plan.tape,
					column: glass?.pointer.c ?? 0,
					row: glass?.pointer.r ?? 0,
					scroll: glass?.scroll ?? 0,
					closePopups,
					task: jobOrder
				} });
				publish(machine.id, page);
				setTape(plan.tape);
			} catch {
				setModelResult("The sandbox did not run that tape.");
				setDriving(false);
				return;
			}
			setDriving(false);
		}
		let veil = "";
		if (plan.packet) try {
			veil = await deliverChiefPacket({ data: { packet: plan.packet } });
		} catch {
			veil = "Veil did not take that packet.";
		}
		setModelResult([
			"RESULT",
			page ? formatAgent(page) : "(The pointer did not move.)",
			veil ? `VEIL\n${veil}` : "",
			"Do not ask the person for another copy."
		].filter(Boolean).join("\n"));
	};
	const runTape = () => {
		const parsed = parseCommands(tape, machine.kind === "web" ? 24 : 200);
		if (parsed.skipped.length) pushTrace(`Skipped ${parsed.skipped.slice(0, 4).join(", ")}`, "warn");
		if (parsed.commands.length === 0) {
			pushTrace("No controls in the tape. Use up, down, left, right, click.", "warn");
			return;
		}
		if (machine.kind === "web") {
			runWeb(tape);
			return;
		}
		play(parsed.commands);
	};
	const stepOnce = () => {
		if (playing.current || driving) return;
		const parsed = parseCommands(tape);
		if (parsed.commands.length === 0) {
			pushTrace("The tape has no controls to step.", "warn");
			return;
		}
		if (machine.kind === "web") {
			runWeb(parsed.commands[0]);
			setTape(parsed.commands.slice(1).join(" "));
			return;
		}
		applyTo(machine.id, parsed.commands[0]);
		setTape(parsed.commands.slice(1).join(" "));
	};
	const rehearse = () => {
		if (machine.kind === "web") {
			setDraft("selfdefenseartllc.com");
			runWeb("", "https://selfdefenseartllc.com");
			return;
		}
		stop();
		resetMachine(machine.id);
		setTape(machine.rehearsal);
		const parsed = parseCommands(machine.rehearsal, 240);
		window.setTimeout(() => play(parsed.commands), 40);
	};
	const ask = async () => {
		if (asking || playing.current) return;
		if (looks <= 0) {
			pushTrace("No model looks left today. The tape still takes any model's words.", "warn");
			return;
		}
		link(machine.id);
		setAsking(true);
		try {
			const result = await driveMachine({ data: { brief: machine.kind === "web" ? `${AGENT_HAND}\n\n${formatAgent(glass ?? emptyAgent())}` : briefFor(machine) } });
			if (!result.ok) {
				if (result.spent) {
					const left = Math.max(0, looks - 1);
					setLooks(left);
					writeLooks(left);
				}
				pushTrace(result.error, "warn");
				return;
			}
			const left = Math.max(0, looks - 1);
			setLooks(left);
			writeLooks(left);
			setLooked(true);
			setTape(result.commands);
			pushTrace(`Model → ${result.commands}`, "model");
			const parsed = parseCommands(result.commands);
			if (parsed.commands.length === 0) {
				pushTrace("That reply had no up, down, left, right, or click.", "warn");
				return;
			}
			if (parsed.skipped.length) pushTrace(`Ignored extra words: ${parsed.skipped.slice(0, 3).join(", ")}`, "warn");
			if (machine.kind === "web") {
				await runWeb(parsed.commands.join(" "));
				return;
			}
			play(parsed.commands);
		} catch {
			pushTrace("The model link did not answer. Try again, or paste a hand into the tape.", "warn");
		} finally {
			setAsking(false);
		}
	};
	const gather = async () => {
		if (gathering || asking) return;
		const job = task.trim();
		const url = toUrl(draft) || toUrl(glass?.url || "") || toUrl(machine.web?.address || "");
		if (!url) {
			pushTrace("Type a public site, then let the model drive the pointer.", "warn");
			return;
		}
		if (job.length < 2) {
			pushTrace("Tell the model what to find.", "warn");
			return;
		}
		if (looks <= 0) {
			pushTrace("No model looks left today.", "warn");
			return;
		}
		setGathering(true);
		try {
			const result = await steerWeb({ data: {
				url,
				goal: job
			} });
			if (result.spent) {
				const left = Math.max(0, looks - 1);
				setLooks(left);
				writeLooks(left);
			}
			if (!result.ok) {
				pushTrace(result.error, "warn");
				return;
			}
			publish(machine.id, result.state);
			setTape(result.tape);
			savePaper({
				task: job,
				text: `${result.answer}\n\nThe pointer ran: ${result.tape}`,
				sources: result.state.url ? [result.state.url] : []
			});
			setOpenPaper(null);
			pushTrace(`Pointer ran ${result.tape}`, "model");
		} catch {
			pushTrace("The model did not get back from the web. Try again.", "warn");
		} finally {
			setGathering(false);
		}
	};
	const showRead = (page) => {
		const links = page.links.slice(0, 48);
		const cells = links.map((link, index) => ({
			c: index % 8,
			r: Math.floor(index / 8),
			items: [{
				label: link.text,
				kind: "link"
			}]
		}));
		const map = {};
		links.forEach((link, index) => {
			map[`${index % 8},${Math.floor(index / 8)}`] = link.url;
		});
		setJobLinks(map);
		setGlass((current) => ({
			...current ?? emptyAgent(),
			ok: true,
			error: "",
			url: page.url,
			title: page.title,
			transcript: page.transcript,
			cells,
			note: ""
		}));
		if (page.url) {
			openAddress(activeRef.current, page.url);
			noteReading(activeRef.current, page.url, page.title || "Page", page.transcript);
		}
	};
	const openRead = async (url) => {
		try {
			const page = await readPageLink({ data: { url } });
			showRead(page);
		} catch (error) {
			pushTrace(error instanceof Error ? error.message : "That page did not open.", "warn");
		}
	};
	const pullBoard = async () => {
		const board = await readPageBoard();
		setSandboxLive(board.sandbox);
		setTaskTrace(board.trace ?? []);
		setTaskId(board.taskId ?? "");
		if (board.shot) setGlass((current) => ({
			...current ?? emptyAgent(),
			ok: true,
			error: "",
			shot: board.shot,
			url: board.page || current?.url || ""
		}));
		if (board.note && jobRunningRef.current) setJobResult(board.note);
		setJobSteps(board.steps.filter((step) => step.fn && step.fn !== "job"));
		const fresh = board.steps.map((step) => step.page).find((page) => page.startsWith("http") && !seenPages.current.has(page));
		if (!fresh) return;
		seenPages.current.add(fresh);
		try {
			showRead(await readPageLink({ data: { url: fresh } }));
		} catch {}
	};
	pullRef.current = pullBoard;
	const startJob = async () => {
		const order = jobOrder.trim();
		if (order.length < 2 || jobRunning) return;
		if (single && !model) return;
		setJobRunning(true);
		setJobResult("Working");
		setJobNote("");
		setJobCrew("");
		setReport("");
		seenPages.current.clear();
		try {
			const run = await runPageJob({ data: {
				order,
				keep: jobKeep,
				shared,
				model: single ? model : ""
			} });
			const crew = typeof run?.crew === "string" ? run.crew : "";
			const result = typeof run?.result === "string" ? run.result : "";
			const reads = Array.isArray(run?.reads) ? run.reads : [];
			setJobCrew(crew);
			setJobResult(result);
			setReport(typeof run?.report === "string" ? run.report : "");
			if (run?.status === 401 || run?.status === 503) setJobNote(result);
			if (reads[0]) showRead(reads[0]);
			for (const page of reads) seenPages.current.add(page.url);
			savePaper({
				task: order,
				text: result,
				sources: reads.map((page) => page.url)
			});
			await pullRef.current();
			setRecent(await listPageJobs());
		} catch (error) {
			setJobNote(error instanceof Error ? error.message : "The job did not start.");
		} finally {
			setJobRunning(false);
		}
	};
	const copyBrief = async () => {
		const notes = papers.map((paper) => `TASK ${paper.task}\n${paper.text}\n${paper.sources.join("\n")}`).join("\n\n");
		const body = machine.kind === "web" ? `${PROTOCOL}\n\n${formatAgent(glass ?? emptyAgent())}\n\nAGENT ${agentHref}` : packetFor(machine);
		const text = notes ? `${body}\n\nFILED NOTES\n${notes}` : body;
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			pushTrace("Could not copy the brief from this browser. The reader link is still on the page.", "warn");
		}
	};
	const aim = (col, row) => {
		if (playing.current) return;
		const spot = hotspotAt(machine, col, row);
		if (!(machine.cursor.c === col && machine.cursor.r === row)) placeCursor(machine.id, col, row);
		if (spot) applyTo(machine.id, "click");
	};
	const nudge = (command) => {
		if (playing.current) return;
		applyTo(machine.id, command);
	};
	const append = (word) => setTape(tape.trim() ? `${tape.trim()} ${word}` : word);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full min-w-0 max-w-[100vw] flex-col gap-3 overflow-x-hidden px-3 py-3 box-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid w-full min-w-0 max-w-full items-start gap-3 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full min-w-0 max-w-full flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-label": "Prompt",
							className: "w-full min-w-0 max-w-full",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs tracking-wide text-muted uppercase",
									children: "Prompt"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									"data-testid": "job-order",
									value: jobOrder,
									onChange: (event) => setJobOrder(event.target.value),
									"aria-label": "Prompt",
									spellCheck: true,
									className: "mt-2 min-h-28 w-full max-w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none focus-visible:border-brass"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex w-full min-w-0 max-w-full flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"data-testid": "job-run",
										className: "tap min-h-11 rounded-2xl bg-brass px-4 text-sm text-ink disabled:opacity-40",
										onClick: () => void startJob(),
										disabled: jobRunning || jobOrder.trim().length < 2 || single && (!model || models.find((item) => item.id === model)?.status === "Key missing"),
										children: jobRunning ? "Running…" : "Run"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex min-h-11 items-center gap-2 text-sm text-fg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											"data-testid": "single-model",
											checked: single,
											onChange: (event) => setSingle(event.target.checked)
										}), "Single Model Test"]
									})]
								}),
								single ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									"data-testid": "model-pick",
									"aria-label": "Model",
									value: model,
									onChange: (event) => setModel(event.target.value),
									className: "mt-2 min-h-11 w-full max-w-full rounded-2xl border border-line bg-bg px-3 text-sm text-fg",
									children: (() => {
										const groups = [];
										for (const item of models) if (!groups.includes(item.group)) groups.push(item.group);
										const dull = (status) => status === "Key missing" || status === "Quota hit" || status === "Failed";
										return groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
											label: group,
											children: models.filter((item) => item.group === group).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: item.id,
												disabled: item.status === "Key missing",
												style: dull(item.status) ? { color: "#8d887c" } : void 0,
												children: [
													item.label,
													" · ",
													item.status
												]
											}, item.id))
										}, group));
									})()
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-label": "Shared instructions",
							className: "w-full min-w-0 max-w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-wide text-muted uppercase",
								children: "Shared instructions"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								"data-testid": "shared-instructions",
								value: shared,
								onChange: (event) => {
									sharedDirty.current = true;
									setShared(event.target.value);
								},
								"aria-label": "Shared instructions",
								spellCheck: true,
								placeholder: "Links and instructions for every follower. Not sent on Veil.",
								className: "mt-2 min-h-28 w-full max-w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none focus-visible:border-brass"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-label": "Results",
							className: "w-full min-w-0 max-w-full",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs tracking-wide text-muted uppercase",
										children: "Results"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "tap min-h-11 rounded-2xl border border-line px-3 text-xs text-fg",
										onClick: () => {
											const text = jobResult;
											const done = () => {
												setCopiedAnswer(true);
												window.setTimeout(() => setCopiedAnswer(false), 1200);
											};
											const fallback = () => {
												const area = document.createElement("textarea");
												area.value = text;
												area.setAttribute("readonly", "");
												area.style.position = "fixed";
												area.style.left = "-9999px";
												document.body.appendChild(area);
												area.select();
												try {
													document.execCommand("copy");
												} catch {}
												area.remove();
												done();
											};
											if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(done).catch(fallback);
											else fallback();
										},
										children: copiedAnswer ? "Copied" : "Copy"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									"data-testid": "job-result",
									className: "wrap-any mt-2 min-h-16 w-full max-w-full whitespace-pre-wrap text-sm leading-6 text-fg",
									children: jobResult
								}),
								report ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 w-full min-w-0 max-w-full",
									"data-testid": "test-report",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-wide text-muted uppercase",
											children: "Test report"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "tap min-h-11 rounded-2xl border border-line px-3 text-xs text-fg",
											onClick: () => {
												const text = report;
												const done = () => {
													setCopiedReport(true);
													window.setTimeout(() => setCopiedReport(false), 1200);
												};
												const fallback = () => {
													const area = document.createElement("textarea");
													area.value = text;
													area.setAttribute("readonly", "");
													area.style.position = "fixed";
													area.style.left = "-9999px";
													document.body.appendChild(area);
													area.select();
													try {
														document.execCommand("copy");
													} catch {}
													area.remove();
													done();
												};
												if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(done).catch(fallback);
												else fallback();
											},
											children: copiedReport ? "Copied" : "Copy"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
										className: "wrap-any mt-2 whitespace-pre-wrap text-sm leading-6 text-fg",
										children: report
									})]
								}) : null,
								jobNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-brass",
									children: jobNote
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "mt-3 flex w-full min-w-0 max-w-full flex-col gap-1",
									"data-testid": "job-monitor",
									"aria-live": "polite",
									children: jobSteps.slice(-6).map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "wrap-any text-xs text-muted",
										children: [
											step.step,
											" ",
											step.fn,
											" · ",
											step.follower || "waiting",
											" · ",
											step.status,
											step.page ? ` · ${step.page}` : ""
										]
									}, step.id || `${step.step}-${step.fn}`))
								}),
								taskTrace.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									"data-testid": "task-trace",
									className: "mt-2 flex w-full min-w-0 max-w-full flex-col gap-1",
									children: taskTrace.slice(-8).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "wrap-any text-xs text-muted",
										children: line
									}, line))
								}) : null
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full min-w-0 max-w-full flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-label": "Sandbox",
							className: "w-full min-w-0 max-w-full overflow-hidden rounded-card border border-line bg-bg",
							children: [
								machine.kind === "web" && machine.web ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowserPane, {
									url: glass?.url || machine.web.url,
									typed: machine.web.address,
									draft,
									ready,
									driving,
									shot: "",
									page: false,
									onDraft: setDraft,
									onOpen: openTyped
								}) : null,
								sandboxLive?.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									"data-testid": "sandbox-active",
									className: "border-b border-line px-3 py-2 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-wide text-brass uppercase",
											children: "Sandbox active"
										}),
										taskId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "wrap-any",
											children: ["Task: ", taskId]
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "wrap-any",
											children: ["Follower: ", sandboxLive.follower || "…"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "wrap-any",
											children: ["Step: ", sandboxLive.step]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "wrap-any",
											children: ["Action: ", sandboxLive.action || "…"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Interactive actions: ", sandboxLive.actions] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "wrap-any text-xs text-brass",
											children: sandboxLive.url
										}),
										sandboxLive.typing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "wrap-any",
											children: ["Typing in: ", sandboxLive.typing]
										}) : null,
										sandboxLive.scrolling ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: sandboxLive.scrolling }) : null
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative aspect-[3/4] w-full max-w-full",
									children: [
										glass?.shot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: `data:image/jpeg;base64,${glass.shot}`,
											alt: "The page the pointer is on",
											className: "absolute inset-0 h-full w-full object-contain object-top"
										}) : null,
										sandboxLive?.active && sandboxLive.action.startsWith("CLICK") && sandboxLive.clickX > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"data-testid": "sandbox-click",
											className: "pointer-events-none absolute z-10 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-brass bg-brass/50",
											style: {
												left: `${sandboxLive.clickX}%`,
												top: `${sandboxLive.clickY}%`
											}
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute inset-0 grid",
											style: {
												gridTemplateColumns: "repeat(8, minmax(0, 1fr))",
												gridTemplateRows: "repeat(32, minmax(0, 1fr))",
												gap: 0,
												display: showGrid ? "grid" : "none"
											},
											children: Array.from({ length: 256 }, (_, index) => {
												const col = index % 8;
												const row = Math.floor(index / 8);
												const active = (glass?.pointer.c ?? 0) === col && (glass?.pointer.r ?? 0) === row;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-label": `Column ${col}, row ${row}`,
													className: "relative min-h-0 min-w-0 border border-white/25 bg-transparent p-0",
													onClick: () => {
														const href = jobLinks[`${col},${row}`];
														if (href) {
															openRead(href);
															return;
														}
														const from = glass?.pointer ?? {
															c: 0,
															r: 0
														};
														runWeb(tapeBetween(from, {
															c: col,
															r: row
														}));
													},
													children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brass ring-2 ring-black/40" }) : null
												}, `${col}-${row}`);
											})
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
							onSubmit: (event) => {
								event.preventDefault();
								if (command.trim()) runWeb(command.trim());
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								"aria-label": "Commands",
								value: command,
								onChange: (event) => setCommand(event.target.value),
								spellCheck: false,
								placeholder: "up down left right click select type",
								className: "min-h-11 w-full max-w-full rounded-2xl border border-line bg-bg px-3 text-sm text-fg outline-none focus-visible:border-brass"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1",
							children: [
								"up",
								"down",
								"left",
								"right",
								"click",
								"select",
								"type"
							].map((word) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "tap min-h-11 rounded-2xl border border-line bg-surface px-3 text-xs text-fg",
								onClick: () => setCommand((value) => `${value.trim()} ${word}`.trim()),
								children: word
							}, word))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							"aria-label": "Keyboard",
							className: "flex w-full min-w-0 max-w-full flex-col items-stretch gap-1",
							children: [[
								"qwertyuiop",
								"asdfghjkl",
								"zxcvbnm"
							].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid w-full max-w-full gap-1",
								style: { gridTemplateColumns: `repeat(${row.length}, minmax(0, 1fr))` },
								children: [...row].map((letter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "tap h-11 min-w-0 rounded-xl border border-line bg-surface px-0 text-sm text-fg",
									onClick: () => setCommand((value) => `${value}${letter}`),
									children: letter
								}, letter))
							}, row)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid w-full max-w-full grid-cols-[minmax(0,1fr)_auto] gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "tap min-h-11 rounded-xl border border-line bg-surface px-6 text-sm text-fg",
									onClick: () => setCommand((value) => `${value} `),
									children: "space"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "tap min-h-11 rounded-xl border border-line bg-surface px-3 text-sm text-fg",
									onClick: () => setCommand((value) => value.slice(0, -1)),
									children: "delete"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
							onCommand: (word) => {
								runWeb(word);
							},
							disabled: driving
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "w-full min-w-0 max-w-full overflow-x-hidden rounded-card border border-line bg-surface px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "min-h-11 cursor-pointer text-sm text-fg",
						children: "Rules and API"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "mt-4 flex flex-wrap items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl leading-none text-fg sm:text-5xl",
							children: "Quay"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-2 h-px w-16 bg-brass" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/docs",
								className: "tap inline-flex min-h-11 items-center rounded-card border border-line bg-surface px-4 text-sm text-fg",
								children: "Docs"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "tap min-h-11 rounded-card border border-line bg-surface px-4 text-sm text-fg",
								onClick: () => {
									const opening = !machine.attached;
									toggleLink(machine.id);
									pushTrace(opening ? `Link open on ${machine.name}. A model may drive this pointer.` : `Link closed on ${machine.name}.`, "model");
								},
								children: machine.attached ? "Link open" : "Open a link"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-card border border-brass/50 bg-surface px-4 py-3",
						"aria-label": "Legacy bot tape",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-wide text-brass uppercase",
								children: "Legacy · /api/bot tape"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Legacy. AIs submit a QUAY JOB on Veil. Humans use the Prompt box. This tape does not take new jobs."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								"data-testid": "bot-link",
								href: botHref,
								className: "mt-3 block break-all font-mono text-xs text-brass underline-offset-2 hover:underline",
								children: botHref
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								"data-testid": "model-screen",
								className: "mt-3 max-h-48 overflow-auto whitespace-pre-wrap font-mono text-xs leading-relaxed text-fg",
								children: formatAgent(glass ?? emptyAgent())
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								"data-testid": "model-manual",
								className: "mt-3 max-h-40 overflow-auto whitespace-pre-wrap font-mono text-xs leading-relaxed text-fg",
								children: PROTOCOL
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						role: "tablist",
						"aria-label": "Machines",
						children: machines.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							role: "tab",
							"aria-selected": item.id === machine.id,
							onClick: () => setActive(item.id),
							className: "tap flex min-h-11 flex-col items-start justify-center rounded-card border px-3 py-2 text-left " + (item.id === machine.id ? "border-brass bg-raised" : "border-line bg-surface"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-fg",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: item.solved ? "Clear" : item.attached ? "Linked" : "Idle"
							})]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid items-start gap-5 lg:grid-cols-[minmax(0,1.45fr)_minmax(18rem,0.8fr)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-card border border-line bg-surface px-4 py-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-wide text-muted uppercase",
											children: "Task"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-fg",
											children: machine.goal
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 flex flex-wrap gap-2",
											children: captions.map((chip, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "max-w-full truncate rounded-full border px-2 py-1 text-xs " + (chip.live ? "border-brass text-brass" : "border-line text-muted"),
												children: chip.label
											}, `${index}-${chip.label}`))
										}),
										machine.kind === "desk" && machine.desk?.letter && !machine.desk.sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm text-fg",
											children: "Pier 4. The lamp is out. Please reply and send the note back."
										}) : null,
										machine.kind === "breakers" && machine.breakers ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pattern, {
											target: machine.breakers.target,
											on: machine.breakers.on
										}) : null
									]
								}),
								machine.kind === "web" && machine.web ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowserPane, {
									url: glass?.url || machine.web.url,
									typed: machine.web.address,
									draft,
									ready,
									driving,
									shot: glass?.shot ?? "",
									onDraft: setDraft,
									onOpen: openTyped
								}) : null,
								machine.kind === "web" && machine.web ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlassTranscript, { web: {
									url: glass?.url || machine.web.url,
									address: machine.web.address,
									title: driving ? "Opening" : glass?.title || machine.web.title,
									transcript: driving ? "The browser is moving. The transcript updates when it stops." : glass?.transcript || machine.web.transcript
								} }) : null,
								machine.kind === "web" && machine.web ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebHand, {
									task,
									papers,
									openPaper,
									gathering,
									looksLeft: looks,
									onTask: setTask,
									onOpen: setOpenPaper,
									onClear: clearPapers,
									onGather: () => void gather()
								}) : null,
								machine.kind === "web" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid items-start gap-3 lg:grid-cols-[minmax(0,28rem)_minmax(0,1fr)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Floor, {
										machine,
										spots,
										busy,
										solved: machine.solved,
										onAim: aim
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-card border border-line bg-surface px-4 py-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-baseline justify-between gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs tracking-wide text-muted uppercase",
														children: "Under the pointer"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-sm text-brass tabular-nums",
														children: [
															machine.cursor.c,
															",",
															machine.cursor.r
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-2 text-sm text-fg",
													children: under ? under.label : "Open floor"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-sm text-muted",
													children: under ? under.detail : "Click a key to type it. Arrow keys step. Enter clicks."
												}),
												machine.log.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-3 text-xs text-muted",
													children: machine.log[machine.log.length - 1]
												}) : null
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
											onCommand: nudge,
											disabled: busy
										})]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "flex flex-col gap-3 lg:sticky lg:top-4",
							children: [
								machine.kind === "web" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentFloor, {
									pointer: glass?.pointer ?? {
										c: 0,
										r: 0
									},
									cells: glass?.cells ?? [],
									busy: driving,
									onAim: (col, row) => {
										const href = jobLinks[`${col},${row}`];
										if (href) {
											openRead(href);
											return;
										}
										const from = glass?.pointer ?? {
											c: 0,
											r: 0
										};
										runWeb(tapeBetween(from, {
											c: col,
											r: row
										}));
									}
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
									onCommand: (command) => {
										runWeb(command);
									},
									disabled: busy || driving
								})] }) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-card border border-line bg-surface p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-xs text-muted",
											children: "An AI that cannot send a request can still paste one line here, TAPE: right click. An AI that can send a request does not need this box."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											"data-testid": "model-reply",
											value: modelReply,
											onChange: (event) => setModelReply(event.target.value),
											spellCheck: false,
											"aria-label": "Model reply",
											placeholder: "TAPE: right click type \"the words\"",
											className: "mt-3 min-h-24 w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none placeholder:text-muted focus-visible:border-brass"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"data-testid": "run-reply",
											className: "tap mt-2 min-h-11 w-full rounded-2xl bg-brass px-3 text-sm text-ink disabled:opacity-40",
											onClick: () => void runModelReply(),
											disabled: busy || asking || driving,
											children: "Run reply"
										}),
										modelResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
											"data-testid": "model-result",
											className: "mt-3 max-h-48 overflow-auto whitespace-pre-wrap font-mono text-xs leading-relaxed text-fg",
											children: modelResult
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 text-xs tracking-wide text-muted uppercase",
											children: "Command tape"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											"data-testid": "tape",
											value: tape,
											onChange: (event) => setTape(event.target.value),
											spellCheck: false,
											"aria-label": "Command tape",
											placeholder: "up up right click",
											className: "mt-3 min-h-28 w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none placeholder:text-muted focus-visible:border-brass"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-2 flex flex-wrap gap-2",
											children: [
												"up",
												"down",
												"left",
												"right",
												"click"
											].map((word) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "tap min-h-11 rounded-full border border-line bg-bg px-3 text-xs text-fg",
												onClick: () => append(word),
												children: word
											}, word))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 grid grid-cols-2 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"data-testid": "run",
													className: "tap min-h-11 rounded-2xl bg-brass px-3 text-sm text-ink disabled:opacity-40",
													onClick: runTape,
													disabled: busy || asking || driving,
													children: "Run"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "tap min-h-11 rounded-2xl border border-line bg-raised px-3 text-sm text-fg disabled:opacity-40",
													onClick: busy ? stop : stepOnce,
													children: busy ? "Stop" : "Step"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"data-testid": "ask",
													className: "tap min-h-11 rounded-2xl border border-brass bg-raised px-3 text-sm text-brass disabled:opacity-40",
													onClick: () => void ask(),
													disabled: busy || asking || looks <= 0 || driving,
													children: asking ? "Looking…" : looked ? "Continue" : "Hand to model"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "tap min-h-11 rounded-2xl border border-line bg-bg px-3 text-sm text-fg",
													onClick: rehearse,
													children: "Rehearse"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 grid grid-cols-2 gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "tap flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-line px-3 text-xs text-muted",
												onClick: () => void copyBrief(),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
													className: "size-3.5",
													"aria-hidden": "true"
												}), copied ? "Copied" : "Copy for a model"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "tap flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-line px-3 text-xs text-muted",
												onClick: () => {
													stop();
													resetMachine(machine.id);
													if (machine.kind === "web") {
														setGlass(null);
														setJobLinks({});
													}
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
													className: "size-3.5",
													"aria-hidden": "true"
												}), "Reset bay"]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-card border border-line bg-bg px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs tracking-wide text-muted uppercase",
										children: "Wire"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
										className: "mt-2 flex max-h-52 flex-col gap-1 overflow-auto",
										"aria-live": "polite",
										children: trace.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "text-sm text-muted",
											children: "The link is quiet. Open a site, or hand the floor to a model."
										}) : trace.slice(-12).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "text-xs " + (line.tone === "warn" ? "text-brass" : line.tone === "model" ? "text-fg" : "text-muted"),
											children: line.text
										}, line.id))
									})]
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "w-full min-w-0 max-w-full overflow-x-hidden rounded-card border border-line bg-surface px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "min-h-11 cursor-pointer text-sm text-fg",
						children: "Settings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 flex min-h-11 items-center justify-between gap-3 text-sm text-fg",
						children: ["Show pointer and grid lines", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: showGrid,
							onChange: (event) => setShowGrid(event.target.checked)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-2 flex min-h-11 items-center justify-between gap-3 text-sm text-fg",
						children: ["Close only popups not needed for the task", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: closePopups,
							onChange: (event) => setClosePopups(event.target.checked)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-2 flex min-h-11 items-center justify-between gap-3 text-sm text-fg",
						children: ["Recent jobs", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: String(jobKeep),
							onChange: (event) => setJobKeep(Number(event.target.value)),
							className: "min-h-11 rounded-xl border border-line bg-bg px-2 text-sm text-fg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "1",
									children: "1 hour"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "24",
									children: "24 hours"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "0",
									children: "Off"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 flex flex-col gap-2",
						children: [recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-xs text-muted",
							children: "None"
						}) : null, recent.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-xs text-muted",
							children: row.order
						}, `${row.order}-${row.answer.slice(0, 24)}`))]
					})
				]
			})
		]
	});
}
function WebHand({ task, papers, openPaper, gathering, looksLeft, onTask, onOpen, onClear, onGather }) {
	const shown = papers.find((paper) => paper.id === openPaper) ?? papers[0];
	const [copied, setCopied] = (0, import_react.useState)(false);
	const copyPaper = async () => {
		if (!shown) return;
		const body = [
			shown.task,
			"",
			shown.text,
			"",
			...shown.sources
		].join("\n");
		try {
			await navigator.clipboard.writeText(body);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setCopied(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-surface px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-wide text-muted uppercase",
					children: "Web hand"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [looksLeft, " looks"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "One task. The model keeps moving the pointer until that task is finished. You do not type the next command."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				"data-testid": "task",
				value: task,
				onChange: (event) => onTask(event.target.value),
				"aria-label": "Task for the web",
				spellCheck: true,
				className: "mt-3 min-h-20 w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none focus-visible:border-brass"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"data-testid": "gather",
					className: "tap min-h-11 rounded-2xl bg-brass px-4 text-sm text-ink disabled:opacity-40",
					onClick: onGather,
					disabled: gathering || looksLeft <= 0,
					children: gathering ? "Driving…" : "Drive"
				}), papers.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tap min-h-11 rounded-2xl border border-line px-3 text-sm text-muted",
					onClick: onClear,
					children: "Clear notes"
				}) : null]
			}),
			shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				"data-testid": "paper",
				className: "mt-4 border-t border-line pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm text-fg",
							children: shown.task
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "tap shrink-0 text-xs text-brass",
							onClick: () => void copyPaper(),
							children: copied ? "Copied" : "Copy"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-h-72 overflow-auto whitespace-pre-wrap text-sm leading-relaxed text-fg",
						children: shown.text
					}),
					shown.sources.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-1",
						children: shown.sources.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "truncate text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: source,
								target: "_blank",
								rel: "noreferrer",
								className: "text-brass underline-offset-2 hover:underline",
								children: source
							})
						}, source))
					}) : null,
					papers.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: papers.map((paper) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "tap max-w-full truncate rounded-full border px-2 py-1 text-xs " + (paper.id === shown.id ? "border-brass text-brass" : "border-line text-muted"),
							onClick: () => onOpen(paper.id),
							children: paper.task
						}, paper.id))
					}) : null
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "No notes filed yet."
			})
		]
	});
}
function GlassTranscript({ web }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"data-testid": "transcript",
		className: "rounded-card border border-line bg-surface px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-brass uppercase",
				children: "Transcript"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "This is the page, written out. A model that cannot see the glass still reads this."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 truncate text-sm text-brass",
				children: web.url || "No page yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-fg",
				children: plain(web.title) || "No page yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-h-40 overflow-auto whitespace-pre-wrap text-sm leading-relaxed text-fg",
				children: web.transcript?.trim() ? plain(web.transcript) : "Open a public site. The writing shows up here, and the grid shows what you can click."
			})
		]
	});
}
function BrowserPane({ url, typed, draft, ready, driving, shot, page = true, onDraft, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-testid": "browser",
		className: "overflow-hidden rounded-card border border-line bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2 border-b border-line px-3 py-2 sm:flex-row",
				onSubmit: (event) => {
					event.preventDefault();
					onOpen();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					"data-testid": "open-address",
					value: draft,
					onChange: (event) => onDraft(event.target.value),
					"aria-label": "Site to open",
					spellCheck: false,
					placeholder: "any public site",
					className: "min-h-11 w-full flex-1 rounded-2xl border border-line bg-surface px-3 text-sm text-fg outline-none focus-visible:border-brass"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					"data-testid": "open-site",
					className: "tap min-h-11 rounded-2xl bg-brass px-4 text-sm text-ink disabled:opacity-40",
					disabled: !ready || driving,
					children: driving ? "Moving…" : "Open"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-line px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					"data-testid": "web-address",
					className: "wrap-any text-xs text-brass",
					children: url || "No page yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					"data-testid": "typed",
					className: "wrap-any mt-1 text-xs text-muted",
					children: typed ? `Open ${typed}` : "Nothing open"
				})]
			}),
			page ? shot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				"data-testid": "agent-shot",
				src: `data:image/jpeg;base64,${shot}`,
				alt: "The page the pointer is on",
				className: "w-full bg-surface"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 py-6 text-sm text-muted",
				children: driving ? "The page is opening." : url ? "The page is open. Its links are on the grid. The transcript is the writing." : "Press Open. The grid lists the links, and the transcript is the writing."
			}) : null
		]
	});
}
function AgentFloor({ pointer, cells, busy, onAim }) {
	const tiles = [];
	for (let row = 0; row < 32; row += 1) for (let col = 0; col < 8; col += 1) {
		const cell = cells.find((item) => item.c === col && item.r === row);
		const active = pointer.c === col && pointer.r === row;
		tiles.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"data-testid": `agent-${col}-${row}`,
			"aria-label": `Column ${col}, row ${row}`,
			"aria-current": active ? "true" : void 0,
			disabled: busy,
			onClick: () => onAim(col, row),
			className: "tap flex aspect-square min-w-0 items-end overflow-hidden rounded-xl border px-0.5 pb-0.5 text-left " + (active ? "border-brass bg-raised" : cell ? "border-line bg-surface" : "border-transparent bg-transparent")
		}, `${col}-${row}`));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-bg p-1 sm:p-3",
		"data-testid": "agent-floor",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-center justify-between px-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-muted uppercase",
				children: busy ? "Hand moving" : "Page grid"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-brass tabular-nums",
				"data-testid": "agent-pointer",
				children: [
					pointer.c,
					",",
					pointer.r
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-8 gap-0.5",
			children: tiles
		})]
	});
}
function Pattern({ target, on }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex flex-wrap items-center gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: "Pattern"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1",
				"aria-hidden": "true",
				children: target.map((flag, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm " + (flag ? "bg-brass" : "bg-line") }, `t-${index}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: "Now"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1",
				"aria-hidden": "true",
				children: on.map((flag, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm " + (flag === target[index] ? flag ? "bg-brass" : "bg-raised" : "bg-muted") }, `n-${index}`))
			})
		]
	});
}
function Pad({ onCommand, disabled }) {
	const key = (command, label, icon) => {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": label,
			disabled,
			onClick: () => onCommand(command),
			className: "tap flex size-12 items-center justify-center rounded-2xl border border-line bg-surface text-fg disabled:opacity-40 " + (command === "click" ? "border-brass text-brass" : ""),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(icon, {
				className: "size-4",
				"aria-hidden": "true"
			})
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center justify-center gap-2",
		"aria-label": "Pointer pad",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
				key("up", "Move up", ArrowUp),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
				key("left", "Move left", ArrowLeft),
				key("click", "Click", CircleCheck),
				key("right", "Move right", ArrowRight),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
				key("down", "Move down", ArrowDown),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
			]
		})
	});
}
function Floor({ machine, spots, busy, solved, onAim }) {
	const gridRef = (0, import_react.useRef)(null);
	const [cell, setCell] = (0, import_react.useState)(40);
	(0, import_react.useEffect)(() => {
		const el = gridRef.current;
		if (!el) return;
		const measure = () => {
			const size = (el.clientWidth - GAP * (machine.cols - 1)) / machine.cols;
			setCell(size > 0 ? size : 40);
		};
		measure();
		const observer = new ResizeObserver(measure);
		observer.observe(el);
		return () => observer.disconnect();
	}, [machine.cols]);
	const cells = [];
	for (let row = 0; row < machine.rows; row += 1) for (let col = 0; col < machine.cols; col += 1) {
		const spot = spots.find((item) => item.col === col && item.row === row);
		const active = machine.cursor.c === col && machine.cursor.r === row;
		const letter = spot?.glyph === "key" || spot?.glyph === "del";
		const alwaysLabel = letter || spot?.glyph === "search" || spot?.glyph === "page";
		const Mark = spot && spot.glyph !== "breaker" && !letter ? ICONS[spot.glyph] : null;
		const breakerOn = machine.kind === "breakers" && spot?.glyph === "breaker" ? machine.breakers?.on[col] : false;
		cells.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"data-testid": `cell-${col}-${row}`,
			"aria-label": spot ? spot.label : `Floor ${col},${row}`,
			"aria-current": active ? "true" : void 0,
			disabled: busy,
			onClick: () => onAim(col, row),
			className: "tap relative flex aspect-square min-w-0 flex-col items-center justify-center gap-1 overflow-hidden rounded-xl border " + (spot ? toneClass(spot.tone, active && Boolean(spot)) : "border-transparent bg-transparent") + (active && !spot ? " border-brass/50" : ""),
			children: [
				Mark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
					className: "size-4 shrink-0",
					"aria-hidden": "true"
				}) : null,
				spot?.glyph === "breaker" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-1 rounded-full " + (breakerOn ? "h-5 bg-brass" : "h-2 bg-line"),
					"aria-hidden": "true"
				}) : null,
				spot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "max-w-full truncate px-0.5 text-xs " + (alwaysLabel ? "" : "hidden sm:block"),
					children: spot.label
				}) : null
			]
		}, `${col}-${row}`));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-md rounded-card border bg-bg p-1 sm:p-3 " + (solved ? "border-brass" : "border-line"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-center justify-between px-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-muted uppercase",
				children: solved ? "Clear" : busy ? "Hand moving" : "Floor"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted tabular-nums",
				children: [
					machine.cols,
					"×",
					machine.rows
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: gridRef,
				"data-testid": "floor",
				className: "grid",
				style: {
					gridTemplateColumns: `repeat(${machine.cols}, minmax(0, 1fr))`,
					gap: GAP
				},
				children: cells
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hand-move pointer-events-none absolute top-0 left-0 z-10",
				style: {
					width: cell,
					height: cell,
					transform: `translate(${machine.cursor.c * (cell + GAP)}px, ${machine.cursor.r * (cell + GAP)}px)`
				},
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 left-0 size-2.5 border-t-2 border-l-2 border-brass" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 right-0 size-2.5 border-t-2 border-r-2 border-brass" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-0 left-0 size-2.5 border-b-2 border-l-2 border-brass" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-0 bottom-0 size-2.5 border-r-2 border-b-2 border-brass" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-1/2 size-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brass" })
				]
			})]
		})]
	});
}
var SplitComponent = QuayApp;
//#endregion
export { SplitComponent as component };
