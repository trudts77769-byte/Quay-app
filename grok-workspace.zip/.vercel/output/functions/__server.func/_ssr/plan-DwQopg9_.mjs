import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { g as toUrl, p as readPublicDocument } from "./read-page-BfummKTD.mjs";
import { n as readSecret, r as scrubSecrets, t as readHfToken } from "./secrets-C8jEd3tJ.mjs";
import { appendFileSync, existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { tmpdir } from "node:os";
//#region node_modules/.nitro/vite/services/ssr/assets/plan-DwQopg9_.js
var sandbox_session_default = "import { createRequire } from \"node:module\";\nimport readline from \"node:readline\";\n\nconst require = createRequire(import.meta.url);\n\nasync function loadChromium() {\n  try {\n    const mod = await import(\"playwright\");\n    if (mod.chromium) return mod.chromium;\n    if (mod.default?.chromium) return mod.default.chromium;\n  } catch {\n    /* playwright is not installed in this runtime */\n  }\n  const loaded = require(\"playwright-core\");\n  return loaded.chromium || loaded.default?.chromium;\n}\n\nconst chromium = await loadChromium();\nconst browser = await chromium.launch({\n  headless: true,\n  executablePath: process.env.QUAY_CHROMIUM || undefined,\n  args: [\"--no-sandbox\", \"--disable-dev-shm-usage\"],\n});\nconst page = await browser.newPage({ viewport: { width: 390, height: 844 } });\n\nasync function screen() {\n  const data = await page.evaluate(() => {\n    const viewH = window.innerHeight;\n    const viewW = window.innerWidth;\n    const visible = (el) => {\n      const style = window.getComputedStyle(el);\n      if (style.visibility === \"hidden\" || style.display === \"none\") return false;\n      const box = el.getBoundingClientRect();\n      return box.bottom > 4 && box.top < viewH - 4 && box.right > 4 && box.left < viewW - 4 && box.width > 8 && box.height > 8;\n    };\n    const raw = (el) =>\n      (el.getAttribute(\"aria-label\") || el.getAttribute(\"title\") || el.getAttribute(\"alt\") || el.innerText || el.textContent || el.getAttribute(\"placeholder\") || el.getAttribute(\"name\") || \"\")\n        .replace(/\\s+/g, \" \")\n        .trim()\n        .slice(0, 80);\n    const nodes = document.querySelectorAll(\"a[href], button, input, textarea, select, summary, [role=button], [role=link], [role=menuitem], [role=tab], [aria-label]\");\n    const options = [];\n    const seen = new Set();\n    for (const el of nodes) {\n      if (!(el instanceof HTMLElement) || !visible(el)) continue;\n      const label = raw(el);\n      if (!label) continue;\n      const tag = el.tagName.toLowerCase();\n      let kind = \"link\";\n      if (tag === \"input\" || tag === \"textarea\" || tag === \"select\") kind = \"form\";\n      else if (el.getAttribute(\"role\") === \"menuitem\" || el.closest(\"nav, [role=menu], [role=menubar]\")) kind = \"menu\";\n      else if (tag === \"button\" || el.getAttribute(\"role\") === \"button\" || tag === \"summary\") kind = \"button\";\n      else if ((el.querySelector(\"svg, img\") && label.length < 24) || (el.getAttribute(\"aria-label\") && !(el.innerText || \"\").trim())) kind = \"icon\";\n      const key = `${kind}:${label.toLowerCase()}`;\n      if (seen.has(key)) continue;\n      seen.add(key);\n      const box = el.getBoundingClientRect();\n      const id = String(options.length + 1);\n      el.setAttribute(\"data-quay\", id);\n      options.push({\n        id,\n        kind,\n        label,\n        x: Math.round(((box.left + box.width / 2) / viewW) * 100),\n        y: Math.round(((box.top + box.height / 2) / viewH) * 100),\n      });\n      if (options.length >= 16) break;\n    }\n    const bits = [];\n    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);\n    let node = walker.nextNode();\n    while (node) {\n      const parent = node.parentElement;\n      if (parent && visible(parent)) {\n        const bit = (node.textContent || \"\").replace(/\\s+/g, \" \").trim();\n        if (bit.length > 1) bits.push(bit);\n      }\n      if (bits.join(\" \").length > 1400) break;\n      node = walker.nextNode();\n    }\n    const fields = [...document.querySelectorAll(\"input, textarea\")]\n      .filter((el) => el instanceof HTMLElement && visible(el))\n      .map((el) => el.value || \"\")\n      .filter(Boolean);\n    const height = Math.max(document.body?.scrollHeight ?? 0, document.documentElement?.scrollHeight ?? 0);\n    return {\n      url: location.href,\n      title: document.title || \"Page\",\n      text: `${bits.join(\" \")} ${fields.join(\" \")}`.replace(/\\s+/g, \" \").trim().slice(0, 1400),\n      moreBelow: window.scrollY + viewH < height - 24,\n      moreAbove: window.scrollY > 24,\n      options,\n    };\n  });\n  const shot = Buffer.from(await page.screenshot({ type: \"jpeg\", quality: 32 })).toString(\"base64\");\n  return { ...data, shot };\n}\n\nfunction send(payload) {\n  process.stdout.write(`${JSON.stringify(payload)}\\n`);\n}\n\nconst lines = readline.createInterface({ input: process.stdin });\nfor await (const line of lines) {\n  let cmd = {};\n  try {\n    cmd = JSON.parse(line);\n  } catch {\n    send({ ok: false, error: \"bad command\" });\n    continue;\n  }\n  try {\n    if (cmd.cmd === \"close\") break;\n    if (cmd.cmd === \"open\") {\n      await page.goto(String(cmd.url || \"\"), { waitUntil: \"domcontentloaded\", timeout: 0 });\n      await page.waitForTimeout(500);\n      send({ ok: true, screen: await screen() });\n      continue;\n    }\n    if (cmd.cmd === \"click\") {\n      const id = String(cmd.id || \"\");\n      const target = page.locator(`[data-quay=\"${id}\"]`).first();\n      const point = await target.boundingBox();\n      const view = page.viewportSize() || { width: 390, height: 844 };\n      const click = point\n        ? {\n            x: Math.round(((point.x + point.width / 2) / view.width) * 100),\n            y: Math.round(((point.y + point.height / 2) / view.height) * 100),\n          }\n        : null;\n      await target.click({ timeout: 10000 });\n      await page.waitForTimeout(500);\n      send({ ok: true, screen: await screen(), click });\n      continue;\n    }\n    if (cmd.cmd === \"type\") {\n      const field = page.locator(`[data-quay=\"${String(cmd.id || \"\")}\"]`).first();\n      await field.fill(String(cmd.text || \"\").slice(0, 160));\n      await page.waitForTimeout(200);\n      send({ ok: true, screen: await screen() });\n      continue;\n    }\n    if (cmd.cmd === \"scroll\") {\n      const dir = String(cmd.dir || \"down\");\n      await page.mouse.wheel(0, dir === \"up\" ? -700 : 700);\n      await page.waitForTimeout(250);\n      send({ ok: true, screen: await screen() });\n      continue;\n    }\n    if (cmd.cmd === \"wait\") {\n      await page.waitForTimeout(800);\n      send({ ok: true, screen: await screen() });\n      continue;\n    }\n    if (cmd.cmd === \"back\") {\n      await page.goBack({ waitUntil: \"domcontentloaded\", timeout: 0 });\n      await page.waitForTimeout(300);\n      send({ ok: true, screen: await screen() });\n      continue;\n    }\n    send({ ok: false, error: \"unknown command\", screen: await screen().catch(() => null) });\n  } catch (error) {\n    let failed = null;\n    try {\n      failed = await screen();\n    } catch {\n      failed = null;\n    }\n    send({ ok: false, error: error instanceof Error ? error.message.slice(0, 160) : \"action failed\", screen: failed });\n  }\n}\n\nlines.close();\nawait browser.close();\n";
var cached = null;
function locateSandboxScript() {
	if (cached?.diagnostic.exists && cached.source) return cached;
	const cwd = process.cwd();
	const runtime = process.env.VERCEL ? "vercel" : "production";
	const fromModule = fileURLToPath(new URL("../../../scripts/sandbox-session.mjs", import.meta.url));
	let path = [join(cwd, "scripts/sandbox-session.mjs"), fromModule].find((item) => existsSync(item)) ?? "";
	let text = sandbox_session_default;
	if (!text && path) try {
		text = readFileSync(path, "utf8");
	} catch {
		text = "";
	}
	if (!path && text) {
		path = join(tmpdir(), "quay-sandbox-session.mjs");
		writeFileSync(path, text);
	}
	cached = {
		path,
		source: text,
		diagnostic: {
			path,
			exists: Boolean(path && existsSync(path) && text),
			cwd,
			runtime
		}
	};
	return cached;
}
function absorbAccounts(text) {
	return text.replace(/(^|\n)([ \t]*PASSWORD:\s*)(\S+)/gi, (_match, lead, label, secret) => secret ? `${lead}${label}[redacted]` : _match);
}
var byId = /* @__PURE__ */ new Map();
function openChief(id, order = "") {
	const key = id || "page";
	const existing = byId.get(key);
	if (existing) {
		if (order && !existing.order) existing.order = order.slice(0, 2e3);
		if (typeof existing.crew !== "string" || !existing.crew) existing.crew = key;
		return existing;
	}
	const created = {
		id: key,
		order: order.slice(0, 2e3),
		crew: key,
		answer: "",
		shot: "",
		page: ""
	};
	byId.set(key, created);
	return created;
}
function chiefById(id) {
	return openChief(id || "page", "");
}
function crewOf(state, id) {
	if (state && typeof state.crew === "string" && state.crew) return state.crew;
	return chiefById(id).crew || id || "page";
}
function rememberShot(id, shot, page) {
	const chief = chiefById(id);
	if (shot) chief.shot = shot.slice(0, 15e5);
	if (page) chief.page = page.slice(0, 300);
}
function setChiefAnswer(id, answer) {
	chiefById(id).answer = answer.slice(0, 2e3);
}
function latestView() {
	const chief = byId.get("page") ?? [...byId.values()].at(-1);
	return {
		shot: chief?.shot ?? "",
		page: chief?.page ?? "",
		crew: chief?.crew ?? "page"
	};
}
var notes = /* @__PURE__ */ new Map();
var traces$1 = /* @__PURE__ */ new Map();
function stamp() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(11, 19);
}
function pushTrace(job, line) {
	const key = job || "page";
	const rows = traces$1.get(key) ?? [];
	rows.push(`${stamp()} ${line}`.replace(/\s+/g, " ").trim().slice(0, 180));
	traces$1.set(key, rows.slice(-16));
}
function readTrace(job) {
	return traces$1.get(job || "page") ?? [];
}
function setWorking(job, cycle, stage) {
	const key = job || "page";
	const text = stage && stage !== "Working" ? stage : "Working";
	notes.set(key, text);
	pushTrace(key, text);
}
function readWorking(job) {
	return notes.get(job || "page") ?? "";
}
function clearWorking(job) {
	notes.delete(job || "page");
}
var file$3 = join(process.cwd(), "data", "tasks.json");
var book = /* @__PURE__ */ new Map();
var loaded$3 = false;
var CLOSED = /* @__PURE__ */ new Set([
	"COMPLETED",
	"CANCELLED",
	"EXHAUSTED"
]);
var DELIVERY_BACKOFF_MS = [
	0,
	2e3,
	5e3,
	15e3
];
function nextDeliveryDelay(attempt) {
	if (attempt < 0 || attempt >= DELIVERY_BACKOFF_MS.length) return null;
	return DELIVERY_BACKOFF_MS[attempt] ?? null;
}
function load$3() {
	if (loaded$3) return;
	loaded$3 = true;
	try {
		if (!existsSync(file$3)) return;
		const rows = JSON.parse(readFileSync(file$3, "utf8"));
		if (!Array.isArray(rows)) return;
		for (const row of rows) if (row?.task_id) book.set(row.task_id, row);
	} catch {}
}
function save() {
	try {
		mkdirSync(join(process.cwd(), "data"), { recursive: true });
		const rows = [...book.values()].slice(-80);
		writeFileSync(file$3, JSON.stringify(rows));
	} catch {}
}
function taskIdFor(channel, task) {
	return `${channel}|${task}`.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 64) || "task";
}
function readTask(taskId) {
	load$3();
	return book.get(taskId) ?? null;
}
function isClosed(status) {
	return CLOSED.has(status);
}
function openTask(input) {
	load$3();
	const existing = book.get(input.task_id);
	if (existing) return existing;
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const created = {
		task_id: input.task_id,
		parent_task_id: "",
		channel_id: input.channel_id,
		source: input.source || "veil",
		created_at: now,
		updated_at: now,
		status: "QUEUED",
		task: input.task.slice(0, 2e3),
		task_type: input.task_type,
		assigned_worker: "",
		attempt: 0,
		max_attempts: 2,
		sandbox_required: input.task_type === "WEB_TASK",
		sandbox_started: false,
		sandbox_completed: false,
		worker_result: "",
		final_result: "",
		error: "",
		lease_expires_at: "",
		delivery_pending: false,
		events: []
	};
	book.set(created.task_id, created);
	save();
	return created;
}
function updateTask(taskId, patch) {
	load$3();
	const row = book.get(taskId);
	if (!row) return null;
	Object.assign(row, patch, {
		updated_at: (/* @__PURE__ */ new Date()).toISOString(),
		task_id: row.task_id
	});
	save();
	return row;
}
function noteTask(taskId, line) {
	const row = readTask(taskId);
	if (!row) return;
	const stamp = (/* @__PURE__ */ new Date()).toISOString().slice(11, 19);
	row.events.push(`${stamp} ${line}`.slice(0, 180));
	row.events = row.events.slice(-24);
	row.updated_at = (/* @__PURE__ */ new Date()).toISOString();
	save();
}
var pageTask = "";
function bindPageTask(taskId) {
	pageTask = taskId;
}
function pageTaskId() {
	return pageTask;
}
var NAMED = [
	[/\bwikipedia\b/i, "https://www.wikipedia.org"],
	[/\bduckduckgo\b/i, "https://duckduckgo.com"],
	[/\bgoogle\b/i, "https://www.google.com"],
	[/\bbing\b/i, "https://www.bing.com"],
	[/\bexample\.com\b/i, "https://example.com"]
];
function taskKind(text) {
	if (/https?:\/\/|\b[a-z0-9-]+\.(com|org|net|io|me|edu|gov)\b/i.test(text)) return "WEB_TASK";
	if (/\b(website|web\s?page|browse|browser|click|scroll|menu|form|navigate|wikipedia|homepage|online|look\s+up|visit\s+\w+|search\s+(the\s+)?(web|for|google))\b/i.test(text)) return "WEB_TASK";
	return "NON_WEB_TASK";
}
function startUrl(text) {
	const explicit = text.match(/https?:\/\/[^\s)>\]]+/i)?.[0]?.replace(/[.,]+$/, "") ?? "";
	if (explicit) return explicit;
	const host = text.match(/\b((?:[a-z0-9-]+\.)+[a-z]{2,})\b/i)?.[1] ?? "";
	if (host && !/^(step|task)\./i.test(host)) return `https://${host.replace(/^www\./, "").toLowerCase()}`;
	for (const [pattern, url] of NAMED) if (pattern.test(text)) return url;
	const named = text.match(/\b(?:open|visit)\s+(?:the\s+)?([a-z0-9-]{2,})\b/i)?.[1] ?? "";
	if (named && !/^(the|a|an|page|site|website)$/i.test(named)) return `https://www.${named.toLowerCase()}.com`;
	const query = text.match(/\bsearch(?:\s+for)?\s+(.{2,80})/i)?.[1]?.replace(/\s+/g, " ").trim() ?? "";
	if (query) return `https://duckduckgo.com/?q=${encodeURIComponent(query.slice(0, 80))}`;
	return "https://duckduckgo.com";
}
var CHAT = [
	"huggingface-projects/llama-2-13b-chat",
	"huggingface-projects/llama-2-7b-chat",
	"ysharma/Chat_with_Meta_llama3_8b",
	"huggingface-projects/gemma-4-12b-it",
	"sambanovasystems/Llama3.1-Instruct-O1",
	"gokaygokay/Gemma-2-llamacpp",
	"huggingface-projects/llama-3.2-3B-Instruct",
	"Qwen/Qwen3-Demo",
	"ehristoforu/mistral-7b-chat",
	"Be-Bo/llama-3-chatbot_70b",
	"DarwinAnim8or/Mistral-Chat",
	"ehristoforu/mixtral-46.7b-chat",
	"Harley-ml/SmolLM2_Chat",
	"ysharma/Chat_with_Meta_llama3_1_8b",
	"chheplo/DeepSeek-R1-Distill-Llama-8B"
];
var SUMMARY = [
	"pszemraj/summarize-long-text",
	"pszemraj/document-summarization",
	"razakhan/text-summarizer",
	"Tulika2000/ai-pdf-summarizer",
	"Walid-Ahmed/Advanced_Text_Summarization",
	"adarshzolekar/Website-Summarizer",
	"anishde/SIMPLIFY_text_summarizer",
	"AmK1304/Document_Summarizer"
];
var OCR = [
	"PaddlePaddle/PP-OCRv5_Online_Demo",
	"pragnakalp/OCR-image-to-text",
	"yonigozlan/GOT-OCR-Transformers",
	"gokaygokay/Florence-2",
	"merterbak/DeepSeek-OCR-Demo",
	"baidu/Unlimited-OCR",
	"khang119966/DeepSeek-OCR-DEMO",
	"prithivMLmods/Multimodal-OCR",
	"prithivMLmods/core-OCR",
	"pszemraj/pdf-ocr",
	"MohamedRashad/Dots-OCR",
	"prithivMLmods/Multimodal-OCR2",
	"prithivMLmods/GLM-OCR-Demo",
	"Ayaan-Sharif/ocr-layout-detection-poc"
];
var WEB = [
	"Agents-MCP-Hackathon/web-scraper",
	"Frantz103/html-to-markdown",
	"deep-div/MCP-Web-Search",
	"AkshayStark3000/webScraper",
	"Agents-MCP-Hackathon/web-search-mcp",
	"siam3310/web-scraper",
	"Ifeanyi/Web-Search-MCP",
	"nelsondiasandre/web-search-mcp"
];
var SHOT = [
	"HuggingFaceM4/screenshot2html",
	"dhuynh95/screenshot_to_html",
	"jiseki/selenium-screenshot-gradio",
	"rafael1994s/Playwright"
];
var TRANSLATE = [
	"avans06/whisper-webui-translate",
	"gundeep/open-translate",
	"Helsinki-NLP/opus-translate",
	"hysts/translategemma-27b-it",
	"CohereLabs/command-a-translate"
];
var SPEECH = [
	"openai/whisper",
	"hf-audio/whisper-large-v3",
	"KingNish/Realtime-whisper-large-v3-turbo",
	"nvidia/parakeet-tdt-0.6b-v3"
];
var IMAGE = [
	"black-forest-labs/FLUX.1-schnell",
	"black-forest-labs/FLUX.1-dev",
	"yanze/PuLID-FLUX",
	"stabilityai/stable-diffusion-3.5-large",
	"stabilityai/stable-diffusion-3-medium"
];
function spaces(kind, group, list, web = false) {
	return list.map((space) => ({
		id: `hf:${space}`,
		label: `${kind} · ${space.split("/")[1] ?? space}`,
		group,
		key: "HF_TOKEN",
		space,
		web
	}));
}
var ROWS = [
	{
		id: "worker-xai",
		label: "Grok 4.5",
		group: "xAI",
		key: "XAI_API_KEY"
	},
	{
		id: "worker-gemini",
		label: "Gemini 2.0 Flash",
		group: "Google",
		key: "GEMINI_API_KEY"
	},
	{
		id: "worker-openrouter",
		label: "Gemma 4 26B",
		group: "OpenRouter",
		key: "OPENROUTER_API_KEY"
	},
	{
		id: "worker-openrouter-2",
		label: "Ling 3.0 Flash",
		group: "OpenRouter",
		key: "OPENROUTER_API_KEY"
	},
	{
		id: "worker-groq",
		label: "Llama 3.3 70B",
		group: "Groq",
		key: "GROQ_API_KEY"
	},
	{
		id: "worker-ovh",
		label: "gpt-oss-20b",
		group: "OVH",
		key: "none"
	},
	{
		id: "worker-airforce",
		label: "rnj-1",
		group: "Airforce",
		key: "none"
	},
	{
		id: "worker-airforce-2",
		label: "Llama Instant",
		group: "Airforce",
		key: "none"
	},
	{
		id: "worker-pollinations",
		label: "Pollinations",
		group: "Pollinations",
		key: "none"
	},
	{
		id: "worker-local",
		label: "Local",
		group: "Local",
		key: "LOCAL"
	},
	{
		id: "worker-hf",
		label: "Qwen 2.5 7B",
		group: "Hugging Face",
		key: "HF_TOKEN"
	},
	...spaces("Chat", "Hugging Face — Chat", CHAT),
	...spaces("Summarization", "Hugging Face — Summarization", SUMMARY),
	...spaces("OCR", "Hugging Face — OCR", OCR),
	...spaces("Web reading", "Hugging Face — Web reading", WEB, true),
	...spaces("Screenshot", "Hugging Face — Screenshot", SHOT),
	...spaces("Translation", "Hugging Face — Translation", TRANSLATE),
	...spaces("Speech to text", "Hugging Face — Speech to text", SPEECH),
	...spaces("Image", "Hugging Face — Image", IMAGE)
];
function allModels() {
	return ROWS;
}
function labelOf(id) {
	return ROWS.find((row) => row.id === id)?.label ?? id;
}
function webSpaces() {
	return ROWS.filter((row) => row.web);
}
var REASON_ORDER = [
	"worker-xai",
	"worker-gemini",
	"worker-openrouter",
	"worker-openrouter-2",
	"worker-hf"
];
var endpoints = /* @__PURE__ */ new Map();
function hosts(space) {
	const [owner, repo] = space.split("/");
	if (!owner || !repo) return [];
	const raw = `${owner}-${repo}`.toLowerCase();
	const dashed = raw.replace(/\./g, "-");
	const list = [`https://${raw}.hf.space`];
	if (dashed !== raw) list.push(`https://${dashed}.hf.space`);
	return list;
}
function promptOf(messages) {
	return messages.filter((message) => message.role !== "system").map((message) => message.content).join("\n").replace(/\s+/g, " ").trim().slice(0, 4e3);
}
function flatten(value) {
	if (typeof value === "string") return value;
	if (typeof value === "number" || typeof value === "boolean") return String(value);
	if (Array.isArray(value)) return value.map(flatten).filter(Boolean).join("\n");
	if (value && typeof value === "object") {
		const row = value;
		const url = typeof row.url === "string" ? row.url : "";
		if (/^https?:\/\//i.test(url)) return url;
		return Object.values(row).map(flatten).filter(Boolean).join("\n");
	}
	return "";
}
function fromBody(raw) {
	const quota = /quota|zerogpu|rate limit/i.test(raw);
	const blocks = raw.split(/\n\n/);
	for (const block of [...blocks].reverse()) {
		const dataLine = block.split("\n").map((line) => line.trim()).find((line) => line.startsWith("data:"));
		if (!dataLine) continue;
		const json = dataLine.slice(5).trim();
		if (/event:\s*error/i.test(block)) return {
			text: "",
			quota: quota || /quota/i.test(json),
			failed: true
		};
		try {
			return {
				text: flatten(JSON.parse(json)),
				quota,
				failed: false
			};
		} catch {
			return {
				text: json,
				quota,
				failed: false
			};
		}
	}
	try {
		const parsed = JSON.parse(raw);
		if (parsed.error) return {
			text: "",
			quota,
			failed: true
		};
		if (parsed.data !== void 0) return {
			text: flatten(parsed.data),
			quota,
			failed: false
		};
	} catch {}
	return {
		text: raw,
		quota,
		failed: false
	};
}
async function endpoint(host, headers) {
	const cached = endpoints.get(host);
	if (cached) return cached;
	try {
		const response = await fetch(`${host}/gradio_api/info`, { headers });
		if (response.ok) {
			const body = await response.json();
			const names = Object.keys(body.named_endpoints ?? {});
			const name = (names.find((name) => /predict|chat|generate|translate|summar/i.test(name)) ?? names[0] ?? "/predict").replace(/^\//, "") || "predict";
			endpoints.set(host, name);
			return name;
		}
	} catch {}
	return "predict";
}
function pack$1(text, quota, failed) {
	const clean = scrubSecrets(text).replace(/\s+/g, " ").trim();
	if (quota || /quota|zerogpu|rate limit/i.test(clean)) return {
		text: null,
		failed: true,
		reason: "quota"
	};
	if (failed || clean.length < 8) return {
		text: null,
		failed: true,
		reason: failed ? "down" : "empty"
	};
	return {
		text: clean.slice(0, 1500),
		failed: false,
		reason: ""
	};
}
async function once$1(host, headers, text) {
	const name = await endpoint(host, headers);
	const posted = await fetch(`${host}/gradio_api/call/${name}`, {
		method: "POST",
		headers,
		body: JSON.stringify({ data: [text] })
	});
	const raw = await posted.text();
	if (posted.status === 404) {
		const legacy = await fetch(`${host}/api/predict`, {
			method: "POST",
			headers,
			body: JSON.stringify({ data: [text] }),
			signal: AbortSignal.timeout(2e4)
		});
		const body = await legacy.text();
		if (!legacy.ok && legacy.status !== 404) return pack$1("", legacy.status === 429, true);
		if (legacy.status === 404) return null;
		const parsed = fromBody(body);
		return pack$1(parsed.text, parsed.quota || legacy.status === 429, parsed.failed);
	}
	if (!posted.ok) return pack$1("", posted.status === 429, true);
	let event = "";
	try {
		event = String(JSON.parse(raw).event_id ?? "");
	} catch {
		event = "";
	}
	if (!event) {
		const parsed = fromBody(raw);
		return pack$1(parsed.text, parsed.quota, parsed.failed);
	}
	const stream = await fetch(`${host}/gradio_api/call/${name}/${event}`, { headers });
	const body = await stream.text();
	if (!stream.ok) return pack$1("", stream.status === 429, true);
	const parsed = fromBody(body);
	return pack$1(parsed.text, parsed.quota, parsed.failed);
}
async function callSpace(space, messages) {
	const token = readHfToken();
	if (!token) return {
		text: null,
		failed: true,
		reason: "no-key"
	};
	const text = promptOf(messages);
	if (text.length < 2) return {
		text: null,
		failed: true,
		reason: "empty"
	};
	const headers = {
		"Content-Type": "application/json",
		Accept: "application/json",
		Authorization: `Bearer ${token}`
	};
	for (const host of hosts(space)) try {
		const called = await once$1(host, headers, text);
		if (called) return called;
	} catch {}
	return {
		text: null,
		failed: true,
		reason: "down"
	};
}
var file$2 = join(process.cwd(), "data", "model-status.json");
var saved = /* @__PURE__ */ new Map();
var loaded$2 = false;
function load$2() {
	if (loaded$2) return;
	loaded$2 = true;
	try {
		if (!existsSync(file$2)) return;
		const json = JSON.parse(readFileSync(file$2, "utf8"));
		for (const [id, status] of Object.entries(json)) if (status === "Ready" || status === "Quota hit" || status === "Failed") saved.set(id, status);
	} catch {}
}
function persist$2() {
	try {
		mkdirSync(join(process.cwd(), "data"), { recursive: true });
		writeFileSync(file$2, JSON.stringify(Object.fromEntries(saved)));
	} catch {}
}
function keyed(key) {
	if (key === "none") return true;
	if (key === "LOCAL") return Boolean(readSecret("LOCAL_OPENAI_URL") || readSecret("OPENAI_COMPAT_URL"));
	return Boolean(readSecret(key));
}
function statusOf(id) {
	load$2();
	const row = allModels().find((item) => item.id === id);
	if (!row) return "Failed";
	if (!keyed(row.key)) return "Key missing";
	return saved.get(id) ?? "Untested";
}
function markFromCall(id, called) {
	load$2();
	if (!id || called.reason === "spend" || called.reason === "waiting") return;
	if (called.reason === "no-key" || /no-key/.test(called.reason)) return;
	const next = /429|quota/i.test(called.reason) ? "Quota hit" : called.text && !called.failed ? "Ready" : "Failed";
	saved.set(id, next);
	persist$2();
}
function dir() {
	return join(process.env.QUAY_DATA_DIR || join(process.cwd(), "data"), "usage");
}
var spent = /* @__PURE__ */ new Map();
function withinSpend(job, cents) {
	const cap = Number(process.env.QUAY_MAX_SPEND_CENTS ?? 500);
	if (!Number.isFinite(cap)) return true;
	const next = (spent.get(job) ?? 0) + Math.max(0, cents);
	if (next > cap) return false;
	spent.set(job, next);
	return true;
}
function estimateTokens(text) {
	return Math.max(1, Math.ceil(text.length / 4));
}
function recordUsage(row) {
	try {
		const folder = dir();
		mkdirSync(folder, { recursive: true });
		const safe = (row.job || "none").replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80) || "none";
		const base = join(folder, safe);
		const line = JSON.stringify(row);
		appendFileSync(`${base}.jsonl`, `${line}\n`);
		const csv = `${base}.csv`;
		const header = "at,job,slot,follower,provider,side,inputTokens,outputTokens,estimated,wallMs,modelCalls,ok\n";
		if (!existsSync(csv) || statSync(csv).size === 0) appendFileSync(csv, header);
		const cell = (value) => `"${String(value).replace(/"/g, "\"\"")}"`;
		appendFileSync(csv, [
			row.at,
			row.job,
			row.slot,
			row.follower,
			row.provider,
			row.side,
			row.inputTokens,
			row.outputTokens,
			row.estimated,
			row.wallMs,
			row.modelCalls,
			row.ok
		].map(cell).join(",") + "\n");
	} catch {}
}
var ORIGIN$1 = "https://infoveil.grok.me";
var file$1 = join(process.cwd(), "data", "veil-pings.json");
var pings = /* @__PURE__ */ new Map();
var loaded$1 = false;
var flight = null;
function load$1() {
	if (loaded$1) return;
	loaded$1 = true;
	try {
		if (!existsSync(file$1)) return;
		const json = JSON.parse(readFileSync(file$1, "utf8"));
		for (const [id, ping] of Object.entries(json)) if (typeof ping === "string" && /^https:\/\//i.test(ping)) pings.set(id, ping);
	} catch {}
}
function persist$1() {
	try {
		mkdirSync(join(process.cwd(), "data"), { recursive: true });
		writeFileSync(file$1, JSON.stringify(Object.fromEntries(pings)));
	} catch {}
}
function absolute(ping) {
	if (/^https?:\/\//i.test(ping)) return ping;
	if (ping.startsWith("/")) return `${ORIGIN$1}${ping}`;
	return "";
}
async function registerOne(id, label) {
	load$1();
	if (!id || pings.get(id)) return;
	try {
		const response = await fetch(`${ORIGIN$1}/api/bot/register`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Accept: "application/json",
				"User-Agent": "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)"
			},
			body: JSON.stringify({
				source: "quay",
				name: id,
				label
			}),
			signal: AbortSignal.timeout(12e3)
		});
		if (!response.ok) return;
		const data = await response.json();
		const ping = typeof data.ping === "string" ? absolute(data.ping) : "";
		if (!ping) return;
		pings.set(id, ping);
		persist$1();
	} catch {}
}
function registerMissing(rows) {
	load$1();
	const missing = rows.filter((row) => row.id && !pings.get(row.id));
	if (missing.length === 0) return Promise.resolve();
	if (flight) return flight;
	flight = (async () => {
		for (let index = 0; index < missing.length; index += 4) await Promise.all(missing.slice(index, index + 4).map((row) => registerOne(row.id, row.label)));
	})().finally(() => {
		flight = null;
	});
	return flight;
}
async function unreadFor(id) {
	load$1();
	if (!id) return "";
	if (!pings.get(id)) await registerOne(id, labelOf(id));
	const ping = pings.get(id) ?? "";
	if (!ping) return "";
	try {
		const response = await fetch(ping, {
			headers: {
				Accept: "application/json, text/plain",
				"User-Agent": "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)"
			},
			signal: AbortSignal.timeout(4e3)
		});
		if (!response.ok) return "";
		const text = (await response.text()).replace(/\s+/g, " ").trim();
		if (!text || /^no pings\.?$/i.test(text)) return "";
		return text.slice(0, 1500);
	} catch {
		return "";
	}
}
var stats = /* @__PURE__ */ new Map();
function row(id) {
	const existing = stats.get(id);
	if (existing) return existing;
	const created = {
		ok: 0,
		fail: 0,
		timeout: 0,
		lastOk: 0,
		lastBeat: 0,
		cooldownUntil: 0,
		busyUntil: 0
	};
	stats.set(id, created);
	return created;
}
function noteWorker(id, kind) {
	if (!id) return;
	const stat = row(id);
	const now = Date.now();
	stat.lastBeat = now;
	if (kind === "ok") {
		stat.ok += 1;
		stat.lastOk = now;
		stat.busyUntil = 0;
		stat.cooldownUntil = 0;
	} else if (kind === "timeout") {
		stat.timeout += 1;
		stat.fail += 1;
		stat.busyUntil = 0;
		stat.cooldownUntil = now + 45e3;
	} else if (kind === "fail") {
		stat.fail += 1;
		stat.busyUntil = 0;
		stat.cooldownUntil = now + 45e3;
	} else stat.busyUntil = now + 2e4;
}
function healthOf(id, registered, hasKey, now = Date.now()) {
	if (!registered) return "OFFLINE";
	if (!hasKey) return "OFFLINE";
	const stat = stats.get(id);
	if (!stat) return "REGISTERED";
	if (stat.busyUntil > now) return "BUSY";
	if (stat.cooldownUntil > now) return stat.timeout > stat.ok ? "FAILED" : "COOLDOWN";
	if (stat.lastOk > 0 && now - stat.lastOk < 6e5) return "HEALTHY";
	if (stat.lastBeat > 0 && now - stat.lastBeat < 6e5) return "AVAILABLE";
	return "REGISTERED";
}
function routable(id, registered, hasKey, now = Date.now()) {
	const health = healthOf(id, registered, hasKey, now);
	return health === "HEALTHY" || health === "AVAILABLE" || health === "REGISTERED";
}
function emptyCall(reason, estimated = true) {
	return {
		text: null,
		failed: true,
		reason,
		inputTokens: 0,
		outputTokens: 0,
		estimated
	};
}
async function complete(url, model, messages, key = "") {
	const prompt = messages.map((item) => item.content).join("\n");
	try {
		const response = await fetch(url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				...key ? { Authorization: `Bearer ${key}` } : {}
			},
			signal: AbortSignal.timeout(15e3),
			body: JSON.stringify({
				model,
				max_tokens: 500,
				messages: messages.map((item) => item.image ? {
					role: item.role,
					content: [{
						type: "text",
						text: item.content
					}, {
						type: "image_url",
						image_url: { url: `data:image/jpeg;base64,${item.image}` }
					}]
				} : {
					role: item.role,
					content: item.content
				})
			})
		});
		if (!response.ok) return emptyCall(response.status === 429 ? "429" : `http-${response.status}`);
		const body = await response.json();
		const text = body.choices?.[0]?.message?.content?.trim() ?? "";
		const reportedIn = body.usage?.prompt_tokens;
		const reportedOut = body.usage?.completion_tokens;
		const estimated = reportedIn == null && reportedOut == null;
		const result = {
			text: (/^(open|click|type|scroll|back|wait|done|fail)\b/i.test(text) || /^\s*\{/.test(text) ? text.length > 0 : text.length >= 8) ? scrubSecrets(text.slice(0, 1500)) : null,
			failed: /api key|rate limit|unauthorized|quota|budget exceeded/i.test(text),
			reason: /rate limit|quota/i.test(text) ? "quota" : text ? "" : "empty",
			inputTokens: reportedIn ?? estimateTokens(prompt),
			outputTokens: reportedOut ?? estimateTokens(text),
			estimated
		};
		if (result.failed) result.text = null;
		return result;
	} catch (error) {
		const name = error instanceof Error ? error.name : "";
		const message = error instanceof Error ? scrubSecrets(error.message).slice(0, 80) : "network";
		if (name === "TimeoutError" || name === "AbortError" || /timeout|aborted/i.test(message)) return emptyCall("timeout");
		return emptyCall(message ? `down: ${message}` : "down");
	}
}
function sources() {
	const keyed = (name, url, model, secret, side) => ({
		name,
		side,
		local: false,
		call: (messages) => {
			const key = readSecret(secret);
			if (!key) return Promise.resolve(emptyCall("no-key"));
			return complete(url, model, messages, key);
		}
	});
	const list = [
		keyed("worker-gemini", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "gemini-2.0-flash", "GEMINI_API_KEY", "chief"),
		keyed("worker-openrouter", "https://openrouter.ai/api/v1/chat/completions", "google/gemma-4-26b-a4b-it:free", "OPENROUTER_API_KEY", "follower"),
		keyed("worker-openrouter-2", "https://openrouter.ai/api/v1/chat/completions", "inclusionai/ling-3.0-flash-sante:free", "OPENROUTER_API_KEY", "follower"),
		keyed("worker-hf", "https://router.huggingface.co/v1/chat/completions", "Qwen/Qwen2.5-7B-Instruct", "HF_TOKEN", "follower"),
		{
			name: "worker-ovh",
			side: "follower",
			local: false,
			call: (messages) => complete("https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/chat/completions", "gpt-oss-20b", messages)
		},
		{
			name: "worker-airforce",
			side: "follower",
			local: false,
			call: (messages) => complete("https://api.airforce/v1/chat/completions", "rnj-1", messages)
		},
		{
			name: "worker-airforce-2",
			side: "follower",
			local: false,
			call: (messages) => complete("https://api.airforce/v1/chat/completions", "llama-instant", messages)
		},
		{
			name: "worker-pollinations",
			side: "follower",
			local: false,
			call: async (messages) => {
				const latest = [...messages].reverse().find((message) => message.role === "user")?.content ?? "";
				try {
					const response = await fetch(`https://text.pollinations.ai/${encodeURIComponent(latest.slice(0, 1500))}`);
					if (!response.ok) return emptyCall(response.status === 429 ? "429" : `http-${response.status}`);
					const text = scrubSecrets((await response.text()).trim());
					if (text.length < 8) return emptyCall("empty");
					return {
						text: text.slice(0, 1500),
						failed: /api key|quota|budget/i.test(text),
						reason: "",
						inputTokens: estimateTokens(latest),
						outputTokens: estimateTokens(text),
						estimated: true
					};
				} catch (error) {
					return emptyCall(error instanceof Error ? error.message.slice(0, 80) : "network");
				}
			}
		},
		keyed("worker-xai", "https://api.x.ai/v1/chat/completions", "grok-4.5", "XAI_API_KEY", "chief"),
		keyed("worker-groq", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "GROQ_API_KEY", "follower")
	];
	const local = readSecret("LOCAL_OPENAI_URL") || readSecret("OPENAI_COMPAT_URL");
	if (local && /^https?:\/\//i.test(local)) list.push({
		name: "worker-local",
		side: "follower",
		local: true,
		call: (messages) => complete(local, readSecret("LOCAL_OPENAI_MODEL") || "local", messages, readSecret("LOCAL_OPENAI_KEY"))
	});
	return list;
}
function freeModels() {
	return allModels().map((row) => ({
		id: row.id,
		label: row.label,
		group: row.group,
		status: statusOf(row.id)
	}));
}
var pins = /* @__PURE__ */ new Map();
function pinModel(job, model) {
	const id = freeModels().some((row) => row.id === model) ? model : "";
	if (!id) pins.delete(job || "page");
	else pins.set(job || "page", id);
}
function clearPin(job) {
	pins.delete(job || "page");
}
function pinnedModel(job) {
	return pins.get(job || "page") ?? "";
}
function followerKind(id) {
	return id === "worker-xai" || id === "worker-gemini" ? "VISION_BROWSER_FOLLOWER" : "TEXT_BROWSER_FOLLOWER";
}
function outsideProviders() {
	return sources().filter((source) => !source.local);
}
function localProvider() {
	return sources().find((source) => source.local) ?? null;
}
function remember(job, slot, source, called, started) {
	recordUsage({
		at: (/* @__PURE__ */ new Date()).toISOString(),
		job,
		slot,
		follower: source.name,
		provider: source.name,
		side: source.side,
		inputTokens: called.inputTokens,
		outputTokens: called.outputTokens,
		estimated: called.estimated,
		wallMs: Date.now() - started,
		modelCalls: 1,
		ok: Boolean(called.text) && !called.failed
	});
}
async function callCheap(job, messages) {
	const pin = pinnedModel(job);
	if (pin) {
		if (!withinSpend(job, 0)) return null;
		const called = await runModel(job, "planner", pin, messages, false);
		if (called.reason === "no-key") return null;
		return called.text;
	}
	const all = outsideProviders();
	const chief = [
		...all.filter((source) => source.name === "worker-xai"),
		...all.filter((source) => source.name === "worker-gemini"),
		...all.filter((source) => source.name.startsWith("worker-openrouter")),
		...all.filter((source) => source.name.startsWith("worker-hf"))
	];
	for (const source of chief) {
		if (!withinSpend(job, 0)) return null;
		const started = Date.now();
		const called = await source.call(messages);
		remember(job, "planner", source, called, started);
		markFromCall(source.name, called);
		if (called.reason === "no-key") continue;
		if (called.text) return called.text;
	}
	return null;
}
function cannotDo(reason, text) {
	if (/429|quota|http-401|http-402|http-403|http-5|network|no-key|down|unable|timeout/.test(reason)) return true;
	return Boolean(text && /^(i'?m sorry|i can'?t|i cannot|i do not have the ability)/i.test(text.trim()));
}
async function once(job, slot, source, messages) {
	if (!withinSpend(job, source.side === "chief" ? 1 : 0)) return {
		called: emptyCall("spend"),
		follower: source.name
	};
	const started = Date.now();
	const called = await source.call(messages);
	remember(job, slot, source, called, started);
	markFromCall(source.name, called);
	if (called.reason === "timeout") noteWorker(source.name, "timeout");
	else if (called.text && !called.failed) noteWorker(source.name, "ok");
	else if (called.reason && called.reason !== "no-key" && called.reason !== "spend") noteWorker(source.name, "fail");
	return {
		called,
		follower: source.name
	};
}
async function withPings(id, messages) {
	try {
		const text = await unreadFor(id);
		if (!text) return messages;
		return [...messages, {
			role: "user",
			content: `UNREAD PINGS\n${text}`
		}];
	} catch {
		return messages;
	}
}
async function runModel(job, slot, id, messages, pings) {
	const packed = pings ? await withPings(id, messages) : messages;
	const source = sources().find((item) => item.name === id);
	if (source) {
		const { called } = await once(job, slot, source, packed);
		return called;
	}
	if (id.startsWith("hf:")) {
		const full = {
			...await callSpace(id.slice(3), packed),
			inputTokens: 0,
			outputTokens: 0,
			estimated: true
		};
		markFromCall(id, full);
		return full;
	}
	const missing = emptyCall("no-key");
	markFromCall(id, missing);
	return missing;
}
async function callFollower(job, slot, messages, onSwitch, prefer, skip = []) {
	const pin = pinnedModel(job);
	if (pin) {
		const called = await runModel(job, slot, pin, messages, true);
		return {
			text: called.text,
			follower: pin,
			reason: called.reason || (called.text ? "" : "empty"),
			tried: [pin]
		};
	}
	const cap = Number(process.env.QUAY_HIRE_FAILOVER_MAX ?? 3);
	const skipped = new Set(skip);
	const all = outsideProviders().filter((source) => !skipped.has(source.name));
	const alive = (source) => routable(source.name, true, statusOf(source.name) !== "Key missing");
	const pool = [
		...all.filter((source) => /xai|groq/.test(source.name)),
		...all.filter((source) => /openrouter|hf/.test(source.name)),
		...all.filter((source) => /ovh|airforce|pollinations/.test(source.name)),
		...all.filter((source) => source.name === "worker-gemini")
	].filter(alive);
	const local = localProvider();
	const tried = [];
	let switches = 0;
	let lastReason = "empty";
	const held = prefer ? sources().find((source) => source.name === prefer && !skipped.has(source.name)) : void 0;
	if (held) {
		tried.push(held.name);
		const { called } = await once(job, slot, held, await withPings(held.name, messages));
		if (called.reason === "no-key") lastReason = "no-key";
		else if (!cannotDo(called.reason, called.text)) return {
			text: called.text,
			follower: held.name,
			reason: called.reason || (called.text ? "" : "empty"),
			tried
		};
		else {
			lastReason = cannotDo("", called.text) ? "unable" : called.reason || "down";
			const next = pool.find((source) => source.name !== held.name) ?? (local && local.name !== held.name ? local : void 0);
			if (next && onSwitch) await onSwitch(held.name, next.name, lastReason);
		}
	}
	for (let index = 0; index < pool.length; index += 1) {
		const source = pool[index];
		if (source.name === held?.name) continue;
		tried.push(source.name);
		const { called } = await once(job, slot, source, await withPings(source.name, messages));
		if (called.reason === "no-key") continue;
		if (called.text && !called.failed && !cannotDo("", called.text)) return {
			text: called.text,
			follower: source.name,
			reason: "",
			tried
		};
		if (!cannotDo(called.reason, called.text)) return {
			text: called.text,
			follower: source.name,
			reason: called.reason || "empty",
			tried
		};
		lastReason = cannotDo("", called.text) ? "unable" : called.reason;
		const next = pool[index + 1];
		if (!next || switches >= cap) {
			if (local && local.name !== source.name && onSwitch) await onSwitch(source.name, local.name, lastReason);
			break;
		}
		switches += 1;
		if (onSwitch) await onSwitch(source.name, next.name, lastReason);
	}
	if (!local || skipped.has(local.name) || local.name === held?.name) return {
		text: null,
		follower: "",
		reason: tried.length ? "repository-empty" : lastReason,
		tried
	};
	if (!withinSpend(job, 0)) return {
		text: null,
		follower: local.name,
		reason: "spend",
		tried
	};
	tried.push(local.name);
	const { called } = await once(job, slot, local, await withPings(local.name, messages));
	if (called.text && !called.failed && !cannotDo(called.reason, called.text)) return {
		text: called.text,
		follower: local.name,
		reason: "",
		tried
	};
	return {
		text: called.text,
		follower: local.name,
		reason: called.reason || lastReason,
		tried
	};
}
var audits = /* @__PURE__ */ new Map();
var seenRepo = /* @__PURE__ */ new Set();
function empty() {
	return {
		pages: 0,
		clicks: 0,
		scrolls: 0,
		shots: 0,
		types: 0,
		backs: 0,
		waits: 0,
		interactive: 0,
		replacements: 0,
		protocol: 0,
		repo: 0,
		failed: false,
		website: false,
		created: false,
		operated: false,
		vision: false,
		done: false,
		sessionId: "",
		follower: "",
		initialUrl: "",
		finalUrl: "",
		verdict: "",
		trace: []
	};
}
function bag(job) {
	const key = job || "page";
	const existing = audits.get(key);
	if (existing) return existing;
	const created = empty();
	audits.set(key, created);
	return created;
}
function noteSandbox(job, change) {
	const row = bag(job);
	row.pages += change.pages ?? 0;
	row.clicks += change.clicks ?? 0;
	row.scrolls += change.scrolls ?? 0;
	row.shots += change.shots ?? 0;
}
function setSandboxReport(job, report) {
	const row = bag(job);
	row.created = report.created;
	row.operated = report.operated;
	row.vision = report.vision;
	row.done = report.done;
	row.sessionId = report.sessionId;
	row.follower = report.follower;
	row.initialUrl = report.initialUrl;
	row.finalUrl = report.finalUrl;
	row.pages = report.pages;
	row.interactive = report.interactive;
	row.clicks = report.clicks;
	row.types = report.types;
	row.scrolls = report.scrolls;
	row.shots = report.shots;
	row.replacements = report.replacements;
	row.protocol = report.protocol;
	row.verdict = report.verdict;
	row.trace = report.trace.slice(0, 24);
	if (report.created) row.website = true;
}
function noteRepoMatches(job, ids) {
	const row = bag(job);
	for (const id of ids) {
		const key = `${job}:${id}`;
		if (!id || seenRepo.has(key)) continue;
		seenRepo.add(key);
		row.repo += 1;
	}
}
function markFailedStep(job) {
	bag(job).failed = true;
}
function clearFailed(job) {
	bag(job).failed = false;
}
function markWebsite(job) {
	bag(job).website = true;
}
function sandboxFailed(job) {
	const row = bag(job);
	return row.website && row.failed && !row.operated && row.verdict !== "PASS";
}
function auditLines(job) {
	const row = bag(job);
	const lines = [`Task type: ${row.website ? "WEB_TASK" : "NON_WEB_TASK"}`];
	if (!row.created) lines.push("Sandbox created: NO");
	else {
		lines.push("Sandbox created: YES");
		lines.push(`Sandbox session: ${row.sessionId || "none"}`);
		lines.push(`Browser follower: ${row.follower || "none"}`);
		lines.push(`Vision input: ${row.vision ? "YES" : "NO"}`);
		lines.push(`Initial URL: ${row.initialUrl || "none"}`);
		lines.push(`Final URL: ${row.finalUrl || "none"}`);
		lines.push(`Pages opened: ${row.pages}`);
		lines.push(`Interactive actions: ${row.interactive}`);
		lines.push(`Clicks: ${row.clicks}`);
		lines.push(`Types: ${row.types}`);
		lines.push(`Scrolls: ${row.scrolls}`);
		lines.push(`Screenshots: ${row.shots}`);
		lines.push(`Follower replacements: ${row.replacements}`);
		lines.push(`Protocol corrections: ${row.protocol}`);
		lines.push(`DONE received: ${row.done ? "YES" : "NO"}`);
		lines.push(`Chief verdict: ${row.verdict || "INCOMPLETE"}`);
		if (row.operated && row.trace.length > 0) {
			lines.push("Browser trace:");
			lines.push(...row.trace);
		} else if (!row.operated) lines.push("No follower-operated sandbox trace.");
	}
	lines.push(`Failure repository: ${row.repo} matches used.`);
	return lines;
}
function clearAudit(job) {
	audits.delete(job || "page");
}
var TEMPLATE$1 = () => process.env.QUAY_E2B_BROWSER_TEMPLATE || "quay-reader-chromium";
function scriptText(path) {
	return readFileSync(path, "utf8");
}
async function openRemoteBrowser(scriptPath, url, source = "") {
	const { resolveE2bKey } = await import("./e2b-key.server-DGZlzSBT.mjs");
	const apiKey = await resolveE2bKey();
	if (!apiKey) return { error: "E2B_API_KEY missing" };
	let text = source;
	if (!text && scriptPath) try {
		text = scriptText(scriptPath);
	} catch {
		text = "";
	}
	if (!text) return { error: "sandbox script missing" };
	const started = Date.now();
	try {
		const { Sandbox } = await import("../_libs/e2b+openapi-fetch+platform.mjs").then((n) => n.t);
		const sandbox = await Sandbox.create(TEMPLATE$1(), {
			apiKey,
			timeoutMs: 18e4,
			allowInternetAccess: true
		});
		const installed = await sandbox.commands.run("npm install --prefix /tmp/pw playwright-core@1.55.0 --silent", { timeoutMs: 4e4 });
		if (installed.exitCode) {
			await sandbox.kill().catch(() => void 0);
			return { error: scrubSecrets(installed.stderr || "playwright-core install failed").slice(0, 180) };
		}
		await sandbox.files.write("/tmp/sandbox-session.mjs", text);
		const waiters = [];
		let buffer = "";
		let stderr = "";
		const take = (chunk) => {
			buffer += chunk;
			let cut = buffer.indexOf("\n");
			while (cut >= 0) {
				const line = buffer.slice(0, cut);
				buffer = buffer.slice(cut + 1);
				let parsed = null;
				try {
					parsed = JSON.parse(line);
				} catch {
					parsed = null;
				}
				waiters.shift()?.(parsed);
				cut = buffer.indexOf("\n");
			}
		};
		const handle = await sandbox.commands.run("NODE_PATH=/tmp/pw/node_modules QUAY_CHROMIUM=/usr/local/bin/chromium node /tmp/sandbox-session.mjs", {
			background: true,
			stdin: true,
			timeoutMs: 3e5,
			onStdout: (data) => take(data),
			onStderr: (data) => {
				stderr = `${stderr}${data}`.slice(-400);
			}
		});
		const send = (cmd) => new Promise((resolve) => {
			const timer = setTimeout(() => resolve(null), 2e4);
			waiters.push((value) => {
				clearTimeout(timer);
				resolve(value);
			});
			handle.sendStdin(`${JSON.stringify(cmd)}\n`).catch(() => {
				clearTimeout(timer);
				resolve(null);
			});
		});
		const reply = await send({
			cmd: "open",
			url
		});
		const screen = reply && reply.ok !== false && reply.screen && typeof reply.screen === "object" ? reply.screen : null;
		if (!screen) {
			await sandbox.kill().catch(() => void 0);
			return { error: scrubSecrets(stderr || "remote browser did not return a screen").slice(0, 180) };
		}
		return {
			screen,
			browser: {
				send,
				close: async () => {
					try {
						await handle.sendStdin(`${JSON.stringify({ cmd: "close" })}\n`);
					} catch {}
					await sandbox.kill().catch(() => void 0);
				}
			}
		};
	} catch (error) {
		const message = error instanceof Error ? error.message : "e2b failed";
		return { error: `${scrubSecrets(message).slice(0, 160)} ${Date.now() - started}ms` };
	}
}
var held = /* @__PURE__ */ new Map();
var panels = /* @__PURE__ */ new Map();
var fault = null;
function lastSandboxFault() {
	return fault;
}
function scriptFile() {
	return locateSandboxScript().path;
}
function sandboxScriptDiagnostic() {
	return locateSandboxScript().diagnostic;
}
function rememberFault(row) {
	fault = {
		attempt: row.attempt ?? 1,
		...row,
		message: row.message.slice(0, 180)
	};
}
async function localBrowser() {
	try {
		await import("playwright");
		return {
			ok: true,
			error: ""
		};
	} catch (error) {
		return {
			ok: false,
			error: error instanceof Error ? error.message.slice(0, 160) : "playwright missing"
		};
	}
}
function parseBrowserCommand(raw) {
	const clean = raw.replace(/```[a-z]*|```/gi, " ").trim();
	const line = clean.split(/\n/).map((item) => item.trim()).find((item) => /^(open|click|type|scroll|back|wait|done|fail)\b/i.test(item)) ?? clean;
	const open = line.match(/^open\s+(https?:\/\/\S+)/i);
	if (open?.[1]) return {
		kind: "open",
		url: open[1].replace(/[.,]+$/, "")
	};
	const click = line.match(/^click\s+(\d+)/i);
	if (click?.[1]) return {
		kind: "click",
		id: click[1]
	};
	const typed = line.match(/^type\s+(.+?)\s+in\s+(\d+)\s*$/i);
	if (typed?.[1] && typed[2]) return {
		kind: "type",
		id: typed[2],
		text: typed[1].replace(/^["']|["']$/g, "").slice(0, 160)
	};
	if (/^scroll\s+up\b/i.test(line)) return {
		kind: "scroll",
		dir: "up"
	};
	if (/^scroll(\s+down)?\b/i.test(line)) return {
		kind: "scroll",
		dir: "down"
	};
	if (/^back\b/i.test(line)) return { kind: "back" };
	if (/^wait\b/i.test(line)) return { kind: "wait" };
	const done = line.match(/^done\b[:\s-]*(.*)$/i);
	if (done) return {
		kind: "done",
		text: (done[1] ?? "").trim().slice(0, 500)
	};
	const fail = line.match(/^fail\b[:\s-]*(.*)$/i);
	if (fail) return {
		kind: "fail",
		reason: (fail[1] ?? "").trim().slice(0, 240)
	};
	const start = clean.indexOf("{");
	const end = clean.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		const json = JSON.parse(clean.slice(start, end + 1));
		const act = String(json.act ?? json.cmd ?? "").toLowerCase();
		if (act === "open") return {
			kind: "open",
			url: String(json.url ?? "")
		};
		if (act === "click") return {
			kind: "click",
			id: String(json.id ?? "")
		};
		if (act === "type") return {
			kind: "type",
			id: String(json.id ?? ""),
			text: String(json.text ?? "").slice(0, 160)
		};
		if (act === "scroll") return {
			kind: "scroll",
			dir: String(json.dir ?? "down") === "up" ? "up" : "down"
		};
		if (act === "back") return { kind: "back" };
		if (act === "wait") return { kind: "wait" };
		if (act === "found" || act === "done") return {
			kind: "done",
			text: String(json.found ?? json.text ?? "").slice(0, 500)
		};
		if (act === "fail" || act === "none") return {
			kind: "fail",
			reason: String(json.reason ?? "none")
		};
		return null;
	} catch {
		return null;
	}
}
var STOP = /* @__PURE__ */ new Set([
	"that",
	"this",
	"with",
	"from",
	"have",
	"were",
	"been",
	"your",
	"about",
	"there",
	"their",
	"which",
	"what",
	"when",
	"where"
]);
function answerOnScreen(answer, screen, history) {
	const hay = `${screen.text} ${screen.title} ${screen.url} ${history}`.toLowerCase();
	const tokens = (answer.toLowerCase().match(/[a-z0-9]{4,}/g) ?? []).filter((token) => !STOP.has(token));
	if (tokens.length === 0) return answer.trim().length > 8 && hay.includes(answer.trim().toLowerCase().slice(0, 24));
	return tokens.filter((token) => hay.includes(token)).length >= Math.min(2, tokens.length);
}
function asScreen(value) {
	if (!value || typeof value !== "object") return null;
	const row = value;
	const options = Array.isArray(row.options) ? row.options.map((item) => {
		const option = item;
		return {
			id: String(option.id ?? ""),
			kind: String(option.kind ?? "link"),
			label: String(option.label ?? ""),
			x: Number(option.x ?? 0),
			y: Number(option.y ?? 0)
		};
	}).filter((option) => option.id && option.label) : [];
	if (!row.url && !row.shot && !row.text) return null;
	return {
		url: String(row.url ?? ""),
		title: String(row.title ?? "Page"),
		text: String(row.text ?? ""),
		moreBelow: Boolean(row.moreBelow),
		moreAbove: Boolean(row.moreAbove),
		options,
		shot: String(row.shot ?? "")
	};
}
function keyOf(job, step) {
	return `${job || "page"}:${step}`;
}
function commandLabel(cmd) {
	if (cmd.kind === "open") return `OPEN ${cmd.url}`;
	if (cmd.kind === "click") return `CLICK ${cmd.id}`;
	if (cmd.kind === "type") return `TYPE ${cmd.text} IN ${cmd.id}`;
	if (cmd.kind === "scroll") return cmd.dir === "up" ? "SCROLL UP" : "SCROLL DOWN";
	if (cmd.kind === "back") return "BACK";
	if (cmd.kind === "wait") return "WAIT";
	if (cmd.kind === "done") return `DONE ${cmd.text}`;
	return `FAIL ${cmd.reason}`;
}
function fingerprint(screen) {
	return `${screen.url}|${screen.text.slice(0, 180)}|${screen.options.map((option) => option.label).join(",")}`;
}
function publish(row) {
	const panel = {
		active: !row.closing && !row.crashed,
		follower: labelOf(row.follower),
		step: row.step,
		action: row.action,
		actions: row.interactive,
		url: row.screen.url,
		typing: row.typing,
		scrolling: row.scrolling,
		clickX: row.clickX,
		clickY: row.clickY,
		sessionId: row.id
	};
	panels.set(row.job || "page", panel);
	if (row.screen.shot) rememberShot(row.job, row.screen.shot, row.screen.url);
}
function syncReport(row) {
	setSandboxReport(row.job, {
		created: true,
		operated: row.operated,
		vision: row.kind === "VISION_BROWSER_FOLLOWER",
		done: row.done,
		sessionId: row.id,
		follower: labelOf(row.follower),
		initialUrl: row.initialUrl,
		finalUrl: row.screen.url,
		pages: row.pages,
		interactive: row.interactive,
		clicks: row.clicks,
		types: row.types,
		scrolls: row.scrolls,
		shots: row.shots,
		replacements: row.replacements,
		protocol: row.protocol,
		verdict: row.verdict,
		trace: row.receipts.map((item) => `${item.n} ${item.command} ${item.ok ? "ok" : "failed"} ${item.urlBefore || "?"} -> ${item.urlAfter || "?"} ${item.reason}`.replace(/\s+/g, " ").trim())
	});
}
function readLive(job) {
	return panels.get(job || "page") ?? null;
}
function attach(child) {
	const waiters = [];
	let buffer = "";
	child.stdout.on("data", (chunk) => {
		buffer += chunk.toString("utf8");
		let cut = buffer.indexOf("\n");
		while (cut >= 0) {
			const line = buffer.slice(0, cut);
			buffer = buffer.slice(cut + 1);
			let parsed = null;
			try {
				parsed = JSON.parse(line);
			} catch {
				parsed = null;
			}
			waiters.shift()?.(parsed);
			cut = buffer.indexOf("\n");
		}
	});
	child.on("close", () => {
		while (waiters.length > 0) waiters.shift()?.(null);
	});
	return (cmd) => new Promise((done) => {
		waiters.push(done);
		child.stdin.write(`${JSON.stringify(cmd)}\n`);
	});
}
async function openLocal(url) {
	const script = scriptFile();
	if (!script) return { error: "sandbox script missing" };
	const ready = await localBrowser();
	if (!ready.ok) return { error: ready.error };
	const started = Date.now();
	let stderr = "";
	const child = spawn(process.execPath, [script], { stdio: [
		"pipe",
		"pipe",
		"pipe"
	] });
	child.stderr.on("data", (chunk) => {
		stderr = `${stderr}${chunk.toString("utf8")}`.slice(-400);
	});
	const send = attach(child);
	const reply = await Promise.race([send({
		cmd: "open",
		url
	}), new Promise((resolve) => setTimeout(() => resolve(null), 15e3))]);
	const screen = reply && reply.ok !== false ? asScreen(reply.screen) : null;
	if (!screen) {
		child.kill();
		return { error: `${(stderr.trim() || (reply ? String(reply.error || "local browser returned no screen") : "local browser timed out")).slice(0, 160)} ${Date.now() - started}ms` };
	}
	child.on("close", () => void 0);
	return {
		send,
		screen,
		note: "",
		end: () => {
			try {
				child.stdin.write(`${JSON.stringify({ cmd: "close" })}\n`);
			} catch {}
			child.kill();
		}
	};
}
function adopt(job, step, follower, runtime, opened) {
	const row = {
		id: `${Date.now().toString(36)}-${step}`,
		job: job || "page",
		step,
		send: opened.send,
		end: opened.end,
		runtime,
		screen: opened.screen,
		crashed: false,
		closing: false,
		follower,
		kind: followerKind(follower),
		action: "OPEN",
		typing: "",
		scrolling: "",
		clickX: 0,
		clickY: 0,
		initialUrl: opened.screen.url,
		pages: 1,
		interactive: 0,
		clicks: 0,
		types: 0,
		scrolls: 0,
		backs: 0,
		waits: 0,
		shots: opened.screen.shot ? 1 : 0,
		replacements: 0,
		protocol: 0,
		done: false,
		operated: false,
		verdict: "INCOMPLETE",
		answer: "",
		history: [],
		receipts: [],
		notice: ""
	};
	held.set(keyOf(job, step), row);
	publish(row);
	syncReport(row);
	pushTrace(job, `Sandbox ready ${opened.screen.url}`);
	return row;
}
async function openHeld(job, step, url, follower) {
	const started = Date.now();
	pushTrace(job, "Sandbox starting");
	if (preferRuntime !== "e2b") {
		const local = await openLocal(url);
		if (!("error" in local)) return adopt(job, step, follower, "local", local);
		rememberFault({
			taskId: job,
			endpoint: "local-chromium",
			errorClass: "LOCAL_BROWSER",
			message: local.error,
			durationMs: Date.now() - started,
			sessionId: "",
			url
		});
		pushTrace(job, `Local sandbox failed: ${local.error}`);
	}
	const remote = await openRemoteBrowser(scriptFile(), url, locateSandboxScript().source);
	if ("error" in remote) {
		rememberFault({
			taskId: job,
			attempt: 2,
			endpoint: "e2b",
			errorClass: "E2B_BROWSER",
			message: remote.error,
			durationMs: Date.now() - started,
			sessionId: "",
			url
		});
		pushTrace(job, `SANDBOX FAILED ${remote.error}`);
		return null;
	}
	const screen = asScreen(remote.screen);
	if (!screen) {
		await remote.browser.close();
		rememberFault({
			taskId: job,
			attempt: 2,
			endpoint: "e2b",
			errorClass: "E2B_SCREEN",
			message: "remote browser returned no screen",
			durationMs: Date.now() - started,
			sessionId: "",
			url
		});
		return null;
	}
	return adopt(job, step, follower, "e2b", {
		send: remote.browser.send,
		end: () => void remote.browser.close(),
		screen
	});
}
async function releaseBrowser(job, step) {
	const row = held.get(keyOf(job, step));
	if (!row) return;
	row.closing = true;
	publish(row);
	syncReport(row);
	row.end();
	held.delete(keyOf(job, step));
}
function screenPrompt(task, goal, row) {
	const options = row.screen.options.map((option) => `${option.id}. ${option.kind}: ${option.label}`).join("\n");
	const extras = [row.screen.moreBelow ? "scroll: more of this page is below" : "", row.screen.moreAbove ? "back: leave this screen" : ""].filter(Boolean);
	const shotLine = row.kind === "VISION_BROWSER_FOLLOWER" ? "Current screenshot: attached." : "TEXT_BROWSER_FOLLOWER. You are not receiving a screenshot. Use the structured screen below.";
	return [
		`TASK\n${task}`,
		`GOAL\n${goal}`,
		shotLine,
		`Current URL:\n${row.screen.url}`,
		`Title: ${row.screen.title}`,
		`VISIBLE\n${row.screen.text.slice(0, 900) || "(no text on this screen)"}`,
		`Current available elements:\n${options || "(none)"}`,
		extras.join("\n"),
		`Action history:\n${row.history.join("\n") || "none"}`,
		row.notice,
		"Reply with exactly one action: OPEN [url], CLICK [id], TYPE [text] IN [id], SCROLL DOWN, SCROLL UP, BACK, WAIT, DONE [answer], or FAIL [reason]."
	].filter(Boolean).join("\n\n");
}
async function perform(row, cmd) {
	const before = row.screen.url;
	const shotBefore = Boolean(row.screen.shot);
	row.typing = "";
	row.scrolling = "";
	if (cmd.kind === "click") {
		const option = row.screen.options.find((item) => item.id === cmd.id);
		if (!option) return {
			ok: false,
			reason: `element ${cmd.id} is no longer available`
		};
		row.clickX = option.x;
		row.clickY = option.y;
	}
	if (cmd.kind === "type") {
		const option = row.screen.options.find((item) => item.id === cmd.id);
		if (!option || option.kind !== "form") return {
			ok: false,
			reason: `element ${cmd.id} is not a field`
		};
		row.typing = option.label;
	}
	if (cmd.kind === "scroll") {
		if (cmd.dir === "down" && !row.screen.moreBelow) return {
			ok: false,
			reason: "no more page below"
		};
		if (cmd.dir === "up" && !row.screen.moreAbove) return {
			ok: false,
			reason: "no more page above"
		};
		row.scrolling = cmd.dir === "up" ? "Scrolling up" : "Scrolling down";
	}
	const packet = cmd.kind === "open" ? {
		cmd: "open",
		url: cmd.url
	} : cmd.kind === "click" ? {
		cmd: "click",
		id: cmd.id
	} : cmd.kind === "type" ? {
		cmd: "type",
		id: cmd.id,
		text: cmd.text
	} : cmd.kind === "scroll" ? {
		cmd: "scroll",
		dir: cmd.dir
	} : cmd.kind === "back" ? { cmd: "back" } : { cmd: "wait" };
	const reply = await row.send(packet);
	if (!reply) {
		row.crashed = true;
		return {
			ok: false,
			reason: "sandbox stopped"
		};
	}
	const next = asScreen(reply.screen);
	if (next) {
		row.screen = next;
		row.shots += next.shot ? 1 : 0;
	}
	const click = reply.click;
	if (cmd.kind === "click" && click) {
		row.clickX = Number(click.x ?? row.clickX);
		row.clickY = Number(click.y ?? row.clickY);
	}
	const ok = reply.ok !== false;
	const reason = ok ? "" : String(reply.error ?? "action failed").slice(0, 160);
	row.interactive += 1;
	row.operated = true;
	if (cmd.kind === "click") row.clicks += 1;
	if (cmd.kind === "type") row.types += 1;
	if (cmd.kind === "scroll") row.scrolls += 1;
	if (cmd.kind === "back") row.backs += 1;
	if (cmd.kind === "wait") row.waits += 1;
	if (cmd.kind === "open") row.pages += 1;
	const label = commandLabel(cmd);
	row.action = label;
	row.history.push(`${label} ${ok ? "ok" : "failed"}`.slice(0, 180));
	row.history = row.history.slice(-12);
	row.receipts.push({
		n: row.receipts.length + 1,
		at: (/* @__PURE__ */ new Date()).toISOString(),
		follower: row.follower,
		command: label,
		urlBefore: before,
		urlAfter: row.screen.url,
		ok,
		reason,
		shotBefore,
		shotAfter: Boolean(row.screen.shot)
	});
	publish(row);
	syncReport(row);
	return {
		ok,
		reason
	};
}
async function runBrowserFollower(input) {
	const slot = keyOf(input.job, input.step);
	const existing = held.get(slot);
	let row = input.continueSession && existing && !existing.crashed && !existing.closing ? existing : void 0;
	if (!row) {
		if (existing) await releaseBrowser(input.job, input.step);
		row = await openHeld(input.job, input.step, input.url, input.follower) ?? void 0;
	}
	if (!row) return {
		verdict: "SANDBOX_TECHNICAL_FAILURE",
		answer: "",
		follower: input.follower,
		sessionId: "",
		url: "",
		operated: false
	};
	row.follower = input.follower || row.follower;
	row.kind = followerKind(row.follower);
	row.verdict = "INCOMPLETE";
	row.notice = input.continueSession ? "A previous follower stopped. Continue this same page. Do not restart unless you must OPEN a url." : "";
	let protocol = 0;
	let stagnant = 0;
	let lastState = "";
	let lastCommand = "";
	const missed = /* @__PURE__ */ new Set();
	for (let safety = 0; safety < 30; safety += 1) {
		if (row.crashed) {
			row.verdict = "SANDBOX_TECHNICAL_FAILURE";
			break;
		}
		publish(row);
		const prompt = screenPrompt(input.task, input.goal, row);
		const asked = await input.ask({
			follower: row.follower,
			kind: row.kind,
			prompt,
			image: row.kind === "VISION_BROWSER_FOLLOWER" ? row.screen.shot : void 0,
			screen: row.screen
		});
		if (asked.follower) row.follower = asked.follower;
		const cmd = parseBrowserCommand(asked.text || "");
		if (!cmd) {
			protocol += 1;
			row.protocol += 1;
			row.notice = "INVALID BROWSER COMMAND. You are controlling an active Quay sandbox. Reply with exactly ONE valid action. Do not explain. Choose one action.";
			syncReport(row);
			if (protocol >= 3) {
				row.verdict = "FOLLOWER_PROTOCOL_FAILURE";
				break;
			}
			continue;
		}
		protocol = 0;
		if (cmd.kind === "done") {
			const claim = cmd.text || row.screen.title;
			if (!answerOnScreen(claim, row.screen, row.history.join(" "))) {
				row.notice = "The claimed evidence was not found on this screen. Stay on this page and choose another action, or DONE only with words that are visible.";
				row.verdict = "WRONG_ANSWER";
				continue;
			}
			row.done = true;
			row.operated = true;
			row.answer = claim;
			row.action = `DONE ${claim}`.slice(0, 180);
			row.verdict = "PASS";
			row.notice = "";
			row.receipts.push({
				n: row.receipts.length + 1,
				at: (/* @__PURE__ */ new Date()).toISOString(),
				follower: row.follower,
				command: row.action,
				urlBefore: row.screen.url,
				urlAfter: row.screen.url,
				ok: true,
				reason: "",
				shotBefore: Boolean(row.screen.shot),
				shotAfter: Boolean(row.screen.shot)
			});
			publish(row);
			syncReport(row);
			break;
		}
		if (cmd.kind === "fail") {
			row.notice = cmd.reason || "follower stopped";
			row.verdict = "INCOMPLETE";
			row.action = commandLabel(cmd);
			publish(row);
			break;
		}
		const state = fingerprint(row.screen);
		const label = commandLabel(cmd);
		if (state === lastState && label === lastCommand) {
			stagnant += 1;
			row.notice = "That action did not change the screen. Choose a different action.";
			if (stagnant >= 3) {
				row.verdict = "INCOMPLETE";
				break;
			}
		} else stagnant = 0;
		lastState = state;
		lastCommand = label;
		if (missed.has(label) && cmd.kind !== "wait") {
			row.notice = `ACTION FAILED. ${label} already failed. Choose another action.`;
			continue;
		}
		const result = await perform(row, cmd);
		if (row.crashed) {
			row.verdict = "SANDBOX_TECHNICAL_FAILURE";
			break;
		}
		if (!result.ok) {
			missed.add(label);
			row.notice = `ACTION FAILED\nReason: ${result.reason}\nChoose another action.`;
			continue;
		}
		row.notice = "";
		row.verdict = "INCOMPLETE";
	}
	syncReport(row);
	publish(row);
	return {
		verdict: row.verdict,
		answer: row.answer,
		follower: row.follower,
		sessionId: row.id,
		url: row.screen.url,
		operated: row.operated
	};
}
function markReplacement(job, step) {
	const row = held.get(keyOf(job, step));
	if (!row) return;
	row.replacements += 1;
	syncReport(row);
}
var preferRuntime = "auto";
async function probeSandbox() {
	const script = sandboxScriptDiagnostic();
	const job = `probe-${Date.now()}`;
	const row = await openHeld(job, 1, "https://example.com", "probe");
	if (!row) return {
		ok: false,
		browserAvailable: false,
		canCreateSession: false,
		runtime: "",
		url: "",
		title: "",
		text: "",
		sessionId: "",
		error: !script.exists ? `sandbox script missing path=${script.path || "(none)"} exists=false cwd=${script.cwd} runtime=${script.runtime}` : fault?.message || "sandbox did not start",
		script
	};
	const result = {
		ok: /example domain/i.test(row.screen.title),
		browserAvailable: true,
		canCreateSession: true,
		runtime: row.runtime,
		url: row.screen.url,
		title: row.screen.title,
		text: row.screen.text.slice(0, 400),
		sessionId: row.id,
		error: "",
		script
	};
	await releaseBrowser(job, 1);
	return result;
}
var traces = /* @__PURE__ */ new Map();
function beginTrace(job, model) {
	traces.set(job || "page", {
		model,
		started: Date.now(),
		cycles: 0,
		loops: 0,
		misses: [],
		hires: []
	});
}
function noteCycle(job) {
	const trace = traces.get(job || "page");
	if (trace) trace.cycles += 1;
}
function noteLoop(job) {
	const trace = traces.get(job || "page");
	if (trace) trace.loops += 1;
}
function noteMiss(job, step, first) {
	const trace = traces.get(job || "page");
	if (!trace || trace.misses.some((miss) => miss.step === step)) return;
	trace.misses.push({
		step,
		first: first.replace(/\s+/g, " ").trim().slice(0, 180),
		fix: ""
	});
}
function noteFix(job, step, fix) {
	const miss = traces.get(job || "page")?.misses.find((row) => row.step === step);
	if (miss) miss.fix = fix.replace(/\s+/g, " ").trim().slice(0, 180);
}
function noteHire(job, step, name, role, used = true) {
	const trace = traces.get(job || "page");
	const clean = name.replace(/\s+/g, " ").trim().slice(0, 120);
	if (!trace || !clean) return;
	const existing = trace.hires.find((hire) => hire.step === step && hire.name === clean && hire.role === role);
	if (existing) {
		if (used) existing.used = true;
		return;
	}
	trace.hires.push({
		step,
		name: clean,
		role,
		used,
		helped: false
	});
}
function passHires(job, step) {
	const trace = traces.get(job || "page");
	if (!trace) return;
	for (const hire of trace.hires) if (hire.step === step && hire.used) hire.helped = true;
}
function finishTrace(job, pass) {
	const trace = traces.get(job || "page");
	traces.delete(job || "page");
	if (!trace) return "";
	const seconds = Math.max(1, Math.round((Date.now() - trace.started) / 1e3));
	const lines = [`Model: ${trace.model}`, `Cycles: ${trace.cycles}. Redundancy loops: ${trace.loops}.`];
	if (trace.misses.length === 0) lines.push("No step failed.");
	for (const miss of trace.misses) lines.push(`Step ${miss.step} failed first: ${miss.first || "threshold"}. Fix: ${miss.fix || "still open"}.`);
	if (trace.hires.length === 0) lines.push("No bots hired.");
	for (const hire of trace.hires) lines.push(`Hired: ${hire.name} · ${hire.role} · ${hire.helped ? "led to a pass" : "did not lead to a pass"}.`);
	lines.push(...auditLines(job));
	lines.push(`Time: ${seconds}s`);
	lines.push(pass ? "PASS" : "FAIL");
	return lines.join("\n");
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ORIGIN = "https://infoveil.grok.me";
var READER = "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)";
function quayChannel(job) {
	return `quay-${(job || "job").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 40) || "job"}`;
}
function forVeil(line) {
	const text = line.replace(/\s+/g, " ").trim();
	if (!text) return "";
	if (/password|passcode|\bssn\b|social security|\bcvv\b|card number|KIND\s+(type|values)/i.test(text)) return "";
	return text.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "{EMAIL}").replace(/\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/g, "{PHONE}").slice(0, 3500);
}
async function postBotMessage(channel, envelope) {
	const line = forVeil(envelope.line);
	if (!line) return "";
	try {
		const response = await fetch(`${ORIGIN}/api/bot/post`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Accept: "application/json",
				"User-Agent": READER
			},
			body: JSON.stringify({
				channel,
				envelope: {
					...envelope,
					line
				}
			}),
			signal: AbortSignal.timeout(12e3)
		});
		if (!response.ok) return "";
		const data = await response.json();
		return data.ok ? String(data.id ?? "") : "";
	} catch {
		return "";
	}
}
async function postBotText(channel, text) {
	const sent = await deliverBotText(channel, text);
	return sent.ok ? sent.id : "";
}
async function deliverBotText(channel, text) {
	const line = forVeil(text);
	if (!line) return {
		ok: false,
		id: "",
		error: "empty",
		status: 0
	};
	const started = Date.now();
	try {
		const response = await fetch(`${ORIGIN}/api/bot/post`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Accept: "application/json",
				"User-Agent": READER
			},
			body: JSON.stringify({
				channel,
				envelope: line
			}),
			signal: AbortSignal.timeout(8e3)
		});
		if (!response.ok) return {
			ok: false,
			id: "",
			error: `http-${response.status}`,
			status: response.status
		};
		const data = await response.json();
		if (!data.ok) return {
			ok: false,
			id: "",
			error: "rejected",
			status: response.status
		};
		return {
			ok: true,
			id: String(data.id ?? ""),
			error: "",
			status: response.status
		};
	} catch (error) {
		return {
			ok: false,
			id: "",
			error: `${error instanceof Error ? error.name || error.message : "network"} ${Date.now() - started}ms`.slice(0, 80),
			status: 0
		};
	}
}
async function readChannel(channel) {
	try {
		const url = new URL("/api/bot/read", ORIGIN);
		url.searchParams.set("channel", channel);
		const response = await fetch(url, {
			headers: {
				Accept: "application/json",
				"User-Agent": READER
			},
			signal: AbortSignal.timeout(12e3)
		});
		if (!response.ok) return {
			ok: false,
			error: (await response.text()).replace(/\s+/g, " ").trim().slice(0, 180) || "Veil did not answer.",
			messages: []
		};
		return {
			ok: true,
			error: "",
			messages: ((await response.json()).messages ?? []).map((row) => ({
				id: String(row.id ?? ""),
				envelope: typeof row.envelope === "string" ? row.envelope : "",
				expiresAt: Number(row.expiresAt ?? 0)
			}))
		};
	} catch (error) {
		return {
			ok: false,
			error: (error instanceof Error ? error.message : "Veil did not answer.").slice(0, 180),
			messages: []
		};
	}
}
async function readBotMessages(channel) {
	const read = await readChannel(channel);
	return read.ok ? read.messages : [];
}
async function sendChiefLine(job, run, line, from) {
	const text = forVeil(line);
	if (!text) return;
	await postBotMessage(quayChannel(job), {
		from,
		job,
		run,
		line: text
	});
}
function linesFromRead(messages, run) {
	const lines = [];
	for (const message of messages) try {
		const parsed = JSON.parse(message.envelope);
		if (parsed.run !== run || typeof parsed.line !== "string" || !parsed.line) continue;
		if (/"method":"follower_changed"/.test(parsed.line)) continue;
		lines.push(parsed.line);
	} catch {}
	return lines;
}
var deliverChiefPacket = createServerFn({ method: "POST" }).validator((input) => {
	const packet = typeof input?.packet === "string" ? input.packet.trim().slice(0, 4e3) : "";
	if (packet.length < 2) throw new Error("Nothing to send.");
	return { packet };
}).handler(createSsrRpc("366ed8b94fb7ac68963c3314692a32956840e0b7a9eb27775b18e03a24a9022f"));
var file = join(process.cwd(), "data", "failure-repository.json");
var openIds = /* @__PURE__ */ new Map();
var rows = [];
var loaded = false;
function load() {
	if (loaded) return;
	loaded = true;
	try {
		if (!existsSync(file)) return;
		const parsed = JSON.parse(readFileSync(file, "utf8"));
		if (Array.isArray(parsed)) rows = parsed;
	} catch {
		rows = [];
	}
}
function persist() {
	try {
		mkdirSync(join(process.cwd(), "data"), { recursive: true });
		writeFileSync(file, JSON.stringify(rows));
	} catch {}
}
function taskTypeOf(text) {
	if (/https?:\/\/|\b[a-z0-9-]+\.(com|org|net|io|me)\b/i.test(text)) return "website";
	if (/\bsearch\b/i.test(text)) return "search";
	return "question";
}
function sourceOf(text) {
	const url = text.match(/https?:\/\/[^\s)>\]]+/i)?.[0] ?? "";
	if (url) try {
		return new URL(url).host.replace(/^www\./, "").toLowerCase();
	} catch {
		return url.slice(0, 80);
	}
	return text.match(/\b([a-z0-9-]+\.(?:com|org|net|io|me))\b/i)?.[1]?.toLowerCase() ?? "";
}
function words(text) {
	return text.toLowerCase().match(/[a-z]{5,}/g)?.slice(0, 12) ?? [];
}
function searchFailures(taskType, source, error) {
	load();
	const errWords = new Set(words(error));
	const host = source.toLowerCase();
	const used = rows.filter((row) => {
		if (taskType && row.taskType === taskType) return true;
		if (host && row.source && (row.source === host || row.source.includes(host) || host.includes(row.source))) return true;
		if (errWords.size === 0) return false;
		return words(`${row.wrong} ${row.fixes.join(" ")}`).some((word) => errWords.has(word));
	});
	const worked = [];
	const skip = [];
	for (const row of used) if (row.worked && row.worked !== "none yet") worked.push(row.worked);
	else skip.push(...row.fixes);
	const workedUnique = [...new Set(worked)].slice(0, 6);
	return {
		used,
		worked: workedUnique,
		skip: [...new Set(skip)].filter((item) => !workedUnique.includes(item)).slice(0, 6)
	};
}
function lessonText(found) {
	const lines = [];
	if (found.worked.length > 0) lines.push(`Try these fixes first:\n${found.worked.map((item) => `- ${item}`).join("\n")}`);
	if (found.skip.length > 0) lines.push(`Skip these. They already failed:\n${found.skip.map((item) => `- ${item}`).join("\n")}`);
	return lines.join("\n");
}
function recordFailure(input) {
	load();
	const wrong = input.wrong.replace(/\s+/g, " ").trim().slice(0, 240);
	const existing = rows.find((row) => row.worked === "none yet" && row.step === input.step && row.model === input.model && row.source === input.source && row.wrong === wrong);
	if (existing) return existing.id;
	const row = {
		id: `${Date.now().toString(36)}-${rows.length}`,
		at: (/* @__PURE__ */ new Date()).toISOString(),
		taskType: input.taskType.slice(0, 40),
		source: input.source.slice(0, 120),
		step: input.step,
		model: input.model.slice(0, 80),
		wrong,
		fixes: [],
		worked: "none yet"
	};
	rows.push(row);
	persist();
	return row.id;
}
function rememberOpen(job, step, id) {
	openIds.set(`${job}:${step}`, id);
}
function openRow(job, step) {
	load();
	const id = openIds.get(`${job}:${step}`);
	return rows.find((row) => row.id === id);
}
function addFix(job, step, fix) {
	const row = openRow(job, step);
	const clean = fix.replace(/\s+/g, " ").trim().slice(0, 240);
	if (!row || !clean || row.fixes.includes(clean)) return;
	row.fixes.push(clean);
	persist();
}
function markWorked(job, step, fix) {
	const row = openRow(job, step);
	if (!row) return;
	const clean = fix.replace(/\s+/g, " ").trim().slice(0, 240);
	if (clean && !row.fixes.includes(clean)) row.fixes.push(clean);
	row.worked = clean || row.fixes.at(-1) || "none yet";
	persist();
}
var TOOLS = /* @__PURE__ */ new Set([
	"copy_text",
	"inspect",
	"click_and_screenshot",
	"length_check",
	"scroll"
]);
var CAP$1 = 1800;
function sci(value) {
	if (!Number.isFinite(value)) return "0";
	const n = Math.abs(Math.round(value));
	if (n < 1e5) return String(Math.round(value));
	const exp = Math.floor(Math.log10(n));
	return `${(n / 10 ** exp).toFixed(2).replace(/\.?0+$/, "")}e${exp}`;
}
function parseTool(raw) {
	const start = raw.search(/"tool"\s*:/);
	if (start < 0) return null;
	const brace = raw.lastIndexOf("{", start);
	if (brace < 0) return null;
	let depth = 0;
	let end = -1;
	for (let index = brace; index < raw.length; index += 1) {
		const char = raw[index];
		if (char === "{") depth += 1;
		else if (char === "}") {
			depth -= 1;
			if (depth === 0) {
				end = index;
				break;
			}
		}
	}
	if (end < 0) return null;
	try {
		const json = JSON.parse(raw.slice(brace, end + 1));
		const tool = String(json.tool ?? "");
		const url = typeof json.url === "string" ? json.url.trim() : "";
		const target = typeof json.target === "string" ? json.target.trim().slice(0, 160) : "";
		const named = TOOLS.has(tool) ? tool : url ? target ? "click_and_screenshot" : "copy_text" : null;
		if (!named) return null;
		return {
			tool: named,
			url,
			target,
			text: typeof json.text === "string" ? json.text.slice(0, 4e3) : ""
		};
	} catch {
		return null;
	}
}
function realUrl(raw) {
	const cleaned = raw.split(`${String.fromCharCode(38)}amp;`).join(String.fromCharCode(38)).trim();
	try {
		const wrapped = new URL(cleaned, "https://duckduckgo.com").searchParams.get("uddg");
		if (wrapped) return decodeURIComponent(wrapped);
	} catch {
		return cleaned;
	}
	return cleaned;
}
function shortPreview(body) {
	const start = body.slice(0, 360);
	const tokens = body.match(/[A-Za-z]{15,}/g) ?? [];
	let longest = "";
	for (const token of tokens) if (token.length > longest.length) longest = token;
	if (!longest || start.includes(longest)) return start;
	const at = body.indexOf(longest);
	return `${start} … ${body.slice(Math.max(0, at - 140), at + longest.length + 180).trim()}`.slice(0, 900);
}
function hostOf$1(raw) {
	try {
		return new URL(raw).host.replace(/^www\./, "").toLowerCase();
	} catch {
		return "";
	}
}
function thinPage(text) {
	const body = text.replace(/\s+/g, " ").trim();
	return body.length < 500 || /having trouble accessing|enable javascript|unusual traffic|before you continue/i.test(body);
}
function usefulLinks(pageUrl, links, thin) {
	const host = hostOf$1(pageUrl);
	const cleaned = links.map((link) => link.split(`${String.fromCharCode(38)}amp;`).join(String.fromCharCode(38))).filter((link) => hostOf$1(link));
	const off = cleaned.filter((link) => {
		const next = hostOf$1(link);
		if (!next || next === host) return false;
		if (thin && /(^|\.)google\./.test(next)) return false;
		return true;
	});
	return (thin ? off : off.length > 0 ? off : cleaned).slice(0, 8);
}
function pack(url, title, text, links) {
	const body = text.replace(/\s+/g, " ").trim();
	const thin = thinPage(body);
	const linkBlock = usefulLinks(url, links, thin).join("\n");
	if (thin) return [
		`No findings on this page. Open a different host.`,
		`source: ${url}`,
		body.slice(0, 280),
		linkBlock ? `links:\n${linkBlock}` : ""
	].filter(Boolean).join("\n");
	const full = [
		`title: ${title}`,
		`source: ${url}`,
		body,
		linkBlock ? `links:\n${linkBlock}` : ""
	].filter(Boolean).join("\n");
	if (full.length <= CAP$1) return full;
	return [
		`length: ${sci(body.length)}`,
		`preview: ${shortPreview(body)}`,
		`source: ${url}`,
		linkBlock ? `links:\n${linkBlock}` : ""
	].filter(Boolean).join("\n");
}
async function open(raw) {
	const url = toUrl(raw);
	if (!url) return { error: "That address cannot be opened." };
	const page = await readPublicDocument(url);
	const links = page.links.map((link) => realUrl(link.url)).map((link) => toUrl(link) || "").filter((link, index, list) => link && list.indexOf(link) === index).slice(0, 8);
	return {
		url: page.address || url,
		title: page.title || "Page",
		text: page.detail || page.error || "",
		links,
		html: page.html
	};
}
async function shot(job, url) {
	try {
		const { capturePage } = await import("./live-page-CvwyhLgH.mjs");
		const viewed = await capturePage(url);
		if (viewed?.shot) rememberShot(job, viewed.shot, url);
	} catch {}
}
async function runPageTool(job, call) {
	if (call.tool === "length_check" && call.text && !call.url) return `length: ${sci(call.text.length)}`;
	if (call.tool === "scroll") {
		const url = toUrl(call.url);
		if (!url) return "That address cannot be opened.";
		const { walkSandbox } = await import("./live-page-CvwyhLgH.mjs");
		const walked = await walkSandbox(url);
		if (!walked) return `Sandbox did not open ${url}`;
		if (walked.shot) rememberShot(job, walked.shot, url);
		noteSandbox(job, {
			pages: walked.pages,
			clicks: walked.clicks,
			scrolls: walked.scrolls,
			shots: walked.shots
		});
		return walked.text || `source: ${url}\nSandbox opened the page and scrolled.`;
	}
	const page = await open(call.url);
	if ("error" in page) return page.error;
	if (call.tool === "length_check") return `length: ${sci(page.text.length)}\nsource: ${page.url}`;
	if (call.tool === "click_and_screenshot") {
		await shot(job, page.url);
		const target = call.target.toLowerCase();
		if (target) {
			const at = page.text.toLowerCase().indexOf(target);
			if (at < 0) return `source: ${page.url}\ntarget not on the page: ${call.target}\n${pack(page.url, page.title, page.text, page.links)}`;
			const window = page.text.slice(Math.max(0, at - 200), at + call.target.length + 500);
			return pack(page.url, page.title, window, page.links);
		}
		return pack(page.url, page.title, page.text, page.links);
	}
	if (call.tool === "inspect") {
		const heads = [...page.html.matchAll(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/gi)].map((match) => match[1]?.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim() ?? "").filter(Boolean).slice(0, 12);
		const body = [heads.length ? `headings: ${heads.join(" | ")}` : "", page.text.slice(0, 700)].filter(Boolean).join("\n");
		return pack(page.url, page.title, body, page.links);
	}
	await shot(job, page.url);
	return pack(page.url, page.title, page.text, page.links);
}
function intentMiss(task, answer) {
	const text = answer.replace(/\s+/g, " ").trim();
	if (!text) return "";
	const dictionary = /\bdictionary\b/i.test(task) && !/\bliterature\b/i.test(task);
	const literature = /aristophanes|literature|pneumonoultramicroscopicsilicovolcanoconiosis/i.test(text);
	if (dictionary && literature && !/\bdictionary\b/i.test(text)) return "that word is from literature, not an English dictionary";
	if (/example\.com/i.test(task) && /\b(title|heading)\b/i.test(task) && !/example domain/i.test(text)) return "the homepage title was not Example Domain";
	return "";
}
var TEMPLATE = () => process.env.QUAY_E2B_BROWSER_TEMPLATE || "quay-reader-chromium";
function clean(text) {
	return text.replace(/\s+/g, " ").trim();
}
async function withE2B(work) {
	const { resolveE2bKey } = await import("./e2b-key.server-DGZlzSBT.mjs");
	const apiKey = await resolveE2bKey();
	if (!apiKey) return null;
	try {
		const { Sandbox } = await import("../_libs/e2b+openapi-fetch+platform.mjs").then((n) => n.t);
		const sandbox = await Sandbox.create(TEMPLATE(), {
			apiKey,
			timeoutMs: 18e4,
			allowInternetAccess: true
		});
		try {
			return await work(sandbox);
		} finally {
			await sandbox.kill().catch(() => void 0);
		}
	} catch {
		return null;
	}
}
function looksLikeError(text) {
	const sample = clean(text).slice(0, 500);
	if (!sample) return true;
	return /^(error|forbidden|access denied|unauthorized)\b/i.test(sample) || /captcha|unusual traffic|just a moment|enable javascript/i.test(sample);
}
var waiters = [];
var running = /* @__PURE__ */ new Map();
var busy = 0;
var browsers = 0;
var ticket = 0;
var browserWaiters = [];
var history = [];
function slotCount() {
	const parsed = Number(process.env.QUAY_SLOT_COUNT ?? 20);
	return Number.isFinite(parsed) && parsed > 0 ? Math.min(parsed, 40) : 20;
}
function leaseCount() {
	const parsed = Number(process.env.QUAY_BROWSER_LEASES ?? 2);
	return Number.isFinite(parsed) && parsed > 0 ? Math.min(parsed, 2) : 2;
}
function grantNext() {
	while (busy < slotCount() && waiters.length > 0) {
		const waiter = waiters.shift();
		if (!waiter) return;
		busy += 1;
		ticket += 1;
		const slot = `slot-${(ticket - 1) % slotCount() + 1}`;
		running.set(waiter.id, slot);
		waiter.grant(slot);
	}
}
function acquire(id) {
	return new Promise((resolve) => {
		waiters.push({
			id,
			grant: resolve
		});
		grantNext();
	});
}
function release(id) {
	running.delete(id);
	busy = Math.max(0, busy - 1);
	grantNext();
}
function noteStep(note) {
	const row = {
		page: "",
		detail: "",
		...note
	};
	const index = history.findIndex((item) => item.id === row.id);
	if (index >= 0) history[index] = row;
	else history.push(row);
	if (history.length > 80) history.splice(0, history.length - 80);
}
async function withSlot(id, work) {
	const slot = await acquire(id);
	try {
		return await work(slot);
	} finally {
		release(id);
	}
}
function enqueueJob(id, run) {
	noteStep({
		id,
		slot: "",
		step: 0,
		fn: "job",
		status: "queued",
		follower: "",
		tries: 0
	});
	withSlot(id, async (slot) => {
		noteStep({
			id,
			slot,
			step: 0,
			fn: "job",
			status: "running",
			follower: "",
			tries: 0
		});
		await run();
		noteStep({
			id,
			slot,
			step: 0,
			fn: "job",
			status: "done",
			follower: "",
			tries: 0
		});
	});
}
async function leaseBrowser(work) {
	while (browsers >= leaseCount()) await new Promise((resolve) => browserWaiters.push(resolve));
	browsers += 1;
	try {
		return await work();
	} finally {
		browsers -= 1;
		const wake = browserWaiters.shift();
		if (wake) wake();
	}
}
function statusBoard() {
	return {
		slots: slotCount(),
		busy,
		queued: waiters.length,
		browserLeases: leaseCount(),
		browsersInUse: browsers,
		jobs: [...running.entries()].map(([id, slot]) => ({
			id,
			slot
		})),
		steps: history.map((row) => ({ ...row }))
	};
}
var SOURCES = [
	"duckduckgo",
	"bing",
	"wikipedia",
	"stackexchange",
	"hf-space"
];
function shQuote(value) {
	return `'${value.replace(/'/g, `'\\''`)}'`;
}
function decode(value) {
	try {
		return decodeURIComponent(value);
	} catch {
		return value;
	}
}
function pushHit(hits, url, title) {
	const safe = toUrl(url);
	if (!safe || hits.some((hit) => hit.url === safe)) return;
	if (/duckduckgo\.com|bing\.com|r\.jina\.ai/i.test(safe)) return;
	hits.push({
		title: title.replace(/\s+/g, " ").trim().slice(0, 140) || safe,
		url: safe
	});
}
function linksFromHtml(html) {
	const hits = [];
	for (const match of html.matchAll(/uddg=([^&"]+)/gi)) pushHit(hits, decode(match[1] ?? ""), "");
	for (const match of html.matchAll(/<a\b[^>]*href="(https?:\/\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)) {
		const title = (match[2] ?? "").replace(/<[^>]+>/g, " ");
		pushHit(hits, match[1] ?? "", title);
	}
	return hits.slice(0, 8);
}
function formatHits(source, hits) {
	return hits.map((hit) => `- ${hit.title}: ${hit.url}`).join("\n") || `(${source} returned nothing)`;
}
function note(job, source, status, tries) {
	noteStep({
		id: `${job}:search:${source}`,
		slot: "search",
		step: SOURCES.indexOf(source) + 1,
		fn: "find",
		status,
		follower: `search-${source}`,
		tries
	});
}
function packSource(id, body) {
	if (!body || looksLikeError(body)) return "";
	if (id === "wikipedia") try {
		const data = JSON.parse(body);
		const hits = [];
		if (!data.error) for (const row of data.query?.search ?? []) {
			if (!row.title) continue;
			pushHit(hits, `https://en.wikipedia.org/wiki/${encodeURIComponent(row.title.replace(/ /g, "_"))}`, row.title);
		}
		return hits.length > 0 ? formatHits(id, hits) : "";
	} catch {
		return "";
	}
	if (id === "stackexchange") try {
		const data = JSON.parse(body);
		const hits = [];
		if (!data.error_id) {
			for (const row of data.items ?? []) if (row.link) pushHit(hits, row.link, row.title ?? "");
		}
		return hits.length > 0 ? formatHits(id, hits) : "";
	} catch {
		return "";
	}
	const hits = linksFromHtml(body);
	return hits.length > 0 ? formatHits(id, hits) : "";
}
var RESEARCH$1 = [
	{
		id: "duckduckgo",
		name: "DuckDuckGo",
		url: (q) => `https://html.duckduckgo.com/html/?q=${q}`
	},
	{
		id: "bing",
		name: "Bing",
		url: (q) => `https://www.bing.com/search?q=${q}`
	},
	{
		id: "wikipedia",
		name: "Wikipedia",
		url: (q) => `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${q}&utf8=1&format=json&srlimit=5`
	},
	{
		id: "stackexchange",
		name: "StackExchange",
		url: (q) => `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${q}&site=stackoverflow&pagesize=5`
	}
];
async function researchBundle(job, query) {
	const q = query.replace(/[\r\n]+/g, " ").trim().slice(0, 160);
	if (q.length < 2) return [];
	const encoded = encodeURIComponent(q);
	return await withE2B(async (sandbox) => {
		const rows = [];
		for (const source of RESEARCH$1) {
			note(job, source.id, "running", 1);
			let body = "";
			try {
				const result = await sandbox.commands.run(`curl -fsSL -A ${shQuote("QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)")} --max-time 12 ${shQuote(source.url(encoded))}`, { timeoutMs: 16e3 });
				body = result.stdout ?? "";
				if (result.exitCode && result.exitCode !== 0 || looksLikeError(body)) body = "";
			} catch {
				body = "";
			}
			const text = packSource(source.id, body);
			note(job, source.id, text ? "done" : "released", 1);
			rows.push({
				name: source.name,
				text
			});
		}
		return rows;
	}) ?? [];
}
function chatCandidates(skip) {
	return REASON_ORDER.filter((id) => id !== skip && statusOf(id) !== "Key missing");
}
async function otherReasoning(job, step, user) {
	const system = "You are the Reasoning bot hired by the chief. You run this redundancy stage. Do not answer the user's task. Do not browse. Reply with a JSON array only. Each item has who, what, when, where, why, and how. One item per cause.";
	for (const id of chatCandidates(pinnedModel(job))) {
		const called = await runModel(job, "reasoning", id, [{
			role: "system",
			content: system
		}, {
			role: "user",
			content: user
		}], true);
		noteHire(job, step, labelOf(id), "reasoning", Boolean(called.text));
		if (called.text) return called.text;
	}
	return "";
}
async function otherResearch(job, step, task, goal, causes) {
	const pin = pinnedModel(job);
	const found = searchFailures(taskTypeOf(`${task} ${goal}`), sourceOf(`${task} ${goal} ${causes}`), causes);
	noteRepoMatches(job, found.used.map((row) => row.id));
	const repo = lessonText(found);
	const chunks = [];
	if (repo) chunks.push(repo);
	const bundle = await researchBundle(job, `${goal} ${task}`.slice(0, 160));
	for (const row of bundle) {
		noteHire(job, step, row.name, "research", Boolean(row.text));
		if (row.text) chunks.push(`${row.name}\n${row.text}`);
	}
	if (statusOf("worker-hf") !== "Key missing") {
		const spaces = webSpaces().filter((space) => space.id !== pin);
		for (let index = 0; index < spaces.length; index += 4) {
			const batch = spaces.slice(index, index + 4);
			const results = await Promise.all(batch.map(async (space) => {
				const called = await runModel(job, "research", space.id, [{
					role: "user",
					content: `${goal}\n${task}`.slice(0, 500)
				}], true);
				return {
					name: space.space ?? space.label,
					text: called.text ?? ""
				};
			}));
			for (const row of results) {
				noteHire(job, step, row.name, "research", Boolean(row.text));
				if (row.text) chunks.push(`${row.name}\n${row.text}`);
			}
		}
	}
	const findings = chunks.join("\n\n").slice(0, 3500);
	const ranker = chatCandidates(pin)[0];
	if (ranker && findings) {
		const called = await runModel(job, "research-rank", ranker, [{
			role: "system",
			content: "You rank research findings for the chief. Do not answer the user's task. Reply with the useful findings and one workaround per cause."
		}, {
			role: "user",
			content: `TASK\n${task}\n\nGOAL\n${goal}\n\nCAUSES\n${causes}\n\nFINDINGS\n${findings}`
		}], true);
		noteHire(job, step, labelOf(ranker), "research", Boolean(called.text));
		if (called.text) chunks.push(called.text);
	}
	return chunks.join("\n").slice(0, 1200);
}
var RPC_METHODS = [
	"task",
	"fix",
	"status",
	"result",
	"error",
	"criteria",
	"judge",
	"block",
	"plan",
	"step",
	"step_result",
	"follower_changed",
	"assemble",
	"review"
];
var RPC_EXAMPLE = "{\"jsonrpc\":\"2.0\",\"id\":\"1\",\"method\":\"result\",\"params\":{\"text\":\"ANSWER: the fact. Source: https://example.com\"}}";
var LEGACY_NOTE = "Q1 shorthand (up, down, left, right, click, TAPE) is legacy. Prefer one JSON-RPC 2.0 object.";
function rpcLine(id, method, params) {
	return JSON.stringify({
		jsonrpc: "2.0",
		id,
		method,
		params
	});
}
function extractRpc(raw) {
	const stripped = raw.replace(/```(?:json)?/gi, "").trim();
	const start = stripped.indexOf("{");
	const end = stripped.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		const value = JSON.parse(stripped.slice(start, end + 1));
		if (value.jsonrpc !== "2.0" || typeof value.method !== "string") return null;
		if (!RPC_METHODS.includes(value.method)) return null;
		return {
			jsonrpc: "2.0",
			id: String(value.id ?? ""),
			method: value.method,
			params: value.params && typeof value.params === "object" ? value.params : {}
		};
	} catch {
		return null;
	}
}
function rpcHint() {
	return `${LEGACY_NOTE} Example: ${RPC_EXAMPLE}`;
}
var DAY = 864e5;
var CAP = 2e5;
var STANDING = "standing";
var sheets = /* @__PURE__ */ new Map();
function clip(text) {
	return scrubSecrets(text).replace(/\u0000/g, "").trim().slice(0, CAP);
}
function sweep(now = Date.now()) {
	for (const [key, row] of sheets) if (now - row.at >= DAY) sheets.delete(key);
}
function putShared(job, text) {
	sweep();
	const clean = clip(text);
	const key = job || "page";
	if (!clean) {
		sheets.delete(key);
		return;
	}
	sheets.set(key, {
		text: clean,
		at: Date.now()
	});
}
function readShared(job) {
	sweep();
	return sheets.get(job || "page")?.text ?? "";
}
function wipeShared(job) {
	sheets.delete(job || "page");
}
function putStanding(text) {
	putShared(STANDING, text);
}
function standingShared() {
	return readShared(STANDING);
}
function beginJobShared(job, text) {
	const clean = clip(text);
	putStanding(clean);
	if (clean) putShared(job, clean);
	else wipeShared(job);
}
var SHORTHAND_KEY = [
	"R = result text",
	"F = failed + reason",
	"N = need",
	"U = url",
	"Q = quoted fact",
	"D = done",
	"A very large number may be scientific notation when an exact count is not needed, such as 1.9e5 for about 190,000. When the exact count matters, write the digits."
].join(". ");
var CODE = /^(R|F|N|U|Q|D)\s*(?::\s*(.*))?$/i;
function decodeShorthand(raw, method, id) {
	const lines = raw.split(/\n/).map((line) => line.trim()).filter(Boolean);
	if (lines.length === 0 || lines.length > 12) return null;
	const found = /* @__PURE__ */ new Map();
	for (const line of lines) {
		const match = line.match(CODE);
		if (!match) return null;
		found.set(match[1].toUpperCase(), (match[2] ?? "").trim());
	}
	if (found.size === 0) return null;
	const params = {};
	const result = found.get("R") ?? "";
	const failed = found.get("F") ?? "";
	const need = found.get("N") ?? "";
	const url = found.get("U") ?? "";
	const quote = found.get("Q") ?? "";
	if (result) params.text = result;
	if (url) params.url = url;
	if (quote) params.quote = quote;
	if (need) params.need = need;
	if (failed) {
		params.failed = true;
		params.reason = failed;
		if (!params.text) params.text = failed;
	}
	if (found.has("D")) params.done = true;
	if (method === "review") {
		params.pass = failed ? false : /\bfail\b/i.test(result) ? false : true;
		if (!params.text) params.text = params.pass ? "pass" : "fail";
	}
	if (!params.text && quote) params.text = quote;
	if (!params.text && params.done) params.text = "done";
	if (typeof params.text !== "string" || !params.text) return null;
	return {
		jsonrpc: "2.0",
		id,
		method,
		params
	};
}
var RULES = [
	"You are one follower. Do only the assignment in the final input.",
	"The chief does not browse and does not relay. You do the browsing and the work.",
	"Read the rules, then the shared instructions, then the final input.",
	"Any method may be used first, except on a website. A website task starts in the sandbox browser.",
	"After the sandbox, a later fix may use other methods. Do not open the sandbox again.",
	"Tools: {\"tool\":\"copy_text\",\"url\":\"https://...\"} {\"tool\":\"inspect\",\"url\":\"https://...\"} {\"tool\":\"click_and_screenshot\",\"url\":\"https://...\",\"target\":\"visible text\"} {\"tool\":\"length_check\",\"url\":\"https://...\"} {\"tool\":\"scroll\",\"url\":\"https://...\"}",
	"After a tool result, either call one more tool or answer. Use the shorthand key or one JSON-RPC 2.0 object.",
	`Key: ${SHORTHAND_KEY}`,
	"If a tool result says no findings, the next tool must use a different host. Do not retry that host.",
	"Do not invent a source you did not open. Very large numbers use scientific notation."
].join("\n");
function withWait(work) {
	return work;
}
function pinSkip(name, extra) {
	const others = sources().map((source) => source.name).filter((item) => item !== name);
	return [.../* @__PURE__ */ new Set([...extra, ...others])];
}
function hire(brief, job) {
	const shared = readShared(job);
	const user = [shared ? `SHARED INSTRUCTIONS\n${shared}` : "", `FINAL INPUT\n${brief}`].filter(Boolean).join("\n\n");
	return [{
		role: "system",
		content: RULES
	}, {
		role: "user",
		content: user
	}];
}
function plainResult(text) {
	return text.replace(/\b[RFNUQD]\s*:\s*/gi, " ").replace(/^\s*D\.?\s*/i, "").replace(/\s+/g, " ").trim();
}
function spoken(raw, method, id) {
	const rpc = extractRpc(raw) ?? decodeShorthand(raw, method, id);
	const text = rpc ? String(rpc.params.text ?? rpc.params.quote ?? rpc.params.answer ?? "") : raw;
	const url = rpc && typeof rpc.params.url === "string" ? rpc.params.url : "";
	const merged = url && !text.includes(url) ? `${text} ${url}` : text;
	return plainResult(absorbAccounts(scrubSecrets(merged || raw))).slice(0, 1500);
}
function vague(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (clean.length < 24) return true;
	if (/^(pass|fail|done|ok|yes|no|error)\b[.!]?$/i.test(clean)) return true;
	if (/^(i don't know|i do not know|not found|no results|nothing found|unable)\b/i.test(clean)) return true;
	return false;
}
function errorText(text) {
	return /^(error|forbidden)\b|\b(403|429|quota|timed out|timeout|rate limit)\b/i.test(text.trim().slice(0, 240));
}
function hostOf(url) {
	try {
		return new URL(url).host.replace(/^www\./, "").toLowerCase();
	} catch {
		return "";
	}
}
function needsFacts(finish) {
	return /\bword\b/i.test(finish) && /\b(letter|count|number)\b/i.test(finish);
}
function completes(finish, text, evidence) {
	if (vague(text) || errorText(text)) return false;
	const link = text.match(/https?:\/\/[^\s)>\]]+/i)?.[0]?.replace(/[.,]+$/, "") ?? "";
	const host = link ? hostOf(link) : "";
	if (needsFacts(finish)) {
		if (!host || !evidence.toLowerCase().includes(host)) return false;
		if (!(text.match(/[A-Za-z]{12,}/g) ?? []).some((word) => evidence.toLowerCase().includes(word.toLowerCase()))) return false;
		return (text.match(/\b\d{2,4}\b|\d+(?:\.\d+)?e\d+/gi) ?? []).some((num) => evidence.toLowerCase().includes(num.toLowerCase()));
	}
	if (/\blink\b|\bsource\b|\burl\b/i.test(finish)) {
		if (!host || evidence && !evidence.toLowerCase().includes(host)) return false;
	}
	return text.length >= 40;
}
function moves(text, evidence) {
	if (vague(text) || errorText(text) || evidence.trim().length < 40) return false;
	const tokens = evidence.match(/[A-Za-z]{8,}/g) ?? [];
	const lower = text.toLowerCase();
	return tokens.some((token) => lower.includes(token.toLowerCase())) || /https?:\/\//i.test(text);
}
var REASONING = "You are the Reasoning bot hired by the chief. You run this redundancy stage. Do not answer the user's task. Do not browse.";
var RESEARCH = "You are the Research bot hired by the chief. Research every cause. Do not answer the user's task. Reply with one workaround per cause.";
var orders = /* @__PURE__ */ new Map();
function weak(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (!clean) return true;
	if (/\bno answer\b/i.test(clean)) return true;
	return vague(clean) || errorText(clean);
}
async function pickedAsk(job, system, user) {
	try {
		return await withWait(callCheap(job, [{
			role: "system",
			content: system
		}, {
			role: "user",
			content: user
		}])) ?? "";
	} catch {
		return "";
	}
}
async function hireBots(job) {
	if (!pinnedModel(job)) {
		orders.set(job, {
			reasoning: false,
			research: false
		});
		return;
	}
	let reply = "";
	try {
		reply = await withWait(callCheap(job, [{
			role: "system",
			content: "You are the chief. You only hire. Reply with exactly: HIRE reasoning. HIRE research."
		}, {
			role: "user",
			content: "A step failed the threshold. Hire the Reasoning bot to run the redundancy loop and the Research bot to research causes. Do not answer the task."
		}])) ?? "";
	} catch {
		reply = "";
	}
	orders.set(job, {
		reasoning: /hire\s+reasoning/i.test(reply),
		research: /hire\s+research/i.test(reply)
	});
}
async function chiefYes(job, task, goal, text, evidence, responseOnly) {
	try {
		const reply = await withWait(callCheap(job, [{
			role: "system",
			content: "You are the chief. You only judge the follower's response against the goal. Do not browse. Do not recheck the sandbox or the screenshots. Reply with one word, yes or no. Pass only if the response is relevant AND moves closer to the goal AND to completing the task. Incomplete, partial, vague, or off-target is no."
		}, {
			role: "user",
			content: responseOnly ? `TASK\n${task}\n\nGOAL\n${goal}\n\nRESPONSE\n${text.slice(0, 1200)}` : `TASK\n${task}\n\nGOAL\n${goal}\n\nRESPONSE\n${text.slice(0, 900)}\n\nEVIDENCE\n${evidence.slice(0, 900)}`
		}]));
		if (!reply) return null;
		if (/^\s*no\b/i.test(reply)) return false;
		if (/^\s*yes\b/i.test(reply)) return true;
		return null;
	} catch {
		return null;
	}
}
async function judge(job, task, goal, text, evidence, strict, responseOnly = false) {
	const full = completes(task, text, responseOnly ? text : evidence);
	const closer = full || !strict && moves(text, responseOnly ? text : evidence);
	const missed = intentMiss(task, text);
	if (missed) return {
		pass: false,
		full: false,
		why: missed
	};
	if (!closer) return {
		pass: false,
		full: false,
		why: "partial, vague, or off-target"
	};
	if (await chiefYes(job, task, goal, text, evidence, responseOnly) === false) return {
		pass: false,
		full: false,
		why: "the chief rejected it"
	};
	if (strict && !full) return {
		pass: false,
		full: false,
		why: "the task is not complete"
	};
	return {
		pass: true,
		full,
		why: ""
	};
}
async function attemptOnce(job, step, brief, prefer, skip, scrapersOnly = false) {
	const method = step.fn === "assemble" ? "assemble" : "step_result";
	const messages = hire(brief, job);
	let follower = prefer;
	let evidence = "";
	const pages = [];
	let reason = "";
	const skipped = prefer ? pinSkip(prefer, skip) : skip;
	for (let turn = 0; turn < 5; turn += 1) {
		let called;
		try {
			called = await withWait(callFollower(job, `goal-${step.n}`, messages, void 0, follower || void 0, skipped));
		} catch {
			return {
				text: "",
				follower,
				reason: "waiting",
				evidence,
				pages
			};
		}
		if (called.follower) follower = called.follower;
		reason = called.reason || (called.text ? "" : "empty");
		const raw = called.text ?? "";
		const tool = parseTool(raw);
		if (tool && scrapersOnly && (tool.tool === "scroll" || tool.tool === "click_and_screenshot")) {
			messages.push({
				role: "assistant",
				content: raw.slice(0, 400)
			});
			messages.push({
				role: "user",
				content: "The sandbox was already tried. Use copy_text, inspect, or length_check."
			});
			continue;
		}
		if (tool) {
			let output = "";
			try {
				output = await withWait(runPageTool(job, tool));
			} catch {
				return {
					text: "",
					follower,
					reason: "waiting",
					evidence,
					pages
				};
			}
			evidence = `${evidence}\n${output}`.trim().slice(-8e3);
			if (tool.url) pages.push(tool.url);
			const next = /no findings/i.test(output) ? "This page had no findings. Next reply must be one tool on a different host." : "If this completes the assignment, reply with the shorthand key or one JSON-RPC object. Otherwise one page tool.";
			messages.push({
				role: "assistant",
				content: raw.slice(0, 400)
			});
			messages.push({
				role: "user",
				content: `TOOL RESULT\n${output.slice(0, 1800)}\n\n${next}`
			});
			continue;
		}
		return {
			text: spoken(raw, method, `${job}:${step.n}`),
			follower,
			reason,
			evidence,
			pages
		};
	}
	return {
		text: "",
		follower,
		reason: "no result",
		evidence,
		pages
	};
}
function oneCause(reason, text, goal) {
	return {
		who: reason || "the follower",
		what: "the result did not pass the threshold",
		when: "on this attempt",
		where: goal.slice(0, 160),
		why: (text || reason || "off target").slice(0, 220),
		how: "Open a different public https page with a page tool and use only facts from that page."
	};
}
function parseCauses(raw, fallback) {
	const start = raw.indexOf("[");
	const end = raw.lastIndexOf("]");
	if (start < 0 || end <= start) return [fallback];
	try {
		const value = JSON.parse(raw.slice(start, end + 1));
		if (!Array.isArray(value)) return [fallback];
		const causes = value.map((item) => {
			const row = item;
			return {
				who: String(row.who ?? fallback.who).slice(0, 160),
				what: String(row.what ?? fallback.what).slice(0, 200),
				when: String(row.when ?? fallback.when).slice(0, 120),
				where: String(row.where ?? fallback.where).slice(0, 160),
				why: String(row.why ?? fallback.why).slice(0, 240),
				how: String(row.how ?? fallback.how).slice(0, 240)
			};
		}).filter((cause) => cause.why || cause.how);
		return causes.length > 0 ? causes.slice(0, 4) : [fallback];
	} catch {
		return [fallback];
	}
}
async function analyze(job, task, goal, text, reason, evidence, step) {
	const fallback = oneCause(reason, text, goal);
	const user = `TASK\n${task}\n\nGOAL\n${goal}\n\nWHY IT FAILED\n${reason}\n\nRESULT\n${text.slice(0, 600)}\n\nEVIDENCE\n${evidence.slice(0, 800)}`;
	if (pinnedModel(job)) {
		const order = orders.get(job) ?? {
			reasoning: false,
			research: false
		};
		const prompt = `${REASONING} Reply with a JSON array only. Each item has who, what, when, where, why, and how. One item per cause.`;
		if (!order.reasoning) {
			const own = await pickedAsk(job, prompt, user);
			if (!weak(own)) return parseCauses(own, fallback);
		}
		const hired = await otherReasoning(job, step, user);
		return hired ? parseCauses(hired, fallback) : [fallback];
	}
	try {
		const reply = await withWait(callCheap(job, [{
			role: "system",
			content: "You are the chief. Do not answer the task. Reply with a JSON array only. Each item has who, what, when, where, why, and how. One item per cause."
		}, {
			role: "user",
			content: user
		}]));
		return reply ? parseCauses(reply, fallback) : [fallback];
	} catch {
		return [fallback];
	}
}
async function research(job, task, goal, causes, follower, skip, step) {
	const list = causes.map((cause, index) => `${index + 1}. who ${cause.who}; what ${cause.what}; when ${cause.when}; where ${cause.where}; why ${cause.why}; how ${cause.how}`).join("\n");
	const found = searchFailures(taskTypeOf(`${task} ${goal}`), sourceOf(`${task} ${goal}`), list);
	noteRepoMatches(job, found.used.map((row) => row.id));
	const repo = lessonText(found);
	if (pinnedModel(job)) {
		if (!(orders.get(job) ?? {
			reasoning: false,
			research: false
		}).research) {
			const own = await pickedAsk(job, RESEARCH, `TASK\n${task}\n\nGOAL\n${goal}\n\nFAILURE REPOSITORY\n${repo || "No saved match."}\n\nCAUSES\n${list}`);
			if (!weak(own)) return [repo, own].filter(Boolean).join("\n");
		}
		return [repo, await otherResearch(job, step, task, goal, list)].filter(Boolean).join("\n") || causes.map((cause) => cause.how).join(" ");
	}
	let chiefNote = "";
	try {
		chiefNote = await withWait(callCheap(job, [{
			role: "system",
			content: "You are the chief. Research every cause. Do not answer the task. Reply with one short workaround per cause."
		}, {
			role: "user",
			content: `FAILURE REPOSITORY\n${repo || "No saved match."}\n\nTASK\n${task}\n\nGOAL\n${goal}\n\nCAUSES\n${list}`
		}])) ?? "";
	} catch {
		chiefNote = "";
	}
	if (!(causes.length > 1 || /\band\b/i.test(task))) return [repo, chiefNote].filter(Boolean).join("\n") || causes.map((cause) => cause.how).join(" ");
	const extra = spoken((await callFollower(job, "reason", [{
		role: "system",
		content: "You are a reasoning follower hired only for this check. Do not answer the user's task. Make sure the assignment lines up with completing the task. Research every cause. Reply with the shorthand key or one JSON object whose text is the fix, not the answer."
	}, {
		role: "user",
		content: `TASK\n${task}\n\nASSIGNMENT\n${goal}\n\nCAUSES\n${list}`
	}], void 0, void 0, follower ? [follower, ...skip] : skip)).text ?? "", "step_result", `${job}:reason`);
	return [
		repo,
		chiefNote,
		extra
	].filter(Boolean).join("\n").slice(0, 1200);
}
function capableFollower(skip) {
	const skipped = new Set(skip);
	return [...REASON_ORDER, ...sources().map((source) => source.name)].find((id) => !skipped.has(id) && !id.startsWith("hf:") && statusOf(id) !== "Key missing" && statusOf(id) !== "Failed" && statusOf(id) !== "Quota hit") ?? "";
}
async function chiefWorkaround(job, task, goal, response, notes, mode) {
	const system = mode === "complete" ? "You are the chief. Decide the pathway forward for this same follower. Research is every source below. A workaround is any possible way to achieve the task. Do not browse. Do not recheck the sandbox or the screenshots. Reply with one short assignment, or NONE if no workaround can achieve the task. Do not state the answer." : "You are the chief. No follower can complete this task. Look for a workaround to this particular task, not a way to complete it. Use the research. Do not browse. Do not recheck the sandbox or the screenshots. Reply with one short pathway around the task, or NONE if every option is exhausted. Do not state the answer.";
	const user = `TASK\n${task}\n\nFAILED ASSIGNMENT\n${goal}\n\nRESPONSE\n${response.slice(0, 800)}\n\nRESEARCH\n${notes.slice(0, 800) || "No saved research."}`;
	let reply = "";
	if (pinnedModel(job)) reply = await pickedAsk(job, system, user);
	else try {
		reply = await withWait(callCheap(job, [{
			role: "system",
			content: system
		}, {
			role: "user",
			content: user
		}])) ?? "";
	} catch {
		reply = "";
	}
	const clean = reply.replace(/\s+/g, " ").trim();
	if (!clean || /^none\b/i.test(clean)) return "";
	return clean.slice(0, 700);
}
function priorText(needs, done) {
	return needs.map((n) => done.get(n)).filter((row) => Boolean(row?.ok && row.text)).map((row) => `STEP ${row.n} RESULT:\n${row.text.slice(0, 800)}`).join("\n\n").slice(0, 2e3);
}
function nextBrowser(job, skip) {
	const pin = pinnedModel(job);
	if (pin) return skip.includes(pin) ? "" : pin;
	const ranked = [
		"worker-xai",
		"worker-gemini",
		...REASON_ORDER,
		...sources().map((source) => source.name)
	];
	return ranked.find((id, index) => ranked.indexOf(id) === index && !skip.includes(id) && !id.startsWith("hf:") && statusOf(id) !== "Key missing" && statusOf(id) !== "Failed" && statusOf(id) !== "Quota hit") ?? "";
}
async function runWebAttempt(input) {
	const { job, step, task, brief, prefer, skip } = input;
	const url = startUrl(`${task}\n${brief}`);
	let follower = prefer || nextBrowser(job, skip);
	let continued = false;
	let outcome = await runBrowserFollower({
		job,
		step: step.n,
		task,
		goal: brief,
		url,
		follower,
		continueSession: false,
		ask: async ({ prompt, image, follower: who, kind }) => {
			const called = await callFollower(job, `goal-${step.n}`, [{
				role: "system",
				content: kind === "VISION_BROWSER_FOLLOWER" ? "You are a VISION_BROWSER_FOLLOWER. The current screenshot is attached. Reply with exactly one browser action." : "You are a TEXT_BROWSER_FOLLOWER. No screenshot is attached. Use the structured screen. Reply with exactly one browser action."
			}, {
				role: "user",
				content: prompt,
				image
			}], void 0, who || void 0, who ? pinSkip(who, skip) : skip);
			return {
				text: called.text ?? "",
				follower: called.follower || who
			};
		}
	});
	for (let seat = 1; seat < 3 && outcome.verdict !== "PASS" && !pinnedModel(job); seat += 1) {
		if (outcome.verdict === "SANDBOX_TECHNICAL_FAILURE") {
			const reason = lastSandboxFault()?.message || "browser did not start";
			setWorking(job, 0, `SANDBOX FAILED — trying fallback: ${reason}`);
			noteStep({
				id: `${job}:step:${step.n}`,
				slot: follower || "open",
				step: step.n,
				fn: step.fn,
				status: "failed",
				follower,
				tries: seat,
				detail: reason.slice(0, 180)
			});
			await releaseBrowser(job, step.n);
			await new Promise((resolve) => setTimeout(resolve, 1e3));
			continued = false;
		} else {
			continued = true;
			markReplacement(job, step.n);
			const next = nextBrowser(job, [
				...skip,
				follower,
				outcome.follower
			]);
			if (!next) break;
			follower = next;
		}
		outcome = await runBrowserFollower({
			job,
			step: step.n,
			task,
			goal: brief,
			url,
			follower,
			continueSession: continued,
			ask: async ({ prompt, image, follower: who, kind }) => {
				const called = await callFollower(job, `goal-${step.n}`, [{
					role: "system",
					content: kind === "VISION_BROWSER_FOLLOWER" ? "You are a VISION_BROWSER_FOLLOWER. The current screenshot is attached. Continue the same sandbox. Reply with exactly one browser action." : "You are a TEXT_BROWSER_FOLLOWER. No screenshot is attached. Continue the same sandbox. Reply with exactly one browser action."
				}, {
					role: "user",
					content: prompt,
					image
				}], void 0, who || void 0, who ? pinSkip(who, skip) : skip);
				return {
					text: called.text ?? "",
					follower: called.follower || who
				};
			}
		});
	}
	const text = outcome.answer ? `Found: ${outcome.answer}\nWhere: ${outcome.url}` : "";
	const attempt = {
		text,
		follower: outcome.follower || follower,
		reason: outcome.verdict === "PASS" ? "" : outcome.verdict,
		evidence: text,
		pages: outcome.url ? [outcome.url] : []
	};
	if (outcome.verdict === "PASS") return {
		pass: true,
		full: true,
		why: "",
		attempt
	};
	return {
		pass: false,
		full: false,
		why: outcome.verdict,
		attempt
	};
}
async function pursueGoal(input) {
	const { job, step, task, done, last: lastGoal } = input;
	try {
		const prior = priorText(step.needs, done);
		let follower = pinnedModel(job);
		const skip = [];
		let learned = "";
		let prompt = prior ? `${step.brief}\n\nEARLIER RESULTS\n${prior}` : step.brief;
		const website = taskKind(`${task}\n${step.brief}`) === "WEB_TASK";
		if (website) markWebsite(job);
		const known = searchFailures(taskTypeOf(`${task} ${step.brief}`), sourceOf(`${task} ${step.brief} ${prompt}`), "");
		noteRepoMatches(job, known.used.map((row) => row.id));
		const lesson0 = lessonText(known);
		if (lesson0) prompt = `${prompt}\n\n${lesson0}`.slice(0, 1500);
		let swaps = 0;
		let last = {
			text: "",
			follower: "",
			reason: "",
			evidence: "",
			pages: []
		};
		const runAttempt = async (brief, prefer, strict, scrapersOnly = false) => {
			noteStep({
				id: `${job}:step:${step.n}`,
				slot: prefer || "open",
				step: step.n,
				fn: step.fn,
				status: "waiting",
				follower: prefer,
				tries: swaps + 1,
				detail: "waiting"
			});
			noteCycle(job);
			try {
				last = await attemptOnce(job, step, brief, prefer, skip, scrapersOnly);
			} catch {
				last = {
					...last,
					text: "",
					reason: "empty"
				};
			}
			if (last.follower) follower = last.follower;
			if (last.reason === "waiting") return {
				pass: false,
				full: false,
				why: "the model returned nothing"
			};
			return judge(job, task, step.brief, last.text, last.evidence, strict);
		};
		const passed = (full) => {
			clearFailed(job);
			return {
				n: step.n,
				fn: step.fn,
				follower,
				slot: follower || crewOf(chiefById(job), job),
				text: last.text,
				pages: last.pages,
				tries: swaps + 1,
				ok: true,
				reason: full ? "task" : "goal"
			};
		};
		while (swaps < 6) {
			setWorking(job, 0, website ? "Sandbox browser" : "Working");
			const first = await withSlot(`${job}:step:${step.n}`, async () => {
				if (website) {
					noteStep({
						id: `${job}:step:${step.n}`,
						slot: follower || "open",
						step: step.n,
						fn: step.fn,
						status: "waiting",
						follower,
						tries: swaps + 1,
						detail: "sandbox"
					});
					noteCycle(job);
					const run = await runWebAttempt({
						job,
						step,
						task,
						brief: prompt,
						prefer: follower,
						skip
					});
					last = run.attempt;
					if (last.follower) follower = last.follower;
					return {
						pass: run.pass,
						full: run.full,
						why: run.why
					};
				}
				return runAttempt(prompt, follower, lastGoal);
			});
			if (first.pass) {
				noteStep({
					id: `${job}:step:${step.n}`,
					slot: follower,
					step: step.n,
					fn: step.fn,
					status: "done",
					follower,
					tries: swaps + 1,
					page: last.pages[0] ?? "",
					detail: first.full ? "task" : "goal"
				});
				return passed(first.full);
			}
			markFailedStep(job);
			const model = labelOf(follower || pinnedModel(job) || "follower");
			rememberOpen(job, step.n, recordFailure({
				taskType: taskTypeOf(`${task} ${step.brief}`),
				source: sourceOf(`${task} ${step.brief} ${last.pages.join(" ")}`),
				step: step.n,
				model,
				wrong: first.why || last.reason || "threshold"
			}));
			noteMiss(job, step.n, first.why || last.reason || "threshold");
			await hireBots(job);
			for (let cycle = 1; cycle <= 3; cycle += 1) {
				noteLoop(job);
				setWorking(job, cycle, "Pathway");
				const causes = await analyze(job, task, step.brief, last.text, last.reason || first.why, last.evidence, step.n);
				setWorking(job, cycle, "Research");
				const notes = await research(job, task, step.brief, causes, follower, skip, step.n);
				setWorking(job, cycle, "Workaround");
				const way = await chiefWorkaround(job, task, step.brief, `${last.text}\n${learned}`, notes, "complete");
				if (!way) break;
				addFix(job, step.n, way);
				prompt = way;
				learned = [learned, notes].filter(Boolean).join("\n").slice(-2e3);
				setWorking(job, cycle, "Workaround attempt");
				const again = await runAttempt(website ? `${way}\nThe sandbox was already tried. Use another method.` : way, follower, true, website);
				if (again.pass && again.full) {
					markWorked(job, step.n, way);
					passHires(job, step.n);
					noteStep({
						id: `${job}:step:${step.n}`,
						slot: follower,
						step: step.n,
						fn: step.fn,
						status: "done",
						follower,
						tries: cycle,
						page: last.pages[0] ?? "",
						detail: "workaround"
					});
					noteFix(job, step.n, way);
					return passed(true);
				}
				learned = `${learned}\nWorkaround failed: ${again.why || "no"}`.slice(-2e3);
				last = {
					...last,
					reason: again.why || last.reason
				};
			}
			if (pinnedModel(job)) break;
			if (follower && !skip.includes(follower)) skip.push(follower);
			const hired = capableFollower(skip);
			if (!hired) break;
			follower = hired;
			swaps += 1;
			prompt = `${prior ? `${step.brief}\n\nEARLIER RESULTS\n${prior}` : step.brief}\n${learned}`.slice(0, 1500);
			learned = `${learned}\nFired the follower. Hired ${labelOf(hired)}.`.slice(-2e3);
		}
		setWorking(job, 0, "Another path");
		const aroundCauses = await analyze(job, task, step.brief, last.text, last.reason || "no follower", last.evidence, step.n);
		const aroundNotes = await research(job, task, step.brief, aroundCauses, follower, skip, step.n);
		const around = await chiefWorkaround(job, task, step.brief, last.text, aroundNotes, "around");
		if (around) {
			addFix(job, step.n, around);
			noteLoop(job);
			const again = await runAttempt(around, follower, false, false);
			if (again.pass) {
				markWorked(job, step.n, around);
				passHires(job, step.n);
				noteFix(job, step.n, around);
				noteStep({
					id: `${job}:step:${step.n}`,
					slot: follower,
					step: step.n,
					fn: step.fn,
					status: "done",
					follower,
					tries: swaps + 1,
					page: last.pages[0] ?? "",
					detail: "path around the task"
				});
				return passed(true);
			}
			last = {
				...last,
				reason: again.why || last.reason
			};
		}
		noteStep({
			id: `${job}:step:${step.n}`,
			slot: follower,
			step: step.n,
			fn: step.fn,
			status: "failed",
			follower,
			tries: swaps,
			detail: "failed"
		});
		return {
			n: step.n,
			fn: step.fn,
			follower,
			slot: follower,
			text: "",
			pages: last.pages,
			tries: swaps,
			ok: false,
			reason: last.reason || "failed"
		};
	} finally {
		await releaseBrowser(job, step.n);
	}
}
var FNS = /* @__PURE__ */ new Set([
	"read",
	"find",
	"extract",
	"write",
	"assemble",
	"review"
]);
function urlsIn(text) {
	const found = [];
	for (const match of text.matchAll(/https?:\/\/[^\s<>"']+/gi)) {
		const url = toUrl(match[0].replace(/[),.;]+$/, ""));
		if (url && !found.includes(url)) found.push(url);
	}
	return found;
}
function asFn(value) {
	const name = value.toLowerCase();
	if (name === "open" || name === "read") return "read";
	if (name === "find" || name === "link") return "find";
	if (name === "extract") return "extract";
	if (name === "write") return "write";
	if (name === "assemble") return "assemble";
	if (name === "review") return "review";
	return FNS.has(name) ? name : null;
}
function fnOf(text) {
	if (/\breview\b|\bpass criteria\b|\bjudge\b/i.test(text)) return "review";
	if (/\bassembl/i.test(text)) return "assemble";
	if (/\bwrite\b|\bdraft\b/i.test(text)) return "write";
	if (/\bextract\b|\btitles?\b|\bfirst sentence\b|\blist the\b/i.test(text)) return "extract";
	if (/\bfind\b|\blink\b/i.test(text) && !/\bopen\b|\bread\b/i.test(text)) return "find";
	if (/\bopen\b|\bread\b|\bbrowse\b/i.test(text)) return "read";
	if (/\bfind\b|\blink\b/i.test(text)) return "find";
	return "extract";
}
function numberedPlan(order) {
	const matches = [...order.matchAll(/(?:^|\n)\s*(?:step\s*)?(\d{1,2})\s*[.)\-:\]]\s*([^\n]+)/gi)];
	if (matches.length < 2) return null;
	const steps = [];
	const seen = /* @__PURE__ */ new Set();
	for (const match of matches) {
		const n = Number(match[1]);
		const brief = match[2]?.trim().slice(0, 240) ?? "";
		if (!n || seen.has(n) || brief.length < 2) continue;
		seen.add(n);
		steps.push({
			n,
			fn: fnOf(brief),
			brief,
			needs: []
		});
	}
	return steps.length >= 2 ? steps.sort((left, right) => left.n - right.n) : null;
}
function directedPlan(order) {
	const quoted = order.match(/['"]([^'"]{3,160})['"]/)?.[1]?.trim();
	if (!quoted || !/\bgoogle\b/i.test(order)) return null;
	return [{
		n: 1,
		fn: "read",
		brief: `Open ${`https://www.google.com/search?q=${encodeURIComponent(quoted)}&hl=en`} and report the findings. The task is complete only when the actual word, its letter count, and the source link are stated.`,
		needs: []
	}];
}
function fallbackPlan(order) {
	const urls = urlsIn(order).slice(0, 3);
	const ask = order.replace(/https?:\/\/\S+/g, " ").replace(/\s+/g, " ").trim().slice(0, 180);
	const steps = [];
	if (urls.length === 0) {
		steps.push({
			n: 1,
			fn: "find",
			brief: `Return one public https URL and nothing else for: ${ask || "the question"}`,
			needs: []
		});
		steps.push({
			n: 2,
			fn: "read",
			brief: "Open and read only the URL from the find step.",
			needs: []
		});
	} else for (const url of urls) steps.push({
		n: steps.length + 1,
		fn: "read",
		brief: `Open and read only ${url}`,
		needs: []
	});
	steps.push({
		n: steps.length + 1,
		fn: "extract",
		brief: `Extract only these facts: ${ask || "the requested facts"}`,
		needs: []
	});
	steps.push({
		n: steps.length + 1,
		fn: "write",
		brief: "Write a draft from the extracted facts only.",
		needs: []
	});
	return steps;
}
function linkNeeds(steps) {
	return steps.map((step, index) => {
		const n = index + 1;
		const prior = steps.slice(0, index);
		let needs = [];
		if (index === 0) needs = [];
		else if (step.fn === "assemble") needs = prior.map((_, i) => i + 1);
		else if (step.fn === "review") needs = [n - 1];
		else if ((step.fn === "read" || step.fn === "find") && !/\b(then|after|using|from the|previous|that page)\b/i.test(step.brief)) needs = [];
		else if (step.fn === "extract" || step.fn === "write") {
			const inputs = prior.map((item, itemIndex) => ({
				item,
				n: itemIndex + 1
			})).filter((row) => row.item.fn === "read" || row.item.fn === "find" || row.item.fn === "extract" || row.item.fn === "write");
			needs = inputs.length > 0 ? inputs.map((row) => row.n) : [n - 1];
		} else needs = [n - 1];
		return {
			...step,
			n,
			needs
		};
	});
}
function concreteFinish(order) {
	if (/\blongest word\b/i.test(order)) return "State the actual word, its letter count, and the source link.";
	return `State the result of this task: ${order.replace(/\s+/g, " ").trim().slice(0, 220)}`;
}
function finish(steps, order) {
	const core = steps.filter((step) => step.fn !== "review");
	if (core.length === 0) return linkNeeds(fallbackPlan(order));
	return linkNeeds(core);
}
function parseFinish(raw) {
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) return "";
	try {
		const parsed = JSON.parse(raw.slice(start, end + 1));
		const finish = parsed.finish ?? parsed.params?.finish;
		return typeof finish === "string" ? finish.trim().slice(0, 400) : "";
	} catch {
		return "";
	}
}
function parsePlan(raw) {
	const rpc = extractRpc(raw);
	let value = rpc?.method === "plan" ? rpc.params.steps : void 0;
	if (!value) {
		const start = raw.indexOf("{");
		const end = raw.lastIndexOf("}");
		if (start < 0 || end <= start) return null;
		try {
			const parsed = JSON.parse(raw.slice(start, end + 1));
			value = parsed.steps ?? parsed.params?.steps;
		} catch {
			return null;
		}
	}
	if (!Array.isArray(value)) return null;
	const steps = [];
	for (const item of value) {
		if (!item || typeof item !== "object") continue;
		const row = item;
		const fn = asFn(String(row.fn ?? row.function ?? ""));
		const brief = String(row.brief ?? "").trim().slice(0, 240);
		if (!fn || brief.length < 2) continue;
		steps.push({
			n: steps.length + 1,
			fn,
			brief,
			needs: []
		});
	}
	return steps.length >= 2 ? steps : null;
}
async function preparePlan(job, order) {
	const base = concreteFinish(order);
	const numbered = numberedPlan(order);
	if (numbered) return {
		steps: finish(numbered, order),
		spent: false,
		finish: base
	};
	const directed = directedPlan(order);
	if (directed) return {
		steps: finish(directed, order),
		spent: false,
		finish: base
	};
	const text = await callCheap(job, [{
		role: "system",
		content: "You are the chief. You only plan. Do not answer the task and do not browse. Define the finish line in concrete terms, then split the work into goals. Each goal is one assignment for one follower. Reply with one JSON object {\"finish\":\"what must be stated\",\"steps\":[{\"fn\":\"read\",\"brief\":\"one short assignment\"}]}. Use 2 to 4 goals. A brief is only the short final input, such as one site or one target. Do not copy shared instructions into a brief. Do not add a review goal. Do not state the answer. Try saved fixes that already worked. Do not repeat a fix that already failed."
	}, {
		role: "user",
		content: `${readShared(job) ? `SHARED INSTRUCTIONS\n${readShared(job)}\n\n` : ""}${(() => {
			const found = searchFailures(taskTypeOf(order), sourceOf(order), order);
			noteRepoMatches(job, found.used.map((row) => row.id));
			const lesson = lessonText(found);
			return lesson ? `FAILURE REPOSITORY\n${lesson}\n\n` : "";
		})()}FINAL INPUT\n${order.slice(0, 1200)}`
	}]);
	return {
		steps: finish((text ? parsePlan(text) : null) ?? fallbackPlan(order), order),
		spent: true,
		finish: (text ? parseFinish(text) : "") || base
	};
}
async function buildPlan(job, order) {
	return (await preparePlan(job, order)).steps;
}
function hideShared(job, value) {
	const shared = readShared(job);
	const flat = shared.replace(/\s+/g, " ").trim();
	const walk = (item) => {
		if (typeof item === "string") {
			let next = item;
			if (shared.length >= 8) next = next.split(shared).join("");
			if (flat.length >= 8) next = next.split(flat).join("");
			return next.replace(/[ \t]+\n/g, "\n").trim();
		}
		if (Array.isArray(item)) return item.map(walk);
		if (item && typeof item === "object") {
			const out = {};
			for (const [key, child] of Object.entries(item)) out[key] = walk(child);
			return out;
		}
		return item;
	};
	return walk(value);
}
async function logRpc(job, method, params, rpc, run) {
	const line = rpcLine(job || "step", method, hideShared(job, params));
	rpc.push(line);
	await sendChiefLine(job || "step", run, line, method === "step_result" || method === "assemble" || method === "review" ? "follower" : "chief");
}
async function tellChief(job, previous, next, reason, run = "") {
	const line = rpcLine(job || "step", "follower_changed", {
		old: previous,
		new: next,
		reason,
		job
	});
	await sendChiefLine(job || "step", run || job || "step", line, "chief");
}
async function runPlan(job, order) {
	if (!readShared(job)) {
		const standing = standingShared();
		if (standing) putShared(job, standing);
	}
	try {
		return await runPlanBody(job, order);
	} finally {
		wipeShared(job);
		clearWorking(job);
	}
}
async function runPlanBody(job, order) {
	const chief = openChief(job, order);
	const prepared = await preparePlan(job, order);
	const plan = prepared.steps;
	const rpc = [];
	const run = crypto.randomUUID().replace(/-/g, "").slice(0, 16);
	const done = /* @__PURE__ */ new Map();
	const tried = /* @__PURE__ */ new Set();
	await logRpc(job, "plan", {
		finish: prepared.finish,
		steps: plan.map((step) => ({
			n: step.n,
			fn: step.fn,
			needs: step.needs,
			brief: step.brief
		})),
		crew: crewOf(chief, job)
	}, rpc, run);
	const pending = [...plan];
	let answer = "";
	let accepted = false;
	while (pending.length > 0 && !accepted) {
		const readyIndex = pending.findIndex((step) => step.needs.every((n) => done.get(n)?.ok));
		if (readyIndex < 0) break;
		const [step] = pending.splice(readyIndex, 1);
		if (!step) break;
		const record = await pursueGoal({
			job,
			step,
			task: prepared.finish,
			done,
			run,
			last: pending.length === 0
		});
		done.set(record.n, record);
		if (record.follower) tried.add(record.follower);
		await logRpc(job, record.fn === "assemble" ? "assemble" : "step_result", {
			n: record.n,
			fn: record.fn,
			follower: record.follower,
			ok: record.ok,
			reason: record.reason
		}, rpc, run);
		if (record.ok && record.reason === "task") {
			answer = record.text;
			accepted = true;
		} else if (!record.ok) break;
	}
	setChiefAnswer(job, accepted ? answer : "");
	const steps = [...done.values()].sort((left, right) => left.n - right.n);
	const sources = [...new Set(steps.flatMap((step) => step.pages))].slice(0, 12);
	const heard = linesFromRead(await readBotMessages(quayChannel(job)), run);
	return {
		accepted,
		answer: accepted ? answer : "",
		sources,
		plan,
		steps,
		tried: [...tried],
		rpc: heard.length === rpc.length && heard.length > 0 ? heard : rpc,
		spent: prepared.spent || tried.size > 0
	};
}
//#endregion
export { readChannel as A, statusBoard as B, openTask as C, probeSandbox as D, postBotText as E, registerMissing as F, taskKind as H, rpcHint as I, runPlan as L, readTask as M, readTrace as N, pushTrace as O, readWorking as P, sandboxFailed as R, openChief as S, pinModel as T, tellChief as U, taskIdFor as V, updateTask as W, latestView as _, buildPlan as a, noteStep as b, clearAudit as c, deliverBotText as d, deliverChiefPacket as f, isClosed as g, freeModels as h, bindPageTask as i, readLive as j, putStanding as k, clearPin as l, finishTrace as m, beginJobShared as n, callFollower as o, enqueueJob as p, beginTrace as r, chiefById as s, absorbAccounts as t, createSsrRpc as u, leaseBrowser as v, pageTaskId as w, noteTask as x, nextDeliveryDelay as y, standingShared as z };
