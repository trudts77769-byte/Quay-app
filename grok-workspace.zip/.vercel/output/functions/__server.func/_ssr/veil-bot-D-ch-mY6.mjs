import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/veil-bot-D-ch-mY6.js
var ORIGIN = "https://infoveil.grok.me";
var READER = "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)";
function quayChannel(job) {
	return `quay-${(job || "job").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 40) || "job"}`;
}
function forVeil(line) {
	const text = line.replace(/\s+/g, " ").trim();
	if (!text) return "";
	if (/password|passcode|\bssn\b|social security|\bcvv\b|card number|KIND\s+(type|values)/i.test(text)) return "";
	return text.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "{EMAIL}").replace(/\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/g, "{PHONE}").slice(0, 3500);
}
async function postBotMessage(channel, envelope) {
	const line = forVeil(envelope.line);
	if (!line) return "";
	try {
		const response = await fetch(`${ORIGIN}/api/bot/post`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Accept: "application/json",
				"User-Agent": READER
			},
			body: JSON.stringify({
				channel,
				envelope: {
					...envelope,
					line
				}
			}),
			signal: AbortSignal.timeout(12e3)
		});
		if (!response.ok) return "";
		const data = await response.json();
		return data.ok ? String(data.id ?? "") : "";
	} catch {
		return "";
	}
}
async function readChannel(channel) {
	try {
		const url = new URL("/api/bot/read", ORIGIN);
		url.searchParams.set("channel", channel);
		const response = await fetch(url, {
			headers: {
				Accept: "application/json",
				"User-Agent": READER
			},
			signal: AbortSignal.timeout(12e3)
		});
		if (!response.ok) return {
			ok: false,
			error: (await response.text()).replace(/\s+/g, " ").trim().slice(0, 180) || "Veil did not answer.",
			messages: []
		};
		return {
			ok: true,
			error: "",
			messages: ((await response.json()).messages ?? []).map((row) => ({
				id: String(row.id ?? ""),
				envelope: typeof row.envelope === "string" ? row.envelope : "",
				expiresAt: Number(row.expiresAt ?? 0)
			}))
		};
	} catch (error) {
		return {
			ok: false,
			error: (error instanceof Error ? error.message : "Veil did not answer.").slice(0, 180),
			messages: []
		};
	}
}
async function readBotMessages(channel) {
	const read = await readChannel(channel);
	return read.ok ? read.messages : [];
}
var deliverChiefPacket_createServerFn_handler = createServerRpc({
	id: "366ed8b94fb7ac68963c3314692a32956840e0b7a9eb27775b18e03a24a9022f",
	name: "deliverChiefPacket",
	filename: "src/lib/quay/veil-bot.ts"
}, (opts) => deliverChiefPacket.__executeServer(opts));
var deliverChiefPacket = createServerFn({ method: "POST" }).validator((input) => {
	const packet = typeof input?.packet === "string" ? input.packet.trim().slice(0, 4e3) : "";
	if (packet.length < 2) throw new Error("Nothing to send.");
	return { packet };
}).handler(deliverChiefPacket_createServerFn_handler, async ({ data }) => {
	const { scrubSecrets } = await import("./secrets-C8jEd3tJ.mjs").then((n) => n.i);
	const line = forVeil(scrubSecrets(data.packet));
	if (!line) return "Not sent. Quay does not post private values, and it keeps no Veil copy.";
	const channel = quayChannel("chief");
	const id = await postBotMessage(channel, {
		from: "chief",
		job: "chief",
		run: "packet",
		line
	});
	if (!id) return "Veil did not take that packet.";
	return (await readBotMessages(channel)).some((row) => row.id === id) ? "Sent on Veil. Quay kept no copy." : "Veil did not show that message back. Quay kept no copy.";
});
//#endregion
export { deliverChiefPacket_createServerFn_handler };
