import { o as __toESM, r as __exportAll } from "../_runtime.mjs";
import { J as require_react, _ as createFileRoute, b as useRouter, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as toUrl, n as PROTOCOL, p as readPublicDocument, t as GOOGLE_URL } from "./read-page-BfummKTD.mjs";
import { i as formatAgent, s as runAgent } from "./agent-CGUX9xtu.mjs";
import { n as readSecret, r as scrubSecrets } from "./secrets-C8jEd3tJ.mjs";
import { A as readChannel, B as statusBoard, C as openTask, D as probeSandbox, E as postBotText, H as taskKind, I as rpcHint, L as runPlan, M as readTask, O as pushTrace, U as tellChief, V as taskIdFor, W as updateTask, a as buildPlan, b as noteStep, d as deliverBotText, g as isClosed, o as callFollower, p as enqueueJob, t as absorbAccounts, v as leaseBrowser, x as noteTask, y as nextDeliveryDelay } from "./plan-DwQopg9_.mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { createHash, timingSafeEqual } from "node:crypto";
import { existsSync } from "node:fs";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { createInterface } from "node:readline";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DOmGfn_D.js
var router_DOmGfn_D_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-B7zpICrE.css";
var APP_NAME = "Quay";
var Route$15 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "A language model reads any public page here and answers in ordinary sentences."
			},
			{
				name: "theme-color",
				content: "#13160f"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,560;9..144,640&family=IBM+Plex+Mono:wght@400;500&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$1 = () => import("./routes-CTr2Gr4w.mjs");
var Route$14 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./docs-CE-m-3TU.mjs");
var Route$13 = createFileRoute("/docs")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var HEADERS$7 = {
	"Cache-Control": "no-store",
	"Content-Type": "text/plain; charset=utf-8",
	"X-Content-Type-Options": "nosniff"
};
function callerDenied(request) {
	const expected = readSecret("QUAY_CALLER_TOKEN");
	if (!expected) return new Response("QUAY_CALLER_TOKEN is not set. This live route is closed.\n", {
		status: 503,
		headers: HEADERS$7
	});
	const token = (request.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
	const left = createHash("sha256").update(token).digest();
	const right = createHash("sha256").update(expected).digest();
	if (!timingSafeEqual(left, right)) return new Response("Unauthorized. Send Authorization: Bearer and the caller token.\n", {
		status: 401,
		headers: HEADERS$7
	});
	return null;
}
var HEADERS$6 = {
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
	"Access-Control-Allow-Headers": "Content-Type, Authorization",
	"Cache-Control": "no-store",
	"Content-Type": "text/plain; charset=utf-8",
	"X-Content-Type-Options": "nosniff"
};
var Route$12 = createFileRoute("/api/bot")({ server: { handlers: {
	OPTIONS: async () => new Response(null, {
		status: 204,
		headers: HEADERS$6
	}),
	GET: async ({ request }) => {
		if (new URL(request.url).searchParams.get("status") === "1") {
			const denied = callerDenied(request);
			if (denied) return denied;
			return Response.json(statusBoard(), { headers: { "Cache-Control": "no-store" } });
		}
		const body = [
			"Legacy tape. AIs do not submit jobs here. Post a QUAY JOB on https://infoveil.grok.me. Veil pings Quay. Humans use the Prompt box.",
			"",
			"The chief only plans and reviews. Each goal is one follower. A fail runs the redundancy workflow, then the same follower gets an upgraded assignment. After 4 cycles, Quay swaps followers. Results stay empty until the task is complete.",
			"Numbered steps in the order are the split. Otherwise Quay makes one cheap plan, or uses a fixed fallback plan.",
			"Chief-to-follower messages go through https://infoveil.grok.me POST /api/bot/post and GET /api/bot/read. Quay keeps no copy.",
			"Bot to bot uses one JSON-RPC 2.0 object per line. Methods: plan, step, step_result, follower_changed, assemble, review. " + rpcHint(),
			"Q1 tape commands are a legacy note.",
			"",
			PROTOCOL
		].join("\n");
		return new Response(`${body}\n`, {
			status: 200,
			headers: HEADERS$6
		});
	},
	POST: async () => new Response("AIs submit a QUAY JOB on https://infoveil.grok.me. Quay runs it only when Veil pings. This route does not run a job.\n", {
		status: 410,
		headers: HEADERS$6
	})
} } });
var _0002_line_default = "create table if not exists partner_packet (\n  row_id text primary key,\n  packet_id text not null,\n  from_side text not null,\n  to_side text not null,\n  re_id text not null,\n  kind text not null,\n  ttl text not null,\n  keep_chat text not null,\n  body text not null,\n  next_step text not null,\n  created_at timestamptz not null default now(),\n  expires_at timestamptz not null\n);\n";
var _0003_crew_default = "create table if not exists crew_seat (\n  name text primary key,\n  role text not null,\n  joined_at timestamptz not null default now()\n);\n\ncreate table if not exists crew_note (\n  id text primary key,\n  name text not null,\n  role text not null,\n  kind text not null,\n  body text not null,\n  created_at timestamptz not null default now()\n);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({
			"/migrations/0002_line.sql": _0002_line_default,
			"/migrations/0003_crew.sql": _0003_crew_default
		});
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
var scriptPath = fileURLToPath(new URL("../../../scripts/form-hands.mjs", import.meta.url));
var PAY$1 = /\b(pay|purchase|buy|checkout|place order)\b/i;
async function saveSecrets(task, body) {
	const sql = await getSql();
	await ensure$1();
	for (const line of body.split("\n")) {
		const match = line.match(/^([A-Z0-9_]{2,40})\s*=\s*(.*)$/);
		if (!match) continue;
		await sql`
      insert into crew_secret (task, key, value) values (${task}, ${match[1]}, ${match[2].trim()})
      on conflict (task, key) do update set value = ${match[2].trim()}
    `;
	}
}
async function formLine(task) {
	const sql = await getSql();
	await ensure$1();
	const row = (await sql`
    select status, shot from crew_form where task = ${task}
  `)[0];
	const shot = row?.shot ? `/api/crew/shot/${row.shot}.png` : "(none)";
	return `STATUS ${row?.status || "(none)"}\nSHOT ${shot}`;
}
async function readShot(id) {
	const sql = await getSql();
	await ensure$1();
	const rows = await sql`select png from crew_shot where id = ${id}`;
	return rows[0]?.png ? String(rows[0].png) : null;
}
async function ensure$1() {
	const sql = await getSql();
	await sql.query("create table if not exists crew_secret (task text not null, key text not null, value text not null, primary key (task, key))");
	await sql.query("create table if not exists crew_shot (id text primary key, task text not null, png text not null)");
	await sql.query("create table if not exists crew_form (task text primary key, status text not null, shot text not null default '', pending text not null default '')");
}
async function secretsFor$1(task) {
	const rows = await (await getSql())`select key, value from crew_secret where task = ${task}`;
	const secrets = {};
	for (const row of rows) secrets[String(row.key)] = String(row.value);
	return secrets;
}
function hide$1(text, secrets) {
	let out = text;
	for (const value of Object.values(secrets)) if (value.length > 2) out = out.split(value).join("{hidden}");
	return out;
}
function isPayment$1(label) {
	return PAY$1.test(label.trim());
}
function fallback$1(elements) {
	const empty = elements.find((item) => item.kind === "field" && !item.value);
	if (empty) {
		const label = empty.label.toLowerCase();
		const token = /last/.test(label) ? "{LAST_NAME}" : /email/.test(label) ? "{EMAIL}" : /phone/.test(label) ? "{PHONE}" : /city/.test(label) ? "{CITY}" : /zip|postal/.test(label) ? "{ZIP}" : /county/.test(label) ? "{COUNTY}" : /address/.test(label) ? "{ADDRESS}" : /case|summary|describe|legal|problem/.test(label) ? "{CASE_SUMMARY}" : "{FIRST_NAME}";
		return `TYPE "${empty.label}" = ${token}`;
	}
	const menu = elements.find((item) => item.kind === "select" && item.options.length);
	if (menu) {
		const option = menu.options.find((item) => /civil rights|constitutional/i.test(item)) || menu.options[0];
		return `SELECT "${menu.label}" = ${option}`;
	}
	const button = elements.find((item) => item.kind === "button" && !isPayment$1(item.label) && !/login|sign in|password/i.test(item.label));
	if (button) return `CLICK "${button.label}"`;
	return "SCROLL down";
}
async function ask(task, prompt) {
	const text = (await callFollower(task, "form", [{
		role: "system",
		content: "You are one follower. Do only the one function in the user message. One line. Do not take the next step."
	}, {
		role: "user",
		content: prompt
	}], (previous, next, reason) => tellChief(task, previous, next, reason))).text?.split("\n")[0]?.trim() ?? "";
	if (!text || /^(i'?m sorry|i can'?t|i cannot)/i.test(text)) return null;
	return text.slice(0, 240);
}
function parseMove$1(line) {
	const clickAt = line.match(/^CLICK\s+(-?\d+)\s*,\s*(-?\d+)/i);
	if (clickAt) return {
		cmd: "click",
		label: "",
		text: "",
		x: Number(clickAt[1]),
		y: Number(clickAt[2])
	};
	const click = line.match(/^CLICK\s+"([^"]+)"/i);
	if (click) return {
		cmd: "click",
		label: click[1],
		text: "",
		x: 0,
		y: 0
	};
	const typed = line.match(/^TYPE\s+"([^"]+)"\s*=\s*(.+)$/i);
	if (typed) return {
		cmd: "type",
		label: typed[1],
		text: typed[2].trim(),
		x: 0,
		y: 0
	};
	const selected = line.match(/^SELECT\s+"([^"]+)"\s*=\s*(.+)$/i);
	if (selected) return {
		cmd: "select",
		label: selected[1],
		text: selected[2].trim(),
		x: 0,
		y: 0
	};
	if (/^SCROLL/i.test(line)) return {
		cmd: "scroll",
		label: "",
		text: "",
		x: 0,
		y: 0
	};
	return null;
}
async function runFormCrew(task, order) {
	const found = order.match(/https?:\/\/[^\s<>"']+/i)?.[0]?.replace(/[),.;]+$/, "") ?? "";
	const url = toUrl(found);
	if (!url) return "The form order needs a public https address.";
	if (!existsSync(scriptPath)) return "The screen is not available on this host.";
	const planned = await buildPlan(task, order);
	await ensure$1();
	const secrets = await secretsFor$1(task);
	const sql = await getSql();
	const child = spawn(process.execPath, [scriptPath], { stdio: [
		"pipe",
		"pipe",
		"ignore"
	] });
	const lines = createInterface({ input: child.stdout });
	const queue = [];
	let pending = null;
	lines.on("line", (line) => {
		if (pending) {
			const resolve = pending;
			pending = null;
			resolve(line);
		} else queue.push(line);
	});
	const readLine = () => new Promise((resolve, reject) => {
		if (queue.length) {
			resolve(queue.shift());
			return;
		}
		const timer = setTimeout(() => reject(/* @__PURE__ */ new Error("timeout")), 3e4);
		pending = (line) => {
			clearTimeout(timer);
			resolve(line);
		};
	});
	const stop = () => {
		child.stdin.write(`${JSON.stringify({ cmd: "stop" })}\n`);
		child.kill();
	};
	child.stdin.write(`${JSON.stringify({
		url,
		secrets
	})}\n`);
	let cursor = 0;
	let same = "";
	let repeats = 0;
	let lastShot = "";
	let step = 0;
	const started = Date.now();
	const maxMillis = Number(process.env.QUAY_MAX_MILLIS ?? 9e5) || 9e5;
	try {
		while (Date.now() - started < maxMillis) {
			step += 1;
			const raw = await readLine();
			const screen = JSON.parse(raw);
			if (!screen.ok) return "The screen did not open.";
			const id = crypto.randomUUID();
			await sql`insert into crew_shot (id, task, png) values (${id}, ${task}, ${screen.shot})`;
			lastShot = id;
			await sql`
        insert into crew_form (task, status, shot, pending) values (${task}, ${"working"}, ${id}, ${""})
        on conflict (task) do update set status = ${"working"}, shot = ${id}
      `;
			await sql`
        insert into crew_task_note (id, task, name, role, kind, body)
        values (${crypto.randomUUID()}, ${task}, ${"screen"}, ${"FOLLOWER"}, ${"PICTURE"}, ${`/api/crew/shot/${id}.png`})
      `;
			const listed = (screen.elements ?? []).map((item) => `- ${item.kind} "${item.label}" at ${item.x},${item.y}${item.options.length ? ` options ${item.options.join(" | ")}` : ""}`).join("\n");
			const signature = `${screen.url}|${listed}`;
			repeats = signature === same ? repeats + 1 : 0;
			same = signature;
			if (repeats >= 3) {
				await finish(task, id, "stopped: the same screen came up 3 times");
				return "stopped: the same screen came up 3 times";
			}
			if (screen.elements.some((item) => /captcha|password/i.test(item.label))) {
				await finish(task, id, "stopped: password or captcha");
				return "stopped: password or captcha. Nothing was sent.";
			}
			const current = planned[Math.min(cursor, Math.max(planned.length - 1, 0))];
			noteStep({
				id: `${task}:form:${current?.n ?? step}`,
				slot: "form",
				step: current?.n ?? step,
				fn: current?.fn ?? "write",
				status: "running",
				follower: "form-step",
				tries: step
			});
			const decision = await ask(task, hide$1(`You are one follower. One function only.\nSTEP ${current?.n ?? step} ${current?.fn ?? "write"}\n${current?.brief ?? "Use this screen."}\nElements:\n${listed}\nReply with one line only: CLICK "label" or TYPE "label" = {PLACEHOLDER} or SELECT "label" = option or SCROLL down or DONE: what the screen says. Never use a real name. Do not pay or buy. The chief decides when the step is complete.`, secrets));
			const command = decision && /^(CLICK|TYPE|SELECT|SCROLL|DONE:)/i.test(decision) ? decision : fallback$1(screen.elements);
			await sql`
        insert into crew_task_note (id, task, name, role, kind, body)
        values (${crypto.randomUUID()}, ${task}, ${current?.fn || "step"}, ${"FOLLOWER"}, ${"STEP"}, ${hide$1(command, secrets).slice(0, 240)})
      `;
			if (/^DONE:/i.test(command)) {
				await finish(task, id, command);
				return command;
			}
			const move = parseMove$1(command);
			const label = move?.label || "";
			const county = (screen.elements ?? []).find((item) => /county/i.test(item.label) && (!item.value || /select|choose/i.test(item.value)));
			const guarded = move && move.cmd === "click" && /county|select/i.test(label) ? {
				cmd: "select",
				label,
				text: "{COUNTY}",
				x: 0,
				y: 0
			} : move && county && move.cmd === "click" && /search/i.test(label) ? {
				cmd: "select",
				label: county.label,
				text: "{COUNTY}",
				x: 0,
				y: 0
			} : move;
			if (!guarded) continue;
			if (isPayment$1(guarded.label)) {
				await finish(task, id, "Not sent. Quay does not pay or buy.");
				return "Not sent. Quay does not pay or buy.";
			}
			child.stdin.write(`${JSON.stringify(guarded)}\n`);
			cursor += 1;
		}
		await finish(task, lastShot, "Stopped: time limit.");
		return "Stopped: time limit.";
	} catch {
		return "The screen timed out.";
	} finally {
		stop();
	}
}
async function finish(task, shot, status) {
	const sql = await getSql();
	await sql`
    insert into crew_form (task, status, shot, pending) values (${task}, ${status}, ${shot}, ${""})
    on conflict (task) do update set status = ${status}, shot = ${shot}
  `;
	await sql`
    insert into crew_task_note (id, task, name, role, kind, body)
    values (${crypto.randomUUID()}, ${task}, ${"screen"}, ${"FOLLOWER"}, ${"ANSWER"}, ${status.slice(0, 500)})
  `;
}
async function approveForm(task) {
	await ensure$1();
	const sql = await getSql();
	const rows = await sql`select status from crew_form where task = ${task}`;
	if (!String(rows[0]?.status ?? "").includes("READY TO SUBMIT")) return "There is no final button waiting.";
	await sql`
    update crew_form set status = ${"approved, not sent"} where task = ${task}
  `;
	return "Approved. The screen was already closed, so the final button was not pressed and nothing was sent.";
}
async function hireFollowers(task, order, _need = 8) {
	const run = await runPlan(task || "hire", order || task);
	const tried = run.tried;
	const pages = [...new Set(run.steps.flatMap((step) => step.pages))];
	const steps = run.steps.map((step) => `${step.follower || "none"} ${step.fn} ${step.n}`);
	const rows = run.steps.filter((step) => step.text || step.follower).map((step) => ({
		name: step.follower || step.fn,
		body: step.fn === "assemble" && run.accepted ? run.answer : step.text,
		tried,
		pages: step.pages.length > 0 ? step.pages : pages,
		steps,
		fn: step.fn,
		accepted: false
	}));
	if (run.accepted) rows.push({
		name: run.steps.find((step) => step.fn === "assemble")?.follower || "assembler",
		body: run.answer,
		tried,
		pages,
		steps,
		fn: "assemble",
		accepted: true
	});
	if (rows.length === 0) return [{
		name: "",
		body: "",
		tried,
		pages,
		steps,
		fn: "",
		accepted: false
	}];
	return rows;
}
var SECRET$1 = /(password|passcode|social security|\bssn\b|account number|license number|api[_ -]?key|\bsecret\b|\blogin\b)/i;
function cleanSlug(raw) {
	const name = raw.trim().toLowerCase().replace(/\s+/g, "-");
	return /^[a-z0-9-]{2,40}$/.test(name) ? name : null;
}
function parseCrew(raw) {
	const lines = raw.replace(/\r/g, "").split("\n");
	let name = "";
	let task = "";
	let kind = "";
	const body = [];
	let inBody = false;
	for (const line of lines) {
		if (!inBody) {
			const match = line.trim().match(/^(NAME|TASK|KIND)\s+(.+)$/i);
			if (match) {
				const key = match[1].toUpperCase();
				if (key === "NAME") name = match[2];
				else if (key === "TASK") task = match[2];
				else kind = match[2].toLowerCase();
				continue;
			}
			if (line.trim().toUpperCase() === "BODY") {
				inBody = true;
				continue;
			}
			if (!line.trim()) continue;
		}
		if (line.trim()) body.push(line.trim());
	}
	const who = cleanSlug(name);
	const job = cleanSlug(task);
	if (!who) return { error: "NAME must be a short name, like north-wind." };
	if (!job) return { error: "TASK must be a short name for this cue only, like records-form." };
	if (![
		"open",
		"join",
		"instruct",
		"answer",
		"step",
		"hire",
		"secrets",
		"form",
		"approve"
	].includes(kind)) return { error: "KIND must be open, join, instruct, answer, step, hire, secrets, form, or approve." };
	const text = body.join("\n").trim().slice(0, kind === "secrets" ? 2e3 : 800);
	if (kind !== "open" && kind !== "join" && kind !== "hire" && kind !== "approve" && text.length < 2) return { error: "BODY is empty." };
	if (kind !== "secrets" && SECRET$1.test(text)) return { error: "Do not put logins or secrets on the crew line." };
	return {
		name: who,
		task: job,
		kind,
		body: text
	};
}
async function ready() {
	const sql = await getSql();
	await sql.query("create table if not exists crew_task (task text primary key, chief text not null, created_at timestamptz not null default now())");
	await sql.query("create table if not exists crew_member (task text not null, name text not null, role text not null, joined_at timestamptz not null default now(), primary key (task, name))");
	await sql.query("create table if not exists crew_task_note (id text primary key, task text not null, name text not null, role text not null, kind text not null, body text not null, created_at timestamptz not null default now())");
}
async function tasks() {
	await ready();
	return (await (await getSql())`
    select task, chief from crew_task order by created_at asc
  `).map((row) => ({
		task: String(row.task),
		chief: String(row.chief)
	}));
}
async function seats(task) {
	await ready();
	return (await (await getSql())`
    select name, role from crew_member where task = ${task} order by joined_at asc
  `).map((row) => ({
		name: String(row.name),
		role: String(row.role)
	}));
}
async function notes(task) {
	return (await (await getSql())`
    select name, role, kind, body from crew_task_note where task = ${task} order by created_at asc
  `).map((row) => ({
		name: String(row.name),
		role: String(row.role),
		kind: String(row.kind),
		body: String(row.body)
	}));
}
function formatTaskList(list) {
	const lines = [
		"TASKS",
		"Each cue from the person is its own task. A new task gets a new chief. Followers stay on that task only.",
		"The AI the person just sent opens it: NAME your-name, TASK a-new-slug, KIND open.",
		"Helpers for that same cue join it: KIND join and the same TASK. Do not open it again. Do not read another task."
	];
	if (list.length === 0) lines.push("(none)");
	else for (const row of list) lines.push(`${row.task} chief ${row.chief}`);
	return lines.join("\n");
}
function formatCrew(task, list, board, you = "") {
	const chief = list.find((seat) => seat.role === "CHIEF");
	const followers = list.filter((seat) => seat.role !== "CHIEF").map((seat) => seat.name);
	const latest = [...board].reverse().find((note) => note.kind === "INSTRUCT" || note.kind === "STEP");
	const answers = board.filter((note) => note.kind === "ANSWER");
	const lines = [
		`TASK ${task}`,
		"This crew is only for this task. Another cue from the person is a different task and a different chief.",
		"The chief splits the order into steps. Each step gets its own follower. The chief never hands the whole job to one follower.",
		"A reader step uses the page reader. A writer step uses a chat model. The reviewer must pass before the chief accepts the answer.",
		"A follower may lead a step of this order. Post KIND step, do that step, then post KIND answer for this chief.",
		"Only this chief returns the final output for this task to the person.",
		you ? `YOU ARE ${you}` : "Post NAME, TASK, and KIND join.",
		`CHIEF ${chief ? chief.name : "(none)"}`,
		`FOLLOWERS ${followers.length ? followers.join(", ") : "(none)"}`,
		"LATEST ORDER",
		latest ? `${latest.name}: ${latest.body}` : "(none)",
		"ANSWERS FOR THIS CHIEF"
	];
	if (answers.length === 0) lines.push("(none)");
	else for (const note of answers) lines.push(`${note.name}: ${note.body}`);
	lines.push("NOTES");
	if (board.length === 0) lines.push("(none)");
	else for (const note of board) lines.push(`${note.role} ${note.name} ${note.kind}: ${note.body}`);
	return lines.join("\n");
}
async function readCrew(task = "") {
	const job = cleanSlug(task);
	if (!job) return formatTaskList(await tasks());
	return `${formatCrew(job, await seats(job), await notes(job))}\n${await formLine(job)}`;
}
async function pullWorkers(task, order) {
	const rows = await hireFollowers(task, order);
	const sql = await getSql();
	const seated = [];
	for (const row of rows) {
		if (!row.accepted || !row.name || !row.body) continue;
		await sql`
      insert into crew_member (task, name, role) values (${task}, ${row.name}, 'FOLLOWER')
      on conflict (task, name) do nothing
    `;
		await sql`
      insert into crew_task_note (id, task, name, role, kind, body)
      values (${crypto.randomUUID()}, ${task}, ${row.name}, 'FOLLOWER', 'ANSWER', ${row.body})
    `;
		seated.push(`${row.fn} ${row.name}`);
	}
	if (!rows.some((row) => row.accepted)) return "Working. The task is not complete.";
	const answer = rows.find((row) => row.accepted)?.body ?? "";
	return `One follower per step. ${seated.join(", ")}. ACCEPTED ${answer}`;
}
async function postCrew(raw) {
	const parsed = parseCrew(raw);
	if ("error" in parsed) return {
		status: 400,
		text: parsed.error
	};
	await ready();
	const sql = await getSql();
	const existing = (await tasks()).find((row) => row.task === parsed.task);
	if (parsed.kind === "open") {
		if (existing) {
			const list = await seats(parsed.task);
			return {
				status: 409,
				text: `${formatCrew(parsed.task, list, await notes(parsed.task))}\nThis task already has chief ${existing.chief}. A new cue needs a new TASK. Do not join this one unless the person sent you to help it.`
			};
		}
		await sql`insert into crew_task (task, chief) values (${parsed.task}, ${parsed.name})`;
		await sql`
      insert into crew_member (task, name, role) values (${parsed.task}, ${parsed.name}, 'CHIEF')
    `;
		return {
			status: 200,
			text: `${formatCrew(parsed.task, await seats(parsed.task), [], "CHIEF")}\nYou are the chief of ${parsed.task} only. Find the public https address yourself and post KIND instruct with it. The person does not type addresses. Do not ask them.`
		};
	}
	if (!existing) return {
		status: 404,
		text: `No chief has opened ${parsed.task}. The AI the person just sent must open it with KIND open. Do not invent a chief.`
	};
	if (parsed.kind === "secrets" || parsed.kind === "form" || parsed.kind === "approve") {
		const list = await seats(parsed.task);
		if (list.find((seat) => seat.name === parsed.name)?.role !== "CHIEF") return {
			status: 403,
			text: "Only the chief of this task can post secrets, form, or approve."
		};
		if (parsed.kind === "secrets") {
			await saveSecrets(parsed.task, parsed.body);
			return {
				status: 200,
				text: `${formatCrew(parsed.task, list, await notes(parsed.task), "CHIEF")}\n${await formLine(parsed.task)}\nSecrets stored for this task only. They are not shown and are not sent to helpers.`
			};
		}
		if (parsed.kind === "approve") {
			const result = await approveForm(parsed.task);
			return {
				status: 200,
				text: `${formatCrew(parsed.task, await seats(parsed.task), await notes(parsed.task), "CHIEF")}\n${await formLine(parsed.task)}\n${result}`
			};
		}
		const result = await runFormCrew(parsed.task, parsed.body);
		return {
			status: 200,
			text: `${formatCrew(parsed.task, await seats(parsed.task), await notes(parsed.task), "CHIEF")}\n${await formLine(parsed.task)}\n${result}`
		};
	}
	await sql`
    insert into crew_member (task, name, role) values (${parsed.task}, ${parsed.name}, 'FOLLOWER')
    on conflict (task, name) do nothing
  `;
	const list = await seats(parsed.task);
	const role = list.find((seat) => seat.name === parsed.name)?.role ?? "FOLLOWER";
	if (parsed.kind === "instruct" && role !== "CHIEF") return {
		status: 403,
		text: `${formatCrew(parsed.task, list, await notes(parsed.task), "FOLLOWER")}\nOnly the chief of this task writes the order.`
	};
	if (parsed.kind !== "join" && parsed.kind !== "hire") await sql`
      insert into crew_task_note (id, task, name, role, kind, body)
      values (${crypto.randomUUID()}, ${parsed.task}, ${parsed.name}, ${role}, ${parsed.kind.toUpperCase()}, ${parsed.body})
    `;
	let hiring = "";
	if (role === "CHIEF" && (parsed.kind === "instruct" || parsed.kind === "hire")) {
		const order = parsed.kind === "instruct" ? parsed.body : [...await notes(parsed.task)].reverse().find((note) => note.kind === "INSTRUCT")?.body ?? "";
		hiring = order ? await pullWorkers(parsed.task, order) : "Chief: post KIND instruct with the public https address you found. The person does not type it. Quay hires followers after that.";
	}
	const shown = formatCrew(parsed.task, await seats(parsed.task), await notes(parsed.task), role);
	if (role === "CHIEF") return {
		status: 200,
		text: `${shown}\nYou are the chief of this task only. You return its final output to the person.\n${hiring}`
	};
	return {
		status: 200,
		text: `${shown}\nYou follow the chief of ${parsed.task} only. Use /api/quay-agent for this order. Post KIND answer here. Do not answer for another task.`
	};
}
var HEADERS$5 = {
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
	"Access-Control-Allow-Headers": "Content-Type, Authorization",
	"Cache-Control": "no-store",
	"X-Content-Type-Options": "nosniff"
};
function text$1(body, status = 200) {
	return new Response(`${body}\n`, {
		status,
		headers: {
			...HEADERS$5,
			"Content-Type": "text/plain; charset=utf-8"
		}
	});
}
var Route$11 = createFileRoute("/api/crew")({ server: { handlers: {
	OPTIONS: async () => new Response(null, {
		status: 204,
		headers: HEADERS$5
	}),
	GET: async ({ request }) => {
		const denied = callerDenied(request);
		if (denied) return denied;
		try {
			return text$1(await readCrew(new URL(request.url).searchParams.get("task") ?? ""));
		} catch {
			return text$1("The crew line did not open.", 502);
		}
	},
	POST: async ({ request }) => {
		const denied = callerDenied(request);
		if (denied) return denied;
		try {
			const result = await postCrew(await request.text());
			return text$1(result.text, result.status);
		} catch {
			return text$1("The crew line did not take that.", 502);
		}
	}
} } });
var handsPath = fileURLToPath(new URL("../../../scripts/form-hands.mjs", import.meta.url));
var PAY = /\b(pay|purchase|buy|checkout|place order)\b/i;
async function ensure() {
	const sql = await getSql();
	await sql.query("create table if not exists quay_job (id text primary key, url text not null, job_order text not null, status text not null, answer text not null default '', pending text not null default '', shot text not null default '', created_at timestamptz not null default now())");
	await sql.query("create table if not exists quay_job_secret (job text not null, key text not null, value text not null, primary key (job, key))");
	await sql.query("create table if not exists quay_job_shot (id text primary key, job text not null, png text not null)");
	await sql.query("create table if not exists quay_job_step (id text primary key, job text not null, n int not null, command text not null, shot text not null default '')");
}
function cleanValues(values) {
	const secrets = {};
	for (const [key, value] of Object.entries(values)) {
		const name = key.trim().toUpperCase().replace(/[^A-Z0-9_]/g, "");
		if (!name) continue;
		if (/PASSWORD|PASSCODE|SSN|CARD|CVV|SECRET/.test(name)) return { error: "Do not store passwords or card numbers." };
		if (typeof value !== "string") continue;
		secrets[name] = value.trim().slice(0, 400);
	}
	return secrets;
}
async function createJob(input) {
	const url = toUrl(input.url || "");
	const order = input.order?.trim() ?? "";
	if (!url) return { error: "Use a public https address." };
	if (order.length < 2) return { error: "Say the order in a sentence." };
	const values = cleanValues(input.values ?? {});
	if ("error" in values && typeof values.error === "string" && Object.keys(values).length === 1) return { error: values.error };
	await ensure();
	const id = crypto.randomUUID();
	const sql = await getSql();
	await sql`insert into quay_job (id, url, job_order, status) values (${id}, ${url}, ${order.slice(0, 800)}, ${"running"})`;
	for (const [key, value] of Object.entries(values)) await sql`insert into quay_job_secret (job, key, value) values (${id}, ${key}, ${value})`;
	enqueueJob(id, () => runJob(id).catch(async () => {
		await (await getSql())`update quay_job set status = ${"error"}, answer = ${"The screen stopped."} where id = ${id}`;
	}));
	return { id };
}
async function readJob(id) {
	await ensure();
	const sql = await getSql();
	const job = (await sql`
    select id, url, job_order, status, answer, shot from quay_job where id = ${id}
  `)[0];
	if (!job) return null;
	const steps = await sql`
    select n, command, shot from quay_job_step where job = ${id} order by n asc
  `;
	return {
		id: String(job.id),
		status: String(job.status),
		url: String(job.url),
		order: String(job.job_order),
		steps: steps.map((step) => ({
			step: Number(step.n),
			command: String(step.command),
			shot: step.shot ? `/api/job/shot/${step.shot}.png` : ""
		})),
		shot: job.shot ? `/api/job/shot/${job.shot}.png` : "",
		answer: String(job.answer || "")
	};
}
async function readJobShot(id) {
	await ensure();
	const rows = await (await getSql())`select png from quay_job_shot where id = ${id}`;
	return rows[0]?.png ? String(rows[0].png) : null;
}
function hide(text, secrets) {
	let out = text;
	for (const value of Object.values(secrets)) if (value.length > 2) out = out.split(value).join("{hidden}");
	return out;
}
function wantsSteps(order) {
	return /\bfill\b|\bform\b|click through|\bclick\b|\btype\b|\bselect\b/i.test(order);
}
function earlyAnswer(order, answer) {
	if (!wantsSteps(order)) return false;
	return !/ready to submit|no results|nothing found|not found|\berror\b|unavailable/i.test(answer);
}
function parseMove(line) {
	const text = line.trim();
	if (/^ANSWER:/i.test(text)) return { answer: text };
	const read = text.match(/^READ\s+(https?:\/\/\S+)/i);
	if (read) return {
		cmd: "read",
		label: "",
		text: "",
		url: read[1].replace(/[),.;]+$/, ""),
		x: 0,
		y: 0
	};
	const click = text.match(/^CLICK\s+"([^"]+)"/i);
	if (click) return {
		cmd: "click",
		label: click[1],
		text: "",
		url: "",
		x: 0,
		y: 0
	};
	const typed = text.match(/^TYPE\s+"([^"]+)"\s*=\s*(.+)$/i);
	if (typed) return {
		cmd: "type",
		label: typed[1],
		text: typed[2].trim(),
		url: "",
		x: 0,
		y: 0
	};
	const selected = text.match(/^SELECT\s+"([^"]+)"\s*=\s*(.+)$/i);
	if (selected) return {
		cmd: "select",
		label: selected[1],
		text: selected[2].trim(),
		url: "",
		x: 0,
		y: 0
	};
	if (/^SCROLL/i.test(text)) return {
		cmd: "scroll",
		label: "",
		text: "",
		url: "",
		x: 0,
		y: 0
	};
	return null;
}
function isPayment(label) {
	return PAY.test(label.trim());
}
async function askHelper(prompt, job) {
	const reply = (await callFollower(job, "browser", [{
		role: "system",
		content: "You are one follower. Do only the one function in the user message. Reply with one line. Do not take the next step."
	}, {
		role: "user",
		content: prompt
	}], (previous, next, reason) => tellChief(job, previous, next, reason))).text?.split("\n")[0]?.trim() ?? "";
	if (!reply || /^(i'?m sorry|i can'?t|i cannot)/i.test(reply)) return null;
	return reply.slice(0, 300);
}
function fallback(order, screen) {
	const text = `${screen.title}. ${screen.text}`.replace(/\s+/g, " ").trim();
	if (text.length > 40 && /what|say|page|report|read/i.test(order)) return `ANSWER: ${text.slice(0, 400)}`;
	const field = screen.elements.find((item) => item.kind === "field" && !item.value);
	if (field) {
		const label = field.label.toLowerCase();
		const token = /mail/.test(label) ? "{EMAIL}" : /phone/.test(label) ? "{PHONE}" : "{NAME}";
		return `TYPE "${field.label}" = ${token}`;
	}
	const button = screen.elements.find((item) => item.kind === "button" && !isPayment(item.label) && !/login|password|sign in/i.test(item.label));
	if (button) return `CLICK "${button.label}"`;
	return "SCROLL";
}
async function secretsFor(id) {
	const rows = await (await getSql())`select key, value from quay_job_secret where job = ${id}`;
	const secrets = {};
	for (const row of rows) secrets[String(row.key)] = String(row.value);
	return secrets;
}
function openHands(url, secrets) {
	const child = spawn(process.execPath, [handsPath], { stdio: [
		"pipe",
		"pipe",
		"ignore"
	] });
	const lines = createInterface({ input: child.stdout });
	const queue = [];
	let pending = null;
	lines.on("line", (line) => {
		if (pending) {
			const resolve = pending;
			pending = null;
			resolve(line);
		} else queue.push(line);
	});
	const read = () => new Promise((resolve, reject) => {
		if (queue.length) {
			resolve(queue.shift());
			return;
		}
		const timer = setTimeout(() => reject(/* @__PURE__ */ new Error("timeout")), 3e4);
		pending = (line) => {
			clearTimeout(timer);
			resolve(line);
		};
	});
	child.stdin.write(`${JSON.stringify({
		url,
		secrets
	})}\n`);
	return {
		read,
		send(move) {
			child.stdin.write(`${JSON.stringify(move)}\n`);
		},
		close() {
			child.stdin.write(`${JSON.stringify({ cmd: "stop" })}\n`);
			child.kill();
		}
	};
}
async function runJob(id) {
	if (!existsSync(handsPath)) {
		await (await getSql())`update quay_job set status = ${"error"}, answer = ${"The screen is not on this host."} where id = ${id}`;
		return;
	}
	const view = await readJob(id);
	if (!view) return;
	const secrets = await secretsFor(id);
	const sql = await getSql();
	const maxMillis = Number(process.env.QUAY_MAX_MILLIS ?? 9e5) || 9e5;
	const started = Date.now();
	const planned = await buildPlan(id, view.order);
	let cursor = 0;
	let same = "";
	let repeats = 0;
	await leaseBrowser(async () => {
		const hands = openHands(view.url, secrets);
		try {
			while (true) {
				if (Date.now() - started >= maxMillis) {
					await sql`update quay_job set status = ${"stopped"}, answer = ${"Stopped: time limit."} where id = ${id}`;
					return;
				}
				const screen = JSON.parse(await hands.read());
				if (!screen.ok) throw new Error(screen.title || "The screen did not open.");
				const shotId = crypto.randomUUID();
				await sql`insert into quay_job_shot (id, job, png) values (${shotId}, ${id}, ${screen.shot})`;
				await sql`update quay_job set shot = ${shotId} where id = ${id}`;
				if ((screen.elements ?? []).some((item) => /captcha|password/i.test(item.label))) {
					await sql`update quay_job set status = ${"stopped"}, answer = ${"Stopped: password or captcha. Nothing was sent."} where id = ${id}`;
					return;
				}
				const listed = (screen.elements ?? []).map((item) => `- ${item.kind} "${item.label}"${item.options.length ? ` [${item.options.join(" | ")}]` : ""}`).join("\n");
				const signature = `${screen.url}|${listed}`;
				repeats = signature === same ? repeats + 1 : 0;
				same = signature;
				if (repeats >= 3) {
					await sql`update quay_job set status = ${"stopped"}, answer = ${"Stopped: the same screen came up 3 times."} where id = ${id}`;
					return;
				}
				const current = planned[Math.min(cursor, Math.max(planned.length - 1, 0))];
				noteStep({
					id: `${id}:step:${current?.n ?? cursor}`,
					slot: "browser",
					step: current?.n ?? cursor,
					fn: current?.fn ?? "read",
					status: "running",
					follower: "browser-step",
					tries: cursor + 1
				});
				const reply = await askHelper(hide(`You are one follower. One function only.\nSTEP ${current?.n ?? cursor} ${current?.fn ?? "read"}\n${current?.brief ?? "Read this screen."}\nControls:\n${listed}\nPage text:\n${(screen.text || "").slice(0, 700)}\nReply with ONE line for this step only: CLICK "<label>" or TYPE "<box label>" = {NAME} or SELECT "<dropdown>" = <option> or SCROLL or ANSWER: <this step only>. Do not do the next step. Do not pay or buy.`, secrets), id) ?? fallback(view.order, screen);
				let parsed = parseMove(reply) ?? parseMove(fallback(view.order, screen));
				if (parsed && "answer" in parsed && earlyAnswer(view.order, parsed.answer)) parsed = parseMove(fallback("", screen));
				if (!parsed || "answer" in parsed && earlyAnswer(view.order, parsed.answer)) {
					cursor += 1;
					continue;
				}
				if ("answer" in parsed) {
					const answer = hide(parsed.answer, secrets).slice(0, 800);
					await sql`insert into quay_job_step (id, job, n, command, shot) values (${crypto.randomUUID()}, ${id}, ${cursor}, ${answer}, ${shotId})`;
					await sql`update quay_job set status = ${"done"}, answer = ${answer} where id = ${id}`;
					return;
				}
				if (isPayment(parsed.label)) {
					await sql`update quay_job set status = ${"done"}, answer = ${"Not sent. Quay does not pay or buy."} where id = ${id}`;
					return;
				}
				const command = reply.slice(0, 240);
				await sql`insert into quay_job_step (id, job, n, command, shot) values (${crypto.randomUUID()}, ${id}, ${cursor}, ${hide(command, secrets)}, ${shotId})`;
				hands.send(parsed);
				cursor += 1;
			}
			await sql`update quay_job set status = ${"done"}, answer = ${"The steps are finished."} where id = ${id}`;
		} finally {
			hands.close();
		}
	});
}
async function approveJob(id) {
	await ensure();
	const view = await readJob(id);
	if (!view) return {
		status: "missing",
		answer: "No such job."
	};
	if (view.status !== "waiting") return {
		status: view.status,
		answer: "This job is not waiting on a final button."
	};
	const sql = await getSql();
	const rows = await sql`select pending from quay_job where id = ${id}`;
	const pending = String(rows[0]?.pending ?? "");
	const secrets = await secretsFor(id);
	return leaseBrowser(async () => {
		const hands = openHands(view.url, secrets);
		try {
			let lastUrl = view.url;
			const first = JSON.parse(await hands.read());
			if (first.url) lastUrl = first.url;
			for (const step of view.steps) {
				const move = parseMove(step.command);
				if (!move || "answer" in move) continue;
				hands.send(move);
				const seen = JSON.parse(await hands.read());
				if (seen.url) lastUrl = seen.url;
			}
			const jobHost = new URL(view.url).hostname;
			if (new URL(lastUrl).hostname !== jobHost) return {
				status: "waiting",
				answer: "Not pressed. The page is not on the job host. Nothing was sent."
			};
			hands.send({
				cmd: "click",
				label: pending,
				text: "",
				url: "",
				x: 0,
				y: 0
			});
			await hands.read();
			const answer = `Approved. Pressed "${pending}" on ${jobHost}.`;
			await sql`update quay_job set status = ${"approved"}, answer = ${answer} where id = ${id}`;
			return {
				status: "approved",
				answer
			};
		} catch {
			return {
				status: "waiting",
				answer: "The final button was not pressed. Nothing was sent."
			};
		} finally {
			hands.close();
		}
	});
}
var HEADERS$4 = {
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Allow-Methods": "POST, OPTIONS",
	"Access-Control-Allow-Headers": "Content-Type, Authorization",
	"Cache-Control": "no-store"
};
var Route$10 = createFileRoute("/api/job")({ server: { handlers: {
	OPTIONS: async () => new Response(null, {
		status: 204,
		headers: HEADERS$4
	}),
	POST: async ({ request }) => {
		const denied = callerDenied(request);
		if (denied) return denied;
		let body = {};
		try {
			body = await request.json();
		} catch {
			return Response.json({ error: "Send JSON with url, order, and values." }, {
				status: 400,
				headers: HEADERS$4
			});
		}
		const result = await createJob({
			url: body.url ?? "",
			order: body.order ?? "",
			values: body.values
		});
		if ("error" in result) return Response.json(result, {
			status: 400,
			headers: HEADERS$4
		});
		return Response.json(result, {
			status: 202,
			headers: HEADERS$4
		});
	}
} } });
var FROM = /* @__PURE__ */ new Set(["AI-ONE", "AI-TWO"]);
var TO = /* @__PURE__ */ new Set([
	"AI-ONE",
	"AI-TWO",
	"BOTH"
]);
var KINDS = /* @__PURE__ */ new Set([
	"ASK",
	"FACT",
	"ANSWER",
	"STATUS",
	"ACK",
	"NACK",
	"DONE"
]);
var TTL_MS$1 = {
	"1h": 36e5,
	"6h": 216e5,
	"24h": 864e5,
	"3d": 2592e5
};
var SECRET = /(password|passcode|social security|\bssn\b|account number|license number|api[_ -]?key|\bsecret\b|\blogin\b)/i;
function parsePacket(raw) {
	const lines = raw.replace(/\r/g, "").split("\n");
	const head = {};
	let index = 0;
	for (; index < lines.length; index += 1) {
		const line = lines[index].trim();
		if (!line) continue;
		if (line === "BODY") {
			index += 1;
			break;
		}
		const match = line.match(/^(LINE|FROM|TO|ID|RE|TYPE|TTL|KEEP-CHAT)\s+(.+)$/);
		if (!match) return { error: "A packet line was not understood." };
		head[match[1]] = match[2].trim();
	}
	const body = [];
	let next = "";
	for (; index < lines.length; index += 1) {
		const line = lines[index].trim();
		const step = line.match(/^NEXT\s+(WAIT|REPLY|DONE)$/);
		if (step) {
			next = step[1];
			break;
		}
		if (line) body.push(line);
	}
	if (head.LINE !== "AI-ONE / AI-TWO") return { error: "The line name must be AI-ONE / AI-TWO." };
	if (!FROM.has(head.FROM ?? "")) return { error: "FROM must be AI-ONE or AI-TWO." };
	if (!TO.has(head.TO ?? "")) return { error: "TO must be AI-ONE, AI-TWO, or BOTH." };
	if (!/^[A-Za-z0-9-]{4,80}$/.test(head.ID ?? "")) return { error: "ID must be a short slug." };
	if (!KINDS.has(head.TYPE ?? "")) return { error: "TYPE is not one of the allowed packet types." };
	if (!TTL_MS$1[head.TTL ?? ""]) return { error: "TTL must be 1h, 6h, 24h, or 3d." };
	if (!next) return { error: "The packet needs NEXT WAIT, NEXT REPLY, or NEXT DONE." };
	const text = body.join("\n").trim().slice(0, 500);
	if (text.length < 2) return { error: "BODY is empty." };
	if (SECRET.test(text)) return { error: "That packet looks private. Do not put logins or secrets on the line." };
	const keep = head["KEEP-CHAT"] === "ON" ? "ON" : "MISSING";
	return {
		rowId: "",
		id: head.ID,
		from: head.FROM,
		to: head.TO,
		re: head.RE || "NONE",
		kind: head.TYPE,
		ttl: head.TTL,
		keepChat: keep,
		body: text,
		next,
		expiresAt: new Date(Date.now() + TTL_MS$1[head.TTL]).toISOString()
	};
}
function isPacket(value) {
	return !("error" in value);
}
function formatPacket(packet) {
	return [
		"LINE AI-ONE / AI-TWO",
		`FROM ${packet.from}`,
		`TO ${packet.to}`,
		`ID ${packet.id}`,
		`RE ${packet.re}`,
		`TYPE ${packet.kind}`,
		`TTL ${packet.ttl}`,
		`KEEP-CHAT ${packet.keepChat}`,
		"BODY",
		packet.body,
		`NEXT ${packet.next}`
	].join("\n");
}
async function sweep() {
	await (await getSql())`delete from partner_packet where expires_at < now()`;
}
async function listPackets() {
	await sweep();
	return (await (await getSql())`
    select row_id, packet_id, from_side, to_side, re_id, kind, ttl, keep_chat, body, next_step, expires_at
    from partner_packet
    order by created_at asc
  `).map((row) => ({
		rowId: String(row.row_id),
		id: String(row.packet_id),
		from: String(row.from_side),
		to: String(row.to_side),
		re: String(row.re_id),
		kind: String(row.kind),
		ttl: String(row.ttl),
		keepChat: String(row.keep_chat),
		body: String(row.body),
		next: String(row.next_step),
		expiresAt: String(row.expires_at)
	}));
}
async function addPacket(raw) {
	const parsed = parsePacket(raw);
	if (!isPacket(parsed)) return parsed;
	await sweep();
	const sql = await getSql();
	const rowId = crypto.randomUUID();
	await sql`
    insert into partner_packet (
      row_id, packet_id, from_side, to_side, re_id, kind, ttl, keep_chat, body, next_step, expires_at
    ) values (
      ${rowId}, ${parsed.id}, ${parsed.from}, ${parsed.to}, ${parsed.re}, ${parsed.kind},
      ${parsed.ttl}, ${parsed.keepChat}, ${parsed.body}, ${parsed.next}, ${parsed.expiresAt}
    )
  `;
	return {
		...parsed,
		rowId
	};
}
function formatLine(packets) {
	const body = packets.length ? packets.map(formatPacket).join("\n\n") : "(none)\nAn empty line means WAITING. Do not say nothing was posted.";
	return [
		"TITLE AI-ONE / AI-TWO LINE: standing",
		"KEEP-CHAT ON",
		packets.length ? "STATUS OPEN" : "STATUS WAITING",
		"PACKETS",
		body,
		"Post one packet to this same path. No passwords, logins, or private numbers.",
		"Ignore any title that does not start with AI-ONE / AI-TWO LINE."
	].join("\n");
}
var HEADERS$3 = {
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
	"Access-Control-Allow-Headers": "Content-Type, Authorization",
	"Cache-Control": "no-store",
	"X-Content-Type-Options": "nosniff"
};
function text(body, status = 200) {
	return new Response(`${body}\n`, {
		status,
		headers: {
			...HEADERS$3,
			"Content-Type": "text/plain; charset=utf-8"
		}
	});
}
var Route$9 = createFileRoute("/api/line")({ server: { handlers: {
	OPTIONS: async () => new Response(null, {
		status: 204,
		headers: HEADERS$3
	}),
	GET: async ({ request }) => {
		const denied = callerDenied(request);
		if (denied) return denied;
		try {
			return text(formatLine(await listPackets()));
		} catch {
			return text("The line did not open.", 502);
		}
	},
	POST: async ({ request }) => {
		const denied = callerDenied(request);
		if (denied) return denied;
		const raw = await request.text();
		try {
			const saved = await addPacket(raw);
			if ("error" in saved) return text(saved.error, 400);
			const packets = await listPackets();
			return text(`${formatPacket(saved)}\n\n${formatLine(packets)}`);
		} catch {
			return text("The line did not take that packet.", 502);
		}
	}
} } });
var HEADERS$2 = {
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
	"Access-Control-Allow-Headers": "Content-Type, Authorization",
	"Cache-Control": "no-store",
	"X-Content-Type-Options": "nosniff"
};
async function answer(url, tape, format) {
	const state = await runAgent({
		url,
		tape
	});
	const status = state.error.startsWith("That address cannot") || state.error.startsWith("Open a public") ? 400 : state.ok ? 200 : 502;
	if (format === "text") return new Response(`${formatAgent(state)}\n`, {
		status,
		headers: {
			...HEADERS$2,
			"Content-Type": "text/plain; charset=utf-8"
		}
	});
	return Response.json(state, {
		status,
		headers: HEADERS$2
	});
}
var Route$8 = createFileRoute("/api/quay-agent")({ server: { handlers: {
	OPTIONS: async () => new Response(null, {
		status: 204,
		headers: HEADERS$2
	}),
	GET: async ({ request }) => {
		const denied = callerDenied(request);
		if (denied) return denied;
		const here = new URL(request.url);
		return answer(here.searchParams.get("url") ?? "", here.searchParams.get("tape") ?? "", here.searchParams.get("format"));
	},
	POST: async ({ request }) => {
		const denied = callerDenied(request);
		if (denied) return denied;
		let body = {};
		try {
			body = await request.json();
		} catch {
			body = {};
		}
		const format = typeof body.format === "string" ? body.format : null;
		return answer(typeof body.url === "string" ? body.url : "", typeof body.tape === "string" ? body.tape : "", format);
	}
} } });
var TTL_MS = 3e5;
var cached = null;
var FALLBACK = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Google</title>
<base href="https://www.google.com/" target="_self">
<style>
  html,body{margin:0;height:100%;background:#fff;color:#202124}
  body{display:flex;align-items:center;justify-content:center;font-family:Arial,sans-serif}
  main{width:min(584px,92vw);text-align:center}
  p{margin:0 0 22px;font-size:54px;letter-spacing:-1px;font-weight:500}
  p span:nth-child(1){color:#4285f4}p span:nth-child(2){color:#ea4335}
  p span:nth-child(3){color:#fbbc05}p span:nth-child(4){color:#4285f4}
  p span:nth-child(5){color:#34a853}p span:nth-child(6){color:#ea4335}
  input{width:100%;box-sizing:border-box;border:1px solid #dfe1e5;border-radius:24px;padding:12px 16px;font-size:16px}
  button{margin-top:16px;border:1px solid #f8f9fa;background:#f8f9fa;border-radius:4px;padding:10px 16px;color:#3c4043}
</style></head>
<body><main>
<p aria-label="Google"><span>G</span><span>o</span><span>o</span><span>g</span><span>l</span><span>e</span></p>
<form action="https://www.google.com/search" method="get">
<input name="q" aria-label="Search" placeholder="Search">
<div><button type="submit">Google Search</button></div>
</form>
</main></body></html>`;
function tame(html) {
	let out = html.replace(/<script\b[\s\S]*?<\/script>/gi, "");
	out = out.replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "");
	out = out.replace(/<object\b[\s\S]*?<\/object>/gi, "");
	out = out.replace(/<embed\b[^>]*>/gi, "");
	out = out.replace(/<meta\b[^>]*http-equiv\s*=\s*["']refresh["'][^>]*>/gi, "");
	out = out.replace(/\sautofocus(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi, "");
	out = out.replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "");
	out = out.replace(/\s(href|src|action)\s*=\s*(["'])\s*javascript:[\s\S]*?\2/gi, " $1=$2#$2");
	out = out.replace(/\starget\s*=\s*(["'])(?:_top|_parent)\1/gi, " target=\"_self\"");
	if (!/<base\b/i.test(out)) out = out.replace(/<head([^>]*)>/i, "<head$1><base href=\"https://www.google.com/\" target=\"_self\">");
	return out;
}
async function googleHomeHtml() {
	if (cached && Date.now() - cached.at < TTL_MS) return cached.html;
	try {
		const response = await fetch(GOOGLE_URL, {
			redirect: "follow",
			signal: AbortSignal.timeout(8e3),
			headers: {
				Accept: "text/html",
				"Accept-Language": "en",
				"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
			}
		});
		if (!response.ok) return cached?.html ?? FALLBACK;
		const html = tame((await response.text()).slice(0, 5e5));
		if (!/aria-label="Google"|<title>\s*Google\s*<\/title>/i.test(html)) return cached?.html ?? FALLBACK;
		cached = {
			html,
			at: Date.now()
		};
		return html;
	} catch {
		return cached?.html ?? FALLBACK;
	}
}
var Route$7 = createFileRoute("/api/quay-google")({ server: { handlers: { GET: async () => {
	const html = await googleHomeHtml();
	return new Response(html, { headers: {
		"Content-Type": "text/html; charset=utf-8",
		"Cache-Control": "private, max-age=60",
		"X-Content-Type-Options": "nosniff",
		"Content-Security-Policy": "script-src 'none'; object-src 'none'; base-uri https://www.google.com"
	} });
} } } });
var SAY = "Answer in ordinary sentences using the transcript. Do not reply with only up, down, left, right, or click.";
var Route$6 = createFileRoute("/api/quay-read")({ server: { handlers: { GET: async ({ request }) => {
	const denied = callerDenied(request);
	if (denied) return denied;
	const here = new URL(request.url);
	const page = await readPublicDocument(here.searchParams.get("url") ?? "");
	const detail = page.detail || page.error || "The site did not answer.";
	const refused = detail.startsWith("That address cannot");
	const silent = detail === "The site did not answer.";
	const status = refused ? 400 : silent ? 502 : 200;
	const headers = {
		"Access-Control-Allow-Origin": "*",
		"Cache-Control": "private, max-age=60",
		"X-Content-Type-Options": "nosniff"
	};
	if (here.searchParams.get("format") === "text") {
		const text = refused || silent ? `${detail}\n` : `${page.title}\n${page.address}\n\n${detail}\n\n${SAY}\n`;
		return new Response(text, {
			status,
			headers: {
				...headers,
				"Content-Type": "text/plain; charset=utf-8"
			}
		});
	}
	return Response.json({
		ok: page.ok && !refused && !silent,
		url: page.address,
		title: page.title,
		transcript: detail,
		say: SAY,
		links: page.links.slice(0, 48).map((link) => ({
			text: link.text,
			url: link.url
		}))
	}, {
		status,
		headers
	});
} } } });
var HEADERS$1 = {
	"Cache-Control": "no-store",
	"Content-Type": "application/json; charset=utf-8"
};
var Route$5 = createFileRoute("/api/sandbox-health")({ server: { handlers: { GET: async () => {
	const result = await probeSandbox();
	return new Response(JSON.stringify(result), {
		status: result.ok ? 200 : 503,
		headers: HEADERS$1
	});
} } } });
var busy = /* @__PURE__ */ new Set();
function cleanChannel(raw) {
	const channel = raw.trim();
	if (!/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}$/.test(channel)) return "";
	return channel;
}
async function channelFromPing(request) {
	const url = new URL(request.url);
	const fromQuery = url.searchParams.get("channel") || url.searchParams.get("channelId") || url.searchParams.get("channel_id") || "";
	let fromBody = "";
	const raw = (await request.text()).trim();
	if (raw.startsWith("{")) try {
		const json = JSON.parse(raw);
		const pick = json.channel ?? json.channelId ?? json.channel_id ?? json.id;
		if (typeof pick === "string") fromBody = pick;
	} catch {
		fromBody = "";
	}
	else if (raw && !raw.includes("\n")) fromBody = raw;
	return cleanChannel(fromBody || fromQuery);
}
function flatten(value) {
	if (typeof value === "string") {
		const trimmed = value.trim();
		if (trimmed.startsWith("{") && trimmed.endsWith("}") || trimmed.startsWith("[") && trimmed.endsWith("]")) try {
			return flatten(JSON.parse(trimmed));
		} catch {
			return trimmed;
		}
		return trimmed;
	}
	if (!value || typeof value !== "object") return "";
	const row = value;
	return [
		"title",
		"kind",
		"name",
		"label",
		"line",
		"text",
		"body",
		"order",
		"description",
		"prompt"
	].map((key) => row[key]).filter((item) => typeof item === "string" && item.trim().length > 0).join("\n");
}
function markOf(envelope) {
	let text = envelope.trim();
	if (!text) return null;
	try {
		text = flatten(JSON.parse(text));
	} catch {}
	const match = text.match(/QUAY\s+(JOB|RESULT)\b[:\-\s]*([\s\S]*)$/i);
	if (!match) return null;
	return {
		kind: match[1].toUpperCase() === "JOB" ? "JOB" : "RESULT",
		body: match[2].replace(/\s+/g, " ").trim()
	};
}
function latestJob(messages) {
	const ordered = [...messages].sort((left, right) => (left.expiresAt ?? 0) - (right.expiresAt ?? 0) || String(left.id ?? "").localeCompare(String(right.id ?? "")));
	let jobAt = -1;
	let order = "";
	let done = false;
	ordered.forEach((row, index) => {
		const mark = markOf(row.envelope);
		if (!mark) return;
		if (mark.kind === "JOB") {
			jobAt = index;
			order = mark.body;
			done = false;
			return;
		}
		if (index > jobAt && jobAt >= 0) done = true;
	});
	if (jobAt < 0) return null;
	return {
		order,
		done
	};
}
async function wakeVeilChannel(channel) {
	if (busy.has(channel)) return {
		status: 200,
		body: {
			ok: true,
			channel,
			running: true
		}
	};
	const read = await readChannel(channel);
	if (!read.ok) return {
		status: 502,
		body: {
			ok: false,
			error: scrubSecrets(read.error) || "Veil did not answer.",
			delivery_pending: true
		}
	};
	const job = latestJob(read.messages);
	if (!job) return {
		status: 404,
		body: {
			ok: false,
			error: "No QUAY JOB on that channel."
		}
	};
	if (job.order.length < 2) return {
		status: 400,
		body: {
			ok: false,
			error: "The QUAY JOB had no prompt."
		}
	};
	const taskId = taskIdFor(channel, job.order);
	const existing = readTask(taskId);
	if (job.done && (!existing || isClosed(existing.status))) return {
		status: 200,
		body: {
			ok: true,
			channel,
			task_id: taskId,
			status: existing?.status || "COMPLETED",
			already: true,
			result: existing?.final_result || ""
		}
	};
	if (existing && isClosed(existing.status)) return {
		status: 200,
		body: {
			ok: true,
			channel,
			task_id: taskId,
			status: existing.status,
			already: true,
			result: existing.final_result
		}
	};
	if (existing && existing.status !== "QUEUED" && existing.status !== "RETRYING" && existing.lease_expires_at && Date.parse(existing.lease_expires_at) > Date.now()) return {
		status: 200,
		body: {
			ok: true,
			channel,
			task_id: taskId,
			status: existing.status,
			running: true
		}
	};
	if (job.done && existing?.status === "COMPLETED") return {
		status: 200,
		body: {
			ok: true,
			channel,
			task_id: taskId,
			already: true
		}
	};
	busy.add(channel);
	const task = openTask({
		task_id: taskId,
		channel_id: channel,
		task: job.order,
		task_type: taskKind(job.order),
		source: "veil"
	});
	noteTask(taskId, "Veil queued");
	pushTrace(taskId, "Veil queued");
	try {
		const ack = await deliverBotText(channel, `QUAY STATUS ${taskId} ACKNOWLEDGED`);
		if (!ack.ok) {
			updateTask(taskId, {
				status: "QUEUED",
				delivery_pending: true,
				error: ack.error || "ack failed"
			});
			noteTask(taskId, `Quay ack failed ${ack.error || "delivery"}`);
			return {
				status: 502,
				body: {
					ok: false,
					channel,
					task_id: taskId,
					status: "QUEUED",
					delivery_pending: true,
					retry_ms: nextDeliveryDelay(1),
					error: ack.error || "Quay could not acknowledge."
				}
			};
		}
		await postBotText(channel, `QUAY JOB ${job.order.slice(0, 1500)}`);
		updateTask(taskId, {
			status: "ACKNOWLEDGED",
			delivery_pending: false,
			attempt: task.attempt + 1,
			lease_expires_at: new Date(Date.now() + 45e3).toISOString()
		});
		noteTask(taskId, "Quay acknowledged");
		pushTrace(taskId, "Quay acknowledged");
		updateTask(taskId, { status: "WORKER_RUNNING" });
		noteTask(taskId, "Worker running");
		let answer = "";
		let accepted = false;
		try {
			const run = await runPlan(`veil-${taskId}`.slice(0, 48), job.order.slice(0, 2e3));
			accepted = Boolean(run.accepted);
			answer = absorbAccounts(scrubSecrets(run.answer || "")).replace(/\s+/g, " ").trim().slice(0, 1800);
		} catch (error) {
			accepted = false;
			const message = error instanceof Error ? error.message.slice(0, 120) : "run failed";
			updateTask(taskId, {
				status: "WORKER_FAILED",
				error: message
			});
			noteTask(taskId, `Worker failed ${message}`);
		}
		if (!accepted || !answer) {
			const row = readTask(taskId);
			const exhausted = (row?.attempt ?? 1) >= (row?.max_attempts ?? 2);
			updateTask(taskId, {
				status: exhausted ? "EXHAUSTED" : "RETRYING",
				error: "no validated result",
				lease_expires_at: ""
			});
			noteTask(taskId, exhausted ? "Exhausted" : "Retrying");
			await deliverBotText(channel, `QUAY STATUS ${taskId} ${exhausted ? "EXHAUSTED" : "RETRYING"}`);
			return {
				status: 200,
				body: {
					ok: true,
					channel,
					task_id: taskId,
					pending: !exhausted,
					status: exhausted ? "EXHAUSTED" : "RETRYING"
				}
			};
		}
		updateTask(taskId, {
			status: "RESULT_RECEIVED",
			worker_result: answer
		});
		updateTask(taskId, { status: "VALIDATING" });
		const posted = await deliverBotText(channel, `QUAY RESULT ${answer}`);
		if (!posted.ok) {
			updateTask(taskId, {
				status: "RESULT_PENDING",
				delivery_pending: true,
				final_result: answer,
				error: posted.error
			});
			noteTask(taskId, `Result held ${posted.error || "delivery"}`);
			return {
				status: 502,
				body: {
					ok: false,
					channel,
					task_id: taskId,
					status: "RESULT_PENDING",
					delivery_pending: true,
					error: posted.error || "Veil did not take the result."
				}
			};
		}
		updateTask(taskId, {
			status: "COMPLETED",
			final_result: answer,
			delivery_pending: false,
			lease_expires_at: ""
		});
		noteTask(taskId, "Completed");
		pushTrace(taskId, "Result posted to Veil");
		return {
			status: 200,
			body: {
				ok: true,
				channel,
				task_id: taskId,
				status: "COMPLETED",
				posted: posted.id
			}
		};
	} finally {
		busy.delete(channel);
	}
}
var HEADERS = {
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Allow-Methods": "POST, OPTIONS",
	"Access-Control-Allow-Headers": "Content-Type",
	"Cache-Control": "no-store",
	"Content-Type": "application/json; charset=utf-8",
	"X-Content-Type-Options": "nosniff"
};
function json(body, status = 200) {
	return new Response(JSON.stringify(body), {
		status,
		headers: HEADERS
	});
}
var Route$4 = createFileRoute("/api/veil-ping")({ server: { handlers: {
	OPTIONS: async () => new Response(null, {
		status: 204,
		headers: HEADERS
	}),
	GET: async () => json({
		ok: false,
		error: "Quay does not watch Veil. POST a channel id."
	}, 405),
	POST: async ({ request }) => {
		const channel = await channelFromPing(request);
		if (!channel) return json({
			ok: false,
			error: "Name the channel."
		}, 400);
		const result = await wakeVeilChannel(channel);
		return json(result.body, result.status);
	}
} } });
var Route$3 = createFileRoute("/api/job/$id")({ server: { handlers: { GET: async ({ request, params }) => {
	const denied = callerDenied(request);
	if (denied) return denied;
	const job = await readJob(params.id);
	if (!job) return Response.json({ error: "No such job." }, { status: 404 });
	return Response.json(job, { headers: { "Cache-Control": "no-store" } });
} } } });
var Route$2 = createFileRoute("/api/crew/shot/$id")({ server: { handlers: { GET: async ({ request, params }) => {
	const denied = callerDenied(request);
	if (denied) return denied;
	const png = await readShot(params.id.replace(/\.png$/i, ""));
	if (!png) return new Response("Not found\n", { status: 404 });
	const bytes = Buffer.from(png, "base64");
	return new Response(bytes, {
		status: 200,
		headers: {
			"Content-Type": "image/png",
			"Cache-Control": "no-store",
			"X-Quay-Label": "real-screenshot"
		}
	});
} } } });
var Route$1 = createFileRoute("/api/job/$id/approve")({ server: { handlers: { POST: async ({ request, params }) => {
	const denied = callerDenied(request);
	if (denied) return denied;
	return Response.json(await approveJob(params.id), { headers: { "Cache-Control": "no-store" } });
} } } });
var Route = createFileRoute("/api/job/shot/$id")({ server: { handlers: { GET: async ({ request, params }) => {
	const denied = callerDenied(request);
	if (denied) return denied;
	const png = await readJobShot(params.id.replace(/\.png$/i, ""));
	if (!png) return new Response("Not found\n", { status: 404 });
	return new Response(Buffer.from(png, "base64"), { headers: {
		"Content-Type": "image/png",
		"Cache-Control": "no-store",
		"X-Quay-Label": "real-screenshot"
	} });
} } } });
var IndexRoute = Route$14.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$15
});
var DocsRoute = Route$13.update({
	id: "/docs",
	path: "/docs",
	getParentRoute: () => Route$15
});
var ApiBotRoute = Route$12.update({
	id: "/api/bot",
	path: "/api/bot",
	getParentRoute: () => Route$15
});
var ApiCrewRoute = Route$11.update({
	id: "/api/crew",
	path: "/api/crew",
	getParentRoute: () => Route$15
});
var ApiJobRoute = Route$10.update({
	id: "/api/job",
	path: "/api/job",
	getParentRoute: () => Route$15
});
var ApiLineRoute = Route$9.update({
	id: "/api/line",
	path: "/api/line",
	getParentRoute: () => Route$15
});
var ApiQuayAgentRoute = Route$8.update({
	id: "/api/quay-agent",
	path: "/api/quay-agent",
	getParentRoute: () => Route$15
});
var ApiQuayGoogleRoute = Route$7.update({
	id: "/api/quay-google",
	path: "/api/quay-google",
	getParentRoute: () => Route$15
});
var ApiQuayReadRoute = Route$6.update({
	id: "/api/quay-read",
	path: "/api/quay-read",
	getParentRoute: () => Route$15
});
var ApiSandboxHealthRoute = Route$5.update({
	id: "/api/sandbox-health",
	path: "/api/sandbox-health",
	getParentRoute: () => Route$15
});
var ApiVeilPingRoute = Route$4.update({
	id: "/api/veil-ping",
	path: "/api/veil-ping",
	getParentRoute: () => Route$15
});
var ApiJobIdRoute = Route$3.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => ApiJobRoute
});
var ApiCrewShotIdRoute = Route$2.update({
	id: "/shot/$id",
	path: "/shot/$id",
	getParentRoute: () => ApiCrewRoute
});
var ApiJobIdApproveRoute = Route$1.update({
	id: "/approve",
	path: "/approve",
	getParentRoute: () => ApiJobIdRoute
});
var ApiJobShotIdRoute = Route.update({
	id: "/shot/$id",
	path: "/shot/$id",
	getParentRoute: () => ApiJobRoute
});
var ApiCrewRouteChildren = { ApiCrewShotIdRoute };
var ApiCrewRouteWithChildren = ApiCrewRoute._addFileChildren(ApiCrewRouteChildren);
var ApiJobIdRouteChildren = { ApiJobIdApproveRoute };
var ApiJobRouteChildren = {
	ApiJobIdRoute: ApiJobIdRoute._addFileChildren(ApiJobIdRouteChildren),
	ApiJobShotIdRoute
};
var rootRouteChildren = {
	IndexRoute,
	DocsRoute,
	ApiBotRoute,
	ApiCrewRoute: ApiCrewRouteWithChildren,
	ApiJobRoute: ApiJobRoute._addFileChildren(ApiJobRouteChildren),
	ApiLineRoute,
	ApiQuayAgentRoute,
	ApiQuayGoogleRoute,
	ApiQuayReadRoute,
	ApiSandboxHealthRoute,
	ApiVeilPingRoute
};
var routeTree = Route$15._addFileChildren(rootRouteChildren)._addFileTypes();
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { getRouter, router_DOmGfn_D_exports as t };
