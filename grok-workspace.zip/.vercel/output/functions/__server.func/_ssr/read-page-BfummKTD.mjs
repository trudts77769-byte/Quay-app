//#region node_modules/.nitro/vite/services/ssr/assets/read-page-BfummKTD.js
var COLS = 8;
var ROWS = 6;
var READING = "41.2";
var WORDS = {
	up: "up",
	u: "up",
	north: "up",
	n: "up",
	"↑": "up",
	down: "down",
	d: "down",
	south: "down",
	s: "down",
	"↓": "down",
	left: "left",
	l: "left",
	west: "left",
	w: "left",
	"←": "left",
	right: "right",
	r: "right",
	east: "right",
	e: "right",
	"→": "right",
	click: "click",
	tap: "click",
	press: "click",
	c: "click"
};
var POINTER = [
	"You are the hand on the Quay pointer. The person already asked you to drive it.",
	"Reply with commands only. No sentences, no labels, no markdown, no code fences.",
	"Allowed words and nothing else: up down left right click.",
	"A star repeats one word: right*3 means right, right, right. One star cannot exceed 16.",
	"up moves one cell toward row 0. down moves one cell toward higher row numbers. left decreases the column. right increases the column. click presses whatever is under the pointer.",
	"The floor is 8 columns by 6 rows. Column 0, row 0 is the top-left corner. The pointer cannot leave the floor.",
	"Send at most 16 commands, then stop. Do the next unfinished step only.",
	"Web machine, used to open a public site:",
	"Row 0 keys, columns 0 to 7: a b c d e f g h",
	"Row 1 keys, columns 0 to 7: i j k l m n o p",
	"Row 2 keys, columns 0 to 7: q r s t u v w x",
	"Row 3 keys, columns 0 to 7: y z 0 1 2 3 4 5",
	"Row 4 keys, columns 0 to 7: 6 7 8 9 . - / :",
	"Row 5: column 0 is Google, column 2 is Del, column 4 is .com, column 6 is Go. Every other cell on row 5 is empty.",
	"The web pointer starts at column 1, row 5. Walk to each character, click it, then walk to Go and click. Del deletes one typed character. .com adds .com. Google opens Google again.",
	"On Survey Bay, Breaker Row, and Pier Desk, press only stations listed under CLICKABLE. Each line includes a Reach tape from the pointer's current cell. Prefer that tape.",
	"Read MACHINE, GOAL, STATE, UNDER POINTER, TRANSCRIPT, and HOW TO MOVE before you answer.",
	"A correct reply looks like this: right*2 click"
].join("\n");
var PROTOCOL = [
	"You can send requests. You are the bot. This site is your sandbox. The person gives you one task. You finish it. Do not ask for the next command.",
	"Call GET /api/quay-agent?url=SITE&tape=TAPE&format=text on this same host. Start with an empty tape.",
	"Read TRANSCRIPT and CELLS. If the task is not finished, add the next commands and call again with the whole tape. The tape replays from the start. At most 24 commands.",
	"Commands are up, down, left, right, and click. A star repeats, like right*3. Column 0, row 0 is the top-left. On row 0, up scrolls up. On row 5, down scrolls down. click opens the link in that cell.",
	"To fill a field, move onto it and add type \"the words\". A choice lists its options, such as Practice Area: Civil Rights | Constitutional | Civil Trial. Type one option, like type \"Civil Rights\". Click submit only if the task says to send the form.",
	"Close only popups that are not needed for the task. Private network addresses stay closed.",
	"When the person gives you a new task, open a new crew. POST NAME your-short-name, TASK a-new-slug, KIND open. You are the chief of that task only.",
	"Do not hand the whole task to one follower. Split it into steps. Each step is one function, and each step gets its own follower.",
	"A different task from the person is a different TASK and a different chief. Do not reuse a task slug. Do not read another task's followers.",
	"To fill a form, post KIND secrets with placeholders such as FIRST_NAME= on their own lines. Those values stay private. Then post KIND form with the public https address. Helpers see the screen, not the real values. Quay stops before the final submit until you post KIND approve.",
	"If a result is partial, vague, or off-target, the chief decides the next pathway from the research. A workaround is any way for that follower to achieve the task. If none is possible, that follower is fired and a new follower is hired. If no follower can do it, the chief looks for a way around that task, not another way to complete it. The person is told it failed only after every pathway is exhausted.",
	"Only the chief of that task returns its final output to the person.",
	"When TRANSCRIPT has the answer, stop. Tell the person in ordinary sentences. Quote the useful line."
].join("\n");
function pushLog(log, line) {
	return [...log, line].slice(-8);
}
var GOOGLE_URL = "https://www.google.com/webhp?igu=1";
var GOOGLE_READING = [
	"Google is on the glass.",
	"Center: a search box. Under it, the buttons Google Search and I'm Feeling Lucky.",
	"Top corner: Sign in.",
	"No address is typed yet. Type a public site in Open and press it. The floor keyboard is optional."
].join(" ");
function readerPath(target) {
	return `/api/quay-read?${new URLSearchParams({
		url: target,
		format: "text"
	}).toString()}`;
}
function isGoogleHome(raw) {
	try {
		const url = new URL(raw);
		const host = url.hostname.toLowerCase().replace(/\.+$/, "");
		if (host !== "google.com" && host !== "www.google.com") return false;
		const path = url.pathname.replace(/\/+$/, "") || "/";
		return path === "/" || path === "/webhp";
	} catch {
		return false;
	}
}
function webReading(web) {
	if (isGoogleHome(web.url)) return {
		title: "Google",
		transcript: GOOGLE_READING
	};
	const transcript = web.transcript?.trim() ?? "";
	return {
		title: web.title?.trim() || "Page",
		transcript: transcript || "The page is opening. Read TRANSCRIPT again in a moment."
	};
}
var KEY_ROWS = [
	"abcdefgh",
	"ijklmnop",
	"qrstuvwx",
	"yz012345",
	"6789.-/:"
];
function toUrl(raw) {
	let value = raw.trim();
	if (!value) return null;
	if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
	let url;
	try {
		url = new URL(value);
	} catch {
		return null;
	}
	if (url.username || url.password) return null;
	if (url.protocol !== "https:" && url.protocol !== "http:") return null;
	const host = url.hostname.toLowerCase().replace(/\.+$/, "");
	if (!host || host === "localhost" || host.endsWith(".local") || host.endsWith(".localhost")) return null;
	if (host.includes(":")) return null;
	const ip = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
	if (ip) {
		const parts = ip.slice(1).map(Number);
		if (parts.some((part) => part > 255)) return null;
		const [a, b] = parts;
		if (a === 0 || a === 10 || a === 127 || a === 192 && b === 168 || a === 172 && b >= 16 && b <= 31 || a === 169 && b === 254) return null;
	}
	return url.toString();
}
function base(partial) {
	return {
		...partial,
		cols: COLS,
		rows: ROWS,
		cursor: {
			c: 0,
			r: 5
		},
		solved: false,
		attached: false,
		survey: null,
		breakers: null,
		desk: null,
		web: null
	};
}
function createMachine(kind, attached = false) {
	if (kind === "survey") return {
		...base({
			id: "survey",
			kind,
			name: "Survey Bay",
			blurb: "Lamp, probe, ledger, hatch",
			goal: "Light the beacon, run the probe, file the reading, then open the hatch.",
			rehearsal: "up*5 click right*2 click down*2 click up*2 right*2 click down*2 click up*2 right*2 click",
			log: ["The bay is dark. The pointer is on the lower walkway."]
		}),
		attached,
		survey: {
			beacon: false,
			terminal: false,
			ledger: false,
			probe: null,
			filed: null,
			hatch: false
		}
	};
	if (kind === "breakers") return {
		...base({
			id: "breakers",
			kind,
			name: "Breaker Row",
			blurb: "Match the pattern, then check",
			goal: "Set the eight breakers to the pattern, then press Check.",
			rehearsal: "up*3 click right*2 click right click right*2 click down*2 left*2 click",
			log: ["All breakers are off. The pattern is shown above the floor."]
		}),
		attached,
		breakers: {
			on: [
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			],
			target: [
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false
			]
		}
	};
	if (kind === "web") return {
		...base({
			id: "web",
			kind,
			name: "Web",
			blurb: "Read the public web",
			goal: "Open a public page. The floor is that page, 8 by 6. Move the pointer and click.",
			rehearsal: "",
			log: ["No page yet. Type a site and press Open."]
		}),
		cursor: {
			c: 0,
			r: 0
		},
		attached,
		web: {
			address: "",
			url: "",
			title: "",
			transcript: ""
		}
	};
	return {
		...base({
			id: "desk",
			kind,
			name: "Pier Desk",
			blurb: "Open, reply, send",
			goal: "Open the inbox, click Reply, then Send.",
			rehearsal: "up*4 right click down*2 click right*4 click",
			log: ["A letter is waiting. Trash is a decoy."]
		}),
		attached,
		desk: {
			letter: false,
			draft: false,
			sent: false
		}
	};
}
function createRack() {
	return [
		createMachine("web"),
		createMachine("survey"),
		createMachine("breakers"),
		createMachine("desk")
	];
}
function patternWord(flags) {
	return flags.map((on) => on ? "ON" : "OFF").join(" ");
}
function hotspots(machine) {
	if (machine.kind === "survey" && machine.survey) {
		const s = machine.survey;
		const list = [
			{
				id: "beacon",
				col: 0,
				row: 0,
				label: "Beacon",
				detail: s.beacon ? "Lit. The probe will run." : "Dark. Click to light it. The probe refuses to run until it is lit.",
				glyph: "beacon",
				tone: s.beacon ? "live" : "idle"
			},
			{
				id: "terminal",
				col: 2,
				row: 0,
				label: "Terminal",
				detail: s.terminal ? "Open. Probe and Status are on the floor beneath it." : "Closed. Click to open the probe controls.",
				glyph: "terminal",
				tone: s.terminal ? "live" : "idle"
			},
			{
				id: "ledger",
				col: 4,
				row: 0,
				label: "Ledger",
				detail: s.ledger ? "Open. File sits beneath it." : "Closed. Click to open, then file the probe reading.",
				glyph: "ledger",
				tone: s.filed ? "done" : s.ledger ? "live" : "idle"
			},
			{
				id: "hatch",
				col: 6,
				row: 0,
				label: "Hatch",
				detail: s.hatch ? "Open. The bay is clear." : "Shut. It opens only after the beacon is lit and a reading is filed.",
				glyph: "hatch",
				tone: s.hatch ? "done" : "locked"
			}
		];
		if (s.terminal) list.push({
			id: "probe",
			col: 2,
			row: 2,
			label: "Probe",
			detail: s.probe ? `Reading ${s.probe} is on the glass.` : s.beacon ? "Ready. Click to take the reading." : "Dark. Light the beacon before clicking.",
			glyph: "probe",
			tone: s.probe ? "done" : s.beacon ? "live" : "locked"
		}, {
			id: "status",
			col: 2,
			row: 3,
			label: "Status",
			detail: "Click to write the bay's flags into the notes.",
			glyph: "status",
			tone: "idle"
		});
		if (s.ledger) list.push({
			id: "file",
			col: 4,
			row: 2,
			label: "File",
			detail: s.filed ? `Filed ${s.filed}.` : s.probe ? `Click to file reading ${s.probe}.` : "Nothing to file yet. Run the probe first.",
			glyph: "file",
			tone: s.filed ? "done" : s.probe ? "live" : "locked"
		});
		return list;
	}
	if (machine.kind === "breakers" && machine.breakers) {
		const { on, target } = machine.breakers;
		const list = on.map((flag, index) => ({
			id: `br-${index}`,
			col: index,
			row: 2,
			label: `Breaker ${index + 1}`,
			detail: `${flag ? "ON" : "OFF"}. The pattern wants ${target[index] ? "ON" : "OFF"}. Click to flip.`,
			glyph: "breaker",
			tone: flag === target[index] ? flag ? "live" : "done" : "idle"
		}));
		const matched = on.every((flag, index) => flag === target[index]);
		list.push({
			id: "check",
			col: 3,
			row: 4,
			label: "Check",
			detail: matched ? "The row matches. Click to clear the machine." : "Click once the row matches the pattern.",
			glyph: "check",
			tone: matched ? "live" : "locked"
		});
		return list;
	}
	if (machine.kind === "desk" && machine.desk) {
		const d = machine.desk;
		const list = [{
			id: "inbox",
			col: 1,
			row: 1,
			label: "Inbox",
			detail: d.letter ? "Open. The note asks for a reply." : "A sealed letter. Click to open it.",
			glyph: "inbox",
			tone: d.letter ? "live" : "idle"
		}, {
			id: "trash",
			col: 6,
			row: 1,
			label: "Trash",
			detail: "A decoy. Clicking it does not finish the desk.",
			glyph: "trash",
			tone: "locked"
		}];
		if (d.letter && !d.sent) list.push({
			id: "reply",
			col: 1,
			row: 3,
			label: "Reply",
			detail: d.draft ? "Draft is ready. Send is to the right." : "Click to draft the reply.",
			glyph: "reply",
			tone: d.draft ? "done" : "live"
		});
		if (d.draft && !d.sent) list.push({
			id: "send",
			col: 5,
			row: 3,
			label: "Send",
			detail: "Click to send the reply and clear the desk.",
			glyph: "send",
			tone: "live"
		});
		return list;
	}
	if (machine.kind === "web" && machine.web) {
		const web = machine.web;
		const onGoogle = web.url.includes("google.com");
		const list = KEY_ROWS.flatMap((row, rowIndex) => row.split("").map((char, col) => ({
			id: `k:${char}`,
			col,
			row: rowIndex,
			label: char,
			detail: `Type ${char}. The address so far is ${web.address || "empty"}.`,
			glyph: "key",
			tone: "idle"
		})));
		list.push({
			id: "google",
			col: 0,
			row: 5,
			label: "Google",
			detail: onGoogle ? "Google is already open." : "Click to return to Google.",
			glyph: "search",
			tone: onGoogle ? "live" : "idle"
		}, {
			id: "back",
			col: 2,
			row: 5,
			label: "Del",
			detail: "Delete the last character.",
			glyph: "del",
			tone: "idle"
		}, {
			id: "com",
			col: 4,
			row: 5,
			label: ".com",
			detail: "Append .com.",
			glyph: "key",
			tone: "idle"
		}, {
			id: "go",
			col: 6,
			row: 5,
			label: "Go",
			detail: web.address ? `Open ${web.address}.` : "Spell an address first, then click Go.",
			glyph: "page",
			tone: web.address ? "live" : "locked"
		});
		return list;
	}
	return [];
}
function hotspotAt(machine, col, row) {
	return hotspots(machine).find((spot) => spot.col === col && spot.row === row) ?? null;
}
function move(machine, command) {
	const [dc, dr] = {
		up: [0, -1],
		down: [0, 1],
		left: [-1, 0],
		right: [1, 0]
	}[command];
	const next = {
		c: Math.min(machine.cols - 1, Math.max(0, machine.cursor.c + dc)),
		r: Math.min(machine.rows - 1, Math.max(0, machine.cursor.r + dr))
	};
	const blocked = next.c === machine.cursor.c && next.r === machine.cursor.r;
	const name = command[0].toUpperCase() + command.slice(1);
	return {
		machine: {
			...machine,
			cursor: next
		},
		note: blocked ? `${name} — edge, pointer stays at ${next.c},${next.r}` : `${name} — pointer ${next.c},${next.r}`,
		tone: "move"
	};
}
function clickSurvey(machine, id) {
	const survey = machine.survey;
	if (!survey) return {
		machine,
		note: "Click — nothing here",
		tone: "warn"
	};
	if (id === "beacon") {
		const beacon = !survey.beacon;
		return {
			machine: {
				...machine,
				survey: {
					...survey,
					beacon
				},
				log: pushLog(machine.log, beacon ? "Beacon lit." : "Beacon darkened.")
			},
			note: beacon ? "Click — beacon lit" : "Click — beacon darkened",
			tone: "click"
		};
	}
	if (id === "terminal") {
		const terminal = !survey.terminal;
		return {
			machine: {
				...machine,
				survey: {
					...survey,
					terminal
				},
				log: pushLog(machine.log, terminal ? "Terminal open." : "Terminal closed.")
			},
			note: terminal ? "Click — terminal open" : "Click — terminal closed",
			tone: "click"
		};
	}
	if (id === "ledger") {
		const ledger = !survey.ledger;
		return {
			machine: {
				...machine,
				survey: {
					...survey,
					ledger
				},
				log: pushLog(machine.log, ledger ? "Ledger open." : "Ledger closed.")
			},
			note: ledger ? "Click — ledger open" : "Click — ledger closed",
			tone: "click"
		};
	}
	if (id === "probe") {
		if (!survey.beacon) {
			const note = "Click — probe stayed dark. Light the beacon first.";
			return {
				machine: {
					...machine,
					log: pushLog(machine.log, note)
				},
				note,
				tone: "warn"
			};
		}
		return {
			machine: {
				...machine,
				survey: {
					...survey,
					probe: READING
				},
				log: pushLog(machine.log, `Probe reading ${READING}.`)
			},
			note: `Click — probe reading ${READING}`,
			tone: "click"
		};
	}
	if (id === "status") {
		const line = `Beacon ${survey.beacon ? "lit" : "dark"}, probe ${survey.probe ?? "empty"}, ledger ${survey.filed ?? "empty"}, hatch ${survey.hatch ? "open" : "shut"}.`;
		return {
			machine: {
				...machine,
				log: pushLog(machine.log, line)
			},
			note: `Click — ${line}`,
			tone: "click"
		};
	}
	if (id === "file") {
		if (!survey.probe) {
			const note = "Click — nothing to file. Run the probe first.";
			return {
				machine: {
					...machine,
					log: pushLog(machine.log, note)
				},
				note,
				tone: "warn"
			};
		}
		return {
			machine: {
				...machine,
				survey: {
					...survey,
					filed: survey.probe
				},
				log: pushLog(machine.log, `Filed ${survey.probe}.`)
			},
			note: `Click — filed ${survey.probe}`,
			tone: "click"
		};
	}
	if (id === "hatch") {
		if (survey.hatch) return {
			machine,
			note: "Click — hatch is already open",
			tone: "click"
		};
		if (!survey.beacon || !survey.filed) {
			const missing = [!survey.beacon ? "the beacon is dark" : "", !survey.filed ? "nothing is filed" : ""].filter(Boolean).join(" and ");
			const note = `Click — hatch stays shut. ${missing[0].toUpperCase()}${missing.slice(1)}.`;
			return {
				machine: {
					...machine,
					log: pushLog(machine.log, note)
				},
				note,
				tone: "warn"
			};
		}
		return {
			machine: {
				...machine,
				solved: true,
				survey: {
					...survey,
					hatch: true
				},
				log: pushLog(machine.log, "Hatch open. Survey bay clear.")
			},
			note: "Click — hatch open. Bay clear.",
			tone: "click"
		};
	}
	return {
		machine,
		note: "Click — empty floor",
		tone: "warn"
	};
}
function clickBreakers(machine, id) {
	const breakers = machine.breakers;
	if (!breakers) return {
		machine,
		note: "Click — nothing here",
		tone: "warn"
	};
	if (id === "check") {
		if (!breakers.on.every((flag, index) => flag === breakers.target[index])) {
			const note = "Click — pattern does not match yet.";
			return {
				machine: {
					...machine,
					log: pushLog(machine.log, note)
				},
				note,
				tone: "warn"
			};
		}
		return {
			machine: {
				...machine,
				solved: true,
				log: pushLog(machine.log, "Pattern matches. Breaker row clear.")
			},
			note: "Click — pattern matches. Row clear.",
			tone: "click"
		};
	}
	const index = Number(id.slice(3));
	if (!Number.isInteger(index) || index < 0 || index >= breakers.on.length) return {
		machine,
		note: "Click — empty floor",
		tone: "warn"
	};
	const on = breakers.on.map((flag, i) => i === index ? !flag : flag);
	const label = on[index] ? "ON" : "OFF";
	return {
		machine: {
			...machine,
			solved: false,
			breakers: {
				...breakers,
				on
			},
			log: pushLog(machine.log, `Breaker ${index + 1} ${label}.`)
		},
		note: `Click — breaker ${index + 1} ${label}`,
		tone: "click"
	};
}
function clickDesk(machine, id) {
	const desk = machine.desk;
	if (!desk) return {
		machine,
		note: "Click — nothing here",
		tone: "warn"
	};
	if (id === "inbox") {
		if (desk.letter) return {
			machine,
			note: "Click — letter already open",
			tone: "click"
		};
		return {
			machine: {
				...machine,
				desk: {
					...desk,
					letter: true
				},
				log: pushLog(machine.log, "Letter open: Pier 4. Please reply and send.")
			},
			note: "Click — letter open",
			tone: "click"
		};
	}
	if (id === "trash") {
		const note = "Click — trash is a decoy. Open the inbox.";
		return {
			machine: {
				...machine,
				log: pushLog(machine.log, note)
			},
			note,
			tone: "warn"
		};
	}
	if (id === "reply") {
		if (desk.draft) return {
			machine,
			note: "Click — reply already drafted",
			tone: "click"
		};
		return {
			machine: {
				...machine,
				desk: {
					...desk,
					draft: true
				},
				log: pushLog(machine.log, "Reply drafted. Send is waiting.")
			},
			note: "Click — reply drafted",
			tone: "click"
		};
	}
	if (id === "send") return {
		machine: {
			...machine,
			solved: true,
			desk: {
				...desk,
				sent: true
			},
			log: pushLog(machine.log, "Reply sent. Pier desk clear.")
		},
		note: "Click — reply sent. Desk clear.",
		tone: "click"
	};
	return {
		machine,
		note: "Click — empty floor",
		tone: "warn"
	};
}
function clickWeb(machine, id) {
	const web = machine.web;
	if (!web) return {
		machine,
		note: "Click — nothing here",
		tone: "warn"
	};
	if (id.startsWith("k:") && id !== "k:") {
		const char = id.slice(2);
		if (web.address.length >= 80) return {
			machine,
			note: "Click — address is full",
			tone: "warn"
		};
		const address = `${web.address}${char}`;
		return {
			machine: {
				...machine,
				web: {
					...web,
					address
				}
			},
			note: `Click — ${address}`,
			tone: "click"
		};
	}
	if (id === "back") {
		const address = web.address.slice(0, -1);
		return {
			machine: {
				...machine,
				web: {
					...web,
					address
				}
			},
			note: address ? `Click — ${address}` : "Click — address cleared",
			tone: "click"
		};
	}
	if (id === "com") {
		if (web.address.endsWith(".com")) return {
			machine,
			note: `Click — ${web.address}`,
			tone: "click"
		};
		const address = `${web.address}.com`.slice(0, 80);
		return {
			machine: {
				...machine,
				web: {
					...web,
					address
				}
			},
			note: `Click — ${address}`,
			tone: "click"
		};
	}
	if (id === "go") {
		const next = toUrl(web.address);
		if (!next) return {
			machine,
			note: web.address ? "Click — that address cannot be opened." : "Click — spell an address, then press Go.",
			tone: "warn"
		};
		return {
			machine: {
				...machine,
				web: {
					...web,
					url: next,
					title: "Opening",
					transcript: ""
				},
				log: pushLog(machine.log, `Opened ${next}`)
			},
			note: `Click — opened ${next}`,
			tone: "click"
		};
	}
	if (id === "google") return {
		machine: {
			...machine,
			web: {
				...web,
				url: GOOGLE_URL,
				title: "Google",
				transcript: ""
			},
			log: pushLog(machine.log, "Returned to Google.")
		},
		note: "Click — Google",
		tone: "click"
	};
	return {
		machine,
		note: "Click — empty floor",
		tone: "warn"
	};
}
function step(machine, command) {
	if (command !== "click") return move(machine, command);
	const spot = hotspotAt(machine, machine.cursor.c, machine.cursor.r);
	if (!spot) return {
		machine,
		note: `Click — empty floor at ${machine.cursor.c},${machine.cursor.r}`,
		tone: "warn"
	};
	if (machine.kind === "survey") return clickSurvey(machine, spot.id);
	if (machine.kind === "breakers") return clickBreakers(machine, spot.id);
	if (machine.kind === "web") return clickWeb(machine, spot.id);
	return clickDesk(machine, spot.id);
}
function parseCommands(raw, limit = 200) {
	const commands = [];
	const skipped = [];
	const parts = raw.replace(/```[a-z]*/gi, " ").replace(/[`"',.:]+/g, " ").trim().split(/\s+/).filter(Boolean);
	for (const part of parts) {
		if (commands.length >= limit) break;
		const match = part.toLowerCase().match(/^([a-z↑↓←→]+)(?:[*x×](\d+))?$/);
		if (!match) {
			skipped.push(part);
			continue;
		}
		const command = WORDS[match[1]];
		if (!command) {
			skipped.push(part);
			continue;
		}
		let count = match[2] ? Number(match[2]) : 1;
		if (!Number.isFinite(count) || count < 1) count = 1;
		count = Math.min(16, count, limit - commands.length);
		for (let i = 0; i < count; i += 1) commands.push(command);
	}
	return {
		commands,
		skipped
	};
}
function reach(from, to) {
	const parts = [];
	const dc = to.c - from.c;
	const dr = to.r - from.r;
	if (dr < 0) parts.push(dr === -1 ? "up" : `up*${-dr}`);
	if (dr > 0) parts.push(dr === 1 ? "down" : `down*${dr}`);
	if (dc < 0) parts.push(dc === -1 ? "left" : `left*${-dc}`);
	if (dc > 0) parts.push(dc === 1 ? "right" : `right*${dc}`);
	parts.push("click");
	return parts.join(" ");
}
function nextHint(machine) {
	if (machine.solved) return "Goal complete. You may stop.";
	if (machine.kind === "survey" && machine.survey) {
		const s = machine.survey;
		if (!s.beacon) return "Next: light the beacon.";
		if (!s.terminal) return "Next: open the terminal.";
		if (!s.probe) return "Next: click Probe.";
		if (!s.ledger) return "Next: open the ledger.";
		if (!s.filed) return "Next: click File.";
		return "Next: open the hatch.";
	}
	if (machine.kind === "breakers" && machine.breakers) {
		const wrong = machine.breakers.on.findIndex((flag, i) => flag !== machine.breakers.target[i]);
		if (wrong === -1) return "Next: press Check.";
		return `Next: breaker ${wrong + 1} should be ${machine.breakers.target[wrong] ? "ON" : "OFF"}.`;
	}
	if (machine.kind === "desk" && machine.desk) {
		if (!machine.desk.letter) return "Next: open the inbox. Ignore trash.";
		if (!machine.desk.draft) return "Next: click Reply.";
		if (!machine.desk.sent) return "Next: click Send.";
	}
	if (machine.kind === "web" && machine.web) {
		if (!machine.web.address) return "Google is open. Type a public site in Open, or spell it and press Go.";
		if (machine.web.url.includes("google.com")) return `Typed ${machine.web.address}. Press Go to open it, or click Google to stay.`;
		return `${machine.web.url} is open. Click Google to go back, or spell another address and press Go.`;
	}
	return "Look at the clickable list.";
}
function describe(machine, transcriptLimit = 900) {
	const under = hotspotAt(machine, machine.cursor.c, machine.cursor.r);
	const lines = [
		`MACHINE ${machine.name}`,
		`GRID ${machine.cols} by ${machine.rows}. Pointer at column ${machine.cursor.c}, row ${machine.cursor.r}.`,
		`GOAL ${machine.goal}`,
		`STATE ${nextHint(machine)}`,
		`SOLVED ${machine.solved ? "yes" : "no"}`,
		`UNDER POINTER ${under ? under.label + " — " + under.detail : "empty floor"}`
	];
	if (machine.kind === "web" && machine.web) {
		const reading = webReading(machine.web);
		lines.push("TRANSCRIPT");
		lines.push("Answer the person from this writing, in ordinary sentences. Do not answer with a command tape.");
		lines.push(`OPEN ${machine.web.url}`);
		lines.push(`TITLE ${reading.title}`);
		lines.push(reading.transcript.slice(0, transcriptLimit));
		lines.push(`READER ${readerPath(machine.web.url)}`);
		lines.push(`TYPED ${machine.web.address || "(empty)"}`);
		lines.push("HOW TO MOVE");
		for (const [label, col, row] of [
			[
				"Google",
				0,
				5
			],
			[
				"Del",
				2,
				5
			],
			[
				".com",
				4,
				5
			],
			[
				"Go",
				6,
				5
			]
		]) lines.push(`- ${label} column ${col} row ${row}. Tape: ${reach(machine.cursor, {
			c: col,
			r: row
		})}`);
		lines.push("Spell any other character from the key map in the manual, then use the Go tape.");
	} else {
		const spots = hotspots(machine);
		lines.push("CLICKABLE");
		for (const spot of spots) lines.push(`- ${spot.label} at column ${spot.col}, row ${spot.row} (${spot.tone}). Reach with: ${reach(machine.cursor, {
			c: spot.col,
			r: spot.row
		})}`);
	}
	if (machine.kind === "survey" && machine.survey) {
		const s = machine.survey;
		lines.push(`FLAGS beacon ${s.beacon ? "lit" : "dark"}; terminal ${s.terminal ? "open" : "closed"}; probe ${s.probe ?? "none"}; filed ${s.filed ?? "none"}; hatch ${s.hatch ? "open" : "shut"}.`);
	}
	if (machine.kind === "breakers" && machine.breakers) {
		lines.push(`PATTERN ${patternWord(machine.breakers.target)}`);
		lines.push(`CURRENT ${patternWord(machine.breakers.on)}`);
	}
	if (machine.kind === "desk" && machine.desk) lines.push(machine.desk.letter ? "LETTER Pier 4. The lamp is out. Please reply and send the note back." : "LETTER sealed.");
	if (machine.log.length) {
		lines.push("NOTES");
		for (const line of machine.log.slice(-4)) lines.push(`- ${line}`);
	}
	return lines.join("\n");
}
function briefFor(machine) {
	return `${POINTER}\n\n${describe(machine, 900)}`;
}
function packetFor(machine) {
	return `${PROTOCOL}\n\n${describe(machine, 4500)}`;
}
function floorCaption(machine) {
	if (machine.kind === "survey" && machine.survey) {
		const s = machine.survey;
		return [
			{
				label: s.beacon ? "Beacon lit" : "Beacon dark",
				live: s.beacon
			},
			{
				label: s.probe ? `Probe ${s.probe}` : "Probe empty",
				live: Boolean(s.probe)
			},
			{
				label: s.filed ? `Filed ${s.filed}` : "Ledger empty",
				live: Boolean(s.filed)
			},
			{
				label: s.hatch ? "Hatch open" : "Hatch shut",
				live: s.hatch
			}
		];
	}
	if (machine.kind === "breakers" && machine.breakers) return machine.breakers.target.map((flag, index) => ({
		label: flag ? "ON" : "OFF",
		live: machine.breakers.on[index] === flag && flag
	}));
	if (machine.kind === "desk" && machine.desk) {
		const d = machine.desk;
		return [
			{
				label: d.letter ? "Letter open" : "Letter sealed",
				live: d.letter
			},
			{
				label: d.draft ? "Reply drafted" : "No reply",
				live: d.draft
			},
			{
				label: d.sent ? "Sent" : "Not sent",
				live: d.sent
			}
		];
	}
	if (machine.kind === "web" && machine.web) {
		const web = machine.web;
		let host = "No page yet";
		if (web.url) try {
			host = new URL(web.url).hostname || host;
		} catch {
			host = "No page yet";
		}
		return [{
			label: host,
			live: Boolean(web.url)
		}, {
			label: web.address ? web.address : "Nothing open",
			live: Boolean(web.address)
		}];
	}
	return [];
}
function decode(value) {
	let current = value;
	for (let pass = 0; pass < 3; pass += 1) {
		const next = current.replace(/\u0026nbsp;/gi, " ").replace(/\u0026quot;/gi, "\"").replace(/&#0*34;/g, "\"").replace(/\u0026apos;/gi, "'").replace(/&#0*39;/g, "'").replace(/\u0026amp;/gi, "&");
		if (next === current) break;
		current = next;
	}
	return current.replace(/\s+/g, " ").trim();
}
function stripped(html) {
	return html.replace(/<script\b[\s\S]*?<\/script>/gi, " ").replace(/<style\b[\s\S]*?<\/style>/gi, " ").replace(/<noscript\b[\s\S]*?<\/noscript>/gi, " ").replace(/<svg\b[\s\S]*?<\/svg>/gi, " ").replace(/<nav\b[\s\S]*?<\/nav>/gi, " ").replace(/<header\b[\s\S]*?<\/header>/gi, " ").replace(/<footer\b[\s\S]*?<\/footer>/gi, " ").replace(/<aside\b[\s\S]*?<\/aside>/gi, " ").replace(/<form\b[\s\S]*?<\/form>/gi, " ").replace(/<[^>]+(?:cookie|consent|banner)[^>]*>[\s\S]*?<\/[a-z0-9]+>/gi, " ");
}
function readableHtml(html) {
	const cleaned = stripped(html);
	return cleaned.match(/<main\b[^>]*>([\s\S]*?)<\/main>/i)?.[1] ?? cleaned.match(/<article\b[^>]*>([\s\S]*?)<\/article>/i)?.[1] ?? cleaned.match(/<body\b[^>]*>([\s\S]*?)<\/body>/i)?.[1] ?? cleaned;
}
function linkText(raw) {
	return decode(raw.replace(/<[^>]+>/g, " ")).slice(0, 80);
}
function collectLinks(html, base) {
	const found = [];
	for (const match of html.matchAll(/<a\b([^>]*?)>([\s\S]*?)<\/a>/gi)) {
		const href = match[1]?.match(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i);
		const raw = (href?.[1] ?? href?.[2] ?? href?.[3] ?? "").trim();
		if (!raw || raw.startsWith("#") || /^javascript:/i.test(raw)) continue;
		let absolute = "";
		try {
			absolute = toUrl(new URL(raw, base).toString()) ?? "";
		} catch {
			absolute = "";
		}
		if (!absolute) continue;
		const text = linkText(match[2] ?? "") || absolute;
		if (found.some((item) => item.url === absolute)) continue;
		found.push({
			text,
			url: absolute
		});
	}
	return found;
}
function linksFromHtml(html, base) {
	const host = (() => {
		try {
			return new URL(base).hostname.replace(/^www\./, "");
		} catch {
			return "";
		}
	})();
	const inArticle = collectLinks(readableHtml(html), base);
	const rest = collectLinks(html, base).filter((link) => !inArticle.some((item) => item.url === link.url));
	const found = [...inArticle, ...rest];
	found.sort((left, right) => {
		const leftHome = left.url.includes(host) ? 0 : 1;
		const rightHome = right.url.includes(host) ? 0 : 1;
		if (leftHome !== rightHome) return leftHome - rightHome;
		return (inArticle.some((item) => item.url === left.url) ? 0 : 1) - (inArticle.some((item) => item.url === right.url) ? 0 : 1);
	});
	return found.slice(0, 40);
}
function textFromHtml(html) {
	return {
		title: decode(html.match(/<title>([^<]+)<\/title>/i)?.[1] ?? "Page"),
		detail: decode(readableHtml(html).replace(/<[^>]+>/g, " ")).slice(0, 15e3)
	};
}
async function readPublic(start) {
	let current = start;
	for (let hop = 0; hop < 3; hop += 1) {
		const response = await fetch(current, {
			redirect: "manual",
			headers: {
				Accept: "text/html,application/xhtml+xml,application/json",
				"Accept-Language": "en",
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
			}
		});
		if (response.status >= 300 && response.status < 400) {
			const location = response.headers.get("location");
			if (!location) return {
				ok: false,
				finalUrl: current,
				html: ""
			};
			const next = toUrl(new URL(location, current).toString());
			if (!next) return {
				ok: false,
				finalUrl: current,
				html: ""
			};
			current = next;
			continue;
		}
		const html = (await response.text()).slice(0, 2e5);
		return {
			ok: response.ok,
			finalUrl: current,
			html
		};
	}
	return {
		ok: false,
		finalUrl: current,
		html: ""
	};
}
async function readPublicDocument(raw) {
	const url = toUrl(raw);
	if (!url) return {
		ok: false,
		address: raw,
		title: "Page",
		detail: "",
		html: "",
		links: [],
		error: "That address cannot be opened. Use a public http or https site."
	};
	try {
		const page = await readPublic(url);
		const text = textFromHtml(page.html);
		return {
			ok: page.ok && Boolean(page.html),
			address: page.finalUrl,
			title: text.title || "Page",
			detail: text.detail || "The page opened, but it had no readable text.",
			html: page.html,
			links: linksFromHtml(page.html, page.finalUrl),
			error: page.ok ? "" : "The site did not answer."
		};
	} catch {
		return {
			ok: false,
			address: url,
			title: "Page",
			detail: "",
			html: "",
			links: [],
			error: "The site did not answer."
		};
	}
}
function documentFromHtml(address, html) {
	const text = textFromHtml(html);
	return {
		ok: Boolean(html),
		address,
		title: text.title || "Page",
		detail: text.detail || "The page opened, but it had no readable text.",
		html,
		links: linksFromHtml(html, address),
		error: html ? "" : "The site did not answer."
	};
}
async function submitPublic(action, method, fields) {
	const url = toUrl(action);
	if (!url) return {
		ok: false,
		address: action,
		title: "Page",
		detail: "",
		html: "",
		links: [],
		error: "That form cannot be sent."
	};
	if (method !== "post") {
		const next = new URL(url);
		for (const [key, value] of Object.entries(fields)) next.searchParams.set(key, value);
		const safe = toUrl(next.toString());
		if (!safe) return {
			ok: false,
			address: url,
			title: "Page",
			detail: "",
			html: "",
			links: [],
			error: "That form cannot be sent."
		};
		return readPublicDocument(safe);
	}
	try {
		let current = url;
		for (let hop = 0; hop < 3; hop += 1) {
			const response = await fetch(current, {
				method: hop === 0 ? "POST" : "GET",
				redirect: "manual",
				headers: {
					Accept: "text/html,application/xhtml+xml,application/json",
					"Accept-Language": "en",
					...hop === 0 ? { "Content-Type": "application/x-www-form-urlencoded" } : {},
					"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
				},
				...hop === 0 ? { body: new URLSearchParams(fields).toString() } : {}
			});
			if (response.status >= 300 && response.status < 400) {
				const location = response.headers.get("location");
				if (!location) break;
				const next = toUrl(new URL(location, current).toString());
				if (!next) break;
				current = next;
				continue;
			}
			const html = (await response.text()).slice(0, 2e5);
			const text = textFromHtml(html);
			return {
				ok: response.ok,
				address: current,
				title: text.title || "Page",
				detail: text.detail || html.slice(0, 2e3),
				html,
				links: linksFromHtml(html, current),
				error: response.ok ? "" : "The form was not accepted."
			};
		}
	} catch {
		return {
			ok: false,
			address: url,
			title: "Page",
			detail: "",
			html: "",
			links: [],
			error: "The form did not go through."
		};
	}
	return {
		ok: false,
		address: url,
		title: "Page",
		detail: "",
		html: "",
		links: [],
		error: "The form did not go through."
	};
}
//#endregion
export { createRack as a, hotspotAt as c, packetFor as d, parseCommands as f, toUrl as g, submitPublic as h, createMachine as i, hotspots as l, step as m, PROTOCOL as n, documentFromHtml as o, readPublicDocument as p, briefFor as r, floorCaption as s, GOOGLE_URL as t, isGoogleHome as u };
