//#region node_modules/.nitro/vite/services/ssr/assets/e2b-key.server-DGZlzSBT.js
var stored = "e2b_34f38e3d9c8513d75146cbd852dd0ac4eae4eb82";
async function resolveE2bKey() {
	const fromEnv = process.env.E2B_API_KEY?.trim() ?? "";
	if (fromEnv) return fromEnv;
	process.env.E2B_API_KEY = stored;
	return stored;
}
//#endregion
export { resolveE2bKey };
