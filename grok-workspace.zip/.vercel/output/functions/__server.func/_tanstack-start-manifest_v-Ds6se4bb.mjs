//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ds6se4bb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/docs",
			"/api/bot",
			"/api/crew",
			"/api/job",
			"/api/line",
			"/api/quay-agent",
			"/api/quay-google",
			"/api/quay-read",
			"/api/sandbox-health",
			"/api/veil-ping"
		],
		preloads: ["/assets/index-CGn6S_Sm.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CGn6S_Sm.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-nz58yIsN.js"]
	},
	"/docs": {
		filePath: "/workspace/src/routes/docs.tsx",
		children: void 0,
		preloads: ["/assets/docs-VRNE2y2p.js"]
	}
} });
//#endregion
export { tsrStartManifest };
