import { i as __require, t as __commonJSMin } from "../_runtime.mjs";
//#region node_modules/dockerfile-ast/lib/argument.js
var require_argument = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Argument = void 0;
	var Argument = class {
		constructor(value, range) {
			this.value = value;
			this.range = range;
		}
		toString() {
			return this.value;
		}
		getRange() {
			return this.range;
		}
		getValue() {
			return this.value;
		}
		isAfter(position) {
			if (this.range.end.line < position.line) return false;
			return this.range.start.line > position.line ? true : this.range.start.character > position.character;
		}
		isBefore(position) {
			if (this.range.start.line < position.line) return true;
			return this.range.end.line > position.line ? false : this.range.end.character < position.character;
		}
	};
	exports.Argument = Argument;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/jsonArgument.js
var require_jsonArgument = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.JSONArgument = void 0;
	var argument_1 = require_argument();
	var JSONArgument = class extends argument_1.Argument {
		constructor(value, range, jsonRange) {
			super(value, range);
			this.jsonRange = jsonRange;
		}
		getJSONRange() {
			return this.jsonRange;
		}
		getJSONValue() {
			let value = super.getValue();
			value = value.substring(1, value.length - 1);
			return value;
		}
	};
	exports.JSONArgument = JSONArgument;
}));
//#endregion
//#region node_modules/vscode-languageserver-types/lib/umd/main.js
var require_main$2 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(factory) {
		if (typeof module === "object" && typeof module.exports === "object") {
			var v = factory(__require, exports);
			if (v !== void 0) module.exports = v;
		} else if (typeof define === "function" && define.amd) define(["require", "exports"], factory);
	})(function(require, exports$2) {
		"use strict";
		Object.defineProperty(exports$2, "__esModule", { value: true });
		exports$2.TextDocument = exports$2.EOL = exports$2.WorkspaceFolder = exports$2.InlineCompletionContext = exports$2.SelectedCompletionInfo = exports$2.InlineCompletionTriggerKind = exports$2.InlineCompletionList = exports$2.InlineCompletionItem = exports$2.StringValue = exports$2.InlayHint = exports$2.InlayHintLabelPart = exports$2.InlayHintKind = exports$2.InlineValueContext = exports$2.InlineValueEvaluatableExpression = exports$2.InlineValueVariableLookup = exports$2.InlineValueText = exports$2.SemanticTokens = exports$2.SemanticTokenModifiers = exports$2.SemanticTokenTypes = exports$2.SelectionRange = exports$2.DocumentLink = exports$2.FormattingOptions = exports$2.CodeLens = exports$2.CodeAction = exports$2.CodeActionTag = exports$2.CodeActionContext = exports$2.CodeActionTriggerKind = exports$2.CodeActionKind = exports$2.DocumentSymbol = exports$2.WorkspaceSymbol = exports$2.SymbolInformation = exports$2.SymbolTag = exports$2.SymbolKind = exports$2.DocumentHighlight = exports$2.DocumentHighlightKind = exports$2.SignatureInformation = exports$2.ParameterInformation = exports$2.Hover = exports$2.MarkedString = exports$2.CompletionList = exports$2.CompletionItem = exports$2.CompletionItemLabelDetails = exports$2.ApplyKind = exports$2.InsertTextMode = exports$2.InsertReplaceEdit = exports$2.CompletionItemTag = exports$2.InsertTextFormat = exports$2.CompletionItemKind = exports$2.MarkupContent = exports$2.MarkupKind = exports$2.TextDocumentItem = exports$2.LanguageKind = exports$2.OptionalVersionedTextDocumentIdentifier = exports$2.VersionedTextDocumentIdentifier = exports$2.TextDocumentIdentifier = exports$2.WorkspaceChange = exports$2.SnippetTextEdit = exports$2.WorkspaceEdit = exports$2.DeleteFile = exports$2.RenameFile = exports$2.CreateFile = exports$2.TextDocumentEdit = exports$2.AnnotatedTextEdit = exports$2.ChangeAnnotationIdentifier = exports$2.ChangeAnnotation = exports$2.TextEdit = exports$2.Command = exports$2.Diagnostic = exports$2.CodeDescription = exports$2.DiagnosticTag = exports$2.DiagnosticSeverity = exports$2.DiagnosticRelatedInformation = exports$2.FoldingRange = exports$2.FoldingRangeKind = exports$2.ColorPresentation = exports$2.ColorInformation = exports$2.Color = exports$2.LocationLink = exports$2.Location = exports$2.Range = exports$2.Position = exports$2.uinteger = exports$2.integer = exports$2.URI = exports$2.DocumentUri = void 0;
		var DocumentUri;
		(function(DocumentUri) {
			function is(value) {
				return typeof value === "string";
			}
			DocumentUri.is = is;
		})(DocumentUri || (exports$2.DocumentUri = DocumentUri = {}));
		var URI;
		(function(URI) {
			function is(value) {
				return typeof value === "string";
			}
			URI.is = is;
		})(URI || (exports$2.URI = URI = {}));
		var integer;
		(function(integer) {
			integer.MIN_VALUE = -2147483648;
			integer.MAX_VALUE = 2147483647;
			function is(value) {
				return typeof value === "number" && integer.MIN_VALUE <= value && value <= integer.MAX_VALUE;
			}
			integer.is = is;
		})(integer || (exports$2.integer = integer = {}));
		var uinteger;
		(function(uinteger) {
			uinteger.MIN_VALUE = 0;
			uinteger.MAX_VALUE = 2147483647;
			function is(value) {
				return typeof value === "number" && uinteger.MIN_VALUE <= value && value <= uinteger.MAX_VALUE;
			}
			uinteger.is = is;
		})(uinteger || (exports$2.uinteger = uinteger = {}));
		/**
		* The Position namespace provides helper functions to work with
		* {@link Position} literals.
		*/
		var Position;
		(function(Position) {
			/**
			* Creates a new Position literal from the given line and character.
			* @param line The position's line.
			* @param character The position's character.
			*/
			function create(line, character) {
				if (line === Number.MAX_VALUE) line = uinteger.MAX_VALUE;
				if (character === Number.MAX_VALUE) character = uinteger.MAX_VALUE;
				return {
					line,
					character
				};
			}
			Position.create = create;
			/**
			* Checks whether the given literal conforms to the {@link Position} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Is.uinteger(candidate.line) && Is.uinteger(candidate.character);
			}
			Position.is = is;
		})(Position || (exports$2.Position = Position = {}));
		/**
		* The Range namespace provides helper functions to work with
		* {@link Range} literals.
		*/
		var Range;
		(function(Range) {
			function create(one, two, three, four) {
				if (Is.uinteger(one) && Is.uinteger(two) && Is.uinteger(three) && Is.uinteger(four)) return {
					start: Position.create(one, two),
					end: Position.create(three, four)
				};
				else if (Position.is(one) && Position.is(two)) return {
					start: one,
					end: two
				};
				else throw new Error("Range#create called with invalid arguments[".concat(one, ", ").concat(two, ", ").concat(three, ", ").concat(four, "]"));
			}
			Range.create = create;
			/**
			* Checks whether the given literal conforms to the {@link Range} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Position.is(candidate.start) && Position.is(candidate.end);
			}
			Range.is = is;
		})(Range || (exports$2.Range = Range = {}));
		/**
		* The Location namespace provides helper functions to work with
		* {@link Location} literals.
		*/
		var Location;
		(function(Location) {
			/**
			* Creates a Location literal.
			* @param uri The location's uri.
			* @param range The location's range.
			*/
			function create(uri, range) {
				return {
					uri,
					range
				};
			}
			Location.create = create;
			/**
			* Checks whether the given literal conforms to the {@link Location} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Range.is(candidate.range) && (Is.string(candidate.uri) || Is.undefined(candidate.uri));
			}
			Location.is = is;
		})(Location || (exports$2.Location = Location = {}));
		/**
		* The LocationLink namespace provides helper functions to work with
		* {@link LocationLink} literals.
		*/
		var LocationLink;
		(function(LocationLink) {
			/**
			* Creates a LocationLink literal.
			* @param targetUri The definition's uri.
			* @param targetRange The full range of the definition.
			* @param targetSelectionRange The span of the symbol definition at the target.
			* @param originSelectionRange The span of the symbol being defined in the originating source file.
			*/
			function create(targetUri, targetRange, targetSelectionRange, originSelectionRange) {
				return {
					targetUri,
					targetRange,
					targetSelectionRange,
					originSelectionRange
				};
			}
			LocationLink.create = create;
			/**
			* Checks whether the given literal conforms to the {@link LocationLink} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Range.is(candidate.targetRange) && Is.string(candidate.targetUri) && Range.is(candidate.targetSelectionRange) && (Range.is(candidate.originSelectionRange) || Is.undefined(candidate.originSelectionRange));
			}
			LocationLink.is = is;
		})(LocationLink || (exports$2.LocationLink = LocationLink = {}));
		/**
		* The Color namespace provides helper functions to work with
		* {@link Color} literals.
		*/
		var Color;
		(function(Color) {
			/**
			* Creates a new Color literal.
			*/
			function create(red, green, blue, alpha) {
				return {
					red,
					green,
					blue,
					alpha
				};
			}
			Color.create = create;
			/**
			* Checks whether the given literal conforms to the {@link Color} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Is.numberRange(candidate.red, 0, 1) && Is.numberRange(candidate.green, 0, 1) && Is.numberRange(candidate.blue, 0, 1) && Is.numberRange(candidate.alpha, 0, 1);
			}
			Color.is = is;
		})(Color || (exports$2.Color = Color = {}));
		/**
		* The ColorInformation namespace provides helper functions to work with
		* {@link ColorInformation} literals.
		*/
		var ColorInformation;
		(function(ColorInformation) {
			/**
			* Creates a new ColorInformation literal.
			*/
			function create(range, color) {
				return {
					range,
					color
				};
			}
			ColorInformation.create = create;
			/**
			* Checks whether the given literal conforms to the {@link ColorInformation} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Range.is(candidate.range) && Color.is(candidate.color);
			}
			ColorInformation.is = is;
		})(ColorInformation || (exports$2.ColorInformation = ColorInformation = {}));
		/**
		* The Color namespace provides helper functions to work with
		* {@link ColorPresentation} literals.
		*/
		var ColorPresentation;
		(function(ColorPresentation) {
			/**
			* Creates a new ColorInformation literal.
			*/
			function create(label, textEdit, additionalTextEdits) {
				return {
					label,
					textEdit,
					additionalTextEdits
				};
			}
			ColorPresentation.create = create;
			/**
			* Checks whether the given literal conforms to the {@link ColorInformation} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Is.string(candidate.label) && (Is.undefined(candidate.textEdit) || TextEdit.is(candidate)) && (Is.undefined(candidate.additionalTextEdits) || Is.typedArray(candidate.additionalTextEdits, TextEdit.is));
			}
			ColorPresentation.is = is;
		})(ColorPresentation || (exports$2.ColorPresentation = ColorPresentation = {}));
		/**
		* A set of predefined range kinds.
		*/
		var FoldingRangeKind;
		(function(FoldingRangeKind) {
			/**
			* Folding range for a comment
			*/
			FoldingRangeKind.Comment = "comment";
			/**
			* Folding range for an import or include
			*/
			FoldingRangeKind.Imports = "imports";
			/**
			* Folding range for a region (e.g. `#region`)
			*/
			FoldingRangeKind.Region = "region";
		})(FoldingRangeKind || (exports$2.FoldingRangeKind = FoldingRangeKind = {}));
		/**
		* The folding range namespace provides helper functions to work with
		* {@link FoldingRange} literals.
		*/
		var FoldingRange;
		(function(FoldingRange) {
			/**
			* Creates a new FoldingRange literal.
			*/
			function create(startLine, endLine, startCharacter, endCharacter, kind, collapsedText) {
				var result = {
					startLine,
					endLine
				};
				if (Is.defined(startCharacter)) result.startCharacter = startCharacter;
				if (Is.defined(endCharacter)) result.endCharacter = endCharacter;
				if (Is.defined(kind)) result.kind = kind;
				if (Is.defined(collapsedText)) result.collapsedText = collapsedText;
				return result;
			}
			FoldingRange.create = create;
			/**
			* Checks whether the given literal conforms to the {@link FoldingRange} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Is.uinteger(candidate.startLine) && Is.uinteger(candidate.startLine) && (Is.undefined(candidate.startCharacter) || Is.uinteger(candidate.startCharacter)) && (Is.undefined(candidate.endCharacter) || Is.uinteger(candidate.endCharacter)) && (Is.undefined(candidate.kind) || Is.string(candidate.kind));
			}
			FoldingRange.is = is;
		})(FoldingRange || (exports$2.FoldingRange = FoldingRange = {}));
		/**
		* The DiagnosticRelatedInformation namespace provides helper functions to work with
		* {@link DiagnosticRelatedInformation} literals.
		*/
		var DiagnosticRelatedInformation;
		(function(DiagnosticRelatedInformation) {
			/**
			* Creates a new DiagnosticRelatedInformation literal.
			*/
			function create(location, message) {
				return {
					location,
					message
				};
			}
			DiagnosticRelatedInformation.create = create;
			/**
			* Checks whether the given literal conforms to the {@link DiagnosticRelatedInformation} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Location.is(candidate.location) && Is.string(candidate.message);
			}
			DiagnosticRelatedInformation.is = is;
		})(DiagnosticRelatedInformation || (exports$2.DiagnosticRelatedInformation = DiagnosticRelatedInformation = {}));
		/**
		* The diagnostic's severity.
		*/
		var DiagnosticSeverity;
		(function(DiagnosticSeverity) {
			/**
			* Reports an error.
			*/
			DiagnosticSeverity.Error = 1;
			/**
			* Reports a warning.
			*/
			DiagnosticSeverity.Warning = 2;
			/**
			* Reports an information.
			*/
			DiagnosticSeverity.Information = 3;
			/**
			* Reports a hint.
			*/
			DiagnosticSeverity.Hint = 4;
		})(DiagnosticSeverity || (exports$2.DiagnosticSeverity = DiagnosticSeverity = {}));
		/**
		* The diagnostic tags.
		*
		* @since 3.15.0
		*/
		var DiagnosticTag;
		(function(DiagnosticTag) {
			/**
			* Unused or unnecessary code.
			*
			* Clients are allowed to render diagnostics with this tag faded out instead of having
			* an error squiggle.
			*/
			DiagnosticTag.Unnecessary = 1;
			/**
			* Deprecated or obsolete code.
			*
			* Clients are allowed to rendered diagnostics with this tag strike through.
			*/
			DiagnosticTag.Deprecated = 2;
		})(DiagnosticTag || (exports$2.DiagnosticTag = DiagnosticTag = {}));
		/**
		* The CodeDescription namespace provides functions to deal with descriptions for diagnostic codes.
		*
		* @since 3.16.0
		*/
		var CodeDescription;
		(function(CodeDescription) {
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Is.string(candidate.href);
			}
			CodeDescription.is = is;
		})(CodeDescription || (exports$2.CodeDescription = CodeDescription = {}));
		/**
		* The Diagnostic namespace provides helper functions to work with
		* {@link Diagnostic} literals.
		*/
		var Diagnostic;
		(function(Diagnostic) {
			/**
			* Creates a new Diagnostic literal.
			*/
			function create(range, message, severity, code, source, relatedInformation) {
				var result = {
					range,
					message
				};
				if (Is.defined(severity)) result.severity = severity;
				if (Is.defined(code)) result.code = code;
				if (Is.defined(source)) result.source = source;
				if (Is.defined(relatedInformation)) result.relatedInformation = relatedInformation;
				return result;
			}
			Diagnostic.create = create;
			/**
			* Checks whether the given literal conforms to the {@link Diagnostic} interface.
			*/
			function is(value) {
				var _a;
				var candidate = value;
				return Is.defined(candidate) && Range.is(candidate.range) && (Is.string(candidate.message) || MarkupContent.is(candidate.message)) && (Is.number(candidate.severity) || Is.undefined(candidate.severity)) && (Is.integer(candidate.code) || Is.string(candidate.code) || Is.undefined(candidate.code)) && (Is.undefined(candidate.codeDescription) || Is.string((_a = candidate.codeDescription) === null || _a === void 0 ? void 0 : _a.href)) && (Is.string(candidate.source) || Is.undefined(candidate.source)) && (Is.undefined(candidate.relatedInformation) || Is.typedArray(candidate.relatedInformation, DiagnosticRelatedInformation.is));
			}
			Diagnostic.is = is;
			/**
			* Checks whether the given diagnostic's message conforms to the 3.17.0
			* version of the protocol where the message is a string.
			*
			* @param value the diagnostic
			* @returns true if the diagnostic's message is a string, false otherwise.
			*/
			function is3_17(value) {
				return Is.string(value.message);
			}
			Diagnostic.is3_17 = is3_17;
			/**
			* Gets the message string of a diagnostic. If the message is already a
			* string, it is returned as is. If the message is a MarkupContent,
			* the value of the MarkupContent is returned. Otherwise an error is thrown.
			*
			* @param diagnostic the diagnostic to get the message string from.
			* @returns the message string of the given diagnostic.
			*/
			function getMessageString(diagnostic) {
				if (Is.string(diagnostic.message)) return diagnostic.message;
				else if (MarkupContent.is(diagnostic.message)) return diagnostic.message.value;
				else throw new Error("Unknown message type ".concat(typeof diagnostic.message));
			}
			Diagnostic.getMessageString = getMessageString;
		})(Diagnostic || (exports$2.Diagnostic = Diagnostic = {}));
		/**
		* The Command namespace provides helper functions to work with
		* {@link Command} literals.
		*/
		var Command;
		(function(Command) {
			/**
			* Creates a new Command literal.
			*/
			function create(title, command) {
				var args = [];
				for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
				var result = {
					title,
					command
				};
				if (Is.defined(args) && args.length > 0) result.arguments = args;
				return result;
			}
			Command.create = create;
			/**
			* Checks whether the given literal conforms to the {@link Command} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Is.string(candidate.title) && (candidate.tooltip === void 0 || Is.string(candidate.tooltip)) && Is.string(candidate.command);
			}
			Command.is = is;
		})(Command || (exports$2.Command = Command = {}));
		/**
		* The TextEdit namespace provides helper function to create replace,
		* insert and delete edits more easily.
		*/
		var TextEdit;
		(function(TextEdit) {
			/**
			* Creates a replace text edit.
			* @param range The range of text to be replaced.
			* @param newText The new text.
			*/
			function replace(range, newText) {
				return {
					range,
					newText
				};
			}
			TextEdit.replace = replace;
			/**
			* Creates an insert text edit.
			* @param position The position to insert the text at.
			* @param newText The text to be inserted.
			*/
			function insert(position, newText) {
				return {
					range: {
						start: position,
						end: position
					},
					newText
				};
			}
			TextEdit.insert = insert;
			/**
			* Creates a delete text edit.
			* @param range The range of text to be deleted.
			*/
			function del(range) {
				return {
					range,
					newText: ""
				};
			}
			TextEdit.del = del;
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Is.string(candidate.newText) && Range.is(candidate.range);
			}
			TextEdit.is = is;
		})(TextEdit || (exports$2.TextEdit = TextEdit = {}));
		var ChangeAnnotation;
		(function(ChangeAnnotation) {
			function create(label, needsConfirmation, description) {
				var result = { label };
				if (needsConfirmation !== void 0) result.needsConfirmation = needsConfirmation;
				if (description !== void 0) result.description = description;
				return result;
			}
			ChangeAnnotation.create = create;
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Is.string(candidate.label) && (Is.boolean(candidate.needsConfirmation) || candidate.needsConfirmation === void 0) && (Is.string(candidate.description) || candidate.description === void 0);
			}
			ChangeAnnotation.is = is;
		})(ChangeAnnotation || (exports$2.ChangeAnnotation = ChangeAnnotation = {}));
		var ChangeAnnotationIdentifier;
		(function(ChangeAnnotationIdentifier) {
			function is(value) {
				var candidate = value;
				return Is.string(candidate);
			}
			ChangeAnnotationIdentifier.is = is;
		})(ChangeAnnotationIdentifier || (exports$2.ChangeAnnotationIdentifier = ChangeAnnotationIdentifier = {}));
		var AnnotatedTextEdit;
		(function(AnnotatedTextEdit) {
			/**
			* Creates an annotated replace text edit.
			*
			* @param range The range of text to be replaced.
			* @param newText The new text.
			* @param annotation The annotation.
			*/
			function replace(range, newText, annotation) {
				return {
					range,
					newText,
					annotationId: annotation
				};
			}
			AnnotatedTextEdit.replace = replace;
			/**
			* Creates an annotated insert text edit.
			*
			* @param position The position to insert the text at.
			* @param newText The text to be inserted.
			* @param annotation The annotation.
			*/
			function insert(position, newText, annotation) {
				return {
					range: {
						start: position,
						end: position
					},
					newText,
					annotationId: annotation
				};
			}
			AnnotatedTextEdit.insert = insert;
			/**
			* Creates an annotated delete text edit.
			*
			* @param range The range of text to be deleted.
			* @param annotation The annotation.
			*/
			function del(range, annotation) {
				return {
					range,
					newText: "",
					annotationId: annotation
				};
			}
			AnnotatedTextEdit.del = del;
			function is(value) {
				var candidate = value;
				return TextEdit.is(candidate) && (ChangeAnnotation.is(candidate.annotationId) || ChangeAnnotationIdentifier.is(candidate.annotationId));
			}
			AnnotatedTextEdit.is = is;
		})(AnnotatedTextEdit || (exports$2.AnnotatedTextEdit = AnnotatedTextEdit = {}));
		/**
		* The TextDocumentEdit namespace provides helper function to create
		* an edit that manipulates a text document.
		*/
		var TextDocumentEdit;
		(function(TextDocumentEdit) {
			/**
			* Creates a new `TextDocumentEdit`
			*/
			function create(textDocument, edits) {
				return {
					textDocument,
					edits
				};
			}
			TextDocumentEdit.create = create;
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && OptionalVersionedTextDocumentIdentifier.is(candidate.textDocument) && Array.isArray(candidate.edits);
			}
			TextDocumentEdit.is = is;
		})(TextDocumentEdit || (exports$2.TextDocumentEdit = TextDocumentEdit = {}));
		var CreateFile;
		(function(CreateFile) {
			function create(uri, options, annotation) {
				var result = {
					kind: "create",
					uri
				};
				if (options !== void 0 && (options.overwrite !== void 0 || options.ignoreIfExists !== void 0)) result.options = options;
				if (annotation !== void 0) result.annotationId = annotation;
				return result;
			}
			CreateFile.create = create;
			function is(value) {
				var candidate = value;
				return candidate && candidate.kind === "create" && Is.string(candidate.uri) && (candidate.options === void 0 || (candidate.options.overwrite === void 0 || Is.boolean(candidate.options.overwrite)) && (candidate.options.ignoreIfExists === void 0 || Is.boolean(candidate.options.ignoreIfExists))) && (candidate.annotationId === void 0 || ChangeAnnotationIdentifier.is(candidate.annotationId));
			}
			CreateFile.is = is;
		})(CreateFile || (exports$2.CreateFile = CreateFile = {}));
		var RenameFile;
		(function(RenameFile) {
			function create(oldUri, newUri, options, annotation) {
				var result = {
					kind: "rename",
					oldUri,
					newUri
				};
				if (options !== void 0 && (options.overwrite !== void 0 || options.ignoreIfExists !== void 0)) result.options = options;
				if (annotation !== void 0) result.annotationId = annotation;
				return result;
			}
			RenameFile.create = create;
			function is(value) {
				var candidate = value;
				return candidate && candidate.kind === "rename" && Is.string(candidate.oldUri) && Is.string(candidate.newUri) && (candidate.options === void 0 || (candidate.options.overwrite === void 0 || Is.boolean(candidate.options.overwrite)) && (candidate.options.ignoreIfExists === void 0 || Is.boolean(candidate.options.ignoreIfExists))) && (candidate.annotationId === void 0 || ChangeAnnotationIdentifier.is(candidate.annotationId));
			}
			RenameFile.is = is;
		})(RenameFile || (exports$2.RenameFile = RenameFile = {}));
		var DeleteFile;
		(function(DeleteFile) {
			function create(uri, options, annotation) {
				var result = {
					kind: "delete",
					uri
				};
				if (options !== void 0 && (options.recursive !== void 0 || options.ignoreIfNotExists !== void 0)) result.options = options;
				if (annotation !== void 0) result.annotationId = annotation;
				return result;
			}
			DeleteFile.create = create;
			function is(value) {
				var candidate = value;
				return candidate && candidate.kind === "delete" && Is.string(candidate.uri) && (candidate.options === void 0 || (candidate.options.recursive === void 0 || Is.boolean(candidate.options.recursive)) && (candidate.options.ignoreIfNotExists === void 0 || Is.boolean(candidate.options.ignoreIfNotExists))) && (candidate.annotationId === void 0 || ChangeAnnotationIdentifier.is(candidate.annotationId));
			}
			DeleteFile.is = is;
		})(DeleteFile || (exports$2.DeleteFile = DeleteFile = {}));
		var WorkspaceEdit;
		(function(WorkspaceEdit) {
			function is(value) {
				var candidate = value;
				return candidate && (candidate.changes !== void 0 || candidate.documentChanges !== void 0) && (candidate.documentChanges === void 0 || candidate.documentChanges.every(function(change) {
					if (Is.string(change.kind)) return CreateFile.is(change) || RenameFile.is(change) || DeleteFile.is(change);
					else return TextDocumentEdit.is(change);
				}));
			}
			WorkspaceEdit.is = is;
		})(WorkspaceEdit || (exports$2.WorkspaceEdit = WorkspaceEdit = {}));
		var TextEditChangeImpl = function() {
			function TextEditChangeImpl(edits, changeAnnotations) {
				this.edits = edits;
				this.changeAnnotations = changeAnnotations;
			}
			TextEditChangeImpl.prototype.insert = function(position, newText, annotation) {
				var edit;
				var id;
				if (annotation === void 0) edit = TextEdit.insert(position, newText);
				else if (ChangeAnnotationIdentifier.is(annotation)) {
					id = annotation;
					edit = AnnotatedTextEdit.insert(position, newText, annotation);
				} else {
					this.assertChangeAnnotations(this.changeAnnotations);
					id = this.changeAnnotations.manage(annotation);
					edit = AnnotatedTextEdit.insert(position, newText, id);
				}
				this.edits.push(edit);
				if (id !== void 0) return id;
			};
			TextEditChangeImpl.prototype.replace = function(range, newText, annotation) {
				var edit;
				var id;
				if (annotation === void 0) edit = TextEdit.replace(range, newText);
				else if (ChangeAnnotationIdentifier.is(annotation)) {
					id = annotation;
					edit = AnnotatedTextEdit.replace(range, newText, annotation);
				} else {
					this.assertChangeAnnotations(this.changeAnnotations);
					id = this.changeAnnotations.manage(annotation);
					edit = AnnotatedTextEdit.replace(range, newText, id);
				}
				this.edits.push(edit);
				if (id !== void 0) return id;
			};
			TextEditChangeImpl.prototype.delete = function(range, annotation) {
				var edit;
				var id;
				if (annotation === void 0) edit = TextEdit.del(range);
				else if (ChangeAnnotationIdentifier.is(annotation)) {
					id = annotation;
					edit = AnnotatedTextEdit.del(range, annotation);
				} else {
					this.assertChangeAnnotations(this.changeAnnotations);
					id = this.changeAnnotations.manage(annotation);
					edit = AnnotatedTextEdit.del(range, id);
				}
				this.edits.push(edit);
				if (id !== void 0) return id;
			};
			TextEditChangeImpl.prototype.add = function(edit) {
				this.edits.push(edit);
			};
			TextEditChangeImpl.prototype.all = function() {
				return this.edits;
			};
			TextEditChangeImpl.prototype.clear = function() {
				this.edits.splice(0, this.edits.length);
			};
			TextEditChangeImpl.prototype.assertChangeAnnotations = function(value) {
				if (value === void 0) throw new Error("Text edit change is not configured to manage change annotations.");
			};
			return TextEditChangeImpl;
		}();
		var SnippetTextEdit;
		(function(SnippetTextEdit) {
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Range.is(candidate.range) && StringValue.isSnippet(candidate.snippet) && (candidate.annotationId === void 0 || ChangeAnnotation.is(candidate.annotationId) || ChangeAnnotationIdentifier.is(candidate.annotationId));
			}
			SnippetTextEdit.is = is;
		})(SnippetTextEdit || (exports$2.SnippetTextEdit = SnippetTextEdit = {}));
		/**
		* A helper class
		*/
		var ChangeAnnotations = function() {
			function ChangeAnnotations(annotations) {
				this._annotations = annotations === void 0 ? Object.create(null) : annotations;
				this._counter = 0;
				this._size = 0;
			}
			ChangeAnnotations.prototype.all = function() {
				return this._annotations;
			};
			Object.defineProperty(ChangeAnnotations.prototype, "size", {
				get: function() {
					return this._size;
				},
				enumerable: false,
				configurable: true
			});
			ChangeAnnotations.prototype.manage = function(idOrAnnotation, annotation) {
				var id;
				if (ChangeAnnotationIdentifier.is(idOrAnnotation)) id = idOrAnnotation;
				else {
					id = this.nextId();
					annotation = idOrAnnotation;
				}
				if (this._annotations[id] !== void 0) throw new Error("Id ".concat(id, " is already in use."));
				if (annotation === void 0) throw new Error("No annotation provided for id ".concat(id));
				this._annotations[id] = annotation;
				this._size++;
				return id;
			};
			ChangeAnnotations.prototype.nextId = function() {
				this._counter++;
				return this._counter.toString();
			};
			return ChangeAnnotations;
		}();
		exports$2.WorkspaceChange = function() {
			function WorkspaceChange(workspaceEdit) {
				var _this = this;
				this._textEditChanges = Object.create(null);
				if (workspaceEdit !== void 0) {
					this._workspaceEdit = workspaceEdit;
					if (workspaceEdit.documentChanges) {
						this._changeAnnotations = new ChangeAnnotations(workspaceEdit.changeAnnotations);
						workspaceEdit.changeAnnotations = this._changeAnnotations.all();
						workspaceEdit.documentChanges.forEach(function(change) {
							if (TextDocumentEdit.is(change)) {
								var textEditChange = new TextEditChangeImpl(change.edits, _this._changeAnnotations);
								_this._textEditChanges[change.textDocument.uri] = textEditChange;
							}
						});
					} else if (workspaceEdit.changes) Object.keys(workspaceEdit.changes).forEach(function(key) {
						var textEditChange = new TextEditChangeImpl(workspaceEdit.changes[key]);
						_this._textEditChanges[key] = textEditChange;
					});
				} else this._workspaceEdit = {};
			}
			Object.defineProperty(WorkspaceChange.prototype, "edit", {
				/**
				* Returns the underlying {@link WorkspaceEdit} literal
				* use to be returned from a workspace edit operation like rename.
				*/
				get: function() {
					this.initDocumentChanges();
					if (this._changeAnnotations !== void 0) {
						if (this._changeAnnotations.size === 0) this._workspaceEdit.changeAnnotations = void 0;
						else this._workspaceEdit.changeAnnotations = this._changeAnnotations.all();
					}
					return this._workspaceEdit;
				},
				enumerable: false,
				configurable: true
			});
			WorkspaceChange.prototype.getTextEditChange = function(key) {
				if (OptionalVersionedTextDocumentIdentifier.is(key)) {
					this.initDocumentChanges();
					if (this._workspaceEdit.documentChanges === void 0) throw new Error("Workspace edit is not configured for document changes.");
					var textDocument = {
						uri: key.uri,
						version: key.version
					};
					var result = this._textEditChanges[textDocument.uri];
					if (!result) {
						var edits = [];
						var textDocumentEdit = {
							textDocument,
							edits
						};
						this._workspaceEdit.documentChanges.push(textDocumentEdit);
						result = new TextEditChangeImpl(edits, this._changeAnnotations);
						this._textEditChanges[textDocument.uri] = result;
					}
					return result;
				} else {
					this.initChanges();
					if (this._workspaceEdit.changes === void 0) throw new Error("Workspace edit is not configured for normal text edit changes.");
					var result = this._textEditChanges[key];
					if (!result) {
						var edits = [];
						this._workspaceEdit.changes[key] = edits;
						result = new TextEditChangeImpl(edits);
						this._textEditChanges[key] = result;
					}
					return result;
				}
			};
			WorkspaceChange.prototype.initDocumentChanges = function() {
				if (this._workspaceEdit.documentChanges === void 0 && this._workspaceEdit.changes === void 0) {
					this._changeAnnotations = new ChangeAnnotations();
					this._workspaceEdit.documentChanges = [];
					this._workspaceEdit.changeAnnotations = this._changeAnnotations.all();
				}
			};
			WorkspaceChange.prototype.initChanges = function() {
				if (this._workspaceEdit.documentChanges === void 0 && this._workspaceEdit.changes === void 0) this._workspaceEdit.changes = Object.create(null);
			};
			WorkspaceChange.prototype.createFile = function(uri, optionsOrAnnotation, options) {
				this.initDocumentChanges();
				if (this._workspaceEdit.documentChanges === void 0) throw new Error("Workspace edit is not configured for document changes.");
				var annotation;
				if (ChangeAnnotation.is(optionsOrAnnotation) || ChangeAnnotationIdentifier.is(optionsOrAnnotation)) annotation = optionsOrAnnotation;
				else options = optionsOrAnnotation;
				var operation;
				var id;
				if (annotation === void 0) operation = CreateFile.create(uri, options);
				else {
					id = ChangeAnnotationIdentifier.is(annotation) ? annotation : this._changeAnnotations.manage(annotation);
					operation = CreateFile.create(uri, options, id);
				}
				this._workspaceEdit.documentChanges.push(operation);
				if (id !== void 0) return id;
			};
			WorkspaceChange.prototype.renameFile = function(oldUri, newUri, optionsOrAnnotation, options) {
				this.initDocumentChanges();
				if (this._workspaceEdit.documentChanges === void 0) throw new Error("Workspace edit is not configured for document changes.");
				var annotation;
				if (ChangeAnnotation.is(optionsOrAnnotation) || ChangeAnnotationIdentifier.is(optionsOrAnnotation)) annotation = optionsOrAnnotation;
				else options = optionsOrAnnotation;
				var operation;
				var id;
				if (annotation === void 0) operation = RenameFile.create(oldUri, newUri, options);
				else {
					id = ChangeAnnotationIdentifier.is(annotation) ? annotation : this._changeAnnotations.manage(annotation);
					operation = RenameFile.create(oldUri, newUri, options, id);
				}
				this._workspaceEdit.documentChanges.push(operation);
				if (id !== void 0) return id;
			};
			WorkspaceChange.prototype.deleteFile = function(uri, optionsOrAnnotation, options) {
				this.initDocumentChanges();
				if (this._workspaceEdit.documentChanges === void 0) throw new Error("Workspace edit is not configured for document changes.");
				var annotation;
				if (ChangeAnnotation.is(optionsOrAnnotation) || ChangeAnnotationIdentifier.is(optionsOrAnnotation)) annotation = optionsOrAnnotation;
				else options = optionsOrAnnotation;
				var operation;
				var id;
				if (annotation === void 0) operation = DeleteFile.create(uri, options);
				else {
					id = ChangeAnnotationIdentifier.is(annotation) ? annotation : this._changeAnnotations.manage(annotation);
					operation = DeleteFile.create(uri, options, id);
				}
				this._workspaceEdit.documentChanges.push(operation);
				if (id !== void 0) return id;
			};
			return WorkspaceChange;
		}();
		/**
		* The TextDocumentIdentifier namespace provides helper functions to work with
		* {@link TextDocumentIdentifier} literals.
		*/
		var TextDocumentIdentifier;
		(function(TextDocumentIdentifier) {
			/**
			* Creates a new TextDocumentIdentifier literal.
			* @param uri The document's uri.
			*/
			function create(uri) {
				return { uri };
			}
			TextDocumentIdentifier.create = create;
			/**
			* Checks whether the given literal conforms to the {@link TextDocumentIdentifier} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Is.string(candidate.uri);
			}
			TextDocumentIdentifier.is = is;
		})(TextDocumentIdentifier || (exports$2.TextDocumentIdentifier = TextDocumentIdentifier = {}));
		/**
		* The VersionedTextDocumentIdentifier namespace provides helper functions to work with
		* {@link VersionedTextDocumentIdentifier} literals.
		*/
		var VersionedTextDocumentIdentifier;
		(function(VersionedTextDocumentIdentifier) {
			/**
			* Creates a new VersionedTextDocumentIdentifier literal.
			* @param uri The document's uri.
			* @param version The document's version.
			*/
			function create(uri, version) {
				return {
					uri,
					version
				};
			}
			VersionedTextDocumentIdentifier.create = create;
			/**
			* Checks whether the given literal conforms to the {@link VersionedTextDocumentIdentifier} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Is.string(candidate.uri) && Is.integer(candidate.version);
			}
			VersionedTextDocumentIdentifier.is = is;
		})(VersionedTextDocumentIdentifier || (exports$2.VersionedTextDocumentIdentifier = VersionedTextDocumentIdentifier = {}));
		/**
		* The OptionalVersionedTextDocumentIdentifier namespace provides helper functions to work with
		* {@link OptionalVersionedTextDocumentIdentifier} literals.
		*/
		var OptionalVersionedTextDocumentIdentifier;
		(function(OptionalVersionedTextDocumentIdentifier) {
			/**
			* Creates a new OptionalVersionedTextDocumentIdentifier literal.
			* @param uri The document's uri.
			* @param version The document's version.
			*/
			function create(uri, version) {
				return {
					uri,
					version
				};
			}
			OptionalVersionedTextDocumentIdentifier.create = create;
			/**
			* Checks whether the given literal conforms to the {@link OptionalVersionedTextDocumentIdentifier} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Is.string(candidate.uri) && (candidate.version === null || Is.integer(candidate.version));
			}
			OptionalVersionedTextDocumentIdentifier.is = is;
		})(OptionalVersionedTextDocumentIdentifier || (exports$2.OptionalVersionedTextDocumentIdentifier = OptionalVersionedTextDocumentIdentifier = {}));
		/**
		* Predefined Language kinds
		* @since 3.18.0
		*/
		var LanguageKind;
		(function(LanguageKind) {
			LanguageKind.ABAP = "abap";
			LanguageKind.WindowsBat = "bat";
			LanguageKind.BibTeX = "bibtex";
			LanguageKind.Clojure = "clojure";
			LanguageKind.Coffeescript = "coffeescript";
			LanguageKind.C = "c";
			LanguageKind.CPP = "cpp";
			LanguageKind.CSharp = "csharp";
			LanguageKind.CSS = "css";
			/**
			* @since 3.18.0
			*/
			LanguageKind.D = "d";
			/**
			* @since 3.18.0
			*/
			LanguageKind.Delphi = "pascal";
			LanguageKind.Diff = "diff";
			LanguageKind.Dart = "dart";
			LanguageKind.Dockerfile = "dockerfile";
			LanguageKind.Elixir = "elixir";
			LanguageKind.Erlang = "erlang";
			LanguageKind.FSharp = "fsharp";
			LanguageKind.GitCommit = "git-commit";
			LanguageKind.GitRebase = "git-rebase";
			LanguageKind.Go = "go";
			LanguageKind.Groovy = "groovy";
			LanguageKind.Handlebars = "handlebars";
			LanguageKind.Haskell = "haskell";
			LanguageKind.HTML = "html";
			LanguageKind.Ini = "ini";
			LanguageKind.Java = "java";
			LanguageKind.JavaScript = "javascript";
			LanguageKind.JavaScriptReact = "javascriptreact";
			LanguageKind.JSON = "json";
			LanguageKind.LaTeX = "latex";
			LanguageKind.Less = "less";
			LanguageKind.Lua = "lua";
			LanguageKind.Makefile = "makefile";
			LanguageKind.Markdown = "markdown";
			LanguageKind.ObjectiveC = "objective-c";
			LanguageKind.ObjectiveCPP = "objective-cpp";
			/**
			* @since 3.18.0
			*/
			LanguageKind.Pascal = "pascal";
			LanguageKind.Perl = "perl";
			LanguageKind.Perl6 = "perl6";
			LanguageKind.PHP = "php";
			LanguageKind.Plaintext = "plaintext";
			LanguageKind.Powershell = "powershell";
			LanguageKind.Pug = "jade";
			LanguageKind.Python = "python";
			LanguageKind.R = "r";
			LanguageKind.Razor = "razor";
			LanguageKind.Ruby = "ruby";
			LanguageKind.Rust = "rust";
			LanguageKind.SCSS = "scss";
			LanguageKind.SASS = "sass";
			LanguageKind.Scala = "scala";
			LanguageKind.ShaderLab = "shaderlab";
			LanguageKind.ShellScript = "shellscript";
			LanguageKind.SQL = "sql";
			LanguageKind.Swift = "swift";
			LanguageKind.TypeScript = "typescript";
			LanguageKind.TypeScriptReact = "typescriptreact";
			LanguageKind.TeX = "tex";
			LanguageKind.VisualBasic = "vb";
			LanguageKind.XML = "xml";
			LanguageKind.XSL = "xsl";
			LanguageKind.YAML = "yaml";
		})(LanguageKind || (exports$2.LanguageKind = LanguageKind = {}));
		/**
		* The TextDocumentItem namespace provides helper functions to work with
		* {@link TextDocumentItem} literals.
		*/
		var TextDocumentItem;
		(function(TextDocumentItem) {
			/**
			* Creates a new TextDocumentItem literal.
			* @param uri The document's uri.
			* @param languageId The document's language identifier.
			* @param version The document's version number.
			* @param text The document's text.
			*/
			function create(uri, languageId, version, text) {
				return {
					uri,
					languageId,
					version,
					text
				};
			}
			TextDocumentItem.create = create;
			/**
			* Checks whether the given literal conforms to the {@link TextDocumentItem} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Is.string(candidate.uri) && Is.string(candidate.languageId) && Is.integer(candidate.version) && Is.string(candidate.text);
			}
			TextDocumentItem.is = is;
		})(TextDocumentItem || (exports$2.TextDocumentItem = TextDocumentItem = {}));
		/**
		* Describes the content type that a client supports in various
		* result literals like `Hover`, `ParameterInfo` or `CompletionItem`.
		*
		* Please note that `MarkupKinds` must not start with a `$`. This kinds
		* are reserved for internal usage.
		*/
		var MarkupKind;
		(function(MarkupKind) {
			/**
			* Plain text is supported as a content format
			*/
			MarkupKind.PlainText = "plaintext";
			/**
			* Markdown is supported as a content format
			*/
			MarkupKind.Markdown = "markdown";
			/**
			* Checks whether the given value is a value of the {@link MarkupKind} type.
			*/
			function is(value) {
				var candidate = value;
				return candidate === MarkupKind.PlainText || candidate === MarkupKind.Markdown;
			}
			MarkupKind.is = is;
		})(MarkupKind || (exports$2.MarkupKind = MarkupKind = {}));
		var MarkupContent;
		(function(MarkupContent) {
			/**
			* Checks whether the given value conforms to the {@link MarkupContent} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(value) && MarkupKind.is(candidate.kind) && Is.string(candidate.value);
			}
			MarkupContent.is = is;
		})(MarkupContent || (exports$2.MarkupContent = MarkupContent = {}));
		/**
		* The kind of a completion entry.
		*/
		var CompletionItemKind;
		(function(CompletionItemKind) {
			CompletionItemKind.Text = 1;
			CompletionItemKind.Method = 2;
			CompletionItemKind.Function = 3;
			CompletionItemKind.Constructor = 4;
			CompletionItemKind.Field = 5;
			CompletionItemKind.Variable = 6;
			CompletionItemKind.Class = 7;
			CompletionItemKind.Interface = 8;
			CompletionItemKind.Module = 9;
			CompletionItemKind.Property = 10;
			CompletionItemKind.Unit = 11;
			CompletionItemKind.Value = 12;
			CompletionItemKind.Enum = 13;
			CompletionItemKind.Keyword = 14;
			CompletionItemKind.Snippet = 15;
			CompletionItemKind.Color = 16;
			CompletionItemKind.File = 17;
			CompletionItemKind.Reference = 18;
			CompletionItemKind.Folder = 19;
			CompletionItemKind.EnumMember = 20;
			CompletionItemKind.Constant = 21;
			CompletionItemKind.Struct = 22;
			CompletionItemKind.Event = 23;
			CompletionItemKind.Operator = 24;
			CompletionItemKind.TypeParameter = 25;
		})(CompletionItemKind || (exports$2.CompletionItemKind = CompletionItemKind = {}));
		/**
		* Defines whether the insert text in a completion item should be interpreted as
		* plain text or a snippet.
		*/
		var InsertTextFormat;
		(function(InsertTextFormat) {
			/**
			* The primary text to be inserted is treated as a plain string.
			*/
			InsertTextFormat.PlainText = 1;
			/**
			* The primary text to be inserted is treated as a snippet.
			*
			* A snippet can define tab stops and placeholders with `$1`, `$2`
			* and `${3:foo}`. `$0` defines the final tab stop, it defaults to
			* the end of the snippet. Placeholders with equal identifiers are linked,
			* that is typing in one will update others too.
			*
			* See also: https://microsoft.github.io/language-server-protocol/specifications/specification-current/#snippet_syntax
			*/
			InsertTextFormat.Snippet = 2;
		})(InsertTextFormat || (exports$2.InsertTextFormat = InsertTextFormat = {}));
		/**
		* Completion item tags are extra annotations that tweak the rendering of a completion
		* item.
		*
		* @since 3.15.0
		*/
		var CompletionItemTag;
		(function(CompletionItemTag) {
			/**
			* Render a completion as obsolete, usually using a strike-out.
			*/
			CompletionItemTag.Deprecated = 1;
		})(CompletionItemTag || (exports$2.CompletionItemTag = CompletionItemTag = {}));
		/**
		* The InsertReplaceEdit namespace provides functions to deal with insert / replace edits.
		*
		* @since 3.16.0
		*/
		var InsertReplaceEdit;
		(function(InsertReplaceEdit) {
			/**
			* Creates a new insert / replace edit
			*/
			function create(newText, insert, replace) {
				return {
					newText,
					insert,
					replace
				};
			}
			InsertReplaceEdit.create = create;
			/**
			* Checks whether the given literal conforms to the {@link InsertReplaceEdit} interface.
			*/
			function is(value) {
				var candidate = value;
				return candidate && Is.string(candidate.newText) && Range.is(candidate.insert) && Range.is(candidate.replace);
			}
			InsertReplaceEdit.is = is;
		})(InsertReplaceEdit || (exports$2.InsertReplaceEdit = InsertReplaceEdit = {}));
		/**
		* How whitespace and indentation is handled during completion
		* item insertion.
		*
		* @since 3.16.0
		*/
		var InsertTextMode;
		(function(InsertTextMode) {
			/**
			* The insertion or replace strings is taken as it is. If the
			* value is multi line the lines below the cursor will be
			* inserted using the indentation defined in the string value.
			* The client will not apply any kind of adjustments to the
			* string.
			*/
			InsertTextMode.asIs = 1;
			/**
			* The editor adjusts leading whitespace of new lines so that
			* they match the indentation up to the cursor of the line for
			* which the item is accepted.
			*
			* Consider a line like this: <2tabs><cursor><3tabs>foo. Accepting a
			* multi line completion item is indented using 2 tabs and all
			* following lines inserted will be indented using 2 tabs as well.
			*/
			InsertTextMode.adjustIndentation = 2;
		})(InsertTextMode || (exports$2.InsertTextMode = InsertTextMode = {}));
		/**
		* Defines how values from a set of defaults and an individual item will be
		* merged.
		*
		* @since 3.18.0
		*/
		var ApplyKind;
		(function(ApplyKind) {
			/**
			* The value from the individual item (if provided and not `null`) will be
			* used instead of the default.
			*/
			ApplyKind.Replace = 1;
			/**
			* The value from the item will be merged with the default.
			*
			* The specific rules for mergeing values are defined against each field
			* that supports merging.
			*/
			ApplyKind.Merge = 2;
		})(ApplyKind || (exports$2.ApplyKind = ApplyKind = {}));
		var CompletionItemLabelDetails;
		(function(CompletionItemLabelDetails) {
			function is(value) {
				var candidate = value;
				return candidate && (Is.string(candidate.detail) || candidate.detail === void 0) && (Is.string(candidate.description) || candidate.description === void 0);
			}
			CompletionItemLabelDetails.is = is;
		})(CompletionItemLabelDetails || (exports$2.CompletionItemLabelDetails = CompletionItemLabelDetails = {}));
		/**
		* The CompletionItem namespace provides functions to deal with
		* completion items.
		*/
		var CompletionItem;
		(function(CompletionItem) {
			/**
			* Create a completion item and seed it with a label.
			* @param label The completion item's label
			*/
			function create(label) {
				return { label };
			}
			CompletionItem.create = create;
		})(CompletionItem || (exports$2.CompletionItem = CompletionItem = {}));
		/**
		* The CompletionList namespace provides functions to deal with
		* completion lists.
		*/
		var CompletionList;
		(function(CompletionList) {
			/**
			* Creates a new completion list.
			*
			* @param items The completion items.
			* @param isIncomplete The list is not complete.
			*/
			function create(items, isIncomplete) {
				return {
					items: items ? items : [],
					isIncomplete: !!isIncomplete
				};
			}
			CompletionList.create = create;
		})(CompletionList || (exports$2.CompletionList = CompletionList = {}));
		var MarkedString;
		(function(MarkedString) {
			/**
			* Creates a marked string from plain text.
			*
			* @param plainText The plain text.
			*/
			function fromPlainText(plainText) {
				return plainText.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&");
			}
			MarkedString.fromPlainText = fromPlainText;
			/**
			* Checks whether the given value conforms to the {@link MarkedString} type.
			*/
			function is(value) {
				var candidate = value;
				return Is.string(candidate) || Is.objectLiteral(candidate) && Is.string(candidate.language) && Is.string(candidate.value);
			}
			MarkedString.is = is;
		})(MarkedString || (exports$2.MarkedString = MarkedString = {}));
		var Hover;
		(function(Hover) {
			/**
			* Checks whether the given value conforms to the {@link Hover} interface.
			*/
			function is(value) {
				var candidate = value;
				return !!candidate && Is.objectLiteral(candidate) && (MarkupContent.is(candidate.contents) || MarkedString.is(candidate.contents) || Is.typedArray(candidate.contents, MarkedString.is)) && (value.range === void 0 || Range.is(value.range));
			}
			Hover.is = is;
		})(Hover || (exports$2.Hover = Hover = {}));
		/**
		* The ParameterInformation namespace provides helper functions to work with
		* {@link ParameterInformation} literals.
		*/
		var ParameterInformation;
		(function(ParameterInformation) {
			/**
			* Creates a new parameter information literal.
			*
			* @param label A label string.
			* @param documentation A doc string.
			*/
			function create(label, documentation) {
				return documentation ? {
					label,
					documentation
				} : { label };
			}
			ParameterInformation.create = create;
		})(ParameterInformation || (exports$2.ParameterInformation = ParameterInformation = {}));
		/**
		* The SignatureInformation namespace provides helper functions to work with
		* {@link SignatureInformation} literals.
		*/
		var SignatureInformation;
		(function(SignatureInformation) {
			function create(label, documentation) {
				var parameters = [];
				for (var _i = 2; _i < arguments.length; _i++) parameters[_i - 2] = arguments[_i];
				var result = { label };
				if (Is.defined(documentation)) result.documentation = documentation;
				if (Is.defined(parameters)) result.parameters = parameters;
				else result.parameters = [];
				return result;
			}
			SignatureInformation.create = create;
		})(SignatureInformation || (exports$2.SignatureInformation = SignatureInformation = {}));
		/**
		* A document highlight kind.
		*/
		var DocumentHighlightKind;
		(function(DocumentHighlightKind) {
			/**
			* A textual occurrence.
			*/
			DocumentHighlightKind.Text = 1;
			/**
			* Read-access of a symbol, like reading a variable.
			*/
			DocumentHighlightKind.Read = 2;
			/**
			* Write-access of a symbol, like writing to a variable.
			*/
			DocumentHighlightKind.Write = 3;
		})(DocumentHighlightKind || (exports$2.DocumentHighlightKind = DocumentHighlightKind = {}));
		/**
		* DocumentHighlight namespace to provide helper functions to work with
		* {@link DocumentHighlight} literals.
		*/
		var DocumentHighlight;
		(function(DocumentHighlight) {
			/**
			* Create a DocumentHighlight object.
			* @param range The range the highlight applies to.
			* @param kind The highlight kind
			*/
			function create(range, kind) {
				var result = { range };
				if (Is.number(kind)) result.kind = kind;
				return result;
			}
			DocumentHighlight.create = create;
		})(DocumentHighlight || (exports$2.DocumentHighlight = DocumentHighlight = {}));
		/**
		* A symbol kind.
		*/
		var SymbolKind;
		(function(SymbolKind) {
			SymbolKind.File = 1;
			SymbolKind.Module = 2;
			SymbolKind.Namespace = 3;
			SymbolKind.Package = 4;
			SymbolKind.Class = 5;
			SymbolKind.Method = 6;
			SymbolKind.Property = 7;
			SymbolKind.Field = 8;
			SymbolKind.Constructor = 9;
			SymbolKind.Enum = 10;
			SymbolKind.Interface = 11;
			SymbolKind.Function = 12;
			SymbolKind.Variable = 13;
			SymbolKind.Constant = 14;
			SymbolKind.String = 15;
			SymbolKind.Number = 16;
			SymbolKind.Boolean = 17;
			SymbolKind.Array = 18;
			SymbolKind.Object = 19;
			SymbolKind.Key = 20;
			SymbolKind.Null = 21;
			SymbolKind.EnumMember = 22;
			SymbolKind.Struct = 23;
			SymbolKind.Event = 24;
			SymbolKind.Operator = 25;
			SymbolKind.TypeParameter = 26;
		})(SymbolKind || (exports$2.SymbolKind = SymbolKind = {}));
		/**
		* Symbol tags are extra annotations that tweak the rendering of a symbol.
		*
		* @since 3.16
		*/
		var SymbolTag;
		(function(SymbolTag) {
			/**
			* Render a symbol as obsolete, usually using a strike-out.
			*/
			SymbolTag.Deprecated = 1;
		})(SymbolTag || (exports$2.SymbolTag = SymbolTag = {}));
		var SymbolInformation;
		(function(SymbolInformation) {
			/**
			* Creates a new symbol information literal.
			*
			* @param name The name of the symbol.
			* @param kind The kind of the symbol.
			* @param range The range of the location of the symbol.
			* @param uri The resource of the location of symbol.
			* @param containerName The name of the symbol containing the symbol.
			*/
			function create(name, kind, range, uri, containerName) {
				var result = {
					name,
					kind,
					location: {
						uri,
						range
					}
				};
				if (containerName) result.containerName = containerName;
				return result;
			}
			SymbolInformation.create = create;
		})(SymbolInformation || (exports$2.SymbolInformation = SymbolInformation = {}));
		var WorkspaceSymbol;
		(function(WorkspaceSymbol) {
			/**
			* Create a new workspace symbol.
			*
			* @param name The name of the symbol.
			* @param kind The kind of the symbol.
			* @param uri The resource of the location of the symbol.
			* @param range An options range of the location.
			* @returns A WorkspaceSymbol.
			*/
			function create(name, kind, uri, range) {
				return range !== void 0 ? {
					name,
					kind,
					location: {
						uri,
						range
					}
				} : {
					name,
					kind,
					location: { uri }
				};
			}
			WorkspaceSymbol.create = create;
		})(WorkspaceSymbol || (exports$2.WorkspaceSymbol = WorkspaceSymbol = {}));
		var DocumentSymbol;
		(function(DocumentSymbol) {
			/**
			* Creates a new symbol information literal.
			*
			* @param name The name of the symbol.
			* @param detail The detail of the symbol.
			* @param kind The kind of the symbol.
			* @param range The range of the symbol.
			* @param selectionRange The selectionRange of the symbol.
			* @param children Children of the symbol.
			*/
			function create(name, detail, kind, range, selectionRange, children) {
				var result = {
					name,
					detail,
					kind,
					range,
					selectionRange
				};
				if (children !== void 0) result.children = children;
				return result;
			}
			DocumentSymbol.create = create;
			/**
			* Checks whether the given literal conforms to the {@link DocumentSymbol} interface.
			*/
			function is(value) {
				var candidate = value;
				return candidate && Is.string(candidate.name) && Is.number(candidate.kind) && Range.is(candidate.range) && Range.is(candidate.selectionRange) && (candidate.detail === void 0 || Is.string(candidate.detail)) && (candidate.deprecated === void 0 || Is.boolean(candidate.deprecated)) && (candidate.children === void 0 || Array.isArray(candidate.children)) && (candidate.tags === void 0 || Array.isArray(candidate.tags));
			}
			DocumentSymbol.is = is;
		})(DocumentSymbol || (exports$2.DocumentSymbol = DocumentSymbol = {}));
		/**
		* A set of predefined code action kinds
		*/
		var CodeActionKind;
		(function(CodeActionKind) {
			/**
			* Empty kind.
			*/
			CodeActionKind.Empty = "";
			/**
			* Base kind for quickfix actions: 'quickfix'
			*/
			CodeActionKind.QuickFix = "quickfix";
			/**
			* Base kind for refactoring actions: 'refactor'
			*/
			CodeActionKind.Refactor = "refactor";
			/**
			* Base kind for refactoring extraction actions: 'refactor.extract'
			*
			* Example extract actions:
			*
			* - Extract method
			* - Extract function
			* - Extract variable
			* - Extract interface from class
			* - ...
			*/
			CodeActionKind.RefactorExtract = "refactor.extract";
			/**
			* Base kind for refactoring inline actions: 'refactor.inline'
			*
			* Example inline actions:
			*
			* - Inline function
			* - Inline variable
			* - Inline constant
			* - ...
			*/
			CodeActionKind.RefactorInline = "refactor.inline";
			/**
			* Base kind for refactoring move actions: `refactor.move`
			*
			* Example move actions:
			*
			* - Move a function to a new file
			* - Move a property between classes
			* - Move method to base class
			* - ...
			*
			* @since 3.18.0
			*/
			CodeActionKind.RefactorMove = "refactor.move";
			/**
			* Base kind for refactoring rewrite actions: 'refactor.rewrite'
			*
			* Example rewrite actions:
			*
			* - Convert JavaScript function to class
			* - Add or remove parameter
			* - Encapsulate field
			* - Make method static
			* - Move method to base class
			* - ...
			*/
			CodeActionKind.RefactorRewrite = "refactor.rewrite";
			/**
			* Base kind for source actions: `source`
			*
			* Source code actions apply to the entire file.
			*/
			CodeActionKind.Source = "source";
			/**
			* Base kind for an organize imports source action: `source.organizeImports`
			*/
			CodeActionKind.SourceOrganizeImports = "source.organizeImports";
			/**
			* Base kind for auto-fix source actions: `source.fixAll`.
			*
			* Fix all actions automatically fix errors that have a clear fix that do not require user input.
			* They should not suppress errors or perform unsafe fixes such as generating new types or classes.
			*
			* @since 3.15.0
			*/
			CodeActionKind.SourceFixAll = "source.fixAll";
			/**
			* Base kind for all code actions applying to the entire notebook's scope. CodeActionKinds using
			* this should always begin with `notebook.`
			*
			* @since 3.18.0
			*/
			CodeActionKind.Notebook = "notebook";
		})(CodeActionKind || (exports$2.CodeActionKind = CodeActionKind = {}));
		/**
		* The reason why code actions were requested.
		*
		* @since 3.17.0
		*/
		var CodeActionTriggerKind;
		(function(CodeActionTriggerKind) {
			/**
			* Code actions were explicitly requested by the user or by an extension.
			*/
			CodeActionTriggerKind.Invoked = 1;
			/**
			* Code actions were requested automatically.
			*
			* This typically happens when current selection in a file changes, but can
			* also be triggered when file content changes.
			*/
			CodeActionTriggerKind.Automatic = 2;
		})(CodeActionTriggerKind || (exports$2.CodeActionTriggerKind = CodeActionTriggerKind = {}));
		/**
		* The CodeActionContext namespace provides helper functions to work with
		* {@link CodeActionContext} literals.
		*/
		var CodeActionContext;
		(function(CodeActionContext) {
			/**
			* Creates a new CodeActionContext literal.
			*/
			function create(diagnostics, only, triggerKind) {
				var result = { diagnostics };
				if (only !== void 0 && only !== null) result.only = only;
				if (triggerKind !== void 0 && triggerKind !== null) result.triggerKind = triggerKind;
				return result;
			}
			CodeActionContext.create = create;
			/**
			* Checks whether the given literal conforms to the {@link CodeActionContext} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Is.typedArray(candidate.diagnostics, Diagnostic.is) && (candidate.only === void 0 || Is.typedArray(candidate.only, Is.string)) && (candidate.triggerKind === void 0 || candidate.triggerKind === CodeActionTriggerKind.Invoked || candidate.triggerKind === CodeActionTriggerKind.Automatic);
			}
			CodeActionContext.is = is;
		})(CodeActionContext || (exports$2.CodeActionContext = CodeActionContext = {}));
		/**
		* Code action tags are extra annotations that tweak the behavior of a code action.
		*
		* @since 3.18.0
		*/
		var CodeActionTag;
		(function(CodeActionTag) {
			/**
			* Marks the code action as LLM-generated.
			*/
			CodeActionTag.LLMGenerated = 1;
			/**
			* Checks whether the given literal conforms to the {@link CodeActionTag} interface.
			*/
			function is(value) {
				return Is.defined(value) && value === CodeActionTag.LLMGenerated;
			}
			CodeActionTag.is = is;
		})(CodeActionTag || (exports$2.CodeActionTag = CodeActionTag = {}));
		var CodeAction;
		(function(CodeAction) {
			function create(title, kindOrCommandOrEdit, kind) {
				var result = { title };
				var checkKind = true;
				if (typeof kindOrCommandOrEdit === "string") {
					checkKind = false;
					result.kind = kindOrCommandOrEdit;
				} else if (Command.is(kindOrCommandOrEdit)) result.command = kindOrCommandOrEdit;
				else result.edit = kindOrCommandOrEdit;
				if (checkKind && kind !== void 0) result.kind = kind;
				return result;
			}
			CodeAction.create = create;
			function is(value) {
				var candidate = value;
				return candidate && Is.string(candidate.title) && (candidate.diagnostics === void 0 || Is.typedArray(candidate.diagnostics, Diagnostic.is)) && (candidate.kind === void 0 || Is.string(candidate.kind)) && (candidate.edit !== void 0 || candidate.command !== void 0) && (candidate.command === void 0 || Command.is(candidate.command)) && (candidate.isPreferred === void 0 || Is.boolean(candidate.isPreferred)) && (candidate.edit === void 0 || WorkspaceEdit.is(candidate.edit)) && (candidate.tags === void 0 || Is.typedArray(candidate.tags, CodeActionTag.is));
			}
			CodeAction.is = is;
		})(CodeAction || (exports$2.CodeAction = CodeAction = {}));
		/**
		* The CodeLens namespace provides helper functions to work with
		* {@link CodeLens} literals.
		*/
		var CodeLens;
		(function(CodeLens) {
			/**
			* Creates a new CodeLens literal.
			*/
			function create(range, data) {
				var result = { range };
				if (Is.defined(data)) result.data = data;
				return result;
			}
			CodeLens.create = create;
			/**
			* Checks whether the given literal conforms to the {@link CodeLens} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Range.is(candidate.range) && (Is.undefined(candidate.command) || Command.is(candidate.command));
			}
			CodeLens.is = is;
		})(CodeLens || (exports$2.CodeLens = CodeLens = {}));
		/**
		* The FormattingOptions namespace provides helper functions to work with
		* {@link FormattingOptions} literals.
		*/
		var FormattingOptions;
		(function(FormattingOptions) {
			/**
			* Creates a new FormattingOptions literal.
			*/
			function create(tabSize, insertSpaces) {
				return {
					tabSize,
					insertSpaces
				};
			}
			FormattingOptions.create = create;
			/**
			* Checks whether the given literal conforms to the {@link FormattingOptions} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Is.uinteger(candidate.tabSize) && Is.boolean(candidate.insertSpaces);
			}
			FormattingOptions.is = is;
		})(FormattingOptions || (exports$2.FormattingOptions = FormattingOptions = {}));
		/**
		* The DocumentLink namespace provides helper functions to work with
		* {@link DocumentLink} literals.
		*/
		var DocumentLink;
		(function(DocumentLink) {
			/**
			* Creates a new DocumentLink literal.
			*/
			function create(range, target, data) {
				return {
					range,
					target,
					data
				};
			}
			DocumentLink.create = create;
			/**
			* Checks whether the given literal conforms to the {@link DocumentLink} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Range.is(candidate.range) && (Is.undefined(candidate.target) || Is.string(candidate.target));
			}
			DocumentLink.is = is;
		})(DocumentLink || (exports$2.DocumentLink = DocumentLink = {}));
		/**
		* The SelectionRange namespace provides helper function to work with
		* SelectionRange literals.
		*/
		var SelectionRange;
		(function(SelectionRange) {
			/**
			* Creates a new SelectionRange
			* @param range the range.
			* @param parent an optional parent.
			*/
			function create(range, parent) {
				return {
					range,
					parent
				};
			}
			SelectionRange.create = create;
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Range.is(candidate.range) && (candidate.parent === void 0 || SelectionRange.is(candidate.parent));
			}
			SelectionRange.is = is;
		})(SelectionRange || (exports$2.SelectionRange = SelectionRange = {}));
		/**
		* A set of predefined token types. This set is not fixed
		* an clients can specify additional token types via the
		* corresponding client capabilities.
		*
		* @since 3.16.0
		*/
		var SemanticTokenTypes;
		(function(SemanticTokenTypes) {
			SemanticTokenTypes["namespace"] = "namespace";
			/**
			* Represents a generic type. Acts as a fallback for types which can't be mapped to
			* a specific type like class or enum.
			*/
			SemanticTokenTypes["type"] = "type";
			SemanticTokenTypes["class"] = "class";
			SemanticTokenTypes["enum"] = "enum";
			SemanticTokenTypes["interface"] = "interface";
			SemanticTokenTypes["struct"] = "struct";
			SemanticTokenTypes["typeParameter"] = "typeParameter";
			SemanticTokenTypes["parameter"] = "parameter";
			SemanticTokenTypes["variable"] = "variable";
			SemanticTokenTypes["property"] = "property";
			SemanticTokenTypes["enumMember"] = "enumMember";
			SemanticTokenTypes["event"] = "event";
			SemanticTokenTypes["function"] = "function";
			SemanticTokenTypes["method"] = "method";
			SemanticTokenTypes["macro"] = "macro";
			SemanticTokenTypes["keyword"] = "keyword";
			SemanticTokenTypes["modifier"] = "modifier";
			SemanticTokenTypes["comment"] = "comment";
			SemanticTokenTypes["string"] = "string";
			SemanticTokenTypes["number"] = "number";
			SemanticTokenTypes["regexp"] = "regexp";
			SemanticTokenTypes["operator"] = "operator";
			/**
			* @since 3.17.0
			*/
			SemanticTokenTypes["decorator"] = "decorator";
			/**
			* @since 3.18.0
			*/
			SemanticTokenTypes["label"] = "label";
		})(SemanticTokenTypes || (exports$2.SemanticTokenTypes = SemanticTokenTypes = {}));
		/**
		* A set of predefined token modifiers. This set is not fixed
		* an clients can specify additional token types via the
		* corresponding client capabilities.
		*
		* @since 3.16.0
		*/
		var SemanticTokenModifiers;
		(function(SemanticTokenModifiers) {
			SemanticTokenModifiers["declaration"] = "declaration";
			SemanticTokenModifiers["definition"] = "definition";
			SemanticTokenModifiers["readonly"] = "readonly";
			SemanticTokenModifiers["static"] = "static";
			SemanticTokenModifiers["deprecated"] = "deprecated";
			SemanticTokenModifiers["abstract"] = "abstract";
			SemanticTokenModifiers["async"] = "async";
			SemanticTokenModifiers["modification"] = "modification";
			SemanticTokenModifiers["documentation"] = "documentation";
			SemanticTokenModifiers["defaultLibrary"] = "defaultLibrary";
		})(SemanticTokenModifiers || (exports$2.SemanticTokenModifiers = SemanticTokenModifiers = {}));
		/**
		* @since 3.16.0
		*/
		var SemanticTokens;
		(function(SemanticTokens) {
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && (candidate.resultId === void 0 || typeof candidate.resultId === "string") && Array.isArray(candidate.data) && (candidate.data.length === 0 || typeof candidate.data[0] === "number");
			}
			SemanticTokens.is = is;
		})(SemanticTokens || (exports$2.SemanticTokens = SemanticTokens = {}));
		/**
		* The InlineValueText namespace provides functions to deal with InlineValueTexts.
		*
		* @since 3.17.0
		*/
		var InlineValueText;
		(function(InlineValueText) {
			/**
			* Creates a new InlineValueText literal.
			*/
			function create(range, text) {
				return {
					range,
					text
				};
			}
			InlineValueText.create = create;
			function is(value) {
				var candidate = value;
				return candidate !== void 0 && candidate !== null && Range.is(candidate.range) && Is.string(candidate.text);
			}
			InlineValueText.is = is;
		})(InlineValueText || (exports$2.InlineValueText = InlineValueText = {}));
		/**
		* The InlineValueVariableLookup namespace provides functions to
		* deal with InlineValueVariableLookups.
		*
		* @since 3.17.0
		*/
		var InlineValueVariableLookup;
		(function(InlineValueVariableLookup) {
			/**
			* Creates a new InlineValueText literal.
			*/
			function create(range, variableName, caseSensitiveLookup) {
				return {
					range,
					variableName,
					caseSensitiveLookup
				};
			}
			InlineValueVariableLookup.create = create;
			function is(value) {
				var candidate = value;
				return candidate !== void 0 && candidate !== null && Range.is(candidate.range) && Is.boolean(candidate.caseSensitiveLookup) && (Is.string(candidate.variableName) || candidate.variableName === void 0);
			}
			InlineValueVariableLookup.is = is;
		})(InlineValueVariableLookup || (exports$2.InlineValueVariableLookup = InlineValueVariableLookup = {}));
		/**
		* The InlineValueEvaluatableExpression namespace provides functions to deal with InlineValueEvaluatableExpression.
		*
		* @since 3.17.0
		*/
		var InlineValueEvaluatableExpression;
		(function(InlineValueEvaluatableExpression) {
			/**
			* Creates a new InlineValueEvaluatableExpression literal.
			*/
			function create(range, expression) {
				return {
					range,
					expression
				};
			}
			InlineValueEvaluatableExpression.create = create;
			function is(value) {
				var candidate = value;
				return candidate !== void 0 && candidate !== null && Range.is(candidate.range) && (Is.string(candidate.expression) || candidate.expression === void 0);
			}
			InlineValueEvaluatableExpression.is = is;
		})(InlineValueEvaluatableExpression || (exports$2.InlineValueEvaluatableExpression = InlineValueEvaluatableExpression = {}));
		/**
		* The InlineValueContext namespace provides helper functions to work with
		* {@link InlineValueContext} literals.
		*
		* @since 3.17.0
		*/
		var InlineValueContext;
		(function(InlineValueContext) {
			/**
			* Creates a new InlineValueContext literal.
			*/
			function create(frameId, stoppedLocation) {
				return {
					frameId,
					stoppedLocation
				};
			}
			InlineValueContext.create = create;
			/**
			* Checks whether the given literal conforms to the {@link InlineValueContext} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Range.is(value.stoppedLocation);
			}
			InlineValueContext.is = is;
		})(InlineValueContext || (exports$2.InlineValueContext = InlineValueContext = {}));
		/**
		* Inlay hint kinds.
		*
		* @since 3.17.0
		*/
		var InlayHintKind;
		(function(InlayHintKind) {
			/**
			* An inlay hint that for a type annotation.
			*/
			InlayHintKind.Type = 1;
			/**
			* An inlay hint that is for a parameter.
			*/
			InlayHintKind.Parameter = 2;
			function is(value) {
				return value === 1 || value === 2;
			}
			InlayHintKind.is = is;
		})(InlayHintKind || (exports$2.InlayHintKind = InlayHintKind = {}));
		var InlayHintLabelPart;
		(function(InlayHintLabelPart) {
			function create(value) {
				return { value };
			}
			InlayHintLabelPart.create = create;
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && (candidate.tooltip === void 0 || Is.string(candidate.tooltip) || MarkupContent.is(candidate.tooltip)) && (candidate.location === void 0 || Location.is(candidate.location)) && (candidate.command === void 0 || Command.is(candidate.command));
			}
			InlayHintLabelPart.is = is;
		})(InlayHintLabelPart || (exports$2.InlayHintLabelPart = InlayHintLabelPart = {}));
		var InlayHint;
		(function(InlayHint) {
			function create(position, label, kind) {
				var result = {
					position,
					label
				};
				if (kind !== void 0) result.kind = kind;
				return result;
			}
			InlayHint.create = create;
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && Position.is(candidate.position) && (Is.string(candidate.label) || Is.typedArray(candidate.label, InlayHintLabelPart.is)) && (candidate.kind === void 0 || InlayHintKind.is(candidate.kind)) && candidate.textEdits === void 0 || Is.typedArray(candidate.textEdits, TextEdit.is) && (candidate.tooltip === void 0 || Is.string(candidate.tooltip) || MarkupContent.is(candidate.tooltip)) && (candidate.paddingLeft === void 0 || Is.boolean(candidate.paddingLeft)) && (candidate.paddingRight === void 0 || Is.boolean(candidate.paddingRight));
			}
			InlayHint.is = is;
		})(InlayHint || (exports$2.InlayHint = InlayHint = {}));
		var StringValue;
		(function(StringValue) {
			function createSnippet(value) {
				return {
					kind: "snippet",
					value
				};
			}
			StringValue.createSnippet = createSnippet;
			function isSnippet(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && candidate.kind === "snippet" && Is.string(candidate.value);
			}
			StringValue.isSnippet = isSnippet;
		})(StringValue || (exports$2.StringValue = StringValue = {}));
		var InlineCompletionItem;
		(function(InlineCompletionItem) {
			function create(insertText, filterText, range, command) {
				return {
					insertText,
					filterText,
					range,
					command
				};
			}
			InlineCompletionItem.create = create;
		})(InlineCompletionItem || (exports$2.InlineCompletionItem = InlineCompletionItem = {}));
		var InlineCompletionList;
		(function(InlineCompletionList) {
			function create(items) {
				return { items };
			}
			InlineCompletionList.create = create;
		})(InlineCompletionList || (exports$2.InlineCompletionList = InlineCompletionList = {}));
		/**
		* Describes how an {@link InlineCompletionItemProvider inline completion provider} was triggered.
		*
		* @since 3.18.0
		*/
		var InlineCompletionTriggerKind;
		(function(InlineCompletionTriggerKind) {
			/**
			* Completion was triggered explicitly by a user gesture.
			*/
			InlineCompletionTriggerKind.Invoked = 1;
			/**
			* Completion was triggered automatically while editing.
			*/
			InlineCompletionTriggerKind.Automatic = 2;
		})(InlineCompletionTriggerKind || (exports$2.InlineCompletionTriggerKind = InlineCompletionTriggerKind = {}));
		var SelectedCompletionInfo;
		(function(SelectedCompletionInfo) {
			function create(range, text) {
				return {
					range,
					text
				};
			}
			SelectedCompletionInfo.create = create;
		})(SelectedCompletionInfo || (exports$2.SelectedCompletionInfo = SelectedCompletionInfo = {}));
		var InlineCompletionContext;
		(function(InlineCompletionContext) {
			function create(triggerKind, selectedCompletionInfo) {
				return {
					triggerKind,
					selectedCompletionInfo
				};
			}
			InlineCompletionContext.create = create;
		})(InlineCompletionContext || (exports$2.InlineCompletionContext = InlineCompletionContext = {}));
		var WorkspaceFolder;
		(function(WorkspaceFolder) {
			function is(value) {
				var candidate = value;
				return Is.objectLiteral(candidate) && URI.is(candidate.uri) && Is.string(candidate.name);
			}
			WorkspaceFolder.is = is;
		})(WorkspaceFolder || (exports$2.WorkspaceFolder = WorkspaceFolder = {}));
		exports$2.EOL = [
			"\n",
			"\r\n",
			"\r"
		];
		/**
		* @deprecated Use the text document from the new vscode-languageserver-textdocument package.
		*/
		var TextDocument;
		(function(TextDocument) {
			/**
			* Creates a new ITextDocument literal from the given uri and content.
			* @param uri The document's uri.
			* @param languageId The document's language Id.
			* @param version The document's version.
			* @param content The document's content.
			*/
			function create(uri, languageId, version, content) {
				return new FullTextDocument(uri, languageId, version, content);
			}
			TextDocument.create = create;
			/**
			* Checks whether the given literal conforms to the {@link ITextDocument} interface.
			*/
			function is(value) {
				var candidate = value;
				return Is.defined(candidate) && Is.string(candidate.uri) && (Is.undefined(candidate.languageId) || Is.string(candidate.languageId)) && Is.uinteger(candidate.lineCount) && Is.func(candidate.getText) && Is.func(candidate.positionAt) && Is.func(candidate.offsetAt) ? true : false;
			}
			TextDocument.is = is;
			function applyEdits(document, edits) {
				var text = document.getText();
				var sortedEdits = mergeSort(edits, function(a, b) {
					var diff = a.range.start.line - b.range.start.line;
					if (diff === 0) return a.range.start.character - b.range.start.character;
					return diff;
				});
				var lastModifiedOffset = text.length;
				for (var i = sortedEdits.length - 1; i >= 0; i--) {
					var e = sortedEdits[i];
					var startOffset = document.offsetAt(e.range.start);
					var endOffset = document.offsetAt(e.range.end);
					if (endOffset <= lastModifiedOffset) text = text.substring(0, startOffset) + e.newText + text.substring(endOffset, text.length);
					else throw new Error("Overlapping edit");
					lastModifiedOffset = startOffset;
				}
				return text;
			}
			TextDocument.applyEdits = applyEdits;
			function mergeSort(data, compare) {
				if (data.length <= 1) return data;
				var p = data.length / 2 | 0;
				var left = data.slice(0, p);
				var right = data.slice(p);
				mergeSort(left, compare);
				mergeSort(right, compare);
				var leftIdx = 0;
				var rightIdx = 0;
				var i = 0;
				while (leftIdx < left.length && rightIdx < right.length) if (compare(left[leftIdx], right[rightIdx]) <= 0) data[i++] = left[leftIdx++];
				else data[i++] = right[rightIdx++];
				while (leftIdx < left.length) data[i++] = left[leftIdx++];
				while (rightIdx < right.length) data[i++] = right[rightIdx++];
				return data;
			}
		})(TextDocument || (exports$2.TextDocument = TextDocument = {}));
		/**
		* @deprecated Use the text document from the new vscode-languageserver-textdocument package.
		*/
		var FullTextDocument = function() {
			function FullTextDocument(uri, languageId, version, content) {
				this._uri = uri;
				this._languageId = languageId;
				this._version = version;
				this._content = content;
				this._lineOffsets = void 0;
			}
			Object.defineProperty(FullTextDocument.prototype, "uri", {
				get: function() {
					return this._uri;
				},
				enumerable: false,
				configurable: true
			});
			Object.defineProperty(FullTextDocument.prototype, "languageId", {
				get: function() {
					return this._languageId;
				},
				enumerable: false,
				configurable: true
			});
			Object.defineProperty(FullTextDocument.prototype, "version", {
				get: function() {
					return this._version;
				},
				enumerable: false,
				configurable: true
			});
			FullTextDocument.prototype.getText = function(range) {
				if (range) {
					var start = this.offsetAt(range.start);
					var end = this.offsetAt(range.end);
					return this._content.substring(start, end);
				}
				return this._content;
			};
			FullTextDocument.prototype.update = function(event, version) {
				this._content = event.text;
				this._version = version;
				this._lineOffsets = void 0;
			};
			FullTextDocument.prototype.getLineOffsets = function() {
				if (this._lineOffsets === void 0) {
					var lineOffsets = [];
					var text = this._content;
					var isLineStart = true;
					for (var i = 0; i < text.length; i++) {
						if (isLineStart) {
							lineOffsets.push(i);
							isLineStart = false;
						}
						var ch = text.charAt(i);
						isLineStart = ch === "\r" || ch === "\n";
						if (ch === "\r" && i + 1 < text.length && text.charAt(i + 1) === "\n") i++;
					}
					if (isLineStart && text.length > 0) lineOffsets.push(text.length);
					this._lineOffsets = lineOffsets;
				}
				return this._lineOffsets;
			};
			FullTextDocument.prototype.positionAt = function(offset) {
				offset = Math.max(Math.min(offset, this._content.length), 0);
				var lineOffsets = this.getLineOffsets();
				var low = 0, high = lineOffsets.length;
				if (high === 0) return Position.create(0, offset);
				while (low < high) {
					var mid = Math.floor((low + high) / 2);
					if (lineOffsets[mid] > offset) high = mid;
					else low = mid + 1;
				}
				var line = low - 1;
				return Position.create(line, offset - lineOffsets[line]);
			};
			FullTextDocument.prototype.offsetAt = function(position) {
				var lineOffsets = this.getLineOffsets();
				if (position.line >= lineOffsets.length) return this._content.length;
				else if (position.line < 0) return 0;
				var lineOffset = lineOffsets[position.line];
				var nextLineOffset = position.line + 1 < lineOffsets.length ? lineOffsets[position.line + 1] : this._content.length;
				return Math.max(Math.min(lineOffset + position.character, nextLineOffset), lineOffset);
			};
			Object.defineProperty(FullTextDocument.prototype, "lineCount", {
				get: function() {
					return this.getLineOffsets().length;
				},
				enumerable: false,
				configurable: true
			});
			return FullTextDocument;
		}();
		var Is;
		(function(Is) {
			var toString = Object.prototype.toString;
			function defined(value) {
				return typeof value !== "undefined";
			}
			Is.defined = defined;
			function undefined(value) {
				return typeof value === "undefined";
			}
			Is.undefined = undefined;
			function boolean(value) {
				return value === true || value === false;
			}
			Is.boolean = boolean;
			function string(value) {
				return toString.call(value) === "[object String]";
			}
			Is.string = string;
			function number(value) {
				return toString.call(value) === "[object Number]";
			}
			Is.number = number;
			function numberRange(value, min, max) {
				return toString.call(value) === "[object Number]" && min <= value && value <= max;
			}
			Is.numberRange = numberRange;
			function integer(value) {
				return toString.call(value) === "[object Number]" && -2147483648 <= value && value <= 2147483647;
			}
			Is.integer = integer;
			function uinteger(value) {
				return toString.call(value) === "[object Number]" && 0 <= value && value <= 2147483647;
			}
			Is.uinteger = uinteger;
			function func(value) {
				return toString.call(value) === "[object Function]";
			}
			Is.func = func;
			function objectLiteral(value) {
				return value !== null && typeof value === "object";
			}
			Is.objectLiteral = objectLiteral;
			function typedArray(value, check) {
				return Array.isArray(value) && value.every(check);
			}
			Is.typedArray = typedArray;
		})(Is || (Is = {}));
	});
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/line.js
var require_line = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Line = void 0;
	var Line = class {
		constructor(document, range) {
			this.document = document;
			this.range = range;
		}
		getRange() {
			return this.range;
		}
		getTextContent() {
			return this.document.getText().substring(this.document.offsetAt(this.range.start), this.document.offsetAt(this.range.end));
		}
		isAfter(line) {
			return this.range.start.line > line.range.start.line;
		}
		isBefore(line) {
			return this.range.start.line < line;
		}
	};
	exports.Line = Line;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/util.js
var require_util = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Util = void 0;
	exports.Util = class Util {
		static isUTF8BOM(char) {
			const uintArray = Uint8Array.from(Buffer.from(char, "UTF-8"));
			return uintArray[0] === 239 && uintArray[1] == 187 && uintArray[2] == 191;
		}
		static isWhitespace(char) {
			return char === " " || char === "	" || Util.isNewline(char);
		}
		static isNewline(char) {
			return char === "\r" || char === "\n";
		}
		static findLeadingNonWhitespace(content, escapeChar) {
			whitespaceCheck: for (let i = 0; i < content.length; i++) switch (content.charAt(i)) {
				case " ":
				case "	": continue;
				case escapeChar:
					escapeCheck: for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
						case " ":
						case "	": continue;
						case "\r":
							i = j + 1;
							continue whitespaceCheck;
						case "\n":
							i = j;
							continue whitespaceCheck;
						default: break escapeCheck;
					}
					return -1;
				default: return i;
			}
			return -1;
		}
		/**
		* Determines if the given position is contained within the given range.
		*
		* @param position the position to check
		* @param range the range to see if the position is inside of
		*/
		static isInsideRange(position, range) {
			if (range.start.line === range.end.line) return range.start.line === position.line && range.start.character <= position.character && position.character <= range.end.character;
			else if (range.start.line === position.line) return range.start.character <= position.character;
			else if (range.end.line === position.line) return position.character <= range.end.character;
			return range.start.line < position.line && position.line < range.end.line;
		}
		static parseHeredocName(value) {
			value = value.substring(2);
			if (value.charAt(0) === "-") value = value.substring(1);
			if (value.charAt(0) === "\"") {
				if (value.charAt(value.length - 1) !== "\"") return null;
				value = value.substring(1, value.length - 1);
			}
			if (value.charAt(0) === "'") {
				if (value.charAt(value.length - 1) !== "'") return null;
				value = value.substring(1, value.length - 1);
			}
			if (value.charAt(0) === "<") return null;
			return value;
		}
	};
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/comment.js
var require_comment = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Comment = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var line_1 = require_line();
	var util_1 = require_util();
	var Comment = class extends line_1.Line {
		constructor(document, range) {
			super(document, range);
		}
		toString() {
			const content = this.getContent();
			if (content) return "# " + content;
			return "#";
		}
		/**
		* Returns the content of this comment. This excludes leading and
		* trailing whitespace as well as the # symbol. If the comment only
		* consists of whitespace, the empty string will be returned.
		*/
		getContent() {
			let range = this.getContentRange();
			if (range === null) return "";
			return this.document.getText().substring(this.document.offsetAt(range.start), this.document.offsetAt(range.end));
		}
		/**
		* Returns a range that includes the content of the comment
		* excluding any leading and trailing whitespace as well as the #
		* symbol. May return null if the comment only consists of whitespace
		* characters.
		*/
		getContentRange() {
			let range = this.getRange();
			const startOffset = this.document.offsetAt(range.start);
			let raw = this.document.getText().substring(startOffset, this.document.offsetAt(range.end));
			let start = -1;
			let end = -1;
			for (let i = 1; i < raw.length; i++) if (!util_1.Util.isWhitespace(raw.charAt(i))) {
				start = i;
				break;
			}
			if (start === -1) return null;
			for (let i = raw.length - 1; i >= 1; i--) if (!util_1.Util.isWhitespace(raw.charAt(i))) {
				end = i + 1;
				break;
			}
			return vscode_languageserver_types_1.Range.create(this.document.positionAt(startOffset + start), this.document.positionAt(startOffset + end));
		}
	};
	exports.Comment = Comment;
}));
//#endregion
//#region node_modules/vscode-languageserver-textdocument/lib/umd/main.js
var require_main$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var __spreadArray = exports && exports.__spreadArray || function(to, from, pack) {
		if (pack || arguments.length === 2) {
			for (var i = 0, l = from.length, ar; i < l; i++) if (ar || !(i in from)) {
				if (!ar) ar = Array.prototype.slice.call(from, 0, i);
				ar[i] = from[i];
			}
		}
		return to.concat(ar || Array.prototype.slice.call(from));
	};
	(function(factory) {
		if (typeof module === "object" && typeof module.exports === "object") {
			var v = factory(__require, exports);
			if (v !== void 0) module.exports = v;
		} else if (typeof define === "function" && define.amd) define(["require", "exports"], factory);
	})(function(require, exports$1) {
		"use strict";
		Object.defineProperty(exports$1, "__esModule", { value: true });
		exports$1.TextDocument = void 0;
		var FullTextDocument = function() {
			function FullTextDocument(uri, languageId, version, content) {
				this._uri = uri;
				this._languageId = languageId;
				this._version = version;
				this._content = content;
				this._lineOffsets = void 0;
			}
			Object.defineProperty(FullTextDocument.prototype, "uri", {
				get: function() {
					return this._uri;
				},
				enumerable: false,
				configurable: true
			});
			Object.defineProperty(FullTextDocument.prototype, "languageId", {
				get: function() {
					return this._languageId;
				},
				enumerable: false,
				configurable: true
			});
			Object.defineProperty(FullTextDocument.prototype, "version", {
				get: function() {
					return this._version;
				},
				enumerable: false,
				configurable: true
			});
			FullTextDocument.prototype.getText = function(range) {
				if (range) {
					var start = this.offsetAt(range.start);
					var end = this.offsetAt(range.end);
					return this._content.substring(start, end);
				}
				return this._content;
			};
			FullTextDocument.prototype.update = function(changes, version) {
				for (var _i = 0, changes_1 = changes; _i < changes_1.length; _i++) {
					var change = changes_1[_i];
					if (FullTextDocument.isIncremental(change)) {
						var range = getWellformedRange(change.range);
						var startOffset = this.offsetAt(range.start);
						var endOffset = this.offsetAt(range.end);
						this._content = this._content.substring(0, startOffset) + change.text + this._content.substring(endOffset, this._content.length);
						var startLine = Math.max(range.start.line, 0);
						var endLine = Math.max(range.end.line, 0);
						var lineOffsets = this._lineOffsets;
						var addedLineOffsets = computeLineOffsets(change.text, false, startOffset);
						if (endLine - startLine === addedLineOffsets.length) for (var i = 0, len = addedLineOffsets.length; i < len; i++) lineOffsets[i + startLine + 1] = addedLineOffsets[i];
						else if (addedLineOffsets.length < 1e4) lineOffsets.splice.apply(lineOffsets, __spreadArray([startLine + 1, endLine - startLine], addedLineOffsets, false));
						else this._lineOffsets = lineOffsets = lineOffsets.slice(0, startLine + 1).concat(addedLineOffsets, lineOffsets.slice(endLine + 1));
						var diff = change.text.length - (endOffset - startOffset);
						if (diff !== 0) for (var i = startLine + 1 + addedLineOffsets.length, len = lineOffsets.length; i < len; i++) lineOffsets[i] = lineOffsets[i] + diff;
					} else if (FullTextDocument.isFull(change)) {
						this._content = change.text;
						this._lineOffsets = void 0;
					} else throw new Error("Unknown change event received");
				}
				this._version = version;
			};
			FullTextDocument.prototype.getLineOffsets = function() {
				if (this._lineOffsets === void 0) this._lineOffsets = computeLineOffsets(this._content, true);
				return this._lineOffsets;
			};
			FullTextDocument.prototype.positionAt = function(offset) {
				offset = Math.max(Math.min(offset, this._content.length), 0);
				var lineOffsets = this.getLineOffsets();
				var low = 0, high = lineOffsets.length;
				if (high === 0) return {
					line: 0,
					character: offset
				};
				while (low < high) {
					var mid = Math.floor((low + high) / 2);
					if (lineOffsets[mid] > offset) high = mid;
					else low = mid + 1;
				}
				var line = low - 1;
				offset = this.ensureBeforeEOL(offset, lineOffsets[line]);
				return {
					line,
					character: offset - lineOffsets[line]
				};
			};
			FullTextDocument.prototype.offsetAt = function(position) {
				var lineOffsets = this.getLineOffsets();
				if (position.line >= lineOffsets.length) return this._content.length;
				else if (position.line < 0) return 0;
				var lineOffset = lineOffsets[position.line];
				if (position.character <= 0) return lineOffset;
				var nextLineOffset = position.line + 1 < lineOffsets.length ? lineOffsets[position.line + 1] : this._content.length;
				var offset = Math.min(lineOffset + position.character, nextLineOffset);
				return this.ensureBeforeEOL(offset, lineOffset);
			};
			FullTextDocument.prototype.getLineRange = function(line) {
				var lineOffsets = this.getLineOffsets();
				if (line >= lineOffsets.length) {
					var lastLine = lineOffsets.length - 1;
					return {
						start: {
							line: lastLine,
							character: 0
						},
						end: {
							line: lastLine,
							character: this._content.length - lineOffsets[lastLine]
						}
					};
				} else if (line < 0) return {
					start: {
						line: 0,
						character: 0
					},
					end: {
						line: 0,
						character: 0
					}
				};
				var startOffset = lineOffsets[line];
				var nextLineOffset = line + 1 < lineOffsets.length ? lineOffsets[line + 1] : this._content.length;
				var endOffset = this.ensureBeforeEOL(nextLineOffset, startOffset);
				return {
					start: {
						line,
						character: 0
					},
					end: {
						line,
						character: endOffset - startOffset
					}
				};
			};
			FullTextDocument.prototype.getEOLCharacters = function(line) {
				var lineOffsets = this.getLineOffsets();
				if (line >= lineOffsets.length) return "";
				else if (line < 0) return "";
				var nextLineOffset = line + 1 < lineOffsets.length ? lineOffsets[line + 1] : this._content.length;
				var eolOffset = this.ensureBeforeEOL(nextLineOffset, lineOffsets[line]);
				return this._content.substring(eolOffset, nextLineOffset);
			};
			FullTextDocument.prototype.ensureBeforeEOL = function(offset, lineOffset) {
				while (offset > lineOffset && isEOL(this._content.charCodeAt(offset - 1))) offset--;
				return offset;
			};
			Object.defineProperty(FullTextDocument.prototype, "lineCount", {
				get: function() {
					return this.getLineOffsets().length;
				},
				enumerable: false,
				configurable: true
			});
			FullTextDocument.isIncremental = function(event) {
				var candidate = event;
				return candidate !== void 0 && candidate !== null && typeof candidate.text === "string" && candidate.range !== void 0 && (candidate.rangeLength === void 0 || typeof candidate.rangeLength === "number");
			};
			FullTextDocument.isFull = function(event) {
				var candidate = event;
				return candidate !== void 0 && candidate !== null && typeof candidate.text === "string" && candidate.range === void 0 && candidate.rangeLength === void 0;
			};
			return FullTextDocument;
		}();
		var TextDocument;
		(function(TextDocument) {
			/**
			* Creates a new text document.
			*
			* @param uri The document's uri.
			* @param languageId  The document's language Id.
			* @param version The document's initial version number.
			* @param content The document's content.
			*/
			function create(uri, languageId, version, content) {
				return new FullTextDocument(uri, languageId, version, content);
			}
			TextDocument.create = create;
			/**
			* Updates a TextDocument by modifying its content.
			*
			* @param document the document to update. Only documents created by TextDocument.create are valid inputs.
			* @param changes the changes to apply to the document.
			* @param version the changes version for the document.
			* @returns The updated TextDocument. Note: That's the same document instance passed in as first parameter.
			*
			*/
			function update(document, changes, version) {
				if (document instanceof FullTextDocument) {
					document.update(changes, version);
					return document;
				} else throw new Error("TextDocument.update: document must be created by TextDocument.create");
			}
			TextDocument.update = update;
			function applyEdits(document, edits) {
				var text = document.getText();
				var sortedEdits = mergeSort(edits.map(getWellformedEdit), function(a, b) {
					var diff = a.range.start.line - b.range.start.line;
					if (diff === 0) return a.range.start.character - b.range.start.character;
					return diff;
				});
				var lastModifiedOffset = 0;
				var spans = [];
				for (var _i = 0, sortedEdits_1 = sortedEdits; _i < sortedEdits_1.length; _i++) {
					var e = sortedEdits_1[_i];
					var startOffset = document.offsetAt(e.range.start);
					if (startOffset < lastModifiedOffset) throw new Error("Overlapping edit");
					else if (startOffset > lastModifiedOffset) spans.push(text.substring(lastModifiedOffset, startOffset));
					if (e.newText.length) spans.push(e.newText);
					lastModifiedOffset = document.offsetAt(e.range.end);
				}
				spans.push(text.substr(lastModifiedOffset));
				return spans.join("");
			}
			TextDocument.applyEdits = applyEdits;
		})(TextDocument || (exports$1.TextDocument = TextDocument = {}));
		function mergeSort(data, compare) {
			if (data.length <= 1) return data;
			var p = data.length / 2 | 0;
			var left = data.slice(0, p);
			var right = data.slice(p);
			mergeSort(left, compare);
			mergeSort(right, compare);
			var leftIdx = 0;
			var rightIdx = 0;
			var i = 0;
			while (leftIdx < left.length && rightIdx < right.length) if (compare(left[leftIdx], right[rightIdx]) <= 0) data[i++] = left[leftIdx++];
			else data[i++] = right[rightIdx++];
			while (leftIdx < left.length) data[i++] = left[leftIdx++];
			while (rightIdx < right.length) data[i++] = right[rightIdx++];
			return data;
		}
		function computeLineOffsets(text, isAtLineStart, textOffset) {
			if (textOffset === void 0) textOffset = 0;
			var result = isAtLineStart ? [textOffset] : [];
			for (var i = 0; i < text.length; i++) {
				var ch = text.charCodeAt(i);
				if (isEOL(ch)) {
					if (ch === 13 && i + 1 < text.length && text.charCodeAt(i + 1) === 10) i++;
					result.push(textOffset + i + 1);
				}
			}
			return result;
		}
		function isEOL(char) {
			return char === 13 || char === 10;
		}
		function getWellformedRange(range) {
			var start = range.start;
			var end = range.end;
			if (start.line > end.line || start.line === end.line && start.character > end.character) return {
				start: end,
				end: start
			};
			return range;
		}
		function getWellformedEdit(textEdit) {
			var range = getWellformedRange(textEdit.range);
			if (range !== textEdit.range) return {
				newText: textEdit.newText,
				range
			};
			return textEdit;
		}
	});
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/parserDirective.js
var require_parserDirective = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ParserDirective = void 0;
	var main_1 = require_main();
	var line_1 = require_line();
	var ParserDirective = class extends line_1.Line {
		constructor(document, range, nameRange, valueRange) {
			super(document, range);
			this.nameRange = nameRange;
			this.valueRange = valueRange;
		}
		toString() {
			return "# " + this.getName() + "=" + this.getValue();
		}
		getNameRange() {
			return this.nameRange;
		}
		getValueRange() {
			return this.valueRange;
		}
		getName() {
			return this.document.getText().substring(this.document.offsetAt(this.nameRange.start), this.document.offsetAt(this.nameRange.end));
		}
		getValue() {
			return this.document.getText().substring(this.document.offsetAt(this.valueRange.start), this.document.offsetAt(this.valueRange.end));
		}
		getDirective() {
			const directive = main_1.Directive[this.getName().toLowerCase()];
			return directive === void 0 ? null : directive;
		}
	};
	exports.ParserDirective = ParserDirective;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/heredoc.js
var require_heredoc = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Heredoc = void 0;
	/**
	* Heredoc represents a here-document that has been embedded in a
	* Dockerfile.
	*
	* This API is experimental and subject to change.
	*/
	var Heredoc = class {
		constructor(startRange, name, nameRange, contentRange, endRange) {
			this.startRange = startRange;
			this.name = name;
			this.nameRange = nameRange;
			this.contentRange = contentRange;
			this.endRange = endRange;
		}
		/**
		* Returns the name of the here-document.
		*
		* This API is experimental and subject to change.
		*/
		getName() {
			return this.name;
		}
		/**
		* Returns the range of the start operator and the name. If the
		* here-document is initialized with <<EOT then the start range would
		* encompass all five characters.
		*
		* This API is experimental and subject to change.
		*/
		getStartRange() {
			return this.startRange;
		}
		/**
		* Returns the range of this here-document's name that is declared at
		* the beginning of the here-document with the operator. If the
		* here-document is initialized with <<EOT then the name range would
		* encompass the latter three "EOT" characters.
		*
		* This API is experimental and subject to change.
		*/
		getNameRange() {
			return this.nameRange;
		}
		/**
		* Returns the range of the content of this here-document. This may
		* be null if the here-document has no content because:
		* - the start range is the only thing that was declared
		* - the end range was declared immediately and there is no content
		*
		* This API is experimental and subject to change.
		*/
		getContentRange() {
			return this.contentRange;
		}
		/**
		* Returns the range of the here-document's name on a line that
		* represents the end of the here-document.
		*
		* This API is experimental and subject to change.
		*/
		getDelimiterRange() {
			return this.endRange;
		}
	};
	exports.Heredoc = Heredoc;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/variable.js
var require_variable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Variable = void 0;
	var Variable = class {
		constructor(name, nameRange, range, modifier, modifierRange, substitutionParameter, substitutionRange, defined, buildVariable, stringValue) {
			this.name = name;
			this.nameRange = nameRange;
			this.range = range;
			this.modifier = modifier;
			this.modifierRange = modifierRange;
			this.substitutionParameter = substitutionParameter;
			this.substitutionRange = substitutionRange;
			this.defined = defined;
			this.buildVariable = buildVariable;
			this.stringValue = stringValue;
		}
		toString() {
			return this.stringValue;
		}
		getName() {
			return this.name;
		}
		getNameRange() {
			return this.nameRange;
		}
		/**
		* Returns the range of the entire variable. This includes the symbols for
		* the declaration of the variable such as the $, {, and } symbols.
		*
		* @return the range in the document that this variable encompasses in its
		*         entirety
		*/
		getRange() {
			return this.range;
		}
		/**
		* Returns the modifier character that has been set for
		* specifying how this variable should be expanded and resolved.
		* If this variable is ${variable:+value} then the modifier
		* character is '+'. Will be the empty string if the variable is
		* declared as ${variable:}. Otherwise, will be null if this
		* variable will not use variable substitution at all (such as
		* ${variable} or $variable).
		*
		* @return this variable's modifier character, or the empty
		*         string if it does not have one, or null if this
		*         variable will not use variable substitution
		*/
		getModifier() {
			return this.modifier;
		}
		getModifierRange() {
			return this.modifierRange;
		}
		/**
		* Returns the parameter that will be used for substitution if
		* this variable uses modifiers to define how its value should be
		* resolved. If this variable is ${variable:+value} then the
		* substitution value will be 'value'. Will be the empty string
		* if the variable is declared as ${variable:+} or some other
		* variant where the only thing that follows the modifier
		* character (excluding considerations of escape characters and
		* so on) is the variable's closing bracket. May be null if this
		* variable does not have a modifier character defined (such as
		* ${variable} or $variable).
		*
		* @return this variable's substitution parameter, or the empty
		*         string if it does not have one, or null if there is
		*         not one defined
		*/
		getSubstitutionParameter() {
			return this.substitutionParameter;
		}
		getSubstitutionRange() {
			return this.substitutionRange;
		}
		/**
		* Returns whether this variable has been defined or not.
		*
		* @return true if this variable has been defined, false otherwise
		*/
		isDefined() {
			return this.defined;
		}
		isBuildVariable() {
			return this.buildVariable === true;
		}
		isEnvironmentVariable() {
			return this.buildVariable === false;
		}
	};
	exports.Variable = Variable;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instruction.js
var require_instruction = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Instruction = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var util_1 = require_util();
	var line_1 = require_line();
	var argument_1 = require_argument();
	var heredoc_1 = require_heredoc();
	var variable_1 = require_variable();
	var main_1 = require_main();
	var Instruction = class extends line_1.Line {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range);
			this.dockerfile = dockerfile;
			this.escapeChar = escapeChar;
			this.instruction = instruction;
			this.instructionRange = instructionRange;
		}
		toString() {
			let value = this.getKeyword();
			for (let arg of this.getRawArguments()) {
				value += " ";
				value += arg.getValue();
			}
			return value;
		}
		getRangeContent(range) {
			if (range === null) return null;
			return this.document.getText().substring(this.document.offsetAt(range.start), this.document.offsetAt(range.end));
		}
		getInstructionRange() {
			return this.instructionRange;
		}
		getInstruction() {
			return this.instruction;
		}
		getKeyword() {
			return this.getInstruction().toUpperCase();
		}
		getArgumentsRange() {
			let args = this.getArguments();
			if (args.length === 0) return null;
			return vscode_languageserver_types_1.Range.create(args[0].getRange().start, args[args.length - 1].getRange().end);
		}
		getArgumentsRanges() {
			let args = this.getArguments();
			if (args.length === 0) return [];
			if (args[0].getRange().start.line === args[args.length - 1].getRange().end.line) return [vscode_languageserver_types_1.Range.create(args[0].getRange().start, args[args.length - 1].getRange().end)];
			let ranges = [];
			let end = -1;
			let startPosition = args[0].getRange().start;
			let range = this.getInstructionRange();
			let extra = this.document.offsetAt(startPosition) - this.document.offsetAt(range.start);
			let fullArgs = this.getTextContent().substring(extra, this.document.offsetAt(args[args.length - 1].getRange().end) - this.document.offsetAt(range.start));
			let offset = this.document.offsetAt(range.start) + extra;
			let comment = false;
			for (let i = 0; i < fullArgs.length; i++) {
				let char = fullArgs.charAt(i);
				if (char === this.escapeChar) {
					let next = fullArgs.charAt(i + 1);
					if (next === " " || next === "	") whitespaceCheck: for (let j = i + 2; j < fullArgs.length; j++) switch (fullArgs.charAt(j)) {
						case " ":
						case "	": continue;
						case "\r": j++;
						case "\n":
							if (startPosition !== null) ranges.push(vscode_languageserver_types_1.Range.create(startPosition, this.document.positionAt(offset + end + 1)));
							startPosition = null;
							comment = false;
							i = j;
							break whitespaceCheck;
						default: break whitespaceCheck;
					}
					else if (next === "\r") {
						if (startPosition !== null) {
							ranges.push(vscode_languageserver_types_1.Range.create(startPosition, this.document.positionAt(offset + end + 1)));
							startPosition = null;
						}
						comment = false;
						i += 2;
					} else if (next === "\n") {
						if (startPosition !== null) ranges.push(vscode_languageserver_types_1.Range.create(startPosition, this.document.positionAt(offset + end + 1)));
						startPosition = null;
						comment = false;
						i++;
					} else i++;
				} else if (util_1.Util.isNewline(char)) {
					if (comment) {
						startPosition = null;
						comment = false;
					}
				} else if (!comment) {
					if (startPosition === null) {
						if (char === "#") {
							comment = true;
							continue;
						}
						let position = this.document.positionAt(offset + i);
						if (position.character !== 0) startPosition = vscode_languageserver_types_1.Position.create(position.line, 0);
					}
					end = i;
				}
			}
			if (startPosition === null) ranges.push(vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + end), this.document.positionAt(offset + end + 1)));
			else ranges.push(vscode_languageserver_types_1.Range.create(startPosition, this.document.positionAt(offset + end + 1)));
			return ranges;
		}
		getRawArgumentsContent() {
			let args = this.getArguments();
			if (args.length === 0) return null;
			return this.getRangeContent(vscode_languageserver_types_1.Range.create(args[0].getRange().start, args[args.length - 1].getRange().end));
		}
		getArgumentsContent() {
			if (this.getArguments().length === 0) return null;
			let content = "";
			let ranges = this.getArgumentsRanges();
			let documentText = this.document.getText();
			for (let range of ranges) content += documentText.substring(this.document.offsetAt(range.start), this.document.offsetAt(range.end));
			return content;
		}
		getArguments() {
			return this.getRawArguments();
		}
		getRawArguments() {
			let args = [];
			let range = this.getInstructionRange();
			let extra = this.document.offsetAt(range.end) - this.document.offsetAt(range.start);
			let fullArgs = this.getTextContent().substring(extra);
			let offset = this.document.offsetAt(range.start) + extra;
			let start = false;
			let comment = false;
			let found = -1;
			let escapedWhitespaceDetected = false;
			let escaping = false;
			let escapeMarker = -1;
			let escapedArg = "";
			for (let i = 0; i < fullArgs.length; i++) {
				let char = fullArgs.charAt(i);
				if (util_1.Util.isWhitespace(char)) {
					if (escaping) {
						escapedWhitespaceDetected = true;
						if (util_1.Util.isNewline(char)) {
							escapedWhitespaceDetected = false;
							if (comment) {
								comment = false;
								start = true;
							}
						}
						continue;
					} else if (found !== -1) {
						if (escapeMarker === -1) args.push(new argument_1.Argument(escapedArg, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + found), this.document.positionAt(offset + i))));
						else args.push(new argument_1.Argument(escapedArg, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + found), this.document.positionAt(offset + escapeMarker))));
						escapeMarker = -1;
						escapedArg = "";
						found = -1;
					}
				} else if (char === this.escapeChar) {
					let next = fullArgs.charAt(i + 1);
					if (next === " " || next === "	") whitespaceCheck: for (let j = i + 2; j < fullArgs.length; j++) switch (fullArgs.charAt(j)) {
						case " ":
						case "	": continue;
						case "\r": j++;
						case "\n":
							comment = false;
							escaping = true;
							start = true;
							if (found !== -1) escapeMarker = i;
							i = j;
							break whitespaceCheck;
						default:
							escapeMarker = i;
							if (found === -1) i = j - 1;
							break whitespaceCheck;
					}
					else if (next === "\r") {
						comment = false;
						escaping = true;
						start = true;
						if (found !== -1 && escapeMarker === -1) escapeMarker = i;
						i += 2;
					} else if (next === "\n") {
						comment = false;
						escaping = true;
						start = true;
						if (found !== -1 && escapeMarker === -1) escapeMarker = i;
						i++;
					} else {
						if (escapedWhitespaceDetected && escapeMarker !== -1) {
							args.push(new argument_1.Argument(escapedArg, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + found), this.document.positionAt(offset + escapeMarker))));
							escapedArg = "";
							found = -1;
						}
						escapeMarker = -1;
						escapedWhitespaceDetected = false;
						escaping = false;
						if (next === "$") escapedArg = escapedArg + char + next;
						else if (next === "") break;
						else escapedArg = escapedArg + next;
						if (found === -1) found = i;
						i++;
					}
				} else if (!comment) {
					if (start && char === "#") comment = true;
					else {
						if (escapedWhitespaceDetected && escapeMarker !== -1) {
							args.push(new argument_1.Argument(escapedArg, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + found), this.document.positionAt(offset + escapeMarker))));
							escapedArg = "";
							found = -1;
						}
						escapedWhitespaceDetected = false;
						escaping = false;
						escapeMarker = -1;
						escapedArg = escapedArg + char;
						if (found === -1) found = i;
					}
					start = false;
				}
			}
			if (found !== -1) {
				if (escapeMarker === -1) args.push(new argument_1.Argument(escapedArg, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + found), this.document.positionAt(offset + fullArgs.length))));
				else args.push(new argument_1.Argument(escapedArg, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + found), this.document.positionAt(offset + escapeMarker))));
			}
			return args;
		}
		getExpandedArguments() {
			let args = this.getArguments();
			for (let i = 0; i < args.length; i++) {
				const argRange = args[i].getRange();
				let offset = this.document.offsetAt(argRange.start);
				const variables = this.parseVariables(offset, args[i].getValue());
				const swaps = [];
				let requiresExpansion = false;
				for (let variable of variables) {
					const value = this.dockerfile.resolveVariable(variable.getName(), variable.getNameRange().start.line);
					swaps.push(value);
					requiresExpansion = requiresExpansion || value !== void 0;
				}
				if (requiresExpansion) {
					let expanded = "";
					for (let j = 0; j < swaps.length; j++) {
						const variableRange = variables[j].getRange();
						const start = this.document.offsetAt(variableRange.start);
						const end = this.document.offsetAt(variableRange.end);
						if (swaps[j]) {
							expanded += this.document.getText().substring(offset, start);
							expanded += swaps[j];
							offset = end;
						} else {
							expanded += this.document.getText().substring(offset, end);
							offset = end;
						}
					}
					const argEnd = this.document.offsetAt(argRange.end);
					if (argEnd !== offset) expanded += this.document.getText().substring(offset, argEnd);
					args[i] = new argument_1.Argument(expanded, argRange);
				}
			}
			return args;
		}
		getVariables() {
			const variables = [];
			const args = this.getRawArguments();
			for (const arg of args) {
				let range = arg.getRange();
				let rawValue = this.document.getText().substring(this.document.offsetAt(range.start), this.document.offsetAt(range.end));
				const parsedVariables = this.parseVariables(this.document.offsetAt(arg.getRange().start), rawValue);
				for (const parsedVariable of parsedVariables) variables.push(parsedVariable);
			}
			return variables;
		}
		parseVariables(offset, arg) {
			let variables = [];
			variableLoop: for (let i = 0; i < arg.length; i++) switch (arg.charAt(i)) {
				case this.escapeChar:
					if (arg.charAt(i + 1) === "$") i++;
					break;
				case "$":
					if (arg.charAt(i + 1) === "{") {
						let escapedString = "${";
						let escapedName = "";
						let nameEnd = -1;
						let escapedSubstitutionParameter = "";
						let substitutionStart = -1;
						let substitutionEnd = -1;
						let modifierRead = -1;
						nameLoop: for (let j = i + 2; j < arg.length; j++) {
							let char = arg.charAt(j);
							switch (char) {
								case this.escapeChar:
									for (let k = j + 1; k < arg.length; k++) switch (arg.charAt(k)) {
										case " ":
										case "	":
										case "\r": continue;
										case "\n":
											j = k;
											continue nameLoop;
									}
									break;
								case "}":
									escapedString += "}";
									let modifier = null;
									let modifierRange = null;
									let substitutionParameter = modifierRead !== -1 ? escapedSubstitutionParameter : null;
									let substitutionRange = null;
									if (nameEnd === -1) nameEnd = j;
									else if (nameEnd + 1 === j) {
										modifier = "";
										modifierRange = vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + nameEnd + 1), this.document.positionAt(offset + nameEnd + 1));
									} else {
										if (substitutionStart === -1) {
											substitutionStart = modifierRead + 1;
											substitutionEnd = modifierRead + 1;
										} else substitutionEnd = substitutionEnd + 1;
										modifier = arg.substring(modifierRead, modifierRead + 1);
										modifierRange = vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + modifierRead), this.document.positionAt(offset + modifierRead + 1));
										substitutionRange = vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + substitutionStart), this.document.positionAt(offset + substitutionEnd));
									}
									let start = this.document.positionAt(offset + i);
									variables.push(new variable_1.Variable(escapedName, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + i + 2), this.document.positionAt(offset + nameEnd)), vscode_languageserver_types_1.Range.create(start, this.document.positionAt(offset + j + 1)), modifier, modifierRange, substitutionParameter, substitutionRange, this.dockerfile.resolveVariable(escapedName, start.line) !== void 0, this.isBuildVariable(escapedName, start.line), escapedString));
									i = j;
									continue variableLoop;
								case ":":
									if (nameEnd === -1) nameEnd = j;
									else if (modifierRead !== -1) {
										if (substitutionStart === -1) {
											substitutionStart = j;
											substitutionEnd = j;
										} else substitutionEnd = j;
										escapedSubstitutionParameter += ":";
									} else modifierRead = j;
									escapedString += ":";
									break;
								case "\n":
								case "\r":
								case " ":
								case "	": break;
								default:
									if (nameEnd === -1) escapedName += char;
									else if (modifierRead !== -1) {
										if (substitutionStart === -1) {
											substitutionStart = j;
											substitutionEnd = j;
										} else substitutionEnd = j;
										escapedSubstitutionParameter += char;
									} else modifierRead = j;
									escapedString += char;
							}
						}
						break variableLoop;
					} else if (util_1.Util.isWhitespace(arg.charAt(i + 1)) || i === arg.length - 1) continue;
					else {
						let escapedName = "";
						nameLoop: for (let j = i + 1; j < arg.length; j++) {
							let char = arg.charAt(j);
							switch (char) {
								case "\r":
								case "\n":
								case " ":
								case "	": continue;
								case "$":
								case "'":
								case "\"":
									let varStart = this.document.positionAt(offset + i);
									variables.push(new variable_1.Variable(escapedName, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + i + 1), this.document.positionAt(offset + j)), vscode_languageserver_types_1.Range.create(varStart, this.document.positionAt(offset + j)), null, null, null, null, this.dockerfile.resolveVariable(escapedName, varStart.line) !== void 0, this.isBuildVariable(escapedName, varStart.line), "$" + escapedName));
									i = j - 1;
									continue variableLoop;
								case this.escapeChar:
									for (let k = j + 1; k < arg.length; k++) switch (arg.charAt(k)) {
										case " ":
										case "	":
										case "\r": continue;
										case "\n":
											j = k;
											continue nameLoop;
									}
									let start = this.document.positionAt(offset + i);
									variables.push(new variable_1.Variable(escapedName, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + i + 1), this.document.positionAt(offset + j)), vscode_languageserver_types_1.Range.create(start, this.document.positionAt(offset + j)), null, null, null, null, this.dockerfile.resolveVariable(escapedName, start.line) !== void 0, this.isBuildVariable(escapedName, start.line), "$" + escapedName));
									break variableLoop;
							}
							if (char.match(/^[a-z0-9_]+$/i) === null) {
								let varStart = this.document.positionAt(offset + i);
								variables.push(new variable_1.Variable(escapedName, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + i + 1), this.document.positionAt(offset + j)), vscode_languageserver_types_1.Range.create(varStart, this.document.positionAt(offset + j)), null, null, null, null, this.dockerfile.resolveVariable(escapedName, varStart.line) !== void 0, this.isBuildVariable(escapedName, varStart.line), "$" + escapedName));
								i = j - 1;
								continue variableLoop;
							}
							escapedName += char;
						}
						let start = this.document.positionAt(offset + i);
						variables.push(new variable_1.Variable(escapedName, vscode_languageserver_types_1.Range.create(this.document.positionAt(offset + i + 1), this.document.positionAt(offset + arg.length)), vscode_languageserver_types_1.Range.create(start, this.document.positionAt(offset + arg.length)), null, null, null, null, this.dockerfile.resolveVariable(escapedName, start.line) !== void 0, this.isBuildVariable(escapedName, start.line), "$" + escapedName));
					}
					break variableLoop;
			}
			return variables;
		}
		isBuildVariable(variable, line) {
			if (this.getKeyword() === main_1.Keyword.FROM) {
				for (const initialArg of this.dockerfile.getInitialARGs()) {
					const property = initialArg.getProperty();
					if (property && variable === property.getName()) return true;
				}
				return;
			}
			let image = this.dockerfile.getContainingImage(vscode_languageserver_types_1.Position.create(line, 0));
			let envs = image.getENVs();
			for (let i = envs.length - 1; i >= 0; i--) if (envs[i].isBefore(line)) {
				for (let property of envs[i].getProperties()) if (property.getName() === variable) return false;
			}
			let args = image.getARGs();
			for (let i = args.length - 1; i >= 0; i--) if (args[i].isBefore(line)) {
				let property = args[i].getProperty();
				if (property && property.getName() === variable) return true;
			}
		}
		createSingleLineHeredocs(args) {
			const heredocs = [];
			for (const arg of args) {
				const value = arg.getValue();
				if (value.startsWith("<<") && util_1.Util.parseHeredocName(value) !== null) {
					const startRange = arg.getRange();
					const nameRange = this.getNameRange(startRange);
					const name = this.getName(nameRange);
					heredocs.push(new heredoc_1.Heredoc(startRange, name, nameRange, null, null));
				}
			}
			return heredocs;
		}
		getName(nameRange) {
			const content = this.document.getText(nameRange);
			let escaping = false;
			let name = "";
			nameLoop: for (let i = 0; i < content.length; i++) {
				const ch = content.charAt(i);
				switch (ch) {
					case this.escapeChar:
						escaping = true;
						for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
							case " ":
							case "	": break;
							case "\r":
								i = j + 1;
								continue nameLoop;
							case "\n":
								i = j;
								continue nameLoop;
							default:
								name += content.charAt(j);
								i = j;
								continue nameLoop;
						}
						break;
					case "#": if (escaping) for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
						case "\n":
							i = j;
							continue nameLoop;
					}
					case " ":
					case "	":
					case "\r":
					case "\n": if (escaping) break;
					default: name += ch;
				}
			}
			return name;
		}
		getNameRange(startRange) {
			const content = this.document.getText(startRange);
			let endFound = false;
			let searchHyphen = false;
			let start = -1;
			let end = -1;
			let escaping = false;
			let quote = null;
			contentLoop: for (let i = 0; i < content.length; i++) {
				const ch = content.charAt(i);
				switch (ch) {
					case "\"":
					case "'":
						if (quote === ch) break contentLoop;
						quote = ch;
						continue;
					case this.escapeChar:
						for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
							case "\n":
								escaping = true;
								j = i;
								continue contentLoop;
						}
						break;
					case " ":
					case "	":
					case "\r":
					case "\n": break;
					case "<":
						if (endFound) searchHyphen = true;
						else endFound = true;
						break;
					case "-": if (searchHyphen) {
						searchHyphen = false;
						break;
					}
					case "#": if (escaping) for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
						case "\n":
							i = j;
							continue contentLoop;
					}
					default:
						if (start === -1) start = i;
						if (quote !== null) {
							end = i + 1;
							break;
						}
						break contentLoop;
				}
			}
			if (start === -1) return vscode_languageserver_types_1.Range.create(startRange.end, startRange.end);
			const nameStart = this.document.positionAt(this.document.offsetAt(startRange.start) + start);
			const nameEnd = quote !== null ? this.document.positionAt(this.document.offsetAt(startRange.start) + end) : startRange.end;
			return vscode_languageserver_types_1.Range.create(nameStart, nameEnd);
		}
		getHeredocs() {
			const args = this.getArguments();
			if (args.length === 0) return [];
			const heredocs = [];
			const range = this.getRange();
			if (range.start.line === range.end.line) return this.createSingleLineHeredocs(args);
			const heredocDefinitions = [];
			let heredocsProcessed = false;
			let escaping = false;
			let contentStart = -1;
			let contentEnd = -1;
			let lineStart = -1;
			let currentHeredoc = 0;
			const startOffset = this.document.offsetAt(args[0].getRange().start);
			const content = this.getRangeContent(vscode_languageserver_types_1.Range.create(args[0].getRange().start, this.getRange().end));
			contentLoop: for (let i = 0; i < content.length; i++) switch (content.charAt(i)) {
				case this.escapeChar:
					escaping = true;
					for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
						case " ":
						case "	": break;
						case "\r": j++;
						case "\n":
							i = j;
							continue contentLoop;
						default:
							i = j;
							continue contentLoop;
					}
					break;
				case "\r": break;
				case "\n":
					if (escaping) break;
					if (heredocsProcessed) {
						if (contentStart === -1) contentStart = i;
						contentEnd = i;
						const arg = heredocDefinitions[currentHeredoc];
						const startRange = arg.getRange();
						const nameRange = this.getNameRange(startRange);
						const name = this.getName(nameRange);
						const delimiterRange = this.getDelimiterRange(arg, name, vscode_languageserver_types_1.Range.create(this.document.positionAt(startOffset + lineStart), this.document.positionAt(startOffset + i)));
						if (delimiterRange !== null) {
							const contentRange = vscode_languageserver_types_1.Range.create(this.document.positionAt(startOffset + contentStart), this.document.positionAt(startOffset + lineStart - 1));
							heredocs.push(new heredoc_1.Heredoc(startRange, name, nameRange, contentRange, delimiterRange));
							contentStart = -1;
							currentHeredoc++;
						}
						lineStart = -1;
					} else {
						const offsetLimit = startOffset + i;
						for (const arg of args) if (this.document.offsetAt(arg.getRange().start) < offsetLimit) {
							if (arg.getValue().startsWith("<<")) heredocDefinitions.push(arg);
						} else break;
						heredocsProcessed = true;
						lineStart = -1;
						continue contentLoop;
					}
					break;
				case " ":
				case "	": if (escaping) break;
				case "#": if (escaping) for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
					case "\n":
						i = j;
						continue contentLoop;
				}
				default:
					if (escaping) escaping = false;
					if (heredocsProcessed) {
						if (contentStart === -1) contentStart = i;
						if (lineStart === -1) lineStart = i;
					}
			}
			if (heredocsProcessed) {
				const arg = heredocDefinitions[currentHeredoc];
				const startRange = arg.getRange();
				const nameRange = this.getNameRange(startRange);
				const name = this.getName(nameRange);
				let contentRange = null;
				const delimiterRange = this.getDelimiterRange(arg, name, vscode_languageserver_types_1.Range.create(this.document.positionAt(startOffset + lineStart), range.end));
				if (delimiterRange === null) contentRange = vscode_languageserver_types_1.Range.create(this.document.positionAt(startOffset + contentStart), range.end);
				else if (contentEnd !== -1) contentRange = vscode_languageserver_types_1.Range.create(this.document.positionAt(startOffset + contentStart), this.document.positionAt(startOffset + contentEnd));
				heredocs.push(new heredoc_1.Heredoc(startRange, name, nameRange, contentRange, delimiterRange));
				currentHeredoc++;
				for (let i = currentHeredoc; i < heredocDefinitions.length; i++) {
					const startRange = heredocDefinitions[currentHeredoc].getRange();
					const nameRange = this.getNameRange(startRange);
					const name = this.getName(nameRange);
					heredocs.push(new heredoc_1.Heredoc(startRange, name, nameRange, null, null));
					currentHeredoc++;
				}
			} else return this.createSingleLineHeredocs(args);
			return heredocs;
		}
		getDelimiterRange(startArg, name, candidateRange) {
			const text = this.document.getText(candidateRange);
			if (startArg.getValue().startsWith("<<-")) {
				let index = 0;
				while (text.charAt(index) === "	") index++;
				if (text.substring(index) === name) return vscode_languageserver_types_1.Range.create(vscode_languageserver_types_1.Position.create(candidateRange.start.line, index), candidateRange.end);
				return null;
			}
			return text === name ? candidateRange : null;
		}
	};
	exports.Instruction = Instruction;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/flagOption.js
var require_flagOption = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.FlagOption = void 0;
	var FlagOption = class {
		constructor(range, name, nameRange, value, valueRange) {
			this.range = range;
			this.name = name;
			this.nameRange = nameRange;
			this.value = value;
			this.valueRange = valueRange;
		}
		toString() {
			if (this.valueRange !== null) return this.name + "=" + this.value;
			return this.name;
		}
		getRange() {
			return this.range;
		}
		getName() {
			return this.name;
		}
		getNameRange() {
			return this.nameRange;
		}
		getValue() {
			return this.value;
		}
		getValueRange() {
			return this.valueRange;
		}
	};
	exports.FlagOption = FlagOption;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/flag.js
var require_flag = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Flag = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var flagOption_1 = require_flagOption();
	var Flag = class {
		constructor(document, range, name, nameRange, value, valueRange) {
			this.options = [];
			this.range = range;
			this.name = name;
			this.nameRange = nameRange;
			this.value = value;
			this.valueRange = valueRange;
			if (this.value !== null) {
				let offset = document.offsetAt(valueRange.start);
				let nameStart = -1;
				let valueStart = -1;
				let hasOptions = false;
				for (let i = 0; i < value.length; i++) switch (value.charAt(i)) {
					case "=":
						hasOptions = true;
						if (valueStart === -1) {
							valueStart = i + 1;
							break;
						}
						break;
					case ",":
						this.options.push(this.createFlagOption(document, value, offset, nameStart, valueStart, i));
						nameStart = -1;
						valueStart = -1;
						break;
					default: if (nameStart === -1) nameStart = i;
				}
				if (hasOptions && nameStart !== -1) this.options.push(this.createFlagOption(document, value, offset, nameStart, valueStart, value.length));
			}
		}
		createFlagOption(document, content, documentOffset, nameStart, valueStart, valueEnd) {
			const optionRange = vscode_languageserver_types_1.Range.create(document.positionAt(documentOffset + nameStart), document.positionAt(documentOffset + valueEnd));
			if (valueStart === -1) return new flagOption_1.FlagOption(optionRange, content.substring(nameStart, valueEnd), optionRange, null, null);
			return new flagOption_1.FlagOption(optionRange, content.substring(nameStart, valueStart - 1), vscode_languageserver_types_1.Range.create(document.positionAt(documentOffset + nameStart), document.positionAt(documentOffset + valueStart - 1)), content.substring(valueStart, valueEnd), vscode_languageserver_types_1.Range.create(document.positionAt(documentOffset + valueStart), document.positionAt(documentOffset + valueEnd)));
		}
		toString() {
			if (this.valueRange) return "--" + this.name + "=" + this.value;
			return "--" + this.name;
		}
		/**
		* Returns the range that encompasses this entire flag. This includes the
		* -- prefix in the beginning to the last character of the flag's value (if
		* it has been defined).
		*
		* @return the entire range of this flag
		*/
		getRange() {
			return this.range;
		}
		/**
		* Returns the name of this flag. The name does not include the -- prefix.
		* Thus, for HEALTHCHECK's --interval flag, interval is the flag's name and
		* not --interval.
		*
		* @return this flag's name
		*/
		getName() {
			return this.name;
		}
		/**
		* Returns the range that encompasses the flag's name
		*
		* @return the range containing the flag's name
		*/
		getNameRange() {
			return this.nameRange;
		}
		/**
		* Returns the value that has been set to this flag. May be null if the
		* flag is invalid and has no value set like a --start-period. If the flag
		* is instead a --start-period= with an equals sign then the flag's value
		* is the empty string.
		*
		* @return this flag's value if it has been defined, null otherwise
		*/
		getValue() {
			return this.value;
		}
		/**
		* Returns the range that encompasses this flag's value. If no value has
		* been set then null will be returned.
		*
		* @return the range containing this flag's value, or null if the flag
		*         has no value defined
		*/
		getValueRange() {
			return this.valueRange;
		}
		getOption(name) {
			for (const option of this.options) if (option.getName() === name) return option;
			return null;
		}
		getOptions() {
			return this.options;
		}
		hasOptions() {
			return this.options.length > 0;
		}
	};
	exports.Flag = Flag;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/modifiableInstruction.js
var require_modifiableInstruction = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ModifiableInstruction = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var flag_1 = require_flag();
	var instruction_1 = require_instruction();
	var ModifiableInstruction = class extends instruction_1.Instruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		getFlags() {
			if (!this.flags) {
				this.flags = [];
				for (let arg of this.getArguments()) {
					let value = arg.getValue();
					if (this.stopSearchingForFlags(value)) return this.flags;
					else if (value.indexOf("--") === 0) {
						let range = arg.getRange();
						let rawValue = this.document.getText().substring(this.document.offsetAt(range.start), this.document.offsetAt(range.end));
						let nameIndex = value.indexOf("=");
						let index = rawValue.indexOf("=");
						let firstMatch = false;
						let secondMatch = false;
						let startIndex = -1;
						nameSearchLoop: for (let i = 0; i < rawValue.length; i++) switch (rawValue.charAt(i)) {
							case "\\":
							case " ":
							case "	":
							case "\r":
							case "\n": break;
							case "-":
								if (secondMatch) {
									startIndex = i;
									break nameSearchLoop;
								} else if (firstMatch) secondMatch = true;
								else firstMatch = true;
								break;
							default:
								startIndex = i;
								break nameSearchLoop;
						}
						let nameStart = this.document.positionAt(this.document.offsetAt(range.start) + startIndex);
						if (index === -1) this.flags.push(new flag_1.Flag(this.document, range, value.substring(2), vscode_languageserver_types_1.Range.create(nameStart, range.end), null, null));
						else if (index === value.length - 1) {
							let nameEnd = this.document.positionAt(this.document.offsetAt(range.start) + index);
							this.flags.push(new flag_1.Flag(this.document, range, value.substring(2, index), vscode_languageserver_types_1.Range.create(nameStart, nameEnd), "", vscode_languageserver_types_1.Range.create(range.end, range.end)));
						} else {
							let nameEnd = this.document.positionAt(this.document.offsetAt(range.start) + index);
							this.flags.push(new flag_1.Flag(this.document, range, value.substring(2, nameIndex), vscode_languageserver_types_1.Range.create(nameStart, nameEnd), value.substring(nameIndex + 1), vscode_languageserver_types_1.Range.create(this.document.positionAt(this.document.offsetAt(range.start) + index + 1), range.end)));
						}
					}
				}
			}
			return this.flags;
		}
		getArguments() {
			const args = super.getArguments();
			const flags = this.getFlags();
			if (flags.length === 0) return args;
			for (let i = 0; i < flags.length; i++) args.shift();
			return args;
		}
	};
	exports.ModifiableInstruction = ModifiableInstruction;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/jsonInstruction.js
var require_jsonInstruction = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.JSONInstruction = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var argument_1 = require_argument();
	var jsonArgument_1 = require_jsonArgument();
	var modifiableInstruction_1 = require_modifiableInstruction();
	var JSONInstruction = class extends modifiableInstruction_1.ModifiableInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
			this.openingBracket = null;
			this.closingBracket = null;
			this.jsonStrings = [];
			const argsContent = this.getRawArgumentsContent();
			if (argsContent === null) return;
			const args = this.getArguments();
			if (args.length === 1 && args[0].getValue() === "[]") {
				let argRange = args[0].getRange();
				this.openingBracket = new argument_1.Argument("[", vscode_languageserver_types_1.Range.create(argRange.start.line, argRange.start.character, argRange.start.line, argRange.start.character + 1));
				this.closingBracket = new argument_1.Argument("]", vscode_languageserver_types_1.Range.create(argRange.start.line, argRange.start.character + 1, argRange.end.line, argRange.end.character));
				return;
			} else if (args.length === 2 && args[0].getValue() === "[" && args[1].getValue() === "]") {
				this.openingBracket = args[0];
				this.closingBracket = args[1];
				return;
			}
			const argsOffset = document.offsetAt(this.getArgumentsRange().start);
			let start = -1;
			let last = "";
			let quoted = false;
			let escapedArg = "";
			argsCheck: for (let i = 0; i < argsContent.length; i++) {
				let char = argsContent.charAt(i);
				switch (char) {
					case "[":
						if (last === "") {
							this.openingBracket = new argument_1.Argument("[", vscode_languageserver_types_1.Range.create(document.positionAt(argsOffset + i), document.positionAt(argsOffset + i + 1)));
							last = "[";
						} else if (quoted) escapedArg = escapedArg + char;
						else break argsCheck;
						break;
					case "\"":
						if (last === "[" || last === ",") {
							start = i;
							quoted = true;
							last = "\"";
							escapedArg = escapedArg + char;
							continue;
						} else if (last === "\"") {
							if (quoted) {
								escapedArg = escapedArg + char;
								quoted = false;
								this.jsonStrings.push(new jsonArgument_1.JSONArgument(escapedArg, vscode_languageserver_types_1.Range.create(document.positionAt(argsOffset + start), document.positionAt(argsOffset + i + 1)), vscode_languageserver_types_1.Range.create(document.positionAt(argsOffset + start + 1), document.positionAt(argsOffset + i))));
								escapedArg = "";
							} else break argsCheck;
						} else break argsCheck;
						break;
					case ",":
						if (quoted) escapedArg = escapedArg + char;
						else if (last === "\"") last = ",";
						else break argsCheck;
						break;
					case "]":
						if (quoted) escapedArg = escapedArg + char;
						else if (last !== "") {
							this.closingBracket = new argument_1.Argument("]", vscode_languageserver_types_1.Range.create(document.positionAt(argsOffset + i), document.positionAt(argsOffset + i + 1)));
							break argsCheck;
						}
						break;
					case " ":
					case "	": break;
					case "\\":
						if (quoted) switch (argsContent.charAt(i + 1)) {
							case "\"":
							case "\\":
								escapedArg = escapedArg + argsContent.charAt(i + 1);
								i++;
								continue;
							case " ":
							case "	":
								escapeCheck: for (let j = i + 2; j < argsContent.length; j++) switch (argsContent.charAt(j)) {
									case "\r": j++;
									case "\n":
										i = j;
										continue argsCheck;
									case " ":
									case "	": break;
									default: break escapeCheck;
								}
								break;
							case "\r": i++;
							default:
								i++;
								continue;
						}
						else escapeCheck: for (let j = i + 1; j < argsContent.length; j++) switch (argsContent.charAt(j)) {
							case "\r": j++;
							case "\n":
								i = j;
								continue argsCheck;
							case " ":
							case "	": break;
							default: break escapeCheck;
						}
						break argsCheck;
					default:
						if (!quoted) break argsCheck;
						escapedArg = escapedArg + char;
				}
			}
		}
		stopSearchingForFlags(_value) {
			return true;
		}
		getOpeningBracket() {
			return this.openingBracket;
		}
		getJSONStrings() {
			return this.jsonStrings;
		}
		getClosingBracket() {
			return this.closingBracket;
		}
	};
	exports.JSONInstruction = JSONInstruction;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/add.js
var require_add = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Add = void 0;
	var jsonInstruction_1 = require_jsonInstruction();
	var Add = class extends jsonInstruction_1.JSONInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		stopSearchingForFlags(argument) {
			return argument.indexOf("--") === -1;
		}
	};
	exports.Add = Add;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/property.js
var require_property = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Property = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var util_1 = require_util();
	exports.Property = class Property {
		constructor(document, escapeChar, arg, arg2) {
			this.assignmentOperatorRange = null;
			this.assignmentOperator = null;
			this.valueRange = null;
			this.value = null;
			this.document = document;
			this.escapeChar = escapeChar;
			this.nameRange = Property.getNameRange(document, arg);
			let value = document.getText().substring(document.offsetAt(this.nameRange.start), document.offsetAt(this.nameRange.end));
			this.name = Property.getValue(value, escapeChar);
			if (arg2) {
				this.valueRange = arg2.getRange();
				value = document.getText().substring(document.offsetAt(this.valueRange.start), document.offsetAt(this.valueRange.end));
				this.value = Property.getValue(value, escapeChar);
				this.range = vscode_languageserver_types_1.Range.create(this.nameRange.start, this.valueRange.end);
			} else {
				let argRange = arg.getRange();
				if (this.nameRange.start.line === argRange.start.line && this.nameRange.start.character === argRange.start.character && this.nameRange.end.line === argRange.end.line && this.nameRange.end.character === argRange.end.character) {} else {
					this.valueRange = Property.getValueRange(document, arg);
					value = document.getText().substring(document.offsetAt(this.valueRange.start), document.offsetAt(this.valueRange.end));
					this.value = Property.getValue(value, escapeChar);
					this.assignmentOperatorRange = vscode_languageserver_types_1.Range.create(this.nameRange.end, this.valueRange.start);
					this.assignmentOperator = "=";
				}
				this.range = argRange;
			}
		}
		getRange() {
			return this.range;
		}
		getName() {
			return this.name;
		}
		getNameRange() {
			return this.nameRange;
		}
		getValue() {
			return this.value;
		}
		getValueRange() {
			return this.valueRange;
		}
		/**
		* Retrieves the operator used for delimiting between the name and
		* value of this property. This will either be the "=" character
		* or null if a character was not used or if this property has no
		* value defined.
		*/
		getAssignmentOperator() {
			return this.assignmentOperator;
		}
		getAssignmentOperatorRange() {
			return this.assignmentOperatorRange;
		}
		/**
		* Returns the value of this property including any enclosing
		* single or double quotes and relevant escape characters.
		* Escaped newlines and its associated contiguous whitespace
		* characters however will not be returned as they are deemed to
		* be uninteresting to clients trying to return a Dockerfile.
		*
		* @return the unescaped value of this property or null if this
		*         property has no associated value
		*/
		getUnescapedValue() {
			if (this.valueRange === null) return null;
			let escaped = false;
			let rawValue = "";
			let value = this.document.getText().substring(this.document.offsetAt(this.valueRange.start), this.document.offsetAt(this.valueRange.end));
			rawLoop: for (let i = 0; i < value.length; i++) {
				let char = value.charAt(i);
				switch (char) {
					case this.escapeChar:
						for (let j = i + 1; j < value.length; j++) switch (value.charAt(j)) {
							case "\r": j++;
							case "\n":
								escaped = true;
								i = j;
								continue rawLoop;
							case " ":
							case "	": break;
							default:
								rawValue = rawValue + char;
								continue rawLoop;
						}
						rawValue = rawValue + char;
						break;
					case "\r":
					case "\n": break;
					case " ":
					case "	":
						if (!escaped) rawValue = rawValue + char;
						break;
					case "#":
						if (escaped) for (let j = i + 1; j < value.length; j++) switch (value.charAt(j)) {
							case "\r": j++;
							case "\n":
								i = j;
								continue rawLoop;
						}
						else rawValue = rawValue + char;
						break;
					default:
						rawValue = rawValue + char;
						escaped = false;
				}
			}
			return rawValue;
		}
		static getNameRange(document, arg) {
			let value = arg.getValue();
			let index = value.indexOf("=");
			if (index !== -1) {
				let initial = value.charAt(0);
				let before = value.charAt(index - 1);
				if (initial === "\"" && before === "\"" || initial === "'" && before === "'" || initial !== "\"" && initial !== "'") return vscode_languageserver_types_1.Range.create(arg.getRange().start, document.positionAt(document.offsetAt(arg.getRange().start) + index));
			}
			return arg.getRange();
		}
		static getValueRange(document, arg) {
			return vscode_languageserver_types_1.Range.create(document.positionAt(document.offsetAt(arg.getRange().start) + arg.getValue().indexOf("=") + 1), document.positionAt(document.offsetAt(arg.getRange().end)));
		}
		/**
		* Returns the actual value of this key-value pair. The value will
		* have its escape characters removed if applicable. If the value
		* spans multiple lines and there are comments nested within the
		* lines, they too will be removed.
		*
		* @return the value that this key-value pair will actually be, may
		*         be null if no value is defined, may be the empty string
		*         if the value only consists of whitespace
		*/
		static getValue(value, escapeChar) {
			let escaped = false;
			const skip = util_1.Util.findLeadingNonWhitespace(value, escapeChar);
			if (skip !== 0 && value.charAt(skip) === "#") escaped = true;
			value = value.substring(skip);
			let first = value.charAt(0);
			let last = value.charAt(value.length - 1);
			let literal = first === "'" || first === "\"";
			let inSingle = first === "'" && last === "'";
			let inDouble = false;
			if (first === "\"") {
				for (let i = 1; i < value.length; i++) if (value.charAt(i) === escapeChar) i++;
				else if (value.charAt(i) === "\"" && i === value.length - 1) inDouble = true;
			}
			if (inSingle || inDouble) value = value.substring(1, value.length - 1);
			let commentCheck = -1;
			let escapedValue = "";
			parseValue: for (let i = 0; i < value.length; i++) {
				let char = value.charAt(i);
				switch (char) {
					case escapeChar:
						if (i + 1 === value.length) {
							escapedValue = escapedValue + escapeChar;
							break parseValue;
						}
						char = value.charAt(i + 1);
						if (char === " " || char === "	") whitespaceCheck: for (let j = i + 2; j < value.length; j++) {
							let char2 = value.charAt(j);
							switch (char2) {
								case " ":
								case "	": break;
								case "\r": j++;
								case "\n":
									escaped = true;
									i = j;
									continue parseValue;
								default:
									if (!inDouble && !inSingle && !literal) {
										if (char2 === escapeChar) {
											escapedValue = escapedValue + char;
											i = i + 1;
										} else {
											escapedValue = escapedValue + char + char2;
											i = j;
										}
										continue parseValue;
									}
									break whitespaceCheck;
							}
						}
						if (inDouble) {
							if (char === "\r") {
								escaped = true;
								i = i + 2;
							} else if (char === "\n") {
								escaped = true;
								i++;
							} else if (char !== "\"") {
								if (char === escapeChar) i++;
								escapedValue = escapedValue + escapeChar;
							}
							continue parseValue;
						} else if (inSingle || literal) {
							if (char === "\r") {
								escaped = true;
								i = i + 2;
							} else if (char === "\n") {
								escaped = true;
								i++;
							} else escapedValue = escapedValue + escapeChar;
							continue parseValue;
						} else if (char === escapeChar) {
							escapedValue = escapedValue + escapeChar;
							i++;
						} else if (char === "\r") {
							escaped = true;
							i = i + 2;
						} else if (char === "\n") {
							escaped = true;
							i++;
						} else {
							escapedValue = escapedValue + char;
							i++;
						}
						break;
					case " ":
					case "	":
						if (escaped && commentCheck === -1) commentCheck = i;
						escapedValue = escapedValue + char;
						break;
					case "\r": i++;
					case "\n":
						if (escaped && commentCheck !== -1) {
							escapedValue = escapedValue.substring(0, escapedValue.length - (i - commentCheck - 1));
							commentCheck = -1;
						}
						break;
					case "#": if (escaped) {
						if (commentCheck !== -1) {
							escapedValue = escapedValue.substring(0, escapedValue.length - (i - commentCheck));
							commentCheck = -1;
						}
						newlineCheck: for (let j = i + 1; j < value.length; j++) switch (value.charAt(j)) {
							case "\r": j++;
							case "\n":
								i = j;
								break newlineCheck;
						}
						continue parseValue;
					}
					default:
						if (escaped) {
							escaped = false;
							commentCheck = -1;
						}
						escapedValue = escapedValue + char;
				}
			}
			return escapedValue;
		}
	};
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/propertyInstruction.js
var require_propertyInstruction = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.PropertyInstruction = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var instruction_1 = require_instruction();
	var property_1 = require_property();
	var argument_1 = require_argument();
	var util_1 = require_util();
	var PropertyInstruction = class extends instruction_1.Instruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
			this.properties = void 0;
		}
		getProperties() {
			if (this.properties === void 0) {
				let args = this.getPropertyArguments();
				if (args.length === 0) this.properties = [];
				else if (args.length === 1) this.properties = [new property_1.Property(this.document, this.escapeChar, args[0])];
				else if (args.length === 2) {
					if (args[0].getValue().indexOf("=") === -1) this.properties = [new property_1.Property(this.document, this.escapeChar, args[0], args[1])];
					else this.properties = [new property_1.Property(this.document, this.escapeChar, args[0]), new property_1.Property(this.document, this.escapeChar, args[1])];
				} else if (args[0].getValue().indexOf("=") === -1) {
					let text = this.document.getText();
					let start = args[1].getRange().start;
					let end = args[args.length - 1].getRange().end;
					text = text.substring(this.document.offsetAt(start), this.document.offsetAt(end));
					this.properties = [new property_1.Property(this.document, this.escapeChar, args[0], new argument_1.Argument(text, vscode_languageserver_types_1.Range.create(args[1].getRange().start, args[args.length - 1].getRange().end)))];
				} else {
					this.properties = [];
					for (let i = 0; i < args.length; i++) this.properties.push(new property_1.Property(this.document, this.escapeChar, args[i]));
				}
			}
			return this.properties;
		}
		/**
		* Goes from the back of the string and returns the first
		* non-whitespace character that is found. If an escape character
		* is found with newline characters, the escape character will
		* not be considered a non-whitespace character and its index in
		* the string will not be returned.
		*
		* @param content the string to search through
		* @return the index in the string for the first non-whitespace
		*         character when searching from the end of the string
		*/
		findTrailingNonWhitespace(content) {
			let index = content.length;
			whitespaceCheck: for (let i = content.length - 1; i >= 0; i--) switch (content.charAt(i)) {
				case " ":
				case "	": continue;
				case "\n": if (content.charAt(i - 1) === "\r") i = i - 1;
				case "\r":
					newlineCheck: for (let j = i - 1; j >= 0; j--) switch (content.charAt(j)) {
						case " ":
						case "	":
						case "\r":
						case "\n":
						case this.escapeChar: continue;
						default:
							index = j;
							break newlineCheck;
					}
					break whitespaceCheck;
				default:
					index = i;
					break whitespaceCheck;
			}
			return index;
		}
		getPropertyArguments() {
			const args = [];
			let range = this.getInstructionRange();
			let instructionNameEndOffset = this.document.offsetAt(range.end);
			let extra = instructionNameEndOffset - this.document.offsetAt(range.start);
			let content = this.getTextContent();
			let fullArgs = content.substring(extra);
			let start = util_1.Util.findLeadingNonWhitespace(fullArgs, this.escapeChar);
			if (start === -1) return [];
			const startPosition = this.document.positionAt(instructionNameEndOffset + start);
			let escaped = range.start.line !== startPosition.line;
			let endingEscape = false;
			let mark = -1;
			let end = this.findTrailingNonWhitespace(fullArgs);
			content = fullArgs.substring(start, end + 1);
			let argStart = escaped ? -1 : 0;
			let spaced = false;
			argumentLoop: for (let i = 0; i < content.length; i++) {
				let char = content.charAt(i);
				switch (char) {
					case this.escapeChar:
						if (i + 1 === content.length) {
							endingEscape = true;
							break argumentLoop;
						}
						if (!escaped) mark = i;
						switch (content.charAt(i + 1)) {
							case " ":
							case "	":
								if (!util_1.Util.isWhitespace(content.charAt(i + 2))) {
									i = i + 1;
									continue argumentLoop;
								}
								whitespaceCheck: for (let j = i + 2; j < content.length; j++) switch (content.charAt(j)) {
									case "\r": j++;
									case "\n":
										escaped = true;
										i = j;
										continue argumentLoop;
									case " ":
									case "	": break;
									default:
										args.push(new argument_1.Argument(content.substring(argStart, i), vscode_languageserver_types_1.Range.create(this.document.positionAt(instructionNameEndOffset + start + argStart), this.document.positionAt(instructionNameEndOffset + start + i + 2))));
										argStart = j;
										break whitespaceCheck;
								}
								i = argStart - 1;
								continue argumentLoop;
							case "\r": i++;
							case "\n":
								escaped = true;
								i = i + 1;
								continue argumentLoop;
							case this.escapeChar:
								if (argStart === -1) argStart = i;
								i = i + 1;
								continue argumentLoop;
							default:
								if (argStart === -1) argStart = i;
								continue argumentLoop;
						}
					case "'":
					case "\"":
						if (spaced) {
							this.createSpacedArgument(argStart, args, content, mark, instructionNameEndOffset, start);
							argStart = i;
							spaced = false;
						}
						if (argStart === -1) argStart = i;
						for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
							case char:
								if (content.charAt(j + 1) !== " " && content.charAt(j + 1) !== "") {
									i = j;
									continue argumentLoop;
								}
								args.push(new argument_1.Argument(content.substring(argStart, j + 1), vscode_languageserver_types_1.Range.create(this.document.positionAt(instructionNameEndOffset + start + argStart), this.document.positionAt(instructionNameEndOffset + start + j + 1))));
								i = j;
								argStart = -1;
								continue argumentLoop;
							case this.escapeChar: j++;
						}
						break argumentLoop;
					case " ":
					case "	":
						if (escaped) {
							if (argStart !== -1) spaced = true;
						} else if (argStart !== -1) {
							args.push(new argument_1.Argument(content.substring(argStart, i), vscode_languageserver_types_1.Range.create(this.document.positionAt(instructionNameEndOffset + start + argStart), this.document.positionAt(instructionNameEndOffset + start + i))));
							argStart = -1;
						}
						break;
					case "\r": i++;
					case "\n":
						spaced = false;
						break;
					case "#":
						if (escaped) {
							for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
								case "\r": j++;
								case "\n":
									i = j;
									spaced = false;
									continue argumentLoop;
							}
							if (argStart !== -1) {
								let value = content.substring(argStart, mark);
								args.push(new argument_1.Argument(value, vscode_languageserver_types_1.Range.create(this.document.positionAt(instructionNameEndOffset + start + argStart), this.document.positionAt(instructionNameEndOffset + start + mark))));
								argStart = -1;
							}
							break argumentLoop;
						} else if (argStart === -1) argStart = i;
						break;
					default:
						if (spaced) {
							this.createSpacedArgument(argStart, args, content, mark, instructionNameEndOffset, start);
							argStart = i;
							spaced = false;
						}
						escaped = false;
						if (argStart === -1) argStart = i;
						if (char === "$" && content.charAt(i + 1) === "{") {
							let singleQuotes = false;
							let doubleQuotes = false;
							let escaped = false;
							for (let j = i + 1; j < content.length; j++) switch (content.charAt(j)) {
								case this.escapeChar:
									escaped = true;
									break;
								case "\r":
								case "\n": break;
								case "'":
									singleQuotes = !singleQuotes;
									escaped = false;
									break;
								case "\"":
									doubleQuotes = !doubleQuotes;
									escaped = false;
									break;
								case " ":
								case "	":
									if (escaped || singleQuotes || doubleQuotes) break;
									i = j - 1;
									continue argumentLoop;
								case "}":
									i = j;
									continue argumentLoop;
								default: escaped = false;
							}
							break argumentLoop;
						}
				}
			}
			if (argStart !== -1 && argStart !== content.length) {
				let end = endingEscape ? content.length - 1 : content.length;
				let value = content.substring(argStart, end);
				args.push(new argument_1.Argument(value, vscode_languageserver_types_1.Range.create(this.document.positionAt(instructionNameEndOffset + start + argStart), this.document.positionAt(instructionNameEndOffset + start + end))));
			}
			return args;
		}
		createSpacedArgument(argStart, args, content, mark, instructionNameEndOffset, start) {
			if (argStart !== -1) args.push(new argument_1.Argument(content.substring(argStart, mark), vscode_languageserver_types_1.Range.create(this.document.positionAt(instructionNameEndOffset + start + argStart), this.document.positionAt(instructionNameEndOffset + start + mark))));
		}
	};
	exports.PropertyInstruction = PropertyInstruction;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/arg.js
var require_arg = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Arg = void 0;
	var property_1 = require_property();
	var propertyInstruction_1 = require_propertyInstruction();
	var Arg = class extends propertyInstruction_1.PropertyInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
			this.property = null;
			const args = this.getPropertyArguments();
			if (args.length === 1) this.property = new property_1.Property(this.document, this.escapeChar, args[0]);
			else this.property = null;
		}
		/**
		* Returns the variable defined by this ARG. This may be null if
		* this ARG instruction is malformed and has no variable
		* declaration.
		*/
		getProperty() {
			return this.property;
		}
	};
	exports.Arg = Arg;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/cmd.js
var require_cmd = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Cmd = void 0;
	var jsonInstruction_1 = require_jsonInstruction();
	var Cmd = class extends jsonInstruction_1.JSONInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
	};
	exports.Cmd = Cmd;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/copy.js
var require_copy = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Copy = void 0;
	var jsonInstruction_1 = require_jsonInstruction();
	var Copy = class extends jsonInstruction_1.JSONInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		stopSearchingForFlags(argument) {
			return argument.indexOf("--") === -1;
		}
		getFromFlag() {
			let flags = super.getFlags();
			return flags.length === 1 && flags[0].getName() === "from" ? flags[0] : null;
		}
		/**
		* Returns there here-documents that are defined in this RUN
		* instruction.
		*
		* This API is experimental and subject to change.
		*/
		getHeredocs() {
			return super.getHeredocs();
		}
	};
	exports.Copy = Copy;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/env.js
var require_env = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Env = void 0;
	var propertyInstruction_1 = require_propertyInstruction();
	var Env = class extends propertyInstruction_1.PropertyInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		getProperties() {
			return super.getProperties();
		}
	};
	exports.Env = Env;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/entrypoint.js
var require_entrypoint = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Entrypoint = void 0;
	var jsonInstruction_1 = require_jsonInstruction();
	var Entrypoint = class extends jsonInstruction_1.JSONInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
	};
	exports.Entrypoint = Entrypoint;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/from.js
var require_from = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.From = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var modifiableInstruction_1 = require_modifiableInstruction();
	var From = class extends modifiableInstruction_1.ModifiableInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		stopSearchingForFlags(argument) {
			return argument.indexOf("--") === -1;
		}
		getImage() {
			const args = this.getArguments();
			return args.length > 0 ? args[0].getValue() : null;
		}
		/**
		* Returns the name of the image that will be used as the base image.
		*
		* @return the base image's name, or null if unspecified
		*/
		getImageName() {
			const imageName = this.getRangeContent(this.getImageNameRange());
			if (imageName === null) return null;
			let commented = false;
			let escaped = false;
			let name = "";
			for (let i = 0; i < imageName.length; i++) {
				const ch = imageName.charAt(i);
				switch (ch) {
					case this.escapeChar:
						escaped = true;
						break;
					case "\r": continue;
					case "\n":
						commented = false;
						break;
					case " ":
					case "	": break;
					case "#":
						if (escaped) commented = true;
						else {
							name = name + ch;
							escaped = false;
						}
						break;
					default: if (!commented) {
						name = name + ch;
						escaped = false;
					}
				}
			}
			return name;
		}
		/**
		* Returns the range that covers the name of the image used by
		* this instruction.
		*
		* @return the range of the name of this instruction's argument,
		*         or null if no image has been specified
		*/
		getImageNameRange() {
			let range = this.getImageRange();
			if (range) {
				let registryRange = this.getRegistryRange();
				if (registryRange) range.start = this.document.positionAt(this.document.offsetAt(registryRange.end) + 1);
				let tagRange = this.getImageTagRange();
				let digestRange = this.getImageDigestRange();
				if (tagRange === null) {
					if (digestRange !== null) range.end = this.document.positionAt(this.document.offsetAt(digestRange.start) - 1);
				} else range.end = this.document.positionAt(this.document.offsetAt(tagRange.start) - 1);
				return range;
			}
			return null;
		}
		/**
		* Returns the range that covers the image argument of this
		* instruction. This includes the tag or digest of the image if
		* it has been specified by the instruction.
		*
		* @return the range of the image argument, or null if no image
		*         has been specified
		*/
		getImageRange() {
			let args = this.getArguments();
			return args.length !== 0 ? args[0].getRange() : null;
		}
		getImageTag() {
			return this.getRangeContent(this.getImageTagRange());
		}
		/**
		* Returns the range in the document that the tag of the base
		* image encompasses.
		*
		* @return the base image's tag's range in the document, or null
		*         if no tag has been specified
		*/
		getImageTagRange() {
			const range = this.getImageRange();
			if (range) {
				const rangeStartOffset = this.document.offsetAt(range.start);
				const content = this.getRangeContent(range);
				const atIndex = this.indexOf(rangeStartOffset, content, "@");
				const slashIndex = content.indexOf("/");
				if (atIndex === -1) {
					const colonIndex = this.lastIndexOf(rangeStartOffset, content, ":");
					if (colonIndex > slashIndex) return vscode_languageserver_types_1.Range.create(this.document.positionAt(rangeStartOffset + colonIndex + 1), range.end);
				}
				const subcontent = content.substring(0, atIndex);
				const subcolonIndex = subcontent.indexOf(":");
				if (subcolonIndex === -1) return null;
				if (slashIndex === -1) return vscode_languageserver_types_1.Range.create(this.document.positionAt(rangeStartOffset + subcolonIndex + 1), this.document.positionAt(rangeStartOffset + atIndex));
				if (subcolonIndex < slashIndex) return null;
				return vscode_languageserver_types_1.Range.create(this.document.positionAt(rangeStartOffset + subcolonIndex + 1), this.document.positionAt(rangeStartOffset + subcontent.length));
			}
			return null;
		}
		getImageDigest() {
			return this.getRangeContent(this.getImageDigestRange());
		}
		/**
		* Returns the range in the document that the digest of the base
		* image encompasses.
		*
		* @return the base image's digest's range in the document, or null
		*         if no digest has been specified
		*/
		getImageDigestRange() {
			let range = this.getImageRange();
			if (range) {
				let content = this.getRangeContent(range);
				let index = this.lastIndexOf(this.document.offsetAt(range.start), content, "@");
				if (index !== -1) return vscode_languageserver_types_1.Range.create(range.start.line, range.start.character + index + 1, range.end.line, range.end.character);
			}
			return null;
		}
		indexOf(documentOffset, content, searchString) {
			let index = content.indexOf(searchString);
			const variables = this.getVariables();
			for (let i = 0; i < variables.length; i++) {
				const position = documentOffset + index;
				const variableRange = variables[i].getRange();
				if (this.document.offsetAt(variableRange.start) < position && position < this.document.offsetAt(variableRange.end)) {
					const offset = this.document.offsetAt(variableRange.end) - documentOffset;
					const subIndex = content.substring(offset).indexOf(searchString);
					if (subIndex === -1) return -1;
					index = subIndex + offset;
					i = -1;
					continue;
				}
			}
			return index;
		}
		lastIndexOf(documentOffset, content, searchString) {
			let index = content.lastIndexOf(searchString);
			const variables = this.getVariables();
			for (let i = 0; i < variables.length; i++) {
				const position = documentOffset + index;
				const variableRange = variables[i].getRange();
				if (this.document.offsetAt(variableRange.start) < position && position < this.document.offsetAt(variableRange.end)) {
					index = content.substring(0, index).lastIndexOf(searchString);
					if (index === -1) return -1;
					i = -1;
					continue;
				}
			}
			return index;
		}
		getRegistry() {
			return this.getRangeContent(this.getRegistryRange());
		}
		getRegistryRange() {
			const range = this.getImageRange();
			if (range) {
				const tagRange = this.getImageTagRange();
				const digestRange = this.getImageDigestRange();
				if (tagRange === null) {
					if (digestRange !== null) range.end = this.document.positionAt(this.document.offsetAt(digestRange.start) - 1);
				} else range.end = this.document.positionAt(this.document.offsetAt(tagRange.start) - 1);
				const content = this.getRangeContent(range);
				const rangeStart = this.document.offsetAt(range.start);
				const startingSlashIndex = this.indexOf(rangeStart, content, "/");
				if (startingSlashIndex === -1) return null;
				const portIndex = this.indexOf(rangeStart, content, ":");
				const dotIndex = this.indexOf(rangeStart, content, ".");
				if (portIndex !== -1 || dotIndex !== -1) return vscode_languageserver_types_1.Range.create(range.start, this.document.positionAt(rangeStart + startingSlashIndex));
				if (content.substring(0, startingSlashIndex) === "localhost") return vscode_languageserver_types_1.Range.create(range.start, this.document.positionAt(rangeStart + startingSlashIndex));
			}
			return null;
		}
		getBuildStage() {
			let range = this.getBuildStageRange();
			return range === null ? null : this.getRangeContent(range);
		}
		getBuildStageRange() {
			let args = this.getArguments();
			if (args.length > 2 && args[1].getValue().toUpperCase() === "AS") return args[2].getRange();
			return null;
		}
		getPlatformFlag() {
			let flags = super.getFlags();
			return flags.length === 1 && flags[0].getName() === "platform" ? flags[0] : null;
		}
	};
	exports.From = From;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/healthcheck.js
var require_healthcheck = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Healthcheck = void 0;
	var modifiableInstruction_1 = require_modifiableInstruction();
	var Healthcheck = class extends modifiableInstruction_1.ModifiableInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		stopSearchingForFlags(argument) {
			argument = argument.toUpperCase();
			return argument === "CMD" || argument === "NONE";
		}
		getSubcommand() {
			let args = this.getArguments();
			return args.length !== 0 ? args[0] : null;
		}
	};
	exports.Healthcheck = Healthcheck;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/label.js
var require_label = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Label = void 0;
	var propertyInstruction_1 = require_propertyInstruction();
	var util_1 = require_util();
	var Label = class extends propertyInstruction_1.PropertyInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		getVariables() {
			const variables = super.getVariables();
			const properties = this.getProperties();
			for (const property of properties) {
				const value = property.getUnescapedValue();
				if (value !== null && value.length > 2 && value.charAt(0) === "'" && value.charAt(value.length - 1) === "'") {
					const range = property.getValueRange();
					for (let i = 0; i < variables.length; i++) if (util_1.Util.isInsideRange(variables[i].getRange().start, range)) {
						variables.splice(i, 1);
						i--;
					}
				}
			}
			return variables;
		}
		getProperties() {
			return super.getProperties();
		}
	};
	exports.Label = Label;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/onbuild.js
var require_onbuild = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Onbuild = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var parser_1 = require_parser();
	var instruction_1 = require_instruction();
	var Onbuild = class extends instruction_1.Instruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		getTrigger() {
			let trigger = this.getTriggerWord();
			return trigger === null ? null : trigger.toUpperCase();
		}
		getTriggerWord() {
			return this.getRangeContent(this.getTriggerRange());
		}
		getTriggerRange() {
			let args = this.getArguments();
			return args.length > 0 ? args[0].getRange() : null;
		}
		getTriggerInstruction() {
			let triggerRange = this.getTriggerRange();
			if (triggerRange === null) return null;
			let args = this.getArguments();
			return parser_1.Parser.createInstruction(this.document, this.dockerfile, this.escapeChar, vscode_languageserver_types_1.Range.create(args[0].getRange().start, this.getRange().end), this.getTriggerWord(), triggerRange);
		}
	};
	exports.Onbuild = Onbuild;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/run.js
var require_run = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Run = void 0;
	var jsonInstruction_1 = require_jsonInstruction();
	var Run = class extends jsonInstruction_1.JSONInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		stopSearchingForFlags(argument) {
			return argument.indexOf("--") === -1;
		}
		/**
		* Returns there here-documents that are defined in this RUN
		* instruction.
		*
		* This API is experimental and subject to change.
		*/
		getHeredocs() {
			return super.getHeredocs();
		}
	};
	exports.Run = Run;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/shell.js
var require_shell = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Shell = void 0;
	var jsonInstruction_1 = require_jsonInstruction();
	var Shell = class extends jsonInstruction_1.JSONInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
	};
	exports.Shell = Shell;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/stopsignal.js
var require_stopsignal = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Stopsignal = void 0;
	var instruction_1 = require_instruction();
	var Stopsignal = class extends instruction_1.Instruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
	};
	exports.Stopsignal = Stopsignal;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/workdir.js
var require_workdir = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Workdir = void 0;
	var instruction_1 = require_instruction();
	var Workdir = class extends instruction_1.Instruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
		/**
		* Returns the path that has been defined. Note that this path may
		* be absolute or relative depending on what was written in the
		* instruction.
		*
		* @return the working directory's path, or null if this
		*         instruction has no arguments
		*/
		getPath() {
			return this.getArgumentsContent();
		}
		/**
		* Returns the absolute path that this instruction resolves to. The
		* function will inspect prior WORKDIR instructions in the current
		* image or another build stage in the Dockerfile to try to
		* determine this.
		*
		* @return the absolute path of the working directory, or null if
		*         this instruction has no arguments, or undefined if it
		*         cannot be determined because only relative paths could be
		*         found
		*/
		getAbsolutePath() {
			const path = this.getPath();
			if (path === null || path.startsWith("/")) return path;
			const startLine = this.getRange().start.line;
			const hierarchy = this.dockerfile.getStageHierarchy(startLine);
			for (let i = hierarchy.length - 1; i >= 0; i--) {
				const workdirs = hierarchy[i].getWORKDIRs();
				for (let j = workdirs.length - 1; j >= 0; j--) if (workdirs[j].getRange().start.line < startLine) {
					const parent = workdirs[j].getAbsolutePath();
					if (parent === void 0 || parent === null) return;
					return parent.endsWith("/") ? parent + path : parent + "/" + path;
				}
			}
		}
	};
	exports.Workdir = Workdir;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/user.js
var require_user = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.User = void 0;
	var instruction_1 = require_instruction();
	var User = class extends instruction_1.Instruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
	};
	exports.User = User;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/instructions/volume.js
var require_volume = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Volume = void 0;
	var jsonInstruction_1 = require_jsonInstruction();
	var Volume = class extends jsonInstruction_1.JSONInstruction {
		constructor(document, range, dockerfile, escapeChar, instruction, instructionRange) {
			super(document, range, dockerfile, escapeChar, instruction, instructionRange);
		}
	};
	exports.Volume = Volume;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/imageTemplate.js
var require_imageTemplate = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ImageTemplate = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var arg_1 = require_arg();
	var cmd_1 = require_cmd();
	var copy_1 = require_copy();
	var env_1 = require_env();
	var entrypoint_1 = require_entrypoint();
	var from_1 = require_from();
	var healthcheck_1 = require_healthcheck();
	var onbuild_1 = require_onbuild();
	var util_1 = require_util();
	var workdir_1 = require_workdir();
	var ImageTemplate = class {
		constructor() {
			this.comments = [];
			this.instructions = [];
		}
		addComment(comment) {
			this.comments.push(comment);
		}
		getComments() {
			return this.comments;
		}
		addInstruction(instruction) {
			this.instructions.push(instruction);
		}
		getInstructions() {
			return this.instructions;
		}
		getInstructionAt(line) {
			for (let instruction of this.instructions) if (util_1.Util.isInsideRange(vscode_languageserver_types_1.Position.create(line, 0), instruction.getRange())) return instruction;
			return null;
		}
		/**
		* Gets all the ARG instructions that are defined in this image.
		*/
		getARGs() {
			let args = [];
			for (let instruction of this.instructions) if (instruction instanceof arg_1.Arg) args.push(instruction);
			return args;
		}
		/**
		* Gets all the CMD instructions that are defined in this image.
		*/
		getCMDs() {
			let cmds = [];
			for (let instruction of this.instructions) if (instruction instanceof cmd_1.Cmd) cmds.push(instruction);
			return cmds;
		}
		/**
		* Gets all the COPY instructions that are defined in this image.
		*/
		getCOPYs() {
			let copies = [];
			for (let instruction of this.instructions) if (instruction instanceof copy_1.Copy) copies.push(instruction);
			return copies;
		}
		/**
		* Gets all the ENTRYPOINT instructions that are defined in this image.
		*/
		getENTRYPOINTs() {
			let froms = [];
			for (let instruction of this.instructions) if (instruction instanceof entrypoint_1.Entrypoint) froms.push(instruction);
			return froms;
		}
		/**
		* Gets all the ENV instructions that are defined in this image.
		*/
		getENVs() {
			let args = [];
			for (let instruction of this.instructions) if (instruction instanceof env_1.Env) args.push(instruction);
			return args;
		}
		getFROM() {
			for (const instruction of this.instructions) if (instruction instanceof from_1.From) return instruction;
			return null;
		}
		/**
		* Gets all the FROM instructions that are defined in this image.
		*/
		getFROMs() {
			let froms = [];
			for (let instruction of this.instructions) if (instruction instanceof from_1.From) froms.push(instruction);
			return froms;
		}
		/**
		* Gets all the HEALTHCHECK instructions that are defined in this image.
		*/
		getHEALTHCHECKs() {
			let froms = [];
			for (let instruction of this.instructions) if (instruction instanceof healthcheck_1.Healthcheck) froms.push(instruction);
			return froms;
		}
		getWORKDIRs() {
			const workdirs = [];
			for (const instruction of this.instructions) if (instruction instanceof workdir_1.Workdir) workdirs.push(instruction);
			return workdirs;
		}
		getOnbuildTriggers() {
			let triggers = [];
			for (let instruction of this.instructions) if (instruction instanceof onbuild_1.Onbuild) {
				let trigger = instruction.getTriggerInstruction();
				if (trigger) triggers.push(trigger);
			}
			return triggers;
		}
		getAvailableVariables(currentLine) {
			const variables = [];
			for (const arg of this.getARGs()) if (arg.isBefore(currentLine)) {
				const property = arg.getProperty();
				if (property) {
					const variable = property.getName();
					if (variables.indexOf(variable) === -1) variables.push(variable);
				}
			}
			for (const env of this.getENVs()) if (env.isBefore(currentLine)) for (const property of env.getProperties()) {
				const variable = property.getName();
				if (variables.indexOf(variable) === -1) variables.push(variable);
			}
			return variables;
		}
		/**
		* Resolves a variable with the given name at the specified line
		* to its value. If null is returned, then the variable has been
		* defined but no value was given. If undefined is returned, then
		* a variable with the given name has not been defined yet as of
		* the given line.
		*
		* @param variable the name of the variable to resolve
		* @param line the line number that the variable is on, zero-based
		* @return the value of the variable as defined by an ARG or ENV
		*         instruction, or null if no value has been specified, or
		*         undefined if a variable with the given name has not
		*         been defined
		*/
		resolveVariable(variable, line) {
			let envs = this.getENVs();
			for (let i = envs.length - 1; i >= 0; i--) if (envs[i].isBefore(line)) {
				for (let property of envs[i].getProperties()) if (property.getName() === variable) return property.getValue();
			}
			let args = this.getARGs();
			for (let i = args.length - 1; i >= 0; i--) if (args[i].isBefore(line)) {
				let property = args[i].getProperty();
				if (property && property.getName() === variable) return property.getValue();
			}
		}
		getRange() {
			const instructions = this.getInstructions();
			if (instructions.length === 0) return vscode_languageserver_types_1.Range.create(0, 0, 0, 0);
			const instructionStart = instructions[0].getRange().start;
			const instructionEnd = instructions[instructions.length - 1].getRange().end;
			return vscode_languageserver_types_1.Range.create(instructionStart, instructionEnd);
		}
		contains(position) {
			const range = this.getRange();
			if (range === null) return false;
			return util_1.Util.isInsideRange(position, range);
		}
	};
	exports.ImageTemplate = ImageTemplate;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/dockerfile.js
var require_dockerfile = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Dockerfile = void 0;
	var vscode_languageserver_types_1 = require_main$2();
	var ast = require_main();
	var imageTemplate_1 = require_imageTemplate();
	var from_1 = require_from();
	var util_1 = require_util();
	var main_1 = require_main();
	var Dockerfile = class extends imageTemplate_1.ImageTemplate {
		constructor(document) {
			super();
			this.initialInstructions = new imageTemplate_1.ImageTemplate();
			this.buildStages = [];
			this.directives = [];
			/**
			* Whether a FROM instruction has been added to this Dockerfile or not.
			*/
			this.foundFrom = false;
			this.document = document;
		}
		getEscapeCharacter() {
			for (const directive of this.directives) if (directive.getDirective() === ast.Directive.escape) {
				const value = directive.getValue();
				if (value === "\\" || value === "`") return value;
			}
			return "\\";
		}
		getInitialARGs() {
			return this.initialInstructions.getARGs();
		}
		getContainingImage(position) {
			let range = vscode_languageserver_types_1.Range.create(vscode_languageserver_types_1.Position.create(0, 0), this.document.positionAt(this.document.getText().length));
			if (!util_1.Util.isInsideRange(position, range)) return null;
			if (this.initialInstructions.getComments().length > 0 || this.initialInstructions.getInstructions().length > 0) {
				if (util_1.Util.isInsideRange(position, this.initialInstructions.getRange())) return this.initialInstructions;
			}
			for (const buildStage of this.buildStages) if (util_1.Util.isInsideRange(position, buildStage.getRange())) return buildStage;
			return this;
		}
		addInstruction(instruction) {
			if (instruction.getKeyword() === main_1.Keyword.FROM) {
				this.currentBuildStage = new imageTemplate_1.ImageTemplate();
				this.buildStages.push(this.currentBuildStage);
				this.foundFrom = true;
			} else if (!this.foundFrom) this.initialInstructions.addInstruction(instruction);
			if (this.foundFrom) this.currentBuildStage.addInstruction(instruction);
			super.addInstruction(instruction);
		}
		setDirectives(directives) {
			this.directives = directives;
		}
		getDirective() {
			return this.directives.length === 0 ? null : this.directives[0];
		}
		getDirectives() {
			return this.directives;
		}
		resolveVariable(variable, line) {
			for (let from of this.getFROMs()) {
				let range = from.getRange();
				if (range.start.line <= line && line <= range.end.line) {
					let initialARGs = new imageTemplate_1.ImageTemplate();
					for (let instruction of this.initialInstructions.getARGs()) initialARGs.addInstruction(instruction);
					return initialARGs.resolveVariable(variable, line);
				}
			}
			let image = this.getContainingImage(vscode_languageserver_types_1.Position.create(line, 0));
			if (image === null) return;
			let resolvedVariable = image.resolveVariable(variable, line);
			if (resolvedVariable === null) {
				let initialARGs = new imageTemplate_1.ImageTemplate();
				for (let instruction of this.initialInstructions.getARGs()) initialARGs.addInstruction(instruction);
				return initialARGs.resolveVariable(variable, line);
			}
			return resolvedVariable;
		}
		getAvailableVariables(currentLine) {
			if (this.getInstructionAt(currentLine) instanceof from_1.From) {
				let variables = [];
				for (let arg of this.getInitialARGs()) {
					let property = arg.getProperty();
					if (property) variables.push(property.getName());
				}
				return variables;
			}
			let image = this.getContainingImage(vscode_languageserver_types_1.Position.create(currentLine, 0));
			return image ? image.getAvailableVariables(currentLine) : [];
		}
		getParentStage(image) {
			const templateFrom = image.getFROM();
			const imageName = templateFrom === null ? null : templateFrom.getImageName();
			if (imageName === null) return null;
			for (const from of this.getFROMs()) if (from.getBuildStage() === imageName) {
				const range = from.getRange();
				if (range.start.line === templateFrom.getRange().start.line) return null;
				return this.getContainingImage(range.start);
			}
			return null;
		}
		getStageHierarchy(line) {
			const image = this.getContainingImage(vscode_languageserver_types_1.Position.create(line, 0));
			if (image === null) return [];
			const stages = [image];
			let stage = this.getParentStage(image);
			while (stage !== null) {
				stages.splice(0, 0, stage);
				stage = this.getParentStage(stage);
			}
			return stages;
		}
		getAvailableWorkingDirectories(line) {
			const availableDirectories = /* @__PURE__ */ new Set();
			for (const image of this.getStageHierarchy(line)) for (const workdir of image.getWORKDIRs()) if (workdir.getRange().end.line < line) {
				let directory = workdir.getAbsolutePath();
				if (directory !== void 0 && directory !== null) {
					if (!directory.endsWith("/")) directory += "/";
					availableDirectories.add(directory);
				}
			}
			return Array.from(availableDirectories);
		}
		/**
		* Internally reorganize the comments in the Dockerfile and allocate
		* them to the relevant build stages that they belong to.
		*/
		organizeComments() {
			const comments = this.getComments();
			for (let i = 0; i < comments.length; i++) if (util_1.Util.isInsideRange(comments[i].getRange().end, this.initialInstructions.getRange())) this.initialInstructions.addComment(comments[i]);
			else for (const buildStage of this.buildStages) if (util_1.Util.isInsideRange(comments[i].getRange().start, buildStage.getRange())) buildStage.addComment(comments[i]);
		}
		getRange() {
			const comments = this.getComments();
			const instructions = this.getInstructions();
			let range = null;
			if (comments.length === 0) {
				if (instructions.length > 0) range = vscode_languageserver_types_1.Range.create(instructions[0].getRange().start, instructions[instructions.length - 1].getRange().end);
			} else if (instructions.length === 0) range = vscode_languageserver_types_1.Range.create(comments[0].getRange().start, comments[comments.length - 1].getRange().end);
			else {
				const commentStart = comments[0].getRange().start;
				const commentEnd = comments[comments.length - 1].getRange().end;
				const instructionStart = instructions[0].getRange().start;
				const instructionEnd = instructions[instructions.length - 1].getRange().end;
				if (commentStart.line < instructionStart.line) {
					if (commentEnd.line < instructionEnd.line) range = vscode_languageserver_types_1.Range.create(commentStart, instructionEnd);
					range = vscode_languageserver_types_1.Range.create(commentStart, commentEnd);
				} else if (commentEnd.line < instructionEnd.line) range = vscode_languageserver_types_1.Range.create(instructionStart, instructionEnd);
				else range = vscode_languageserver_types_1.Range.create(instructionStart, commentEnd);
			}
			if (range === null) {
				if (this.directives.length === 0) return null;
				return this.directives[0].getRange();
			} else if (this.directives.length === 0) return range;
			return vscode_languageserver_types_1.Range.create(this.directives[0].getRange().start, range.end);
		}
	};
	exports.Dockerfile = Dockerfile;
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/parser.js
var require_parser = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Parser = void 0;
	var vscode_languageserver_textdocument_1 = require_main$1();
	var vscode_languageserver_types_1 = require_main$2();
	var comment_1 = require_comment();
	var parserDirective_1 = require_parserDirective();
	var instruction_1 = require_instruction();
	var add_1 = require_add();
	var arg_1 = require_arg();
	var cmd_1 = require_cmd();
	var copy_1 = require_copy();
	var env_1 = require_env();
	var entrypoint_1 = require_entrypoint();
	var from_1 = require_from();
	var healthcheck_1 = require_healthcheck();
	var label_1 = require_label();
	var onbuild_1 = require_onbuild();
	var run_1 = require_run();
	var shell_1 = require_shell();
	var stopsignal_1 = require_stopsignal();
	var workdir_1 = require_workdir();
	var user_1 = require_user();
	var volume_1 = require_volume();
	var dockerfile_1 = require_dockerfile();
	var util_1 = require_util();
	var main_1 = require_main();
	exports.Parser = class Parser {
		constructor() {
			this.escapeChar = null;
		}
		static createInstruction(document, dockerfile, escapeChar, lineRange, instruction, instructionRange) {
			switch (instruction.toUpperCase()) {
				case "ADD": return new add_1.Add(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "ARG": return new arg_1.Arg(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "CMD": return new cmd_1.Cmd(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "COPY": return new copy_1.Copy(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "ENTRYPOINT": return new entrypoint_1.Entrypoint(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "ENV": return new env_1.Env(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "FROM": return new from_1.From(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "HEALTHCHECK": return new healthcheck_1.Healthcheck(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "LABEL": return new label_1.Label(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "ONBUILD": return new onbuild_1.Onbuild(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "RUN": return new run_1.Run(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "SHELL": return new shell_1.Shell(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "STOPSIGNAL": return new stopsignal_1.Stopsignal(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "WORKDIR": return new workdir_1.Workdir(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "USER": return new user_1.User(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
				case "VOLUME": return new volume_1.Volume(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
			}
			return new instruction_1.Instruction(document, lineRange, dockerfile, escapeChar, instruction, instructionRange);
		}
		getParserDirectives(document, buffer) {
			const directives = [];
			this.escapeChar = "";
			const offset = util_1.Util.isUTF8BOM(buffer.substring(0, 1)) ? 1 : 0;
			directiveCheck: for (let i = offset; i < buffer.length; i++) switch (buffer.charAt(i)) {
				case " ":
				case "	": break;
				case "\r":
				case "\n": break directiveCheck;
				case "#":
					let directiveStart = -1;
					let directiveEnd = -1;
					for (let j = i + 1; j < buffer.length; j++) {
						let char = buffer.charAt(j);
						switch (char) {
							case " ":
							case "	":
								if (directiveStart !== -1 && directiveEnd === -1) directiveEnd = j;
								break;
							case "\r":
							case "\n": break directiveCheck;
							case "=":
								let valueStart = -1;
								let valueEnd = -1;
								if (directiveEnd === -1) directiveEnd = j;
								let lineEnd = buffer.length;
								directiveValue: for (let k = j + 1; k < buffer.length; k++) {
									char = buffer.charAt(k);
									switch (char) {
										case "\r":
										case "\n":
											if (valueStart !== -1 && valueEnd === -1) valueEnd = k;
											lineEnd = k;
											break directiveValue;
										case "	":
										case " ":
											if (valueStart !== -1 && valueEnd === -1) valueEnd = k;
											continue;
										default: if (valueStart === -1) valueStart = k;
									}
								}
								if (directiveStart === -1) break directiveCheck;
								if (valueStart === -1) {
									valueStart = j + 1;
									valueEnd = lineEnd;
								} else if (valueEnd === -1) valueEnd = buffer.length;
								const lineRange = vscode_languageserver_types_1.Range.create(document.positionAt(i), document.positionAt(lineEnd));
								const nameRange = vscode_languageserver_types_1.Range.create(document.positionAt(directiveStart), document.positionAt(directiveEnd));
								const valueRange = vscode_languageserver_types_1.Range.create(document.positionAt(valueStart), document.positionAt(valueEnd));
								directives.push(new parserDirective_1.ParserDirective(document, lineRange, nameRange, valueRange));
								directiveStart = -1;
								if (buffer.charAt(valueEnd) === "\r") i = valueEnd + 1;
								else i = valueEnd;
								continue directiveCheck;
							default: if (directiveStart === -1) directiveStart = j;
						}
					}
					break;
				default: break directiveCheck;
			}
			return directives;
		}
		parse(buffer) {
			this.document = vscode_languageserver_textdocument_1.TextDocument.create("", "", 0, buffer);
			this.buffer = buffer;
			let dockerfile = new dockerfile_1.Dockerfile(this.document);
			let directives = this.getParserDirectives(this.document, this.buffer);
			let offset = 0;
			this.escapeChar = "\\";
			if (directives.length > 0) {
				dockerfile.setDirectives(directives);
				this.escapeChar = dockerfile.getEscapeCharacter();
				offset = this.document.offsetAt(vscode_languageserver_types_1.Position.create(directives.length, 0));
			} else if (util_1.Util.isUTF8BOM(buffer.substring(0, 1))) offset = 1;
			for (let i = offset; i < this.buffer.length; i++) {
				const char = this.buffer.charAt(i);
				switch (char) {
					case " ":
					case "	":
					case "\r":
					case "\n": break;
					case "#":
						i = this.processComment(dockerfile, i);
						break;
					default: i = this.processInstruction(dockerfile, char, i);
				}
			}
			dockerfile.organizeComments();
			return dockerfile;
		}
		processInstruction(dockerfile, char, start) {
			let instruction = char;
			let instructionEnd = -1;
			let escapedInstruction = false;
			instructionCheck: for (let i = start + 1; i < this.buffer.length; i++) {
				char = this.buffer.charAt(i);
				switch (char) {
					case this.escapeChar:
						escapedInstruction = true;
						char = this.buffer.charAt(i + 1);
						if (char === "\r" || char === "\n") {
							if (instructionEnd === -1) instructionEnd = i;
							i++;
						} else if (char === " " || char === "	") {
							for (let j = i + 2; j < this.buffer.length; j++) switch (this.buffer.charAt(j)) {
								case " ":
								case "	": break;
								case "\r":
								case "\n":
									i = j;
									continue instructionCheck;
								default:
									instructionEnd = i + 1;
									instruction = instruction + this.escapeChar;
									i = j - 2;
									continue instructionCheck;
							}
							instructionEnd = i + 1;
							instruction = instruction + this.escapeChar;
							break instructionCheck;
						} else {
							instructionEnd = i + 1;
							instruction = instruction + this.escapeChar;
							escapedInstruction = false;
						}
						break;
					case " ":
					case "	":
						if (escapedInstruction) {
							escapeCheck: for (let j = i + 1; j < this.buffer.length; j++) switch (this.buffer.charAt(j)) {
								case " ":
								case "	": break;
								case "\r":
								case "\n":
									i = j;
									continue instructionCheck;
								default: break escapeCheck;
							}
							escapedInstruction = false;
						}
						if (instructionEnd === -1) instructionEnd = i;
						i = this.processArguments(dockerfile, instruction, instructionEnd, start, i);
						dockerfile.addInstruction(this.createInstruction(dockerfile, instruction, start, instructionEnd, i));
						return i;
					case "\r":
					case "\n":
						if (escapedInstruction) continue;
						if (instructionEnd === -1) instructionEnd = i;
						dockerfile.addInstruction(this.createInstruction(dockerfile, instruction, start, i, i));
						return i;
					case "#": if (escapedInstruction) continue;
					default:
						instructionEnd = i + 1;
						instruction = instruction + char;
						escapedInstruction = false;
				}
			}
			if (instructionEnd === -1) instructionEnd = this.buffer.length;
			dockerfile.addInstruction(this.createInstruction(dockerfile, instruction, start, instructionEnd, this.buffer.length));
			return this.buffer.length;
		}
		processHeredocs(instruction, offset) {
			let keyword = instruction.getKeyword();
			if (keyword === main_1.Keyword.ONBUILD) {
				instruction = instruction.getTriggerInstruction();
				if (instruction === null) return offset;
				keyword = instruction.getKeyword();
			}
			if (keyword !== main_1.Keyword.ADD && keyword !== main_1.Keyword.COPY && keyword !== main_1.Keyword.RUN) return offset;
			const heredocs = [];
			let tabbed = false;
			for (const arg of instruction.getArguments()) {
				const value = arg.getValue();
				if (value.startsWith("<<") && value.length > 2) {
					if (value.startsWith("<<-")) tabbed = true;
					const name = util_1.Util.parseHeredocName(value);
					if (name !== null) heredocs.push(name);
				}
			}
			if (heredocs.length > 0) for (const heredoc of heredocs) offset = this.parseHeredoc(heredoc, offset, tabbed);
			return offset;
		}
		processArguments(dockerfile, instruction, instructionEnd, start, offset) {
			let escaped = false;
			argumentsCheck: for (let i = offset + 1; i < this.buffer.length; i++) switch (this.buffer.charAt(i)) {
				case "\r":
				case "\n":
					if (escaped) continue;
					return this.processHeredocs(this.createInstruction(dockerfile, instruction, start, instructionEnd, i), i);
				case this.escapeChar:
					const next = this.buffer.charAt(i + 1);
					if (next === "\n" || next === "\r") {
						escaped = true;
						i++;
					} else if (next === " " || next === "	") {
						for (let j = i + 2; j < this.buffer.length; j++) switch (this.buffer.charAt(j)) {
							case " ":
							case "	": break;
							case "\r":
							case "\n": escaped = true;
							default:
								i = j;
								continue argumentsCheck;
						}
						return this.buffer.length;
					}
					continue;
				case "#":
					if (escaped) {
						i = this.processComment(dockerfile, i);
						continue argumentsCheck;
					}
					break;
				case " ":
				case "	": break;
				default: if (escaped) escaped = false;
			}
			return this.buffer.length;
		}
		processComment(dockerfile, start) {
			let end = this.buffer.length;
			commentLoop: for (let i = start + 1; i < this.buffer.length; i++) switch (this.buffer.charAt(i)) {
				case "\r":
				case "\n":
					end = i;
					break commentLoop;
			}
			const range = vscode_languageserver_types_1.Range.create(this.document.positionAt(start), this.document.positionAt(end));
			dockerfile.addComment(new comment_1.Comment(this.document, range));
			return end;
		}
		parseHeredoc(heredocName, offset, tabbed) {
			let startWord = -1;
			let lineStart = true;
			for (let i = offset; i < this.buffer.length; i++) switch (this.buffer.charAt(i)) {
				case " ":
					lineStart = false;
					break;
				case "	":
					if (!tabbed) lineStart = false;
					break;
				case "\r":
				case "\n":
					if (startWord !== -1 && heredocName === this.buffer.substring(startWord, i)) return i;
					startWord = -1;
					lineStart = true;
					break;
				default: if (lineStart) {
					startWord = i;
					lineStart = false;
				}
			}
			return this.buffer.length;
		}
		createInstruction(dockerfile, instruction, start, instructionEnd, end) {
			const startPosition = this.document.positionAt(start);
			const instructionRange = vscode_languageserver_types_1.Range.create(startPosition, this.document.positionAt(instructionEnd));
			const lineRange = vscode_languageserver_types_1.Range.create(startPosition, this.document.positionAt(end));
			return Parser.createInstruction(this.document, dockerfile, this.escapeChar, lineRange, instruction, instructionRange);
		}
	};
}));
//#endregion
//#region node_modules/dockerfile-ast/lib/main.js
var require_main = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.DockerfileParser = exports.DefaultVariables = exports.Directive = exports.Keyword = exports.Workdir = exports.Volume = exports.User = exports.Stopsignal = exports.Shell = exports.Run = exports.PropertyInstruction = exports.Onbuild = exports.ModifiableInstruction = exports.Label = exports.JSONInstruction = exports.Heredoc = exports.Healthcheck = exports.From = exports.Env = exports.Entrypoint = exports.Copy = exports.Cmd = exports.Arg = exports.Add = exports.Variable = exports.Property = exports.ParserDirective = exports.Line = exports.Instruction = exports.Flag = exports.Comment = exports.JSONArgument = exports.Argument = void 0;
	var argument_1 = require_argument();
	Object.defineProperty(exports, "Argument", {
		enumerable: true,
		get: function() {
			return argument_1.Argument;
		}
	});
	var jsonArgument_1 = require_jsonArgument();
	Object.defineProperty(exports, "JSONArgument", {
		enumerable: true,
		get: function() {
			return jsonArgument_1.JSONArgument;
		}
	});
	var comment_1 = require_comment();
	Object.defineProperty(exports, "Comment", {
		enumerable: true,
		get: function() {
			return comment_1.Comment;
		}
	});
	var parser_1 = require_parser();
	var flag_1 = require_flag();
	Object.defineProperty(exports, "Flag", {
		enumerable: true,
		get: function() {
			return flag_1.Flag;
		}
	});
	var instruction_1 = require_instruction();
	Object.defineProperty(exports, "Instruction", {
		enumerable: true,
		get: function() {
			return instruction_1.Instruction;
		}
	});
	var line_1 = require_line();
	Object.defineProperty(exports, "Line", {
		enumerable: true,
		get: function() {
			return line_1.Line;
		}
	});
	var parserDirective_1 = require_parserDirective();
	Object.defineProperty(exports, "ParserDirective", {
		enumerable: true,
		get: function() {
			return parserDirective_1.ParserDirective;
		}
	});
	var property_1 = require_property();
	Object.defineProperty(exports, "Property", {
		enumerable: true,
		get: function() {
			return property_1.Property;
		}
	});
	var variable_1 = require_variable();
	Object.defineProperty(exports, "Variable", {
		enumerable: true,
		get: function() {
			return variable_1.Variable;
		}
	});
	var add_1 = require_add();
	Object.defineProperty(exports, "Add", {
		enumerable: true,
		get: function() {
			return add_1.Add;
		}
	});
	var arg_1 = require_arg();
	Object.defineProperty(exports, "Arg", {
		enumerable: true,
		get: function() {
			return arg_1.Arg;
		}
	});
	var cmd_1 = require_cmd();
	Object.defineProperty(exports, "Cmd", {
		enumerable: true,
		get: function() {
			return cmd_1.Cmd;
		}
	});
	var copy_1 = require_copy();
	Object.defineProperty(exports, "Copy", {
		enumerable: true,
		get: function() {
			return copy_1.Copy;
		}
	});
	var entrypoint_1 = require_entrypoint();
	Object.defineProperty(exports, "Entrypoint", {
		enumerable: true,
		get: function() {
			return entrypoint_1.Entrypoint;
		}
	});
	var env_1 = require_env();
	Object.defineProperty(exports, "Env", {
		enumerable: true,
		get: function() {
			return env_1.Env;
		}
	});
	var from_1 = require_from();
	Object.defineProperty(exports, "From", {
		enumerable: true,
		get: function() {
			return from_1.From;
		}
	});
	var healthcheck_1 = require_healthcheck();
	Object.defineProperty(exports, "Healthcheck", {
		enumerable: true,
		get: function() {
			return healthcheck_1.Healthcheck;
		}
	});
	var heredoc_1 = require_heredoc();
	Object.defineProperty(exports, "Heredoc", {
		enumerable: true,
		get: function() {
			return heredoc_1.Heredoc;
		}
	});
	var jsonInstruction_1 = require_jsonInstruction();
	Object.defineProperty(exports, "JSONInstruction", {
		enumerable: true,
		get: function() {
			return jsonInstruction_1.JSONInstruction;
		}
	});
	var label_1 = require_label();
	Object.defineProperty(exports, "Label", {
		enumerable: true,
		get: function() {
			return label_1.Label;
		}
	});
	var modifiableInstruction_1 = require_modifiableInstruction();
	Object.defineProperty(exports, "ModifiableInstruction", {
		enumerable: true,
		get: function() {
			return modifiableInstruction_1.ModifiableInstruction;
		}
	});
	var onbuild_1 = require_onbuild();
	Object.defineProperty(exports, "Onbuild", {
		enumerable: true,
		get: function() {
			return onbuild_1.Onbuild;
		}
	});
	var propertyInstruction_1 = require_propertyInstruction();
	Object.defineProperty(exports, "PropertyInstruction", {
		enumerable: true,
		get: function() {
			return propertyInstruction_1.PropertyInstruction;
		}
	});
	var run_1 = require_run();
	Object.defineProperty(exports, "Run", {
		enumerable: true,
		get: function() {
			return run_1.Run;
		}
	});
	var shell_1 = require_shell();
	Object.defineProperty(exports, "Shell", {
		enumerable: true,
		get: function() {
			return shell_1.Shell;
		}
	});
	var stopsignal_1 = require_stopsignal();
	Object.defineProperty(exports, "Stopsignal", {
		enumerable: true,
		get: function() {
			return stopsignal_1.Stopsignal;
		}
	});
	var user_1 = require_user();
	Object.defineProperty(exports, "User", {
		enumerable: true,
		get: function() {
			return user_1.User;
		}
	});
	var volume_1 = require_volume();
	Object.defineProperty(exports, "Volume", {
		enumerable: true,
		get: function() {
			return volume_1.Volume;
		}
	});
	var workdir_1 = require_workdir();
	Object.defineProperty(exports, "Workdir", {
		enumerable: true,
		get: function() {
			return workdir_1.Workdir;
		}
	});
	var Keyword;
	(function(Keyword) {
		Keyword["ADD"] = "ADD";
		Keyword["ARG"] = "ARG";
		Keyword["CMD"] = "CMD";
		Keyword["COPY"] = "COPY";
		Keyword["ENTRYPOINT"] = "ENTRYPOINT";
		Keyword["ENV"] = "ENV";
		Keyword["EXPOSE"] = "EXPOSE";
		Keyword["FROM"] = "FROM";
		Keyword["HEALTHCHECK"] = "HEALTHCHECK";
		Keyword["LABEL"] = "LABEL";
		Keyword["MAINTAINER"] = "MAINTAINER";
		Keyword["ONBUILD"] = "ONBUILD";
		Keyword["RUN"] = "RUN";
		Keyword["SHELL"] = "SHELL";
		Keyword["STOPSIGNAL"] = "STOPSIGNAL";
		Keyword["USER"] = "USER";
		Keyword["VOLUME"] = "VOLUME";
		Keyword["WORKDIR"] = "WORKDIR";
	})(Keyword || (exports.Keyword = Keyword = {}));
	var Directive;
	(function(Directive) {
		Directive["escape"] = "escape";
		Directive["syntax"] = "syntax";
	})(Directive || (exports.Directive = Directive = {}));
	exports.DefaultVariables = [
		"ALL_PROXY",
		"all_proxy",
		"FTP_PROXY",
		"ftp_proxy",
		"HTTP_PROXY",
		"http_proxy",
		"HTTPS_PROXY",
		"https_proxy",
		"NO_PROXY",
		"no_proxy"
	];
	var DockerfileParser;
	(function(DockerfileParser) {
		function parse(content) {
			return new parser_1.Parser().parse(content);
		}
		DockerfileParser.parse = parse;
	})(DockerfileParser || (exports.DockerfileParser = DockerfileParser = {}));
}));
//#endregion
export { require_main as t };
