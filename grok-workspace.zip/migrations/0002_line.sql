create table if not exists partner_packet (
  row_id text primary key,
  packet_id text not null,
  from_side text not null,
  to_side text not null,
  re_id text not null,
  kind text not null,
  ttl text not null,
  keep_chat text not null,
  body text not null,
  next_step text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
