create table if not exists crew_seat (
  name text primary key,
  role text not null,
  joined_at timestamptz not null default now()
);

create table if not exists crew_note (
  id text primary key,
  name text not null,
  role text not null,
  kind text not null,
  body text not null,
  created_at timestamptz not null default now()
);
