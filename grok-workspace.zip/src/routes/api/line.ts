import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { addPacket, formatLine, formatPacket, listPackets } from "@/lib/quay/line";

const HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
};

function text(body: string, status = 200): Response {
  return new Response(`${body}\n`, {
    status,
    headers: { ...HEADERS, "Content-Type": "text/plain; charset=utf-8" },
  });
}

export const Route = createFileRoute("/api/line")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: HEADERS }),
      GET: async ({ request }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        try {
          return text(formatLine(await listPackets()));
        } catch {
          return text("The line did not open.", 502);
        }
      },
      POST: async ({ request }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        const raw = await request.text();
        try {
          const saved = await addPacket(raw);
          if ("error" in saved) return text(saved.error, 400);
          const packets = await listPackets();
          return text(`${formatPacket(saved)}\n\n${formatLine(packets)}`);
        } catch {
          return text("The line did not take that packet.", 502);
        }
      },
    },
  },
});
