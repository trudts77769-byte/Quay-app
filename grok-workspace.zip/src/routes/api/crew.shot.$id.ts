import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { readShot } from "@/lib/quay/form-crew";

export const Route = createFileRoute("/api/crew/shot/$id")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        const id = params.id.replace(/\.png$/i, "");
        const png = await readShot(id);
        if (!png) return new Response("Not found\n", { status: 404 });
        const bytes = Buffer.from(png, "base64");
        return new Response(bytes, {
          status: 200,
          headers: { "Content-Type": "image/png", "Cache-Control": "no-store", "X-Quay-Label": "real-screenshot" },
        });
      },
    },
  },
});
