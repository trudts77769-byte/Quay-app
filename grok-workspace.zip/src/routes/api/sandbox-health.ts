import { createFileRoute } from "@tanstack/react-router";
import { probeSandbox } from "@/lib/quay/browser-session";

const HEADERS = {
  "Cache-Control": "no-store",
  "Content-Type": "application/json; charset=utf-8",
};

export const Route = createFileRoute("/api/sandbox-health")({
  server: {
    handlers: {
      GET: async () => {
        const result = await probeSandbox();
        return new Response(JSON.stringify(result), { status: result.ok ? 200 : 503, headers: HEADERS });
      },
    },
  },
});
