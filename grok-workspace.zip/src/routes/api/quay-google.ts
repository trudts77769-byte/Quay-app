import { createFileRoute } from "@tanstack/react-router";
import { googleHomeHtml } from "@/lib/quay/google-home.server";

export const Route = createFileRoute("/api/quay-google")({
  server: {
    handlers: {
      GET: async () => {
        const html = await googleHomeHtml();
        return new Response(html, {
          headers: {
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "private, max-age=60",
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy":
              "script-src 'none'; object-src 'none'; base-uri https://www.google.com",
          },
        });
      },
    },
  },
});
