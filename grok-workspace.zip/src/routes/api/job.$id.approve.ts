import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { approveJob } from "@/lib/quay/job";

export const Route = createFileRoute("/api/job/$id/approve")({
  server: {
    handlers: {
      POST: async ({ request, params }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        return Response.json(await approveJob(params.id), { headers: { "Cache-Control": "no-store" } });
      },
    },
  },
});
