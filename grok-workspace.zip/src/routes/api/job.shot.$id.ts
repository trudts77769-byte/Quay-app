import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { readJobShot } from "@/lib/quay/job";

export const Route = createFileRoute("/api/job/shot/$id")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        const png = await readJobShot(params.id.replace(/\.png$/i, ""));
        if (!png) return new Response("Not found\n", { status: 404 });
        return new Response(Buffer.from(png, "base64"), {
          headers: {
            "Content-Type": "image/png",
            "Cache-Control": "no-store",
            "X-Quay-Label": "real-screenshot",
          },
        });
      },
    },
  },
});
