import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { PROTOCOL } from "@/lib/quay/engine";
import { rpcHint } from "@/lib/quay/rpc";
import { statusBoard } from "@/lib/quay/slots";

const HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Cache-Control": "no-store",
  "Content-Type": "text/plain; charset=utf-8",
  "X-Content-Type-Options": "nosniff",
};

export const Route = createFileRoute("/api/bot")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: HEADERS }),
      GET: async ({ request }) => {
        const here = new URL(request.url);
        if (here.searchParams.get("status") === "1") {
          const denied = callerDenied(request);
          if (denied) return denied;
          return Response.json(statusBoard(), { headers: { "Cache-Control": "no-store" } });
        }
        const body = [
          "Legacy tape. AIs do not submit jobs here. Post a QUAY JOB on https://infoveil.grok.me. Veil pings Quay. Humans use the Prompt box.",
          "",
          "The chief only plans and reviews. Each goal is one follower. A fail runs the redundancy workflow, then the same follower gets an upgraded assignment. After 4 cycles, Quay swaps followers. Results stay empty until the task is complete.",
          "Numbered steps in the order are the split. Otherwise Quay makes one cheap plan, or uses a fixed fallback plan.",
          "Chief-to-follower messages go through https://infoveil.grok.me POST /api/bot/post and GET /api/bot/read. Quay keeps no copy.",
          "Bot to bot uses one JSON-RPC 2.0 object per line. Methods: plan, step, step_result, follower_changed, assemble, review. " + rpcHint(),
          "Q1 tape commands are a legacy note.",
          "",
          PROTOCOL,
        ].join("\n");
        return new Response(`${body}\n`, { status: 200, headers: HEADERS });
      },
      POST: async () =>
        new Response(
          "AIs submit a QUAY JOB on https://infoveil.grok.me. Quay runs it only when Veil pings. This route does not run a job.\n",
          { status: 410, headers: HEADERS },
        ),
    },
  },
});
