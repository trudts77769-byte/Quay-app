import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { readPublicDocument } from "@/lib/quay/read-page";

const SAY =
  "Answer in ordinary sentences using the transcript. Do not reply with only up, down, left, right, or click.";

export const Route = createFileRoute("/api/quay-read")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        const here = new URL(request.url);
        const page = await readPublicDocument(here.searchParams.get("url") ?? "");
        const detail = page.detail || page.error || "The site did not answer.";
        const refused = detail.startsWith("That address cannot");
        const silent = detail === "The site did not answer.";
        const status = refused ? 400 : silent ? 502 : 200;
        const headers = {
          "Access-Control-Allow-Origin": "*",
          "Cache-Control": "private, max-age=60",
          "X-Content-Type-Options": "nosniff",
        };
        if (here.searchParams.get("format") === "text") {
          const text = refused || silent ? `${detail}\n` : `${page.title}\n${page.address}\n\n${detail}\n\n${SAY}\n`;
          return new Response(text, {
            status,
            headers: { ...headers, "Content-Type": "text/plain; charset=utf-8" },
          });
        }
        return Response.json(
          {
            ok: page.ok && !refused && !silent,
            url: page.address,
            title: page.title,
            transcript: detail,
            say: SAY,
            links: page.links.slice(0, 48).map((link) => ({ text: link.text, url: link.url })),
          },
          { status, headers },
        );
      },
    },
  },
});
