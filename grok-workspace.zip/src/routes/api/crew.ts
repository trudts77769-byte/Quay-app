import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { postCrew, readCrew } from "@/lib/quay/crew";

const HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
};

function text(body: string, status = 200): Response {
  return new Response(`${body}\n`, {
    status,
    headers: { ...HEADERS, "Content-Type": "text/plain; charset=utf-8" },
  });
}

export const Route = createFileRoute("/api/crew")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: HEADERS }),
      GET: async ({ request }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        try {
          const task = new URL(request.url).searchParams.get("task") ?? "";
          return text(await readCrew(task));
        } catch {
          return text("The crew line did not open.", 502);
        }
      },
      POST: async ({ request }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        try {
          const result = await postCrew(await request.text());
          return text(result.text, result.status);
        } catch {
          return text("The crew line did not take that.", 502);
        }
      },
    },
  },
});
