import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { createJob } from "@/lib/quay/job";

const HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Cache-Control": "no-store",
};

export const Route = createFileRoute("/api/job")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: HEADERS }),
      POST: async ({ request }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        let body: { url?: string; order?: string; values?: Record<string, unknown> } = {};
        try {
          body = (await request.json()) as typeof body;
        } catch {
          return Response.json({ error: "Send JSON with url, order, and values." }, { status: 400, headers: HEADERS });
        }
        const result = await createJob({ url: body.url ?? "", order: body.order ?? "", values: body.values });
        if ("error" in result) return Response.json(result, { status: 400, headers: HEADERS });
        return Response.json(result, { status: 202, headers: HEADERS });
      },
    },
  },
});
