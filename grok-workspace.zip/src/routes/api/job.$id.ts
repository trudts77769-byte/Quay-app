import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { readJob } from "@/lib/quay/job";

export const Route = createFileRoute("/api/job/$id")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        const job = await readJob(params.id);
        if (!job) return Response.json({ error: "No such job." }, { status: 404 });
        return Response.json(job, { headers: { "Cache-Control": "no-store" } });
      },
    },
  },
});
