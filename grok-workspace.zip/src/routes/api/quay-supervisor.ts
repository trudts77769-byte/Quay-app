import { createFileRoute } from "@tanstack/react-router";
import { quaySupervisorPlan, quaySupervisorStatus } from "@/lib/quay/supervisor";

const HEADERS = { "Cache-Control": "no-store", "Content-Type": "application/json; charset=utf-8" };

export const Route = createFileRoute("/api/quay-supervisor")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const job = url.searchParams.get("job") || "page";
        const task = url.searchParams.get("task") || "";
        return new Response(
          JSON.stringify({
            ok: true,
            status: quaySupervisorStatus(job),
            plan: quaySupervisorPlan(task || quaySupervisorStatus(job).task),
            operations: ["quay_supervisor_status", "quay_supervisor_plan"],
          }),
          { status: 200, headers: HEADERS },
        );
      },
    },
  },
});
