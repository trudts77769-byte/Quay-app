import { createFileRoute } from "@tanstack/react-router";
import { callerDenied } from "@/lib/quay/caller";
import { runAgent } from "@/lib/quay/agent";
import { formatAgent } from "@/lib/quay/agent-view";

const HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
};

async function answer(url: string, tape: string, format: string | null): Promise<Response> {
  const state = await runAgent({ url, tape });
  const refused = state.error.startsWith("That address cannot") || state.error.startsWith("Open a public");
  const status = refused ? 400 : state.ok ? 200 : 502;
  if (format === "text") {
    return new Response(`${formatAgent(state)}\n`, {
      status,
      headers: { ...HEADERS, "Content-Type": "text/plain; charset=utf-8" },
    });
  }
  return Response.json(state, { status, headers: HEADERS });
}

export const Route = createFileRoute("/api/quay-agent")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: HEADERS }),
      GET: async ({ request }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        const here = new URL(request.url);
        return answer(here.searchParams.get("url") ?? "", here.searchParams.get("tape") ?? "", here.searchParams.get("format"));
      },
      POST: async ({ request }) => {
        const denied = callerDenied(request);
        if (denied) return denied;
        let body: { url?: unknown; tape?: unknown; format?: unknown } = {};
        try {
          body = (await request.json()) as typeof body;
        } catch {
          body = {};
        }
        const format = typeof body.format === "string" ? body.format : null;
        const url = typeof body.url === "string" ? body.url : "";
        const tape = typeof body.tape === "string" ? body.tape : "";
        return answer(url, tape, format);
      },
    },
  },
});
