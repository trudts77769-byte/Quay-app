import { createFileRoute } from "@tanstack/react-router";
import { channelFromPing, wakeVeilChannel } from "@/lib/quay/veil-ping";

const HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "no-store",
  "Content-Type": "application/json; charset=utf-8",
  "X-Content-Type-Options": "nosniff",
};

function json(body: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export const Route = createFileRoute("/api/veil-ping")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: HEADERS }),
      GET: async () => json({ ok: false, error: "Quay does not watch Veil. POST a channel id." }, 405),
      POST: async ({ request }) => {
        const channel = await channelFromPing(request);
        if (!channel) return json({ ok: false, error: "Name the channel." }, 400);
        const result = await wakeVeilChannel(channel);
        return json(result.body, result.status);
      },
    },
  },
});
