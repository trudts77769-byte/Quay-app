import { createFileRoute } from "@tanstack/react-router";
import { QuayApp } from "@/components/quay/quay-app";

export const Route = createFileRoute("/")({ component: QuayApp });
