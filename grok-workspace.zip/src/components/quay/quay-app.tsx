import { useEffect, useRef, useState } from "react";
import {
  Archive,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  BookOpen,
  CircleCheck,
  Copy,
  DoorOpen,
  Globe,
  Lamp,
  Mail,
  Radar,
  Reply,
  RotateCcw,
  Search,
  Send,
  SquareTerminal,
  Trash2,
} from "lucide-react";
import { driveAgent } from "@/lib/quay/agent-drive";
import { planFromReply } from "@/lib/quay/agent";
import { steerWeb } from "@/lib/quay/hand";
import { deliverChiefPacket } from "@/lib/quay/veil-bot";
import {
  AGENT_HAND,
  agentPath,
  emptyAgent,
  formatAgent,
  tapeBetween,
  type AgentCell,
  type AgentState,
} from "@/lib/quay/agent-view";
import { driveMachine } from "@/lib/quay/drive";
import {
  briefFor,
  floorCaption,
  hotspotAt,
  hotspots,
  isGoogleHome,
  packetFor,
  parseCommands,
  PROTOCOL,
  toUrl,
  type Command,
  type Glyph,
  type Hotspot,
  type Machine,
  type Tone,
  type WebState,
} from "@/lib/quay/engine";
import { readPageBoard, readPageLink, runPageJob, listPageJobs, listFreeModels, readSharedSheet, saveSharedSheet, type PageRead, type PageStep } from "@/lib/quay/page-api";
import { useQuay, type Paper } from "@/lib/quay/store";

const GAP = 2;
const DAILY_LOOKS = 8;
const LOOKS_KEY = "quay-looks";
const SAMPLE = "https://selfdefenseartllc.com";

const ICONS: Record<Glyph, typeof Lamp> = {
  beacon: Lamp,
  terminal: SquareTerminal,
  ledger: BookOpen,
  hatch: DoorOpen,
  probe: Radar,
  status: CircleCheck,
  file: Archive,
  breaker: CircleCheck,
  check: CircleCheck,
  inbox: Mail,
  reply: Reply,
  send: Send,
  trash: Trash2,
  search: Search,
  page: Globe,
  key: Search,
  del: RotateCcw,
};

function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

function readLooks(): number {
  try {
    const raw = localStorage.getItem(LOOKS_KEY);
    if (!raw) return DAILY_LOOKS;
    const parsed = JSON.parse(raw) as { day?: string; left?: number };
    if (parsed.day !== todayKey() || typeof parsed.left !== "number") return DAILY_LOOKS;
    return Math.max(0, Math.min(DAILY_LOOKS, parsed.left));
  } catch {
    return DAILY_LOOKS;
  }
}

function writeLooks(left: number) {
  localStorage.setItem(LOOKS_KEY, JSON.stringify({ day: todayKey(), left }));
}

function plain(value: string): string {
  let current = value;
  for (let pass = 0; pass < 3; pass += 1) {
    const next = current
      .replace(/\u0026nbsp;/gi, " ")
      .replace(/\u0026quot;/gi, '"')
      .replace(/&#0*34;/g, '"')
      .replace(/\u0026apos;/gi, "'")
      .replace(/&#0*39;/g, "'")
      .replace(/\u0026amp;/gi, "&");
    if (next === current) return current;
    current = next;
  }
  return current;
}

function toneClass(tone: Tone, active: boolean): string {
  if (active) return "border-brass text-brass bg-raised";
  if (tone === "live" || tone === "done") return "border-brass/70 text-brass bg-surface";
  if (tone === "locked") return "border-line text-muted bg-bg";
  return "border-line text-fg bg-surface";
}

export function QuayApp() {
  const machines = useQuay((state) => state.machines);
  const activeId = useQuay((state) => state.activeId);
  const tape = useQuay((state) => state.tape);
  const trace = useQuay((state) => state.trace);
  const setActive = useQuay((state) => state.setActive);
  const setTape = useQuay((state) => state.setTape);
  const toggleLink = useQuay((state) => state.toggleLink);
  const link = useQuay((state) => state.link);
  const resetMachine = useQuay((state) => state.resetMachine);
  const applyTo = useQuay((state) => state.applyTo);
  const placeCursor = useQuay((state) => state.placeCursor);
  const pushTrace = useQuay((state) => state.pushTrace);
  const papers = useQuay((state) => state.papers);
  const savePaper = useQuay((state) => state.savePaper);
  const clearPapers = useQuay((state) => state.clearPapers);
  const noteReading = useQuay((state) => state.noteReading);
  const openAddress = useQuay((state) => state.openAddress);

  const machine = machines.find((item) => item.id === activeId) ?? machines[0];
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [asking, setAsking] = useState(false);
  const [looks, setLooks] = useState(DAILY_LOOKS);
  const [copied, setCopied] = useState(false);
  const [looked, setLooked] = useState(false);
  const [task, setTask] = useState("What does selfdefenseartllc.com offer, and how do I reach them?");
  const [gathering, setGathering] = useState(false);
  const [openPaper, setOpenPaper] = useState<number | null>(null);
  const [draft, setDraft] = useState("selfdefenseartllc.com");
  const [agentHref, setAgentHref] = useState(agentPath(SAMPLE));
  const [botHref, setBotHref] = useState("/api/bot");
  const [modelReply, setModelReply] = useState("");
  const [modelResult, setModelResult] = useState("");
  const [glass, setGlass] = useState<AgentState | null>(null);
  const [driving, setDriving] = useState(false);
  const [jobOrder, setJobOrder] = useState("What does selfdefenseartllc.com offer, and how do I reach them?");
  const [shared, setShared] = useState("");
  const sharedDirty = useRef(false);
  const [jobRunning, setJobRunning] = useState(false);
  const [jobSteps, setJobSteps] = useState<PageStep[]>([]);
  const [taskTrace, setTaskTrace] = useState<string[]>([]);
  const [taskId, setTaskId] = useState("");
  const [jobResult, setJobResult] = useState("");
  const [supervisorLine, setSupervisorLine] = useState("");
  const [jobCrew, setJobCrew] = useState("");
  const [jobNote, setJobNote] = useState("");
  const [jobLinks, setJobLinks] = useState<Record<string, string>>({});
  const [showGrid, setShowGrid] = useState(true);
  const [closePopups, setClosePopups] = useState(true);
  const [jobKeep, setJobKeep] = useState<1 | 24 | 0>(1);
  const [command, setCommand] = useState("");
  const [recent, setRecent] = useState<{ order: string; answer: string }[]>([]);
  const [copiedAnswer, setCopiedAnswer] = useState(false);
  const [single, setSingle] = useState(false);
  const [models, setModels] = useState<{ id: string; label: string; group: string; status: string }[]>([]);
  const [model, setModel] = useState("");
  const [report, setReport] = useState("");
  const [sandboxLive, setSandboxLive] = useState<{
    active: boolean;
    follower: string;
    step: number;
    action: string;
    actions: number;
    url: string;
    typing: string;
    scrolling: string;
    clickX: number;
    clickY: number;
  } | null>(null);
  const [copiedReport, setCopiedReport] = useState(false);
  const jobRunningRef = useRef(false);
  const openUrl = machine?.web?.url ?? "";
  const seenPages = useRef(new Set<string>());

  const playing = useRef(false);
  const queue = useRef<Command[]>([]);
  const timer = useRef<number | null>(null);
  const activeRef = useRef(activeId);
  activeRef.current = machine?.id ?? activeId;

  useEffect(() => {
    let cancel = false;
    void Promise.resolve(useQuay.persist.rehydrate()).then(() => {
      if (cancel) return;
      setLooks(readLooks());
      setReady(true);
    });
    return () => {
      cancel = true;
    };
  }, []);

  useEffect(() => {
    let cancel = false;
    void readSharedSheet()
      .then((row) => {
        if (cancel || sharedDirty.current) return;
        if (row?.text) setShared(row.text);
      })
      .catch(() => {});
    return () => {
      cancel = true;
    };
  }, []);

  useEffect(() => {
    if (!sharedDirty.current) return;
    const timer = window.setTimeout(() => {
      void saveSharedSheet({ data: { text: shared } }).catch(() => {});
    }, 400);
    return () => window.clearTimeout(timer);
  }, [shared]);

  useEffect(() => {
    const target = openUrl && !isGoogleHome(openUrl) ? openUrl : SAMPLE;
    const origin = window.location.origin;
    setAgentHref(`${origin}${agentPath(target)}`);
    setBotHref(`${origin}/api/bot`);
  }, [openUrl]);

  const stop = () => {
    queue.current = [];
    playing.current = false;
    setBusy(false);
    if (timer.current !== null) window.clearTimeout(timer.current);
  };

  useEffect(() => {
    queue.current = [];
    playing.current = false;
    setBusy(false);
    return () => {
      queue.current = [];
      playing.current = false;
      if (timer.current !== null) window.clearTimeout(timer.current);
    };
  }, [activeId]);

  const pump = useRef<() => void>(() => {});
  pump.current = () => {
    const command = queue.current.shift();
    if (!command) {
      playing.current = false;
      setBusy(false);
      return;
    }
    applyTo(activeRef.current, command);
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    timer.current = window.setTimeout(() => pump.current(), reduce ? 0 : 120);
  };

  const play = (commands: Command[]) => {
    if (commands.length === 0) return;
    queue.current.push(...commands);
    if (playing.current) return;
    playing.current = true;
    setBusy(true);
    pump.current();
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLTextAreaElement || target instanceof HTMLInputElement) return;
      if (playing.current) return;
      const map: Record<string, Command | undefined> = {
        ArrowUp: "up",
        ArrowDown: "down",
        ArrowLeft: "left",
        ArrowRight: "right",
      };
      const command = map[event.key];
      if (command) {
        event.preventDefault();
        applyTo(activeRef.current, command);
        return;
      }
      if (event.key === "Enter" && !(target instanceof HTMLButtonElement)) {
        event.preventDefault();
        applyTo(activeRef.current, "click");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [applyTo]);

  const pullRef = useRef<() => Promise<void>>(async () => {});
  jobRunningRef.current = jobRunning;
  useEffect(() => {
    if (!jobRunning) return;
    const timer = window.setInterval(() => void pullRef.current(), 1000);
    return () => window.clearInterval(timer);
  }, [jobRunning]);

  useEffect(() => {
    void listPageJobs()
      .then(setRecent)
      .catch(() => undefined);
    void listFreeModels()
      .then((rows) => {
        const list = Array.isArray(rows) ? rows : [];
        setModels(list);
        setModel((current) => current || list.find((item) => item.status !== "Key missing")?.id || "");
      })
      .catch(() => undefined);
  }, []);

  if (!machine) return null;

  const spots = hotspots(machine);
  const under = hotspotAt(machine, machine.cursor.c, machine.cursor.r);
  const captions = floorCaption(machine);

  const publish = (id: string, result: AgentState) => {
    setJobLinks({});
    setGlass(result);
    if (result.url && toUrl(result.url)) {
      openAddress(id, result.url);
      noteReading(id, result.url, result.title || "Page", result.transcript);
    }
    pushTrace(result.error || result.note || `Pointer at ${result.pointer.c},${result.pointer.r}`, result.error ? "warn" : "model");
  };

  const runWeb = async (script: string, url = "") => {
    if (driving) return;
    const fresh = Boolean(url);
    const open = url || glass?.url || "";
    if (!open) {
      pushTrace("Open a public site first.", "warn");
      return;
    }
    setDriving(true);
    const id = machine.id;
    try {
      const result = await driveAgent({
        data: {
          url: open,
          tape: script,
          column: fresh ? 0 : (glass?.pointer.c ?? 0),
          row: fresh ? 0 : (glass?.pointer.r ?? 0),
          scroll: fresh ? 0 : (glass?.scroll ?? 0),
          closePopups,
          task: jobOrder,
        },
      });
      publish(id, result);
    } catch {
      pushTrace("The browser did not answer. Try Open again.", "warn");
    } finally {
      setDriving(false);
    }
  };

  const openTyped = () => {
    const url = toUrl(draft);
    if (!url) {
      pushTrace("That address cannot be opened. Use a public site.", "warn");
      return;
    }
    void runWeb("", url);
  };

  const runModelReply = async () => {
    const plan = planFromReply(modelReply);
    if (!plan.tape && !plan.packet) {
      setModelResult("No TAPE line. The model must write one line like: TAPE: right click");
      return;
    }
    const open = glass?.url || toUrl(draft) || "";
    if (plan.tape && !open) {
      setModelResult("Open a public site first, then paste the model's reply.");
      return;
    }
    let page = glass;
    if (plan.tape && open) {
      setDriving(true);
      try {
        page = await driveAgent({
          data: {
            url: open,
            tape: plan.tape,
            column: glass?.pointer.c ?? 0,
            row: glass?.pointer.r ?? 0,
            scroll: glass?.scroll ?? 0,
            closePopups,
            task: jobOrder,
          },
        });
        publish(machine.id, page);
        setTape(plan.tape);
      } catch {
        setModelResult("The sandbox did not run that tape.");
        setDriving(false);
        return;
      }
      setDriving(false);
    }
    let veil = "";
    if (plan.packet) {
      try {
        veil = await deliverChiefPacket({ data: { packet: plan.packet } });
      } catch {
        veil = "Veil did not take that packet.";
      }
    }
    setModelResult(
      [
        "RESULT",
        page ? formatAgent(page) : "(The pointer did not move.)",
        veil ? `VEIL\n${veil}` : "",
        "Do not ask the person for another copy.",
      ]
        .filter(Boolean)
        .join("\n"),
    );
  };

  const runTape = () => {
    const parsed = parseCommands(tape, machine.kind === "web" ? 24 : 200);
    if (parsed.skipped.length) {
      pushTrace(`Skipped ${parsed.skipped.slice(0, 4).join(", ")}`, "warn");
    }
    if (parsed.commands.length === 0) {
      pushTrace("No controls in the tape. Use up, down, left, right, click.", "warn");
      return;
    }
    if (machine.kind === "web") {
      void runWeb(tape);
      return;
    }
    play(parsed.commands);
  };

  const stepOnce = () => {
    if (playing.current || driving) return;
    const parsed = parseCommands(tape);
    if (parsed.commands.length === 0) {
      pushTrace("The tape has no controls to step.", "warn");
      return;
    }
    if (machine.kind === "web") {
      void runWeb(parsed.commands[0]);
      setTape(parsed.commands.slice(1).join(" "));
      return;
    }
    applyTo(machine.id, parsed.commands[0]);
    setTape(parsed.commands.slice(1).join(" "));
  };

  const rehearse = () => {
    if (machine.kind === "web") {
      setDraft("selfdefenseartllc.com");
      void runWeb("", "https://selfdefenseartllc.com");
      return;
    }
    stop();
    resetMachine(machine.id);
    setTape(machine.rehearsal);
    const parsed = parseCommands(machine.rehearsal, 240);
    window.setTimeout(() => play(parsed.commands), 40);
  };

  const ask = async () => {
    if (asking || playing.current) return;
    if (looks <= 0) {
      pushTrace("No model looks left today. The tape still takes any model's words.", "warn");
      return;
    }
    link(machine.id);
    setAsking(true);
    try {
      const result = await driveMachine({
        data: {
          brief:
            machine.kind === "web"
              ? `${AGENT_HAND}\n\n${formatAgent(glass ?? emptyAgent())}`
              : briefFor(machine),
        },
      });
      if (!result.ok) {
        if (result.spent) {
          const left = Math.max(0, looks - 1);
          setLooks(left);
          writeLooks(left);
        }
        pushTrace(result.error, "warn");
        return;
      }
      const left = Math.max(0, looks - 1);
      setLooks(left);
      writeLooks(left);
      setLooked(true);
      setTape(result.commands);
      pushTrace(`Model → ${result.commands}`, "model");
      const parsed = parseCommands(result.commands);
      if (parsed.commands.length === 0) {
        pushTrace("That reply had no up, down, left, right, or click.", "warn");
        return;
      }
      if (parsed.skipped.length) {
        pushTrace(`Ignored extra words: ${parsed.skipped.slice(0, 3).join(", ")}`, "warn");
      }
      if (machine.kind === "web") {
        await runWeb(parsed.commands.join(" "));
        return;
      }
      play(parsed.commands);
    } catch {
      pushTrace("The model link did not answer. Try again, or paste a hand into the tape.", "warn");
    } finally {
      setAsking(false);
    }
  };

  const gather = async () => {
    if (gathering || asking) return;
    const job = task.trim();
    const url = toUrl(draft) || toUrl(glass?.url || "") || toUrl(machine.web?.address || "");
    if (!url) {
      pushTrace("Type a public site, then let the model drive the pointer.", "warn");
      return;
    }
    if (job.length < 2) {
      pushTrace("Tell the model what to find.", "warn");
      return;
    }
    if (looks <= 0) {
      pushTrace("No model looks left today.", "warn");
      return;
    }
    setGathering(true);
    try {
      const result = await steerWeb({ data: { url, goal: job } });
      if (result.spent) {
        const left = Math.max(0, looks - 1);
        setLooks(left);
        writeLooks(left);
      }
      if (!result.ok) {
        pushTrace(result.error, "warn");
        return;
      }
      publish(machine.id, result.state);
      setTape(result.tape);
      savePaper({
        task: job,
        text: `${result.answer}\n\nThe pointer ran: ${result.tape}`,
        sources: result.state.url ? [result.state.url] : [],
      });
      setOpenPaper(null);
      pushTrace(`Pointer ran ${result.tape}`, "model");
    } catch {
      pushTrace("The model did not get back from the web. Try again.", "warn");
    } finally {
      setGathering(false);
    }
  };

  const showRead = (page: PageRead) => {
    const links = page.links.slice(0, 48);
    const cells: AgentCell[] = links.map((link, index) => ({
      c: index % 8,
      r: Math.floor(index / 8),
      items: [{ label: link.text, kind: "link" }],
    }));
    const map: Record<string, string> = {};
    links.forEach((link, index) => {
      map[`${index % 8},${Math.floor(index / 8)}`] = link.url;
    });
    setJobLinks(map);
    setGlass((current) => ({
      ...(current ?? emptyAgent()),
      ok: true,
      error: "",
      url: page.url,
      title: page.title,
      transcript: page.transcript,
      cells,
      note: "",
    }));
    if (page.url) {
      openAddress(activeRef.current, page.url);
      noteReading(activeRef.current, page.url, page.title || "Page", page.transcript);
    }
  };

  const openRead = async (url: string) => {
    try {
      const page = await readPageLink({ data: { url } });
      showRead(page);
    } catch (error) {
      pushTrace(error instanceof Error ? error.message : "That page did not open.", "warn");
    }
  };

  const pullBoard = async () => {
    const board = await readPageBoard();
    setSandboxLive(board.sandbox);
    setTaskTrace(board.trace ?? []);
    setTaskId(board.taskId ?? "");
    if (board.shot) {
      setGlass((current) => ({
        ...(current ?? emptyAgent()),
        ok: true,
        error: "",
        shot: board.shot,
        url: board.page || current?.url || "",
      }));
    }
    if (board.page?.startsWith("http") && jobRunningRef.current) setDraft(board.page);
    if (board.note && jobRunningRef.current) setJobNote(board.note);
    try {
      const watch = await fetch("/api/quay-supervisor?job=page");
      const body = (await watch.json()) as { status?: { step?: number; next?: string; complete?: boolean } };
      const status = body.status;
      if (status) setSupervisorLine(`${status.complete ? "Complete" : "Step " + (status.step || 0)} · ${status.next || ""}`);
    } catch {
      /* the job result still shows */
    }
    setJobSteps(board.steps.filter((step) => step.fn && step.fn !== "job"));
    const fresh = board.steps.map((step) => step.page).find((page) => page.startsWith("http") && !seenPages.current.has(page));
    if (!fresh) return;
    seenPages.current.add(fresh);
    try {
      showRead(await readPageLink({ data: { url: fresh } }));
    } catch {
      /* the step list still shows the page */
    }
  };

  pullRef.current = pullBoard;

  const startJob = async () => {
    const order = jobOrder.trim();
    if (order.length < 2 || jobRunning) return;
    if (single && !model) return;
    setJobRunning(true);
    setJobResult("");
    setJobNote("Working");
    setJobCrew("");
    setReport("");
    seenPages.current.clear();
    try {
      const run = await runPageJob({ data: { order, keep: jobKeep, shared, model: single ? model : "" } });
      const crew = typeof run?.crew === "string" ? run.crew : "";
      const result = typeof run?.result === "string" ? run.result : "";
      const reads = Array.isArray(run?.reads) ? run.reads : [];
      setJobCrew(crew);
      setJobResult(result);
      setReport(typeof run?.report === "string" ? run.report : "");
      if (run?.status === 401 || run?.status === 503) setJobNote(result);
      if (reads[0]) showRead(reads[0]);
      for (const page of reads) seenPages.current.add(page.url);
      savePaper({ task: order, text: result, sources: reads.map((page) => page.url) });
      await pullRef.current();
      setRecent(await listPageJobs());
    } catch (error) {
      setJobNote(error instanceof Error ? error.message : "The job did not start.");
    } finally {
      setJobRunning(false);
    }
  };

  const copyBrief = async () => {
    const notes = papers
      .map((paper) => `TASK ${paper.task}\n${paper.text}\n${paper.sources.join("\n")}`)
      .join("\n\n");
    const body =
      machine.kind === "web"
        ? `${PROTOCOL}\n\n${formatAgent(glass ?? emptyAgent())}\n\nAGENT ${agentHref}`
        : packetFor(machine);
    const text = notes ? `${body}\n\nFILED NOTES\n${notes}` : body;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      pushTrace("Could not copy the brief from this browser. The reader link is still on the page.", "warn");
    }
  };

  const aim = (col: number, row: number) => {
    if (playing.current) return;
    const spot = hotspotAt(machine, col, row);
    const same = machine.cursor.c === col && machine.cursor.r === row;
    if (!same) placeCursor(machine.id, col, row);
    if (spot) applyTo(machine.id, "click");
  };

  const nudge = (command: Command) => {
    if (playing.current) return;
    applyTo(machine.id, command);
  };

  const append = (word: string) => setTape(tape.trim() ? `${tape.trim()} ${word}` : word);

  return (
    <main className="mx-auto flex min-h-screen w-full min-w-0 max-w-[100vw] flex-col gap-3 overflow-x-hidden px-3 py-3 box-border">
      <div className="grid w-full min-w-0 max-w-full items-start gap-3 lg:grid-cols-2">
        <div className="flex w-full min-w-0 max-w-full flex-col gap-3">
          <section aria-label="Prompt" className="w-full min-w-0 max-w-full">
            <p className="text-xs tracking-wide text-muted uppercase">Prompt</p>
            <textarea
              data-testid="job-order"
              value={jobOrder}
              onChange={(event) => setJobOrder(event.target.value)}
              aria-label="Prompt"
              spellCheck
              className="mt-2 min-h-28 w-full max-w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none focus-visible:border-brass"
            />
            <div className="mt-2 flex w-full min-w-0 max-w-full flex-wrap items-center gap-2">
              <button
                type="button"
                data-testid="job-run"
                className="tap min-h-11 rounded-2xl bg-brass px-4 text-sm text-ink disabled:opacity-40"
                onClick={() => void startJob()}
                disabled={jobRunning || jobOrder.trim().length < 2 || (single && (!model || models.find((item) => item.id === model)?.status === "Key missing"))}
              >
                {jobRunning ? "Running…" : "Run"}
              </button>
              <label className="flex min-h-11 items-center gap-2 text-sm text-fg">
                <input
                  type="checkbox"
                  data-testid="single-model"
                  checked={single}
                  onChange={(event) => setSingle(event.target.checked)}
                />
                Single Model Test
              </label>
            </div>
            {single ? (
              <select
                data-testid="model-pick"
                aria-label="Model"
                value={model}
                onChange={(event) => setModel(event.target.value)}
                className="mt-2 min-h-11 w-full max-w-full rounded-2xl border border-line bg-bg px-3 text-sm text-fg"
              >
                {(() => {
                  const groups: string[] = [];
                  for (const item of models) if (!groups.includes(item.group)) groups.push(item.group);
                  const dull = (status: string) => status === "Key missing" || status === "Quota hit" || status === "Failed";
                  return groups.map((group) => (
                    <optgroup key={group} label={group}>
                      {models
                        .filter((item) => item.group === group)
                        .map((item) => (
                          <option key={item.id} value={item.id} disabled={item.status === "Key missing"} style={dull(item.status) ? { color: "#8d887c" } : undefined}>
                            {item.label} · {item.status}
                          </option>
                        ))}
                    </optgroup>
                  ));
                })()}
              </select>
            ) : null}
          </section>
          <section aria-label="Shared instructions" className="w-full min-w-0 max-w-full">
            <p className="text-xs tracking-wide text-muted uppercase">Shared instructions</p>
            <textarea
              data-testid="shared-instructions"
              value={shared}
              onChange={(event) => {
                sharedDirty.current = true;
                setShared(event.target.value);
              }}
              aria-label="Shared instructions"
              spellCheck
              placeholder="Links and instructions for every follower. Not sent on Veil."
              className="mt-2 min-h-28 w-full max-w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none focus-visible:border-brass"
            />
          </section>
          <section aria-label="Results" className="w-full min-w-0 max-w-full">
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs tracking-wide text-muted uppercase">Results</p>
              <button
                type="button"
                className="tap min-h-11 rounded-2xl border border-line px-3 text-xs text-fg"
                onClick={() => {
                  const text = jobResult;
                  const done = () => {
                    setCopiedAnswer(true);
                    window.setTimeout(() => setCopiedAnswer(false), 1200);
                  };
                  const fallback = () => {
                    const area = document.createElement("textarea");
                    area.value = text;
                    area.setAttribute("readonly", "");
                    area.style.position = "fixed";
                    area.style.left = "-9999px";
                    document.body.appendChild(area);
                    area.select();
                    try {
                      document.execCommand("copy");
                    } catch {
                      /* the button stays enabled */
                    }
                    area.remove();
                    done();
                  };
                  if (navigator.clipboard?.writeText) {
                    void navigator.clipboard.writeText(text).then(done).catch(fallback);
                  } else fallback();
                }}
              >
                {copiedAnswer ? "Copied" : "Copy"}
              </button>
            </div>
            <p data-testid="job-result" className="wrap-any mt-2 min-h-16 w-full max-w-full whitespace-pre-wrap text-sm leading-6 text-fg">
              {jobResult}
            </p>
            {supervisorLine ? <p className="mt-1 text-xs text-muted">{supervisorLine}</p> : null}
            {report ? (
              <div className="mt-3 w-full min-w-0 max-w-full" data-testid="test-report">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs tracking-wide text-muted uppercase">Test report</p>
                  <button
                    type="button"
                    className="tap min-h-11 rounded-2xl border border-line px-3 text-xs text-fg"
                    onClick={() => {
                      const text = report;
                      const done = () => {
                        setCopiedReport(true);
                        window.setTimeout(() => setCopiedReport(false), 1200);
                      };
                      const fallback = () => {
                        const area = document.createElement("textarea");
                        area.value = text;
                        area.setAttribute("readonly", "");
                        area.style.position = "fixed";
                        area.style.left = "-9999px";
                        document.body.appendChild(area);
                        area.select();
                        try {
                          document.execCommand("copy");
                        } catch {
                          /* the button stays enabled */
                        }
                        area.remove();
                        done();
                      };
                      if (navigator.clipboard?.writeText) {
                        void navigator.clipboard.writeText(text).then(done).catch(fallback);
                      } else fallback();
                    }}
                  >
                    {copiedReport ? "Copied" : "Copy"}
                  </button>
                </div>
                <pre className="wrap-any mt-2 whitespace-pre-wrap text-sm leading-6 text-fg">{report}</pre>
              </div>
            ) : null}
            {jobNote ? <p className="mt-2 text-sm text-brass">{jobNote}</p> : null}
            <ol className="mt-3 flex w-full min-w-0 max-w-full flex-col gap-1" data-testid="job-monitor" aria-live="polite">
              {jobSteps.slice(-6).map((step) => (
                <li key={step.id || `${step.step}-${step.fn}`} className="wrap-any text-xs text-muted">
                  {step.step} {step.fn} · {step.follower || "waiting"} · {step.status}
                  {step.page ? ` · ${step.page}` : ""}
                </li>
              ))}
            </ol>
            {taskTrace.length > 0 ? (
              <ol data-testid="task-trace" className="mt-2 flex w-full min-w-0 max-w-full flex-col gap-1">
                {taskTrace.slice(-8).map((line) => (
                  <li key={line} className="wrap-any text-xs text-muted">
                    {line}
                  </li>
                ))}
              </ol>
            ) : null}
          </section>
        </div>
        <div className="flex w-full min-w-0 max-w-full flex-col gap-3">
          <section aria-label="Sandbox" className="w-full min-w-0 max-w-full overflow-hidden rounded-card border border-line bg-bg">
            {machine.kind === "web" && machine.web ? (
              <BrowserPane
                url={glass?.url || machine.web.url}
                typed={machine.web.address}
                draft={draft}
                ready={ready}
                driving={driving}
                shot=""
                page={false}
                onDraft={setDraft}
                onOpen={openTyped}
              />
            ) : null}
            {sandboxLive?.active ? (
              <div data-testid="sandbox-active" className="border-b border-line px-3 py-2 text-sm">
                <p className="text-xs tracking-wide text-brass uppercase">Sandbox active</p>
                {taskId ? <p className="wrap-any">Task: {taskId}</p> : null}
                <p className="wrap-any">Follower: {sandboxLive.follower || "…"}</p>
                <p className="wrap-any">Step: {sandboxLive.step}</p>
                <p className="wrap-any">Action: {sandboxLive.action || "…"}</p>
                <p>Interactive actions: {sandboxLive.actions}</p>
                <p className="wrap-any text-xs text-brass">{sandboxLive.url}</p>
                {sandboxLive.typing ? <p className="wrap-any">Typing in: {sandboxLive.typing}</p> : null}
                {sandboxLive.scrolling ? <p>{sandboxLive.scrolling}</p> : null}
              </div>
            ) : null}
            <div className="relative aspect-[3/4] w-full max-w-full">
              {glass?.shot ? (
                <img
                  src={`data:image/jpeg;base64,${glass.shot}`}
                  alt="The page the pointer is on"
                  className="absolute inset-0 h-full w-full object-contain object-top"
                />
              ) : null}
              {sandboxLive?.active && sandboxLive.action.startsWith("CLICK") && sandboxLive.clickX > 0 ? (
                <span
                  data-testid="sandbox-click"
                  className="pointer-events-none absolute z-10 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-brass bg-brass/50"
                  style={{ left: `${sandboxLive.clickX}%`, top: `${sandboxLive.clickY}%` }}
                />
              ) : null}
              <div
                className="absolute inset-0 grid"
                style={{
                  gridTemplateColumns: "repeat(8, minmax(0, 1fr))",
                  gridTemplateRows: "repeat(32, minmax(0, 1fr))",
                  gap: 0,
                  display: showGrid ? "grid" : "none",
                }}
              >
              {Array.from({ length: 8 * 32 }, (_, index) => {
                const col = index % 8;
                const row = Math.floor(index / 8);
                const active = (glass?.pointer.c ?? 0) === col && (glass?.pointer.r ?? 0) === row;
                return (
                  <button
                    key={`${col}-${row}`}
                    type="button"
                    aria-label={`Column ${col}, row ${row}`}
                    className="relative min-h-0 min-w-0 border border-white/25 bg-transparent p-0"
                    onClick={() => {
                      const href = jobLinks[`${col},${row}`];
                      if (href) {
                        void openRead(href);
                        return;
                      }
                      const from = glass?.pointer ?? { c: 0, r: 0 };
                      void runWeb(tapeBetween(from, { c: col, r: row }));
                    }}
                  >
                    {active ? <span className="absolute top-1/2 left-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brass ring-2 ring-black/40" /> : null}
                  </button>
                );
              })}
            </div>
            </div>
          </section>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              if (command.trim()) void runWeb(command.trim());
            }}
          >
            <input
              aria-label="Commands"
              value={command}
              onChange={(event) => setCommand(event.target.value)}
              spellCheck={false}
              placeholder="up down left right click select type"
              className="min-h-11 w-full max-w-full rounded-2xl border border-line bg-bg px-3 text-sm text-fg outline-none focus-visible:border-brass"
            />
          </form>
          <div className="flex flex-wrap gap-1">
            {(["up", "down", "left", "right", "click", "select", "type"] as const).map((word) => (
              <button
                key={word}
                type="button"
                className="tap min-h-11 rounded-2xl border border-line bg-surface px-3 text-xs text-fg"
                onClick={() => setCommand((value) => `${value.trim()} ${word}`.trim())}
              >
                {word}
              </button>
            ))}
          </div>
          <div aria-label="Keyboard" className="flex w-full min-w-0 max-w-full flex-col items-stretch gap-1">
            {["qwertyuiop", "asdfghjkl", "zxcvbnm"].map((row) => (
              <div
                key={row}
                className="grid w-full max-w-full gap-1"
                style={{ gridTemplateColumns: `repeat(${row.length}, minmax(0, 1fr))` }}
              >
                {[...row].map((letter) => (
                  <button
                    key={letter}
                    type="button"
                    className="tap h-11 min-w-0 rounded-xl border border-line bg-surface px-0 text-sm text-fg"
                    onClick={() => setCommand((value) => `${value}${letter}`)}
                  >
                    {letter}
                  </button>
                ))}
              </div>
            ))}
            <div className="grid w-full max-w-full grid-cols-[minmax(0,1fr)_auto] gap-1">
              <button
                type="button"
                className="tap min-h-11 rounded-xl border border-line bg-surface px-6 text-sm text-fg"
                onClick={() => setCommand((value) => `${value} `)}
              >
                space
              </button>
              <button
                type="button"
                className="tap min-h-11 rounded-xl border border-line bg-surface px-3 text-sm text-fg"
                onClick={() => setCommand((value) => value.slice(0, -1))}
              >
                delete
              </button>
            </div>
          </div>
          <Pad
            onCommand={(word) => {
              void runWeb(word);
            }}
            disabled={driving}
          />
        </div>
      </div>
      <details className="w-full min-w-0 max-w-full overflow-x-hidden rounded-card border border-line bg-surface px-4 py-3">
        <summary className="min-h-11 cursor-pointer text-sm text-fg">Rules and API</summary>
      <header className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-display text-4xl leading-none text-fg sm:text-5xl">Quay</p>
          <div className="mt-2 h-px w-16 bg-brass" />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <a
            href="/docs"
            className="tap inline-flex min-h-11 items-center rounded-card border border-line bg-surface px-4 text-sm text-fg"
          >
            Docs
          </a>
          <button
            type="button"
            className="tap min-h-11 rounded-card border border-line bg-surface px-4 text-sm text-fg"
            onClick={() => {
              const opening = !machine.attached;
              toggleLink(machine.id);
              pushTrace(
                opening
                  ? `Link open on ${machine.name}. A model may drive this pointer.`
                  : `Link closed on ${machine.name}.`,
                "model",
              );
            }}
          >
            {machine.attached ? "Link open" : "Open a link"}
          </button>
        </div>
      </header>

      <section className="rounded-card border border-brass/50 bg-surface px-4 py-3" aria-label="Legacy bot tape">
        <p className="text-xs tracking-wide text-brass uppercase">Legacy · /api/bot tape</p>
        <p className="mt-1 text-sm text-muted">
          Legacy. AIs submit a QUAY JOB on Veil. Humans use the Prompt box. This tape does not take new jobs.
        </p>
        <a
          data-testid="bot-link"
          href={botHref}
          className="mt-3 block break-all font-mono text-xs text-brass underline-offset-2 hover:underline"
        >
          {botHref}
        </a>
        <pre
          data-testid="model-screen"
          className="mt-3 max-h-48 overflow-auto whitespace-pre-wrap font-mono text-xs leading-relaxed text-fg"
        >
          {formatAgent(glass ?? emptyAgent())}
        </pre>
        <pre
          data-testid="model-manual"
          className="mt-3 max-h-40 overflow-auto whitespace-pre-wrap font-mono text-xs leading-relaxed text-fg"
        >
          {PROTOCOL}
        </pre>
      </section>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4" role="tablist" aria-label="Machines">
        {machines.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={item.id === machine.id}
            onClick={() => setActive(item.id)}
            className={
              "tap flex min-h-11 flex-col items-start justify-center rounded-card border px-3 py-2 text-left " +
              (item.id === machine.id ? "border-brass bg-raised" : "border-line bg-surface")
            }
          >
            <span className="text-sm text-fg">{item.name}</span>
            <span className="text-xs text-muted">
              {item.solved ? "Clear" : item.attached ? "Linked" : "Idle"}
            </span>
          </button>
        ))}
      </div>


      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1.45fr)_minmax(18rem,0.8fr)]">
        <section className="flex flex-col gap-3">
          <div className="rounded-card border border-line bg-surface px-4 py-3">
            <p className="text-xs tracking-wide text-muted uppercase">Task</p>
            <p className="mt-1 text-sm text-fg">{machine.goal}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {captions.map((chip, index) => (
                <span
                  key={`${index}-${chip.label}`}
                  className={
                    "max-w-full truncate rounded-full border px-2 py-1 text-xs " +
                    (chip.live ? "border-brass text-brass" : "border-line text-muted")
                  }
                >
                  {chip.label}
                </span>
              ))}
            </div>
            {machine.kind === "desk" && machine.desk?.letter && !machine.desk.sent ? (
              <p className="mt-3 text-sm text-fg">
                Pier 4. The lamp is out. Please reply and send the note back.
              </p>
            ) : null}
            {machine.kind === "breakers" && machine.breakers ? (
              <Pattern target={machine.breakers.target} on={machine.breakers.on} />
            ) : null}
          </div>

          {machine.kind === "web" && machine.web ? (
            <BrowserPane
              url={glass?.url || machine.web.url}
              typed={machine.web.address}
              draft={draft}
              ready={ready}
              driving={driving}
              shot={glass?.shot ?? ""}
              onDraft={setDraft}
              onOpen={openTyped}
            />
          ) : null}

          {machine.kind === "web" && machine.web ? (
            <GlassTranscript
              web={{
                url: glass?.url || machine.web.url,
                address: machine.web.address,
                title: driving ? "Opening" : glass?.title || machine.web.title,
                transcript: driving
                  ? "The browser is moving. The transcript updates when it stops."
                  : glass?.transcript || machine.web.transcript,
              }}
            />
          ) : null}

          {machine.kind === "web" && machine.web ? (
            <WebHand
              task={task}
              papers={papers}
              openPaper={openPaper}
              gathering={gathering}
              looksLeft={looks}
              onTask={setTask}
              onOpen={setOpenPaper}
              onClear={clearPapers}
              onGather={() => void gather()}
            />
          ) : null}

          {machine.kind === "web" ? null : (
          <div className="grid items-start gap-3 lg:grid-cols-[minmax(0,28rem)_minmax(0,1fr)]">
            <Floor machine={machine} spots={spots} busy={busy} solved={machine.solved} onAim={aim} />
            <div className="flex flex-col gap-3">
              <div className="rounded-card border border-line bg-surface px-4 py-3">
                <div className="flex items-baseline justify-between gap-3">
                  <p className="text-xs tracking-wide text-muted uppercase">Under the pointer</p>
                  <p className="text-sm text-brass tabular-nums">
                    {machine.cursor.c},{machine.cursor.r}
                  </p>
                </div>
                <p className="mt-2 text-sm text-fg">{under ? under.label : "Open floor"}</p>
                <p className="mt-1 text-sm text-muted">
                  {under ? under.detail : "Click a key to type it. Arrow keys step. Enter clicks."}
                </p>
                {machine.log.length ? (
                  <p className="mt-3 text-xs text-muted">{machine.log[machine.log.length - 1]}</p>
                ) : null}
              </div>
              <Pad onCommand={nudge} disabled={busy} />
            </div>
          </div>
          )}
        </section>

        <aside className="flex flex-col gap-3 lg:sticky lg:top-4">
          {machine.kind === "web" ? (
            <>
            <AgentFloor
              pointer={glass?.pointer ?? { c: 0, r: 0 }}
              cells={glass?.cells ?? []}
              busy={driving}
              onAim={(col, row) => {
                const href = jobLinks[`${col},${row}`];
                if (href) {
                  void openRead(href);
                  return;
                }
                const from = glass?.pointer ?? { c: 0, r: 0 };
                void runWeb(tapeBetween(from, { c: col, r: row }));
              }}
            />
            <Pad
              onCommand={(command) => {
                void runWeb(command);
              }}
              disabled={busy || driving}
            />
            </>
          ) : null}
          <div className="rounded-card border border-line bg-surface p-4">
            <p className="mt-2 text-xs text-muted">
              An AI that cannot send a request can still paste one line here, TAPE: right click. An
              AI that can send a request does not need this box.
            </p>
            <textarea
              data-testid="model-reply"
              value={modelReply}
              onChange={(event) => setModelReply(event.target.value)}
              spellCheck={false}
              aria-label="Model reply"
              placeholder={'TAPE: right click type "the words"'}
              className="mt-3 min-h-24 w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none placeholder:text-muted focus-visible:border-brass"
            />
            <button
              type="button"
              data-testid="run-reply"
              className="tap mt-2 min-h-11 w-full rounded-2xl bg-brass px-3 text-sm text-ink disabled:opacity-40"
              onClick={() => void runModelReply()}
              disabled={busy || asking || driving}
            >
              Run reply
            </button>
            {modelResult ? (
              <pre
                data-testid="model-result"
                className="mt-3 max-h-48 overflow-auto whitespace-pre-wrap font-mono text-xs leading-relaxed text-fg"
              >
                {modelResult}
              </pre>
            ) : null}
            <p className="mt-4 text-xs tracking-wide text-muted uppercase">Command tape</p>
            <textarea
              data-testid="tape"
              value={tape}
              onChange={(event) => setTape(event.target.value)}
              spellCheck={false}
              aria-label="Command tape"
              placeholder="up up right click"
              className="mt-3 min-h-28 w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none placeholder:text-muted focus-visible:border-brass"
            />
            <div className="mt-2 flex flex-wrap gap-2">
              {(["up", "down", "left", "right", "click"] as const).map((word) => (
                <button
                  key={word}
                  type="button"
                  className="tap min-h-11 rounded-full border border-line bg-bg px-3 text-xs text-fg"
                  onClick={() => append(word)}
                >
                  {word}
                </button>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                data-testid="run"
                className="tap min-h-11 rounded-2xl bg-brass px-3 text-sm text-ink disabled:opacity-40"
                onClick={runTape}
                disabled={busy || asking || driving}
              >
                Run
              </button>
              <button
                type="button"
                className="tap min-h-11 rounded-2xl border border-line bg-raised px-3 text-sm text-fg disabled:opacity-40"
                onClick={busy ? stop : stepOnce}
              >
                {busy ? "Stop" : "Step"}
              </button>
              <button
                type="button"
                data-testid="ask"
                className="tap min-h-11 rounded-2xl border border-brass bg-raised px-3 text-sm text-brass disabled:opacity-40"
                onClick={() => void ask()}
                disabled={busy || asking || looks <= 0 || driving}
              >
                {asking ? "Looking…" : looked ? "Continue" : "Hand to model"}
              </button>
              <button
                type="button"
                className="tap min-h-11 rounded-2xl border border-line bg-bg px-3 text-sm text-fg"
                onClick={rehearse}
              >
                Rehearse
              </button>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button
                type="button"
                className="tap flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-line px-3 text-xs text-muted"
                onClick={() => void copyBrief()}
              >
                <Copy className="size-3.5" aria-hidden="true" />
                {copied ? "Copied" : "Copy for a model"}
              </button>
              <button
                type="button"
                className="tap flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-line px-3 text-xs text-muted"
                onClick={() => {
                  stop();
                  resetMachine(machine.id);
                  if (machine.kind === "web") {
                    setGlass(null);
                    setJobLinks({});
                  }
                }}
              >
                <RotateCcw className="size-3.5" aria-hidden="true" />
                Reset bay
              </button>
            </div>
          </div>
          <div className="rounded-card border border-line bg-bg px-4 py-3">
            <p className="text-xs tracking-wide text-muted uppercase">Wire</p>
            <ol className="mt-2 flex max-h-52 flex-col gap-1 overflow-auto" aria-live="polite">
              {trace.length === 0 ? (
                <li className="text-sm text-muted">
                  The link is quiet. Open a site, or hand the floor to a model.
                </li>
              ) : (
                trace.slice(-12).map((line) => (
                  <li
                    key={line.id}
                    className={
                      "text-xs " +
                      (line.tone === "warn"
                        ? "text-brass"
                        : line.tone === "model"
                          ? "text-fg"
                          : "text-muted")
                    }
                  >
                    {line.text}
                  </li>
                ))
              )}
            </ol>
          </div>
        </aside>
      </div>
      </details>
      <details className="w-full min-w-0 max-w-full overflow-x-hidden rounded-card border border-line bg-surface px-4 py-3">
        <summary className="min-h-11 cursor-pointer text-sm text-fg">Settings</summary>
        <label className="mt-3 flex min-h-11 items-center justify-between gap-3 text-sm text-fg">
          Show pointer and grid lines
          <input type="checkbox" checked={showGrid} onChange={(event) => setShowGrid(event.target.checked)} />
        </label>
        <label className="mt-2 flex min-h-11 items-center justify-between gap-3 text-sm text-fg">
          Close only popups not needed for the task
          <input type="checkbox" checked={closePopups} onChange={(event) => setClosePopups(event.target.checked)} />
        </label>
        <label className="mt-2 flex min-h-11 items-center justify-between gap-3 text-sm text-fg">
          Recent jobs
          <select
            value={String(jobKeep)}
            onChange={(event) => setJobKeep(Number(event.target.value) as 0 | 1 | 24)}
            className="min-h-11 rounded-xl border border-line bg-bg px-2 text-sm text-fg"
          >
            <option value="1">1 hour</option>
            <option value="24">24 hours</option>
            <option value="0">Off</option>
          </select>
        </label>
        <ul className="mt-3 flex flex-col gap-2">
          {recent.length === 0 ? <li className="text-xs text-muted">None</li> : null}
          {recent.map((row) => (
            <li key={`${row.order}-${row.answer.slice(0, 24)}`} className="text-xs text-muted">
              {row.order}
            </li>
          ))}
        </ul>
      </details>
    </main>
  );
}

function WebHand({
  task,
  papers,
  openPaper,
  gathering,
  looksLeft,
  onTask,
  onOpen,
  onClear,
  onGather,
}: {
  task: string;
  papers: Paper[];
  openPaper: number | null;
  gathering: boolean;
  looksLeft: number;
  onTask: (value: string) => void;
  onOpen: (id: number | null) => void;
  onClear: () => void;
  onGather: () => void;
}) {
  const shown = papers.find((paper) => paper.id === openPaper) ?? papers[0];
  const [copied, setCopied] = useState(false);

  const copyPaper = async () => {
    if (!shown) return;
    const body = [shown.task, "", shown.text, "", ...shown.sources].join("\n");
    try {
      await navigator.clipboard.writeText(body);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="rounded-card border border-line bg-surface px-4 py-3">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-xs tracking-wide text-muted uppercase">Web hand</p>
        <p className="text-xs text-muted">{looksLeft} looks</p>
      </div>
      <p className="mt-2 text-sm text-muted">
        One task. The model keeps moving the pointer until that task is finished. You do not type
        the next command.
      </p>
      <textarea
        data-testid="task"
        value={task}
        onChange={(event) => onTask(event.target.value)}
        aria-label="Task for the web"
        spellCheck
        className="mt-3 min-h-20 w-full resize-y rounded-2xl border border-line bg-bg px-3 py-3 text-sm text-fg outline-none focus-visible:border-brass"
      />
      <div className="mt-2 flex flex-wrap gap-2">
        <button
          type="button"
          data-testid="gather"
          className="tap min-h-11 rounded-2xl bg-brass px-4 text-sm text-ink disabled:opacity-40"
          onClick={onGather}
          disabled={gathering || looksLeft <= 0}
        >
          {gathering ? "Driving…" : "Drive"}
        </button>
        {papers.length > 0 ? (
          <button
            type="button"
            className="tap min-h-11 rounded-2xl border border-line px-3 text-sm text-muted"
            onClick={onClear}
          >
            Clear notes
          </button>
        ) : null}
      </div>
      {shown ? (
        <article data-testid="paper" className="mt-4 border-t border-line pt-3">
          <div className="flex items-start justify-between gap-3">
            <h2 className="text-sm text-fg">{shown.task}</h2>
            <button
              type="button"
              className="tap shrink-0 text-xs text-brass"
              onClick={() => void copyPaper()}
            >
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
          <p className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap text-sm leading-relaxed text-fg">
            {shown.text}
          </p>
          {shown.sources.length > 0 ? (
            <ul className="mt-3 flex flex-col gap-1">
              {shown.sources.map((source) => (
                <li key={source} className="truncate text-xs">
                  <a
                    href={source}
                    target="_blank"
                    rel="noreferrer"
                    className="text-brass underline-offset-2 hover:underline"
                  >
                    {source}
                  </a>
                </li>
              ))}
            </ul>
          ) : null}
          {papers.length > 1 ? (
            <div className="mt-3 flex flex-wrap gap-2">
              {papers.map((paper) => (
                <button
                  key={paper.id}
                  type="button"
                  className={
                    "tap max-w-full truncate rounded-full border px-2 py-1 text-xs " +
                    (paper.id === shown.id ? "border-brass text-brass" : "border-line text-muted")
                  }
                  onClick={() => onOpen(paper.id)}
                >
                  {paper.task}
                </button>
              ))}
            </div>
          ) : null}
        </article>
      ) : (
        <p className="mt-3 text-sm text-muted">No notes filed yet.</p>
      )}
    </div>
  );
}

function GlassTranscript({ web }: { web: WebState }) {
  return (
    <section data-testid="transcript" className="rounded-card border border-line bg-surface px-4 py-3">
      <p className="text-xs tracking-wide text-brass uppercase">Transcript</p>
      <p className="mt-1 text-sm text-muted">
        This is the page, written out. A model that cannot see the glass still reads this.
      </p>
      <p className="mt-3 truncate text-sm text-brass">{web.url || "No page yet"}</p>
      <p className="mt-1 text-sm text-fg">{plain(web.title) || "No page yet"}</p>
      <p className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap text-sm leading-relaxed text-fg">
        {web.transcript?.trim()
          ? plain(web.transcript)
          : "Open a public site. The writing shows up here, and the grid shows what you can click."}
      </p>
    </section>
  );
}

function BrowserPane({
  url,
  typed,
  draft,
  ready,
  driving,
  shot,
  page = true,
  onDraft,
  onOpen,
}: {
  url: string;
  typed: string;
  draft: string;
  ready: boolean;
  driving: boolean;
  shot: string;
  page?: boolean;
  onDraft: (value: string) => void;
  onOpen: () => void;
}) {
  return (
    <div data-testid="browser" className="overflow-hidden rounded-card border border-line bg-bg">
      <form
        className="flex flex-col gap-2 border-b border-line px-3 py-2 sm:flex-row"
        onSubmit={(event) => {
          event.preventDefault();
          onOpen();
        }}
      >
        <input
          data-testid="open-address"
          value={draft}
          onChange={(event) => onDraft(event.target.value)}
          aria-label="Site to open"
          spellCheck={false}
          placeholder="any public site"
          className="min-h-11 w-full flex-1 rounded-2xl border border-line bg-surface px-3 text-sm text-fg outline-none focus-visible:border-brass"
        />
        <button
          type="submit"
          data-testid="open-site"
          className="tap min-h-11 rounded-2xl bg-brass px-4 text-sm text-ink disabled:opacity-40"
          disabled={!ready || driving}
        >
          {driving ? "Moving…" : "Open"}
        </button>
      </form>
      <div className="border-b border-line px-3 py-2">
        <p data-testid="web-address" className="wrap-any text-xs text-brass">
          {url || "No page yet"}
        </p>
        <p data-testid="typed" className="wrap-any mt-1 text-xs text-muted">
          {typed ? `Open ${typed}` : "Nothing open"}
        </p>
      </div>
      {page ? (
        shot ? (
        <img
          data-testid="agent-shot"
          src={`data:image/jpeg;base64,${shot}`}
          alt="The page the pointer is on"
          className="w-full bg-surface"
        />
      ) : (
        <p className="px-3 py-6 text-sm text-muted">
          {driving
            ? "The page is opening."
            : url
              ? "The page is open. Its links are on the grid. The transcript is the writing."
              : "Press Open. The grid lists the links, and the transcript is the writing."}
        </p>
      )
      ) : null}
    </div>
  );
}

function AgentFloor({
  pointer,
  cells,
  busy,
  onAim,
}: {
  pointer: { c: number; r: number };
  cells: AgentState["cells"];
  busy: boolean;
  onAim: (col: number, row: number) => void;
}) {
  const tiles = [];
  for (let row = 0; row < 32; row += 1) {
    for (let col = 0; col < 8; col += 1) {
      const cell = cells.find((item) => item.c === col && item.r === row);
      const active = pointer.c === col && pointer.r === row;
      tiles.push(
        <button
          key={`${col}-${row}`}
          type="button"
          data-testid={`agent-${col}-${row}`}
          aria-label={`Column ${col}, row ${row}`}
          aria-current={active ? "true" : undefined}
          disabled={busy}
          onClick={() => onAim(col, row)}
          className={
            "tap flex aspect-square min-w-0 items-end overflow-hidden rounded-xl border px-0.5 pb-0.5 text-left " +
            (active ? "border-brass bg-raised" : cell ? "border-line bg-surface" : "border-transparent bg-transparent")
          }
        >
        </button>,
      );
    }
  }
  return (
    <div className="rounded-card border border-line bg-bg p-1 sm:p-3" data-testid="agent-floor">
      <div className="mb-2 flex items-center justify-between px-1">
        <p className="text-xs tracking-wide text-muted uppercase">{busy ? "Hand moving" : "Page grid"}</p>
        <p className="text-xs text-brass tabular-nums" data-testid="agent-pointer">
          {pointer.c},{pointer.r}
        </p>
      </div>
      <div className="grid grid-cols-8 gap-0.5">{tiles}</div>
    </div>
  );
}

function Pattern({ target, on }: { target: boolean[]; on: boolean[] }) {
  return (
    <div className="mt-3 flex flex-wrap items-center gap-3">
      <span className="text-xs text-muted">Pattern</span>
      <div className="flex gap-1" aria-hidden="true">
        {target.map((flag, index) => (
          <span key={`t-${index}`} className={"size-2.5 rounded-sm " + (flag ? "bg-brass" : "bg-line")} />
        ))}
      </div>
      <span className="text-xs text-muted">Now</span>
      <div className="flex gap-1" aria-hidden="true">
        {on.map((flag, index) => (
          <span
            key={`n-${index}`}
            className={
              "size-2.5 rounded-sm " +
              (flag === target[index] ? (flag ? "bg-brass" : "bg-raised") : "bg-muted")
            }
          />
        ))}
      </div>
    </div>
  );
}

function Pad({ onCommand, disabled }: { onCommand: (command: Command) => void; disabled: boolean }) {
  const key = (command: Command, label: string, icon: typeof ArrowUp) => {
    const Icon = icon;
    return (
      <button
        type="button"
        aria-label={label}
        disabled={disabled}
        onClick={() => onCommand(command)}
        className={
          "tap flex size-12 items-center justify-center rounded-2xl border border-line bg-surface text-fg disabled:opacity-40 " +
          (command === "click" ? "border-brass text-brass" : "")
        }
      >
        <Icon className="size-4" aria-hidden="true" />
      </button>
    );
  };
  return (
    <div className="flex items-center justify-center gap-2" aria-label="Pointer pad">
      <div className="grid grid-cols-3 gap-2">
        <span />
        {key("up", "Move up", ArrowUp)}
        <span />
        {key("left", "Move left", ArrowLeft)}
        {key("click", "Click", CircleCheck)}
        {key("right", "Move right", ArrowRight)}
        <span />
        {key("down", "Move down", ArrowDown)}
        <span />
      </div>
    </div>
  );
}

function Floor({
  machine,
  spots,
  busy,
  solved,
  onAim,
}: {
  machine: Machine;
  spots: Hotspot[];
  busy: boolean;
  solved: boolean;
  onAim: (col: number, row: number) => void;
}) {
  const gridRef = useRef<HTMLDivElement>(null);
  const [cell, setCell] = useState(40);

  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;
    const measure = () => {
      const size = (el.clientWidth - GAP * (machine.cols - 1)) / machine.cols;
      setCell(size > 0 ? size : 40);
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [machine.cols]);

  const cells = [];
  for (let row = 0; row < machine.rows; row += 1) {
    for (let col = 0; col < machine.cols; col += 1) {
      const spot = spots.find((item) => item.col === col && item.row === row);
      const active = machine.cursor.c === col && machine.cursor.r === row;
      const letter = spot?.glyph === "key" || spot?.glyph === "del";
      const alwaysLabel = letter || spot?.glyph === "search" || spot?.glyph === "page";
      const Mark = spot && spot.glyph !== "breaker" && !letter ? ICONS[spot.glyph] : null;
      const breakerOn =
        machine.kind === "breakers" && spot?.glyph === "breaker" ? machine.breakers?.on[col] : false;
      cells.push(
        <button
          key={`${col}-${row}`}
          type="button"
          data-testid={`cell-${col}-${row}`}
          aria-label={spot ? spot.label : `Floor ${col},${row}`}
          aria-current={active ? "true" : undefined}
          disabled={busy}
          onClick={() => onAim(col, row)}
          className={
            "tap relative flex aspect-square min-w-0 flex-col items-center justify-center gap-1 overflow-hidden rounded-xl border " +
            (spot ? toneClass(spot.tone, active && Boolean(spot)) : "border-transparent bg-transparent") +
            (active && !spot ? " border-brass/50" : "")
          }
        >
          {Mark ? <Mark className="size-4 shrink-0" aria-hidden="true" /> : null}
          {spot?.glyph === "breaker" ? (
            <span className={"w-1 rounded-full " + (breakerOn ? "h-5 bg-brass" : "h-2 bg-line")} aria-hidden="true" />
          ) : null}
          {spot ? (
            <span className={"max-w-full truncate px-0.5 text-xs " + (alwaysLabel ? "" : "hidden sm:block")}>
              {spot.label}
            </span>
          ) : null}
        </button>,
      );
    }
  }

  return (
    <div className={"w-full max-w-md rounded-card border bg-bg p-1 sm:p-3 " + (solved ? "border-brass" : "border-line")}>
      <div className="mb-2 flex items-center justify-between px-1">
        <p className="text-xs tracking-wide text-muted uppercase">
          {solved ? "Clear" : busy ? "Hand moving" : "Floor"}
        </p>
        <p className="text-xs text-muted tabular-nums">
          {machine.cols}×{machine.rows}
        </p>
      </div>
      <div className="relative">
        <div
          ref={gridRef}
          data-testid="floor"
          className="grid"
          style={{ gridTemplateColumns: `repeat(${machine.cols}, minmax(0, 1fr))`, gap: GAP }}
        >
          {cells}
        </div>
        <div
          className="hand-move pointer-events-none absolute top-0 left-0 z-10"
          style={{
            width: cell,
            height: cell,
            transform: `translate(${machine.cursor.c * (cell + GAP)}px, ${machine.cursor.r * (cell + GAP)}px)`,
          }}
          aria-hidden="true"
        >
          <span className="absolute top-0 left-0 size-2.5 border-t-2 border-l-2 border-brass" />
          <span className="absolute top-0 right-0 size-2.5 border-t-2 border-r-2 border-brass" />
          <span className="absolute bottom-0 left-0 size-2.5 border-b-2 border-l-2 border-brass" />
          <span className="absolute right-0 bottom-0 size-2.5 border-r-2 border-b-2 border-brass" />
          <span className="absolute top-1/2 left-1/2 size-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brass" />
        </div>
      </div>
    </div>
  );
}
