import { toUrl } from "@/lib/quay/engine";
import { looksLikeError, READER_UA, withE2B } from "@/lib/quay/e2b-box";
import { readHfToken, scrubSecrets } from "@/lib/quay/secrets";
import { noteStep } from "@/lib/quay/slots";

export type SearchHit = { title: string; url: string };

const SOURCES = ["duckduckgo", "bing", "wikipedia", "stackexchange", "hf-space"] as const;

function shQuote(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function decode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function pushHit(hits: SearchHit[], url: string, title: string): void {
  const safe = toUrl(url);
  if (!safe || hits.some((hit) => hit.url === safe)) return;
  if (/duckduckgo\.com|bing\.com|r\.jina\.ai/i.test(safe)) return;
  hits.push({ title: title.replace(/\s+/g, " ").trim().slice(0, 140) || safe, url: safe });
}

function linksFromHtml(html: string): SearchHit[] {
  const hits: SearchHit[] = [];
  for (const match of html.matchAll(/uddg=([^&"]+)/gi)) pushHit(hits, decode(match[1] ?? ""), "");
  for (const match of html.matchAll(/<a\b[^>]*href="(https?:\/\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)) {
    const title = (match[2] ?? "").replace(/<[^>]+>/g, " ");
    pushHit(hits, match[1] ?? "", title);
  }
  return hits.slice(0, 8);
}

function formatHits(source: string, hits: SearchHit[]): string {
  return hits.map((hit) => `- ${hit.title}: ${hit.url}`).join("\n") || `(${source} returned nothing)`;
}

function note(job: string, source: string, status: "running" | "done" | "failed" | "released", tries: number): void {
  noteStep({
    id: `${job}:search:${source}`,
    slot: "search",
    step: SOURCES.indexOf(source as (typeof SOURCES)[number]) + 1,
    fn: "find",
    status,
    follower: `search-${source}`,
    tries,
  });
}

function hfSpaces(): string[] {
  const raw = process.env.QUAY_HF_SEARCH_SPACES || "HuggingFaceH4/web-search,microsoft/web-search";
  return raw
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 4);
}

async function hfSpaceSearch(query: string): Promise<SearchHit[]> {
  const token = readHfToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json",
    "User-Agent": READER_UA,
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  for (const space of hfSpaces()) {
    const name = space.replace(/^https?:\/\/huggingface\.co\/spaces\//i, "").replace(/\/$/, "");
    const [owner, repo] = name.split("/");
    if (!owner || !repo) continue;
    const endpoint = toUrl(`https://${owner}-${repo}.hf.space/api/predict`);
    if (!endpoint) continue;
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers,
        signal: AbortSignal.timeout(20000),
        body: JSON.stringify({ data: [query.slice(0, 180)] }),
      });
      const text = scrubSecrets(await response.text());
      if (!response.ok || looksLikeError(text)) continue;
      const hits = linksFromHtml(text);
      if (hits.length > 0) return hits;
    } catch {
      continue;
    }
  }
  return [];
}

export async function searchFollowers(job: string, query: string): Promise<{ ok: boolean; follower: string; text: string; pages: string[] }> {
  const q = query.replace(/[\r\n]+/g, " ").trim().slice(0, 160);
  if (q.length < 2) return { ok: false, follower: "", text: "", pages: [] };
  const encoded = encodeURIComponent(q);
  const found = await withE2B(async (sandbox) => {
    const run = async (source: string, cmd: string) => {
      note(job, source, "running", 1);
      try {
        const result = await sandbox.commands.run(cmd, { timeoutMs: 25_000 });
        const text = result.stdout ?? "";
        if ((result.exitCode && result.exitCode !== 0) || looksLikeError(text)) {
          note(job, source, "failed", 1);
          return null;
        }
        return text;
      } catch {
        note(job, source, "failed", 1);
        return null;
      }
    };
    const take = (source: string, hits: SearchHit[]) => {
      note(job, source, "done", 1);
      return { follower: `search-${source}`, text: formatHits(source, hits), pages: hits.map((hit) => hit.url) };
    };
    const miss = (source: string) => {
      note(job, source, "released", 1);
    };
    const ddg = await run("duckduckgo", `curl -fsSL -A ${shQuote(READER_UA)} --max-time 20 ${shQuote(`https://html.duckduckgo.com/html/?q=${encoded}`)}`);
    const ddgHits = ddg ? linksFromHtml(ddg) : [];
    if (ddgHits.length > 0) return take("duckduckgo", ddgHits);
    miss("duckduckgo");
    const bing = await run("bing", `curl -fsSL -A ${shQuote(READER_UA)} --max-time 20 ${shQuote(`https://www.bing.com/search?q=${encoded}`)}`);
    const bingHits = bing ? linksFromHtml(bing) : [];
    if (bingHits.length > 0) return take("bing", bingHits);
    miss("bing");
    const wiki = await run(
      "wikipedia",
      `curl -fsSL -A ${shQuote(READER_UA)} --max-time 20 ${shQuote(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encoded}&utf8=1&format=json&srlimit=5`)}`,
    );
    if (wiki && !looksLikeError(wiki)) {
      try {
        const data = JSON.parse(wiki) as { error?: unknown; query?: { search?: { title?: string }[] } };
        const hits: SearchHit[] = [];
        if (!data.error) {
          for (const row of data.query?.search ?? []) {
            if (!row.title) continue;
            pushHit(hits, `https://en.wikipedia.org/wiki/${encodeURIComponent(row.title.replace(/ /g, "_"))}`, row.title);
          }
        }
        if (hits.length > 0) return take("wikipedia", hits);
      } catch {
        /* next source */
      }
    }
    miss("wikipedia");
    const stack = await run(
      "stackexchange",
      `curl -fsSL -A ${shQuote(READER_UA)} --max-time 20 ${shQuote(`https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${encoded}&site=stackoverflow&pagesize=5`)}`,
    );
    if (stack && !looksLikeError(stack)) {
      try {
        const data = JSON.parse(stack) as { error_id?: number; items?: { title?: string; link?: string }[] };
        const hits: SearchHit[] = [];
        if (!data.error_id) {
          for (const row of data.items ?? []) {
            if (row.link) pushHit(hits, row.link, row.title ?? "");
          }
        }
        if (hits.length > 0) return take("stackexchange", hits);
      } catch {
        /* next source */
      }
    }
    miss("stackexchange");
    return null;
  });
  if (found?.pages.length) return { ok: true, follower: found.follower, text: scrubSecrets(found.text), pages: found.pages };
  note(job, "hf-space", "running", 1);
  const hfHits = await hfSpaceSearch(q);
  if (hfHits.length > 0) {
    note(job, "hf-space", "done", 1);
    return {
      ok: true,
      follower: "search-hf-space",
      text: scrubSecrets(formatHits("hf-space", hfHits)),
      pages: hfHits.map((hit) => hit.url),
    };
  }
  note(job, "hf-space", "released", 1);
  return { ok: false, follower: "", text: "", pages: [] };
}

function packSource(id: string, body: string): string {
  if (!body || looksLikeError(body)) return "";
  if (id === "wikipedia") {
    try {
      const data = JSON.parse(body) as { error?: unknown; query?: { search?: { title?: string }[] } };
      const hits: SearchHit[] = [];
      if (!data.error) {
        for (const row of data.query?.search ?? []) {
          if (!row.title) continue;
          pushHit(hits, `https://en.wikipedia.org/wiki/${encodeURIComponent(row.title.replace(/ /g, "_"))}`, row.title);
        }
      }
      return hits.length > 0 ? formatHits(id, hits) : "";
    } catch {
      return "";
    }
  }
  if (id === "stackexchange") {
    try {
      const data = JSON.parse(body) as { error_id?: number; items?: { title?: string; link?: string }[] };
      const hits: SearchHit[] = [];
      if (!data.error_id) {
        for (const row of data.items ?? []) {
          if (row.link) pushHit(hits, row.link, row.title ?? "");
        }
      }
      return hits.length > 0 ? formatHits(id, hits) : "";
    } catch {
      return "";
    }
  }
  const hits = linksFromHtml(body);
  return hits.length > 0 ? formatHits(id, hits) : "";
}

const RESEARCH = [
  { id: "duckduckgo", name: "DuckDuckGo", url: (q: string) => `https://html.duckduckgo.com/html/?q=${q}` },
  { id: "bing", name: "Bing", url: (q: string) => `https://www.bing.com/search?q=${q}` },
  { id: "wikipedia", name: "Wikipedia", url: (q: string) => `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${q}&utf8=1&format=json&srlimit=5` },
  {
    id: "stackexchange",
    name: "StackExchange",
    url: (q: string) => `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${q}&site=stackoverflow&pagesize=5`,
  },
] as const;

export async function researchBundle(job: string, query: string): Promise<{ name: string; text: string }[]> {
  const q = query.replace(/[\r\n]+/g, " ").trim().slice(0, 160);
  if (q.length < 2) return [];
  const encoded = encodeURIComponent(q);
  const found = await withE2B(async (sandbox) => {
    const rows: { name: string; text: string }[] = [];
    for (const source of RESEARCH) {
      note(job, source.id, "running", 1);
      let body = "";
      try {
        const result = await sandbox.commands.run(`curl -fsSL -A ${shQuote(READER_UA)} --max-time 12 ${shQuote(source.url(encoded))}`, {
          timeoutMs: 16_000,
        });
        body = result.stdout ?? "";
        if ((result.exitCode && result.exitCode !== 0) || looksLikeError(body)) body = "";
      } catch {
        body = "";
      }
      const text = packSource(source.id, body);
      note(job, source.id, text ? "done" : "released", 1);
      rows.push({ name: source.name, text });
    }
    return rows;
  });
  return found ?? [];
}
