import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import source from "../../../scripts/sandbox-session.mjs?raw";

export type ScriptDiagnostic = {
  path: string;
  exists: boolean;
  cwd: string;
  runtime: string;
};

export type LocatedScript = {
  path: string;
  source: string;
  diagnostic: ScriptDiagnostic;
};

let cached: LocatedScript | null = null;

export function locateSandboxScript(): LocatedScript {
  if (cached?.diagnostic.exists && cached.source) return cached;
  const cwd = process.cwd();
  const runtime = process.env.VERCEL ? "vercel" : process.env.NODE_ENV || "node";
  const fromModule = fileURLToPath(new URL("../../../scripts/sandbox-session.mjs", import.meta.url));
  const fromCwd = join(cwd, "scripts/sandbox-session.mjs");
  let path = [fromCwd, fromModule].find((item) => existsSync(item)) ?? "";
  let text = typeof source === "string" ? source : "";
  if (!text && path) {
    try {
      text = readFileSync(path, "utf8");
    } catch {
      text = "";
    }
  }
  if (!path && text) {
    path = join(tmpdir(), "quay-sandbox-session.mjs");
    writeFileSync(path, text);
  }
  cached = {
    path,
    source: text,
    diagnostic: { path, exists: Boolean(path && existsSync(path) && text), cwd, runtime },
  };
  return cached;
}
