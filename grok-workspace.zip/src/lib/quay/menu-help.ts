export function parseMenuReply(text: string): { options: string[]; tape: string } {
  const optionLine = text.match(/OPTIONS:\s*(.+)/i)?.[1] ?? "";
  const options = optionLine
    .split("|")
    .map((item) => item.trim())
    .filter((item) => item && !/^\(none\)$/i.test(item))
    .slice(0, 12);
  const tape = (text.match(/TAPE:\s*(.+)/i)?.[1] ?? "").trim().slice(0, 200);
  return { options, tape };
}

export async function askMenu(shot: string, tape: string): Promise<{ options: string[]; tape: string; source: string }> {
  const key = process.env.XAI_API_KEY;
  if (!key || !shot) {
    return {
      options: [],
      tape: "click",
      source: "The picture is on the screen. The helper had no key. Do not stop. Click the menu, then type the option.",
    };
  }
  try {
    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      signal: AbortSignal.timeout(20000),
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 180,
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `A dropdown on this page could not be read as text. Caller tape: ${tape || "(none)"}. List the choices you can see. Reply with exactly two lines and nothing else.\nOPTIONS: first | second | third\nTAPE: click type "the choice"`,
              },
              { type: "image_url", image_url: { url: `data:image/jpeg;base64,${shot}` } },
            ],
          },
        ],
      }),
    });
    if (!response.ok) {
      return {
        options: [],
        tape: "click",
        source: "The picture is on the screen. The helper did not answer. Do not stop. Click the menu, then type the option.",
      };
    }
    const body = (await response.json()) as { choices?: { message?: { content?: string } }[] };
    const parsed = parseMenuReply(body.choices?.[0]?.message?.content ?? "");
    return {
      options: parsed.options,
      tape: parsed.tape || "click",
      source: "A public model read the screenshot and sent the commands.",
    };
  } catch {
    return {
      options: [],
      tape: "click",
      source: "The picture is on the screen. The helper did not answer. Do not stop. Click the menu, then type the option.",
    };
  }
}
