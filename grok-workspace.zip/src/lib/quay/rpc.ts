export const RPC_METHODS = [
  "task",
  "fix",
  "status",
  "result",
  "error",
  "criteria",
  "judge",
  "block",
  "plan",
  "step",
  "step_result",
  "follower_changed",
  "assemble",
  "review",
] as const;

export type RpcMethod = (typeof RPC_METHODS)[number];

export type RpcMessage = {
  jsonrpc: "2.0";
  id: string;
  method: RpcMethod;
  params: Record<string, unknown>;
};

export const RPC_EXAMPLE = '{"jsonrpc":"2.0","id":"1","method":"result","params":{"text":"ANSWER: the fact. Source: https://example.com"}}';

const LEGACY_NOTE = "Q1 shorthand (up, down, left, right, click, TAPE) is legacy. Prefer one JSON-RPC 2.0 object.";

export function rpcLine(id: string, method: RpcMethod, params: Record<string, unknown>): string {
  return JSON.stringify({ jsonrpc: "2.0", id, method, params });
}

export function extractRpc(raw: string): RpcMessage | null {
  const stripped = raw.replace(/```(?:json)?/gi, "").trim();
  const start = stripped.indexOf("{");
  const end = stripped.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const value = JSON.parse(stripped.slice(start, end + 1)) as Partial<RpcMessage>;
    if (value.jsonrpc !== "2.0" || typeof value.method !== "string") return null;
    if (!RPC_METHODS.includes(value.method as RpcMethod)) return null;
    return {
      jsonrpc: "2.0",
      id: String(value.id ?? ""),
      method: value.method as RpcMethod,
      params: value.params && typeof value.params === "object" ? value.params : {},
    };
  } catch {
    return null;
  }
}

export function rpcHint(): string {
  return `${LEGACY_NOTE} Example: ${RPC_EXAMPLE}`;
}
