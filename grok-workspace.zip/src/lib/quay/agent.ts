import { toUrl } from "@/lib/quay/engine";
import { documentFromHtml, readPublicDocument, submitPublic } from "@/lib/quay/read-page";
import {
  emptyAgent,
  GRID_COLS,
  GRID_ROWS,
  type AgentCell,
  type AgentState,
} from "@/lib/quay/agent-view";

const TAPE_LIMIT = 24;

interface Control {
  label: string;
  kind: string;
  href: string;
  name: string;
  value: string;
  caption: string;
  options: { label: string; value: string }[];
}

const NAG = /(cookie|newsletter|subscribe|sign up|no thanks|not now|accept all|i agree|got it|dismiss|advertisement)/i;
const KEEP = /(help|menu|date|calendar|picker|confirm|required|\?)/i;

type Step =
  | { kind: "move"; command: "up" | "down" | "left" | "right" | "click" }
  | { kind: "type"; text: string }
  | { kind: "select"; text: string };

export function movesFromReply(reply: string, limit = 4): string {
  return readTape(reply, limit)
    .map((step) =>
      step.kind === "type" ? `type "${step.text.replace(/"/g, "")}"` : step.kind === "select" ? `select "${step.text.replace(/"/g, "")}"` : step.command,
    )
    .join(" ");
}

export function planFromReply(reply: string): { tape: string; packet: string } {
  const marked = reply.match(/(?:^|\n)\s*TAPE\s*:\s*(.+)$/im);
  const tape = marked ? movesFromReply(marked[1], 24) : "";
  const start = reply.search(/(?:^|\n)LINE AI-ONE \/ AI-TWO\s*(?:\n|$)/);
  let packet = "";
  if (start >= 0) {
    const rest = reply.slice(start).replace(/^\n/, "");
    const end = rest.search(/\nNEXT\s+(?:WAIT|REPLY|DONE)\s*(?:\n|$)/);
    packet = end >= 0 ? rest.slice(0, end + (rest.slice(end).match(/\nNEXT\s+(?:WAIT|REPLY|DONE)/)?.[0].length ?? 0)) : "";
  }
  return { tape, packet: packet.trim() };
}

function readTape(raw: string, limit = TAPE_LIMIT): Step[] {
  const steps: Step[] = [];
  const pattern =
    /select\s+"([^"]*)"|select\s+'([^']*)'|type\s+"([^"]*)"|type\s+'([^']*)'|type:(\S+)|(up|down|left|right|click)(?:\*(\d+))?/gi;
  for (const match of raw.matchAll(pattern)) {
    if (steps.length >= limit) break;
    const selected = match[1] ?? match[2];
    if (selected != null) {
      const text = selected.replace(/\+/g, " ").trim().slice(0, 80);
      if (text) steps.push({ kind: "select", text });
      continue;
    }
    const typed = match[3] ?? match[4] ?? match[5];
    if (typed != null) {
      const text = typed.replace(/\+/g, " ").trim().slice(0, 80);
      if (text) steps.push({ kind: "type", text });
      continue;
    }
    const word = (match[6] ?? "").toLowerCase() as "up" | "down" | "left" | "right" | "click";
    if (!word) continue;
    let count = Math.min(16, Math.max(1, Number(match[7] || 1)));
    while (count > 0 && steps.length < limit) {
      steps.push({ kind: "move", command: word });
      count -= 1;
    }
  }
  return steps;
}

function fail(error: string, pointer = { c: 0, r: 0 }, scroll = 0): AgentState {
  return { ...emptyAgent(), error, pointer, scroll };
}

function attr(source: string, name: string): string {
  const match = source.match(new RegExp(`${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s>]+))`, "i"));
  return (match?.[2] ?? match?.[3] ?? match?.[4] ?? "").trim();
}

function innerText(chunk: string): string {
  return chunk
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&/gi, "&")
    .replace(/"|&#34;/gi, '"')
    .replace(/&#39;|'/gi, "'")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 60);
}

function controlsFromHtml(html: string, base: string): Control[] {
  const cleaned = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ");
  const found: Control[] = [];
  const push = (label: string, kind: string, href: string, name = "", value = "", caption = "", options: Control["options"] = []) => {
    const text = label.replace(/\s+/g, " ").trim().slice(0, kind === "choice" ? 160 : 60);
    if (!text && !href) return;
    if (found.some((item) => item.label === text && item.href === href && item.name === name)) return;
    found.push({ label: text || kind, kind, href, name, value, caption, options });
  };
  const forLabel = (id: string) => {
    if (!id) return "";
    const match = cleaned.match(new RegExp(`<label\\b[^>]*\\bfor\\s*=\\s*["']${id}["'][^>]*>([\\s\\S]*?)<\\/label>`, "i"));
    return match ? innerText(match[1] ?? "") : "";
  };
  const captionBefore = (index: number) => {
    const before = cleaned.slice(Math.max(0, index - 600), index);
    const labeled = [...before.matchAll(/<label\b[^>]*>([\s\S]*?)<\/label>/gi)].at(-1);
    const legend = [...before.matchAll(/<legend\b[^>]*>([\s\S]*?)<\/legend>/gi)].at(-1);
    return innerText(labeled?.[1] ?? "") || innerText(legend?.[1] ?? "");
  };
  for (const match of cleaned.matchAll(/<a\b([^>]*?)>([\s\S]*?)<\/a>/gi)) {
    const href = attr(match[1] ?? "", "href");
    if (!href || href.startsWith("#") || /^javascript:/i.test(href)) continue;
    let absolute = "";
    try {
      absolute = toUrl(new URL(href, base).toString()) ?? "";
    } catch {
      absolute = "";
    }
    if (!absolute) continue;
    push(innerText(match[2] ?? "") || attr(match[1] ?? "", "aria-label"), "link", absolute);
  }
  for (const match of cleaned.matchAll(/<label\b[^>]*>([\s\S]*?)<\/label>/gi)) {
    const inner = match[1] ?? "";
    const input = inner.match(/<(input|textarea)\b([^>]*)>/i);
    if (!input) continue;
    const name = attr(input[2] ?? "", "name");
    const type = attr(input[2] ?? "", "type").toLowerCase();
    if (type === "hidden" || type === "radio" || type === "checkbox") continue;
    const caption = innerText(inner.replace(/<(input|textarea)\b[^>]*>/gi, " "));
    push(caption || name || "field", type === "submit" ? "submit" : "field", "", name);
  }
  for (const match of cleaned.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/gi)) {
    const label = innerText(match[2] ?? "") || attr(match[1] ?? "", "aria-label") || "button";
    const type = attr(match[1] ?? "", "type").toLowerCase();
    const submit = type === "submit" || /submit|search|send|sign in|log in/i.test(label);
    push(label, submit ? "submit" : "button", "");
  }
  for (const match of cleaned.matchAll(/<input\b([^>]*)>/gi)) {
    const type = attr(match[1] ?? "", "type").toLowerCase();
    if (type === "hidden" || type === "radio" || type === "checkbox") continue;
    const name = attr(match[1] ?? "", "name");
    if (name && found.some((item) => item.name === name)) continue;
    const label =
      attr(match[1] ?? "", "aria-label") || attr(match[1] ?? "", "placeholder") || name || type || "field";
    push(label, type === "submit" ? "submit" : "field", "", name, attr(match[1] ?? "", "value"));
  }
  for (const match of cleaned.matchAll(/<textarea\b([^>]*)>/gi)) {
    const name = attr(match[1] ?? "", "name");
    if (name && found.some((item) => item.name === name)) continue;
    push(name || "notes", "field", "", name);
  }
  for (const match of cleaned.matchAll(/<select\b([^>]*)>([\s\S]*?)<\/select>/gi)) {
    const attrs = match[1] ?? "";
    const name = attr(attrs, "name");
    const id = attr(attrs, "id");
    const options = [...(match[2] ?? "").matchAll(/<option\b([^>]*)>([\s\S]*?)<\/option>/gi)]
      .map((option) => ({
        label: innerText(option[2] ?? "") || attr(option[1] ?? "", "value"),
        value: attr(option[1] ?? "", "value") || innerText(option[2] ?? ""),
      }))
      .filter((option) => option.label && !/^(select|choose|please)\b/i.test(option.label));
    if (options.length === 0) continue;
    const caption =
      forLabel(id) || attr(attrs, "aria-label") || captionBefore(match.index ?? 0) || name || "choice";
    push(
      `${caption}: ${options.map((option) => option.label).join(" | ")}`,
      "choice",
      "",
      name,
      "",
      caption,
      options,
    );
  }
  const radios = new Map<string, { label: string; value: string; index: number }[]>();
  for (const match of cleaned.matchAll(/<label\b[^>]*>([\s\S]*?)<\/label>/gi)) {
    const input = (match[1] ?? "").match(/<input\b([^>]*)>/i);
    if (!input || attr(input[1] ?? "", "type").toLowerCase() !== "radio") continue;
    const name = attr(input[1] ?? "", "name");
    if (!name) continue;
    const label = innerText((match[1] ?? "").replace(/<input\b[^>]*>/gi, " "));
    const value = attr(input[1] ?? "", "value") || label;
    const group = radios.get(name) ?? [];
    group.push({ label: label || value, value, index: match.index ?? 0 });
    radios.set(name, group);
  }
  for (const [name, group] of radios) {
    if (found.some((item) => item.name === name)) continue;
    const caption = captionBefore(group[0]?.index ?? 0) || name || "choice";
    const options = group.filter((option) => option.label);
    if (options.length === 0) continue;
    push(
      `${caption}: ${options.map((option) => option.label).join(" | ")}`,
      "choice",
      "",
      name,
      "",
      caption,
      options,
    );
  }
  return found.slice(0, 200);
}

function neededForTask(label: string, task: string): boolean {
  const job = task.toLowerCase();
  if (!job) return false;
  const text = label.toLowerCase().replace(/\s+/g, " ").trim();
  if (text.length > 2 && job.includes(text.slice(0, 40))) return true;
  return text
    .split(/[^a-z0-9]+/)
    .filter((word) => word.length > 3 && !/cookie|newsletter|subscribe|accept|dismiss|advertisement|thanks/.test(word))
    .some((word) => job.includes(word));
}

function clearPopups(controls: Control[], enabled: boolean, task = ""): { controls: Control[]; note: string } {
  if (!enabled) return { controls, note: "" };
  const blockers = controls.filter((item) => NAG.test(item.label) && !KEEP.test(item.label) && !neededForTask(item.label, task));
  if (blockers.length === 0 || blockers.length === controls.length) return { controls, note: "" };
  const gone = new Set(blockers);
  return {
    controls: controls.filter((item) => !gone.has(item)),
    note: `Cleared a blocking popup (${blockers[0]?.label ?? "dialog"}) so the page could be used.`,
  };
}

function formOf(html: string, base: string): { action: string; method: "get" | "post" } {
  const form = html.match(/<form\b([^>]*)>/i);
  if (!form) return { action: base, method: "get" };
  const method = (attr(form[1] ?? "", "method") || "get").toLowerCase() === "post" ? "post" : "get";
  const raw = attr(form[1] ?? "", "action");
  if (!raw) return { action: base, method };
  try {
    return { action: toUrl(new URL(raw, base).toString()) ?? base, method };
  } catch {
    return { action: base, method };
  }
}

function cellsFor(controls: Control[], scroll: number): AgentCell[] {
  const start = scroll * GRID_COLS;
  return controls.slice(start, start + GRID_COLS * GRID_ROWS).map((control, index) => ({
    c: index % GRID_COLS,
    r: Math.floor(index / GRID_COLS),
    items: [{ label: control.label, kind: control.kind }],
  }));
}

function maxScroll(count: number): number {
  return Math.max(0, Math.ceil(count / GRID_COLS) - GRID_ROWS);
}

interface Loaded {
  url: string;
  title: string;
  transcript: string;
  controls: Control[];
  error: string;
  formAction: string;
  formMethod: "get" | "post";
  popup: string;
  shot: string;
  helper: string;
}

function addedChoices(html: string): string {
  const selects = [...html.matchAll(/<select\b[\s\S]*?<\/select>/gi)].map((match) => match[0]);
  return selects.join("");
}

async function load(url: string, tape = "", closePopups = true, task = ""): Promise<Loaded> {
  let page = await readPublicDocument(url);
  let shot = "";
  let helper = "";
  if (typeof window === "undefined") {
    try {
      const live = await import("./live-page");
      const viewed = await live.renderLive(url, tape);
      if (viewed && viewed.html.length > 80) {
        shot = viewed.shot;
        helper = viewed.helper;
        const rendered = documentFromHtml(url, viewed.html);
        if (page.detail.trim().length < 40 && rendered.detail.trim().length > page.detail.trim().length) {
          page = rendered;
        } else if (page.html) {
          page = { ...page, html: `${page.html}${addedChoices(viewed.html)}` };
        } else {
          page = rendered;
        }
      }
    } catch {
      // The plain fetch still stands when a browser is not available.
    }
  }
  if (!page.ok && page.error) {
    return {
      url: page.address,
      title: page.title,
      transcript: page.detail,
      controls: [],
      error: page.error,
      formAction: page.address,
      formMethod: "get",
      popup: "",
      shot,
      helper,
    };
  }
  const form = formOf(page.html, page.address);
  const cleared = clearPopups(controlsFromHtml(page.html, page.address), closePopups, task);
  return {
    url: page.address,
    title: page.title,
    transcript: page.links.length
      ? `${page.detail}\nLINKS\n${page.links.map((link) => `- ${link.text}: ${link.url}`).join("\n")}`
      : page.detail,
    controls: cleared.controls,
    error: "",
    formAction: form.action,
    formMethod: form.method,
    popup: cleared.note,
    shot,
    helper,
  };
}

async function send(loaded: Loaded, closePopups = true, task = ""): Promise<Loaded | null> {
  const fields: Record<string, string> = {};
  for (const control of loaded.controls) {
    if (!control.name || !control.value) continue;
    if (control.kind === "field" || control.kind === "submit" || control.kind === "choice") fields[control.name] = control.value;
  }
  const page = await submitPublic(loaded.formAction || loaded.url, loaded.formMethod, fields);
  if (!page.ok && !page.detail) return null;
  const form = formOf(page.html, page.address);
  const cleared = clearPopups(controlsFromHtml(page.html, page.address), closePopups, task);
  return {
    url: page.address,
    title: page.title,
    transcript: page.detail,
    controls: cleared.controls,
    error: page.error,
    formAction: form.action,
    formMethod: form.method,
    popup: cleared.note,
    shot: loaded.shot,
    helper: loaded.helper,
  };
}

function view(loaded: Loaded, pointer: { c: number; r: number }, scroll: number, note: string): AgentState {
  return {
    ok: !loaded.error,
    error: loaded.error,
    url: loaded.url,
    title: loaded.title,
    transcript: loaded.transcript,
    pointer,
    scroll,
    cols: GRID_COLS,
    rows: GRID_ROWS,
    cells: cellsFor(loaded.controls, scroll),
    shot: loaded.shot,
    note,
  };
}

export async function runAgent(input: {
  url?: string;
  tape?: string;
  column?: number;
  row?: number;
  scroll?: number;
  closePopups?: boolean;
  task?: string;
}): Promise<AgentState> {
  const rawUrl = input.url?.trim() ?? "";
  const tape = input.tape?.trim() ?? "";
  const closePopups = input.closePopups !== false;
  const task = input.task?.trim() ?? "";
  const safe = rawUrl ? toUrl(rawUrl) : null;
  if (rawUrl && !safe) return fail("That address cannot be opened. Use a public http or https site.");
  if (!safe) return fail("Open a public site first.");

  let loaded = await load(safe, tape, closePopups, task);
  if (loaded.error && !loaded.transcript) return fail(loaded.error);

  let pointer = {
    c: Math.min(GRID_COLS - 1, Math.max(0, Math.floor(input.column ?? 0))),
    r: Math.min(GRID_ROWS - 1, Math.max(0, Math.floor(input.row ?? 0))),
  };
  let scroll = Math.max(0, Math.floor(input.scroll ?? 0));
  scroll = Math.min(scroll, maxScroll(loaded.controls.length));
  const steps = readTape(tape);
  let moved = false;

  for (const step of steps) {
    moved = true;
    if (step.kind === "type" || step.kind === "select") {
      const index = scroll * GRID_COLS + pointer.r * GRID_COLS + pointer.c;
      const control = loaded.controls[index];
      if (control?.options.length) {
        const want = step.text.trim().toLowerCase();
        const hit =
          control.options.find((option) => option.label.toLowerCase() === want || option.value.toLowerCase() === want) ??
          control.options.find((option) => option.label.toLowerCase().includes(want) || want.includes(option.label.toLowerCase()));
        const caption = control.caption || "choice";
        if (hit) {
          control.value = hit.value || hit.label;
          control.label = `${caption}: ${hit.label}`.slice(0, 160);
        } else {
          control.label = `${caption}: no match for ${step.text}`.slice(0, 160);
        }
      } else if (control && (control.kind === "field" || control.kind === "submit")) {
        control.value = step.text;
        control.label = `${control.label.replace(/: .*$/, "")}: ${step.text}`.slice(0, 60);
      }
      continue;
    }
    if (step.command === "left") pointer = { c: Math.max(0, pointer.c - 1), r: pointer.r };
    else if (step.command === "right") pointer = { c: Math.min(GRID_COLS - 1, pointer.c + 1), r: pointer.r };
    else if (step.command === "up") {
      if (pointer.r === 0) scroll = Math.max(0, scroll - 1);
      else pointer = { c: pointer.c, r: pointer.r - 1 };
    } else if (step.command === "down") {
      if (pointer.r === GRID_ROWS - 1) scroll = Math.min(maxScroll(loaded.controls.length), scroll + 1);
      else pointer = { c: pointer.c, r: pointer.r + 1 };
    } else {
      const index = scroll * GRID_COLS + pointer.r * GRID_COLS + pointer.c;
      const control = loaded.controls[index];
      if (control?.href && control.href !== loaded.url) {
        const next = await load(control.href, "", closePopups, task);
        if (!next.error || next.transcript) {
          loaded = next;
          pointer = { c: 0, r: 0 };
          scroll = 0;
        }
      } else if (control && (control.kind === "submit" || control.kind === "button") && !/\b(pay|purchase|buy|checkout)\b/i.test(control.label)) {
        const next = await send(loaded, closePopups, task);
        if (next && (!next.error || next.transcript)) {
          loaded = next;
          pointer = { c: 0, r: 0 };
          scroll = 0;
        }
      } else if (!control) {
        loaded.helper = `Clicked column ${pointer.c}, row ${pointer.r}.`;
      }
    }
  }

  const note = [
    loaded.popup,
    loaded.helper,
    `Opened ${loaded.url}`,
    moved ? `Ran ${steps.length} commands` : "",
    `Pointer at ${pointer.c},${pointer.r}`,
  ]
    .filter(Boolean)
    .join(". ");
  return view(loaded, pointer, scroll, note);
}
