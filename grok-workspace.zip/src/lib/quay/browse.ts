import { createServerFn } from "@tanstack/react-start";
import { toUrl } from "@/lib/quay/engine";
import { readPublicPage, type WebPage } from "@/lib/quay/read-page";

export type { WebPage };

export const loadWeb = createServerFn({ method: "POST" })
  .validator((input: unknown): { url: string } => {
    const raw = (input as { url?: unknown })?.url;
    if (typeof raw !== "string") throw new Error("Bad address");
    const url = toUrl(raw);
    if (!url) throw new Error("That address cannot be opened");
    return { url };
  })
  .handler(async ({ data }): Promise<WebPage> => readPublicPage(data.url));
