export type WorkerHealth = "REGISTERED" | "AVAILABLE" | "HEALTHY" | "BUSY" | "COOLDOWN" | "FAILED" | "OFFLINE";

type Stat = {
  ok: number;
  fail: number;
  timeout: number;
  lastOk: number;
  lastBeat: number;
  cooldownUntil: number;
  busyUntil: number;
};

const stats = new Map<string, Stat>();

function row(id: string): Stat {
  const existing = stats.get(id);
  if (existing) return existing;
  const created: Stat = { ok: 0, fail: 0, timeout: 0, lastOk: 0, lastBeat: 0, cooldownUntil: 0, busyUntil: 0 };
  stats.set(id, created);
  return created;
}

export function noteWorker(id: string, kind: "ok" | "fail" | "timeout" | "busy"): void {
  if (!id) return;
  const stat = row(id);
  const now = Date.now();
  stat.lastBeat = now;
  if (kind === "ok") {
    stat.ok += 1;
    stat.lastOk = now;
    stat.busyUntil = 0;
    stat.cooldownUntil = 0;
  } else if (kind === "timeout") {
    stat.timeout += 1;
    stat.fail += 1;
    stat.busyUntil = 0;
    stat.cooldownUntil = now + 45_000;
  } else if (kind === "fail") {
    stat.fail += 1;
    stat.busyUntil = 0;
    stat.cooldownUntil = now + 45_000;
  } else {
    stat.busyUntil = now + 20_000;
  }
}

export function healthOf(id: string, registered: boolean, hasKey: boolean, now = Date.now()): WorkerHealth {
  if (!registered) return "OFFLINE";
  if (!hasKey) return "OFFLINE";
  const stat = stats.get(id);
  if (!stat) return "REGISTERED";
  if (stat.busyUntil > now) return "BUSY";
  if (stat.cooldownUntil > now) return stat.timeout > stat.ok ? "FAILED" : "COOLDOWN";
  if (stat.lastOk > 0 && now - stat.lastOk < 10 * 60_000) return "HEALTHY";
  if (stat.lastBeat > 0 && now - stat.lastBeat < 10 * 60_000) return "AVAILABLE";
  return "REGISTERED";
}

export function routable(id: string, registered: boolean, hasKey: boolean, now = Date.now()): boolean {
  const health = healthOf(id, registered, hasKey, now);
  return health === "HEALTHY" || health === "AVAILABLE" || health === "REGISTERED";
}

export function leaseUntil(now = Date.now(), ms = 20_000): number {
  return now + ms;
}

export function leaseExpired(expiresAt: number, now = Date.now()): boolean {
  return expiresAt > 0 && now >= expiresAt;
}
