import { toUrl } from "@/lib/quay/engine";

export interface WebPage {
  ok: boolean;
  address: string;
  title: string;
  detail: string;
}

export interface PageLink {
  text: string;
  url: string;
}

function decode(value: string): string {
  let current = value;
  for (let pass = 0; pass < 3; pass += 1) {
    const next = current
      .replace(/\u0026nbsp;/gi, " ")
      .replace(/\u0026quot;/gi, '"')
      .replace(/&#0*34;/g, '"')
      .replace(/\u0026apos;/gi, "'")
      .replace(/&#0*39;/g, "'")
      .replace(/\u0026amp;/gi, "&");
    if (next === current) break;
    current = next;
  }
  return current.replace(/\s+/g, " ").trim();
}

function stripped(html: string): string {
  return html
    .replace(/<script\b[\s\S]*?<\/script>/gi, " ")
    .replace(/<style\b[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript\b[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<svg\b[\s\S]*?<\/svg>/gi, " ")
    .replace(/<nav\b[\s\S]*?<\/nav>/gi, " ")
    .replace(/<header\b[\s\S]*?<\/header>/gi, " ")
    .replace(/<footer\b[\s\S]*?<\/footer>/gi, " ")
    .replace(/<aside\b[\s\S]*?<\/aside>/gi, " ")
    .replace(/<form\b[\s\S]*?<\/form>/gi, " ")
    .replace(/<[^>]+(?:cookie|consent|banner)[^>]*>[\s\S]*?<\/[a-z0-9]+>/gi, " ");
}

function readableHtml(html: string): string {
  const cleaned = stripped(html);
  return (
    cleaned.match(/<main\b[^>]*>([\s\S]*?)<\/main>/i)?.[1] ??
    cleaned.match(/<article\b[^>]*>([\s\S]*?)<\/article>/i)?.[1] ??
    cleaned.match(/<body\b[^>]*>([\s\S]*?)<\/body>/i)?.[1] ??
    cleaned
  );
}

function linkText(raw: string): string {
  return decode(raw.replace(/<[^>]+>/g, " ")).slice(0, 80);
}

function collectLinks(html: string, base: string): PageLink[] {
  const found: PageLink[] = [];
  for (const match of html.matchAll(/<a\b([^>]*?)>([\s\S]*?)<\/a>/gi)) {
    const href = match[1]?.match(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i);
    const raw = (href?.[1] ?? href?.[2] ?? href?.[3] ?? "").trim();
    if (!raw || raw.startsWith("#") || /^javascript:/i.test(raw)) continue;
    let absolute = "";
    try {
      absolute = toUrl(new URL(raw, base).toString()) ?? "";
    } catch {
      absolute = "";
    }
    if (!absolute) continue;
    const text = linkText(match[2] ?? "") || absolute;
    if (found.some((item) => item.url === absolute)) continue;
    found.push({ text, url: absolute });
  }
  return found;
}

export function linksFromHtml(html: string, base: string): PageLink[] {
  const host = (() => {
    try {
      return new URL(base).hostname.replace(/^www\./, "");
    } catch {
      return "";
    }
  })();
  const inArticle = collectLinks(readableHtml(html), base);
  const rest = collectLinks(html, base).filter((link) => !inArticle.some((item) => item.url === link.url));
  const found = [...inArticle, ...rest];
  found.sort((left, right) => {
    const leftHome = left.url.includes(host) ? 0 : 1;
    const rightHome = right.url.includes(host) ? 0 : 1;
    if (leftHome !== rightHome) return leftHome - rightHome;
    const leftMain = inArticle.some((item) => item.url === left.url) ? 0 : 1;
    const rightMain = inArticle.some((item) => item.url === right.url) ? 0 : 1;
    return leftMain - rightMain;
  });
  return found.slice(0, 40);
}

function textFromHtml(html: string): { title: string; detail: string } {
  const title = decode(html.match(/<title>([^<]+)<\/title>/i)?.[1] ?? "Page");
  const detail = decode(readableHtml(html).replace(/<[^>]+>/g, " ")).slice(0, 15_000);
  return { title, detail };
}

async function readPublic(start: string): Promise<{ ok: boolean; finalUrl: string; html: string }> {
  let current = start;
  for (let hop = 0; hop < 3; hop += 1) {
    const response = await fetch(current, {
      redirect: "manual",
      headers: {
        Accept: "text/html,application/xhtml+xml,application/json",
        "Accept-Language": "en",
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      },
    });
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      if (!location) return { ok: false, finalUrl: current, html: "" };
      const next = toUrl(new URL(location, current).toString());
      if (!next) return { ok: false, finalUrl: current, html: "" };
      current = next;
      continue;
    }
    const html = (await response.text()).slice(0, 200_000);
    return { ok: response.ok, finalUrl: current, html };
  }
  return { ok: false, finalUrl: current, html: "" };
}

export interface PublicDocument {
  ok: boolean;
  address: string;
  title: string;
  detail: string;
  html: string;
  links: PageLink[];
  error: string;
}

export async function readPublicDocument(raw: string): Promise<PublicDocument> {
  const url = toUrl(raw);
  if (!url) {
    return {
      ok: false,
      address: raw,
      title: "Page",
      detail: "",
      html: "",
      links: [],
      error: "That address cannot be opened. Use a public http or https site.",
    };
  }
  try {
    const page = await readPublic(url);
    const text = textFromHtml(page.html);
    return {
      ok: page.ok && Boolean(page.html),
      address: page.finalUrl,
      title: text.title || "Page",
      detail: text.detail || "The page opened, but it had no readable text.",
      html: page.html,
      links: linksFromHtml(page.html, page.finalUrl),
      error: page.ok ? "" : "The site did not answer.",
    };
  } catch {
    return {
      ok: false,
      address: url,
      title: "Page",
      detail: "",
      html: "",
      links: [],
      error: "The site did not answer.",
    };
  }
}

export function documentFromHtml(address: string, html: string): PublicDocument {
  const text = textFromHtml(html);
  return {
    ok: Boolean(html),
    address,
    title: text.title || "Page",
    detail: text.detail || "The page opened, but it had no readable text.",
    html,
    links: linksFromHtml(html, address),
    error: html ? "" : "The site did not answer.",
  };
}

export async function readCleanPage(raw: string): Promise<{ url: string; text: string; links: PageLink[] } | null> {
  const page = await readPublicDocument(raw);
  if (!toUrl(raw) && !page.ok) return null;
  if (page.detail.trim().length < 20 && page.links.length === 0) return null;
  return { url: page.address, text: page.detail, links: page.links };
}

export async function readPublicPage(raw: string): Promise<WebPage> {
  const page = await readPublicDocument(raw);
  return {
    ok: page.ok,
    address: page.address,
    title: page.title,
    detail: page.detail || page.error || "The site did not answer.",
  };
}

export async function submitPublic(
  action: string,
  method: "get" | "post",
  fields: Record<string, string>,
): Promise<PublicDocument> {
  const url = toUrl(action);
  if (!url) {
    return {
      ok: false,
      address: action,
      title: "Page",
      detail: "",
      html: "",
      links: [],
      error: "That form cannot be sent.",
    };
  }
  if (method !== "post") {
    const next = new URL(url);
    for (const [key, value] of Object.entries(fields)) next.searchParams.set(key, value);
    const safe = toUrl(next.toString());
    if (!safe) {
      return {
        ok: false,
        address: url,
        title: "Page",
        detail: "",
        html: "",
        links: [],
        error: "That form cannot be sent.",
      };
    }
    return readPublicDocument(safe);
  }
  try {
    let current = url;
    for (let hop = 0; hop < 3; hop += 1) {
      const response = await fetch(current, {
        method: hop === 0 ? "POST" : "GET",
        redirect: "manual",
        headers: {
          Accept: "text/html,application/xhtml+xml,application/json",
          "Accept-Language": "en",
          ...(hop === 0 ? { "Content-Type": "application/x-www-form-urlencoded" } : {}),
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        },
        ...(hop === 0 ? { body: new URLSearchParams(fields).toString() } : {}),
      });
      if (response.status >= 300 && response.status < 400) {
        const location = response.headers.get("location");
        if (!location) break;
        const next = toUrl(new URL(location, current).toString());
        if (!next) break;
        current = next;
        continue;
      }
      const html = (await response.text()).slice(0, 200_000);
      const text = textFromHtml(html);
      return {
        ok: response.ok,
        address: current,
        title: text.title || "Page",
        detail: text.detail || html.slice(0, 2000),
        html,
        links: linksFromHtml(html, current),
        error: response.ok ? "" : "The form was not accepted.",
      };
    }
  } catch {
    return {
      ok: false,
      address: url,
      title: "Page",
      detail: "",
      html: "",
      links: [],
      error: "The form did not go through.",
    };
  }
  return {
    ok: false,
    address: url,
    title: "Page",
    detail: "",
    html: "",
    links: [],
    error: "The form did not go through.",
  };
}
