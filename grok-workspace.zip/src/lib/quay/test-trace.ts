import { auditLines } from "@/lib/quay/job-audit";

type Miss = { step: number; first: string; fix: string };

type Hire = { step: number; name: string; role: string; used: boolean; helped: boolean };

type Trace = {
  model: string;
  started: number;
  cycles: number;
  loops: number;
  misses: Miss[];
  hires: Hire[];
};

const traces = new Map<string, Trace>();

export function beginTrace(job: string, model: string): void {
  traces.set(job || "page", { model, started: Date.now(), cycles: 0, loops: 0, misses: [], hires: [] });
}

export function noteCycle(job: string): void {
  const trace = traces.get(job || "page");
  if (trace) trace.cycles += 1;
}

export function noteLoop(job: string): void {
  const trace = traces.get(job || "page");
  if (trace) trace.loops += 1;
}

export function noteMiss(job: string, step: number, first: string): void {
  const trace = traces.get(job || "page");
  if (!trace || trace.misses.some((miss) => miss.step === step)) return;
  trace.misses.push({ step, first: first.replace(/\s+/g, " ").trim().slice(0, 180), fix: "" });
}

export function noteFix(job: string, step: number, fix: string): void {
  const trace = traces.get(job || "page");
  const miss = trace?.misses.find((row) => row.step === step);
  if (miss) miss.fix = fix.replace(/\s+/g, " ").trim().slice(0, 180);
}

export function noteHire(job: string, step: number, name: string, role: string, used = true): void {
  const trace = traces.get(job || "page");
  const clean = name.replace(/\s+/g, " ").trim().slice(0, 120);
  if (!trace || !clean) return;
  const existing = trace.hires.find((hire) => hire.step === step && hire.name === clean && hire.role === role);
  if (existing) {
    if (used) existing.used = true;
    return;
  }
  trace.hires.push({ step, name: clean, role, used, helped: false });
}

export function passHires(job: string, step: number): void {
  const trace = traces.get(job || "page");
  if (!trace) return;
  for (const hire of trace.hires) {
    if (hire.step === step && hire.used) hire.helped = true;
  }
}

export function finishTrace(job: string, pass: boolean): string {
  const trace = traces.get(job || "page");
  traces.delete(job || "page");
  if (!trace) return "";
  const seconds = Math.max(1, Math.round((Date.now() - trace.started) / 1000));
  const lines = [`Model: ${trace.model}`, `Cycles: ${trace.cycles}. Redundancy loops: ${trace.loops}.`];
  if (trace.misses.length === 0) lines.push("No step failed.");
  for (const miss of trace.misses) {
    lines.push(`Step ${miss.step} failed first: ${miss.first || "threshold"}. Fix: ${miss.fix || "still open"}.`);
  }
  if (trace.hires.length === 0) lines.push("No bots hired.");
  for (const hire of trace.hires) {
    lines.push(`Hired: ${hire.name} · ${hire.role} · ${hire.helped ? "led to a pass" : "did not lead to a pass"}.`);
  }
  lines.push(...auditLines(job));
  lines.push(`Time: ${seconds}s`);
  lines.push(pass ? "PASS" : "FAIL");
  return lines.join("\n");
}