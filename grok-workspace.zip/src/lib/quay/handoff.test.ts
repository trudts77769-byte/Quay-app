import assert from "node:assert/strict";
import { test } from "node:test";
import { followerPacket, intentMiss } from "./intent.ts";
import { activeTasks, isClosed, nextDeliveryDelay, noteTask, openTask, readTask, taskIdFor, updateTask } from "./task-ledger.ts";
import { healthOf, leaseExpired, noteWorker, routable } from "./worker-health.ts";

test("a read acknowledges the task and does not complete it", () => {
  const id = taskIdFor("chan-a", "Look up the current homepage title of https://example.com");
  const task = openTask({ task_id: id, channel_id: "chan-a", task: "Look up the current homepage title of https://example.com", task_type: "WEB_TASK" });
  updateTask(id, { status: "ACKNOWLEDGED" });
  noteTask(id, "Quay acknowledged");
  const saved = readTask(id);
  assert.equal(saved?.status, "ACKNOWLEDGED");
  assert.equal(isClosed(saved?.status || "QUEUED"), false);
  assert.equal(activeTasks().some((row) => row.task_id === id), true);
  assert.equal(task.task_id, id);
  assert.notEqual(saved?.status, "COMPLETED");
});

test("the same task id does not start a second record", () => {
  const id = taskIdFor("chan-b", "same order");
  const first = openTask({ task_id: id, channel_id: "chan-b", task: "same order", task_type: "NON_WEB_TASK" });
  updateTask(id, { status: "WORKER_RUNNING", attempt: 1 });
  const second = openTask({ task_id: id, channel_id: "chan-b", task: "same order", task_type: "NON_WEB_TASK" });
  assert.equal(second.task_id, first.task_id);
  assert.equal(readTask(id)?.status, "WORKER_RUNNING");
  assert.equal(readTask(id)?.attempt, 1);
});

test("delivery retries are bounded", () => {
  assert.deepEqual([0, 1, 2, 3].map((attempt) => nextDeliveryDelay(attempt)), [0, 2000, 5000, 15000]);
  assert.equal(nextDeliveryDelay(4), null);
});

test("a stalled worker is not treated as healthy", () => {
  assert.equal(healthOf("worker-airforce", true, true), "REGISTERED");
  assert.equal(routable("worker-airforce", true, true), true);
  noteWorker("worker-airforce", "timeout");
  assert.equal(routable("worker-airforce", true, true), false);
  assert.equal(healthOf("worker-missing", false, false), "OFFLINE");
  assert.equal(leaseExpired(Date.now() - 1000), true);
  assert.equal(leaseExpired(Date.now() + 10_000), false);
});

test("a literature word is not a dictionary answer", () => {
  const miss = intentMiss("longest word in the English dictionary", "pneumonoultramicroscopicsilicovolcanoconiosis from Aristophanes");
  assert.match(miss, /dictionary/);
  assert.equal(intentMiss("homepage title of https://example.com", "Example Domain"), "");
  assert.match(intentMiss("homepage title of https://example.com", "IANA"), /Example Domain/);
});

test("a follower packet stays narrow", () => {
  const history = "CHIEF HISTORY ".repeat(400);
  const packet = followerPacket({
    task: "Look up the current homepage title of https://example.com",
    goal: "report the exact title",
    url: "https://example.com",
    transcript: "Example Domain",
    actions: "OPEN https://example.com",
  });
  assert.equal(packet.includes(history.slice(0, 40)), false);
  assert.ok(packet.length < history.length / 2);
  assert.match(packet, /Example Domain/);
});

test("sandbox failure stays visible until a later close", () => {
  const id = taskIdFor("chan-c", "sandbox down");
  openTask({ task_id: id, channel_id: "chan-c", task: "sandbox down", task_type: "WEB_TASK" });
  updateTask(id, { status: "SANDBOX_FAILED", error: "sandbox did not open" });
  assert.equal(activeTasks().some((row) => row.task_id === id), true);
  updateTask(id, { status: "EXHAUSTED" });
  assert.equal(isClosed("EXHAUSTED"), true);
  assert.equal(activeTasks().some((row) => row.task_id === id), false);
});
