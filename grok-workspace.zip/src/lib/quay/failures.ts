import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

export type FailRow = {
  id: string;
  at: string;
  taskType: string;
  source: string;
  step: number;
  model: string;
  wrong: string;
  fixes: string[];
  worked: string;
};

const file = join(process.cwd(), "data", "failure-repository.json");
const openIds = new Map<string, string>();
let rows: FailRow[] = [];
let loaded = false;

function load(): void {
  if (loaded) return;
  loaded = true;
  try {
    if (!existsSync(file)) return;
    const parsed = JSON.parse(readFileSync(file, "utf8")) as unknown;
    if (Array.isArray(parsed)) rows = parsed as FailRow[];
  } catch {
    rows = [];
  }
}

function persist(): void {
  try {
    mkdirSync(join(process.cwd(), "data"), { recursive: true });
    writeFileSync(file, JSON.stringify(rows));
  } catch {
    /* the in-memory list still holds the entry */
  }
}

export function taskTypeOf(text: string): string {
  if (/https?:\/\/|\b[a-z0-9-]+\.(com|org|net|io|me)\b/i.test(text)) return "website";
  if (/\bsearch\b/i.test(text)) return "search";
  return "question";
}

export function sourceOf(text: string): string {
  const url = text.match(/https?:\/\/[^\s)>\]]+/i)?.[0] ?? "";
  if (url) {
    try {
      return new URL(url).host.replace(/^www\./, "").toLowerCase();
    } catch {
      return url.slice(0, 80);
    }
  }
  return text.match(/\b([a-z0-9-]+\.(?:com|org|net|io|me))\b/i)?.[1]?.toLowerCase() ?? "";
}

export function isWebsiteTask(text: string): boolean {
  return taskTypeOf(text) === "website";
}

function words(text: string): string[] {
  return text.toLowerCase().match(/[a-z]{5,}/g)?.slice(0, 12) ?? [];
}

export function searchFailures(taskType: string, source: string, error: string): { used: FailRow[]; worked: string[]; skip: string[] } {
  load();
  const errWords = new Set(words(error));
  const host = source.toLowerCase();
  const used = rows.filter((row) => {
    if (taskType && row.taskType === taskType) return true;
    if (host && row.source && (row.source === host || row.source.includes(host) || host.includes(row.source))) return true;
    if (errWords.size === 0) return false;
    return words(`${row.wrong} ${row.fixes.join(" ")}`).some((word) => errWords.has(word));
  });
  const worked: string[] = [];
  const skip: string[] = [];
  for (const row of used) {
    if (row.worked && row.worked !== "none yet") worked.push(row.worked);
    else skip.push(...row.fixes);
  }
  const workedUnique = [...new Set(worked)].slice(0, 6);
  return {
    used,
    worked: workedUnique,
    skip: [...new Set(skip)].filter((item) => !workedUnique.includes(item)).slice(0, 6),
  };
}

export function lessonText(found: { worked: string[]; skip: string[] }): string {
  const lines: string[] = [];
  if (found.worked.length > 0) lines.push(`Try these fixes first:\n${found.worked.map((item) => `- ${item}`).join("\n")}`);
  if (found.skip.length > 0) lines.push(`Skip these. They already failed:\n${found.skip.map((item) => `- ${item}`).join("\n")}`);
  return lines.join("\n");
}

export function recordFailure(input: { taskType: string; source: string; step: number; model: string; wrong: string }): string {
  load();
  const wrong = input.wrong.replace(/\s+/g, " ").trim().slice(0, 240);
  const existing = rows.find(
    (row) => row.worked === "none yet" && row.step === input.step && row.model === input.model && row.source === input.source && row.wrong === wrong,
  );
  if (existing) return existing.id;
  const row: FailRow = {
    id: `${Date.now().toString(36)}-${rows.length}`,
    at: new Date().toISOString(),
    taskType: input.taskType.slice(0, 40),
    source: input.source.slice(0, 120),
    step: input.step,
    model: input.model.slice(0, 80),
    wrong,
    fixes: [],
    worked: "none yet",
  };
  rows.push(row);
  persist();
  return row.id;
}

export function rememberOpen(job: string, step: number, id: string): void {
  openIds.set(`${job}:${step}`, id);
}

function openRow(job: string, step: number): FailRow | undefined {
  load();
  const id = openIds.get(`${job}:${step}`);
  return rows.find((row) => row.id === id);
}

export function addFix(job: string, step: number, fix: string): void {
  const row = openRow(job, step);
  const clean = fix.replace(/\s+/g, " ").trim().slice(0, 240);
  if (!row || !clean || row.fixes.includes(clean)) return;
  row.fixes.push(clean);
  persist();
}

export function markWorked(job: string, step: number, fix: string): void {
  const row = openRow(job, step);
  if (!row) return;
  const clean = fix.replace(/\s+/g, " ").trim().slice(0, 240);
  if (clean && !row.fixes.includes(clean)) row.fixes.push(clean);
  row.worked = clean || row.fixes.at(-1) || "none yet";
  persist();
}
