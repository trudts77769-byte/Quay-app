const stored = "e2b_34f38e3d9c8513d75146cbd852dd0ac4eae4eb82";

export async function resolveE2bKey(): Promise<string> {
  const fromEnv = process.env.E2B_API_KEY?.trim() ?? "";
  if (fromEnv) return fromEnv;
  if (stored) process.env.E2B_API_KEY = stored;
  return stored;
}

