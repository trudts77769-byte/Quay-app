import { allModels } from "@/lib/quay/catalog";
import { callSpace } from "@/lib/quay/gradio";
import { markFromCall, statusOf, type ModelStatus } from "@/lib/quay/model-status";
import { readSecret, scrubSecrets } from "@/lib/quay/secrets";
import { estimateTokens, recordUsage, withinSpend } from "@/lib/quay/usage";
import { unreadFor } from "@/lib/quay/veil-register";
import { noteWorker, routable } from "@/lib/quay/worker-health";

export interface Message {
  role: "system" | "user" | "assistant";
  content: string;
  image?: string;
}

export type CallResult = {
  text: string | null;
  failed: boolean;
  reason: string;
  inputTokens: number;
  outputTokens: number;
  estimated: boolean;
};

export interface Source {
  name: string;
  side: "chief" | "follower";
  local: boolean;
  call: (messages: Message[]) => Promise<CallResult>;
}

export function emptyCall(reason: string, estimated = true): CallResult {
  return { text: null, failed: true, reason, inputTokens: 0, outputTokens: 0, estimated };
}

export async function complete(url: string, model: string, messages: Message[], key = ""): Promise<CallResult> {
  const prompt = messages.map((item) => item.content).join("\n");
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(key ? { Authorization: `Bearer ${key}` } : {}),
      },
      signal: AbortSignal.timeout(15000),
      body: JSON.stringify({
        model,
        max_tokens: 500,
        messages: messages.map((item) =>
          item.image
            ? {
                role: item.role,
                content: [
                  { type: "text", text: item.content },
                  { type: "image_url", image_url: { url: `data:image/jpeg;base64,${item.image}` } },
                ],
              }
            : { role: item.role, content: item.content },
        ),
      }),
    });
    if (!response.ok) {
      const reason = response.status === 429 ? "429" : `http-${response.status}`;
      return emptyCall(reason);
    }
    const body = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
      usage?: { prompt_tokens?: number; completion_tokens?: number };
    };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    const reportedIn = body.usage?.prompt_tokens;
    const reportedOut = body.usage?.completion_tokens;
    const estimated = reportedIn == null && reportedOut == null;
    const command = /^(open|click|type|scroll|back|wait|done|fail)\b/i.test(text) || /^\s*\{/.test(text);
    const kept = command ? text.length > 0 : text.length >= 8;
    const result: CallResult = {
      text: kept ? scrubSecrets(text.slice(0, 1500)) : null,
      failed: /api key|rate limit|unauthorized|quota|budget exceeded/i.test(text),
      reason: /rate limit|quota/i.test(text) ? "quota" : text ? "" : "empty",
      inputTokens: reportedIn ?? estimateTokens(prompt),
      outputTokens: reportedOut ?? estimateTokens(text),
      estimated,
    };
    if (result.failed) result.text = null;
    return result;
  } catch (error) {
    const name = error instanceof Error ? error.name : "";
    const message = error instanceof Error ? scrubSecrets(error.message).slice(0, 80) : "network";
    if (name === "TimeoutError" || name === "AbortError" || /timeout|aborted/i.test(message)) return emptyCall("timeout");
    return emptyCall(message ? `down: ${message}` : "down");
  }
}

export function sources(): Source[] {
  const keyed = (name: string, url: string, model: string, secret: string, side: "chief" | "follower"): Source => ({
    name,
    side,
    local: false,
    call: (messages) => {
      const key = readSecret(secret);
      if (!key) return Promise.resolve(emptyCall("no-key"));
      return complete(url, model, messages, key);
    },
  });
  const list: Source[] = [
    keyed("worker-gemini", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "gemini-2.0-flash", "GEMINI_API_KEY", "chief"),
    keyed("worker-openrouter", "https://openrouter.ai/api/v1/chat/completions", "google/gemma-4-26b-a4b-it:free", "OPENROUTER_API_KEY", "follower"),
    keyed("worker-openrouter-2", "https://openrouter.ai/api/v1/chat/completions", "inclusionai/ling-3.0-flash-sante:free", "OPENROUTER_API_KEY", "follower"),
    keyed("worker-hf", "https://router.huggingface.co/v1/chat/completions", "Qwen/Qwen2.5-7B-Instruct", "HF_TOKEN", "follower"),
    {
      name: "worker-ovh",
      side: "follower",
      local: false,
      call: (messages) => complete("https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/chat/completions", "gpt-oss-20b", messages),
    },
    {
      name: "worker-airforce",
      side: "follower",
      local: false,
      call: (messages) => complete("https://api.airforce/v1/chat/completions", "rnj-1", messages),
    },
    {
      name: "worker-airforce-2",
      side: "follower",
      local: false,
      call: (messages) => complete("https://api.airforce/v1/chat/completions", "llama-instant", messages),
    },
    {
      name: "worker-pollinations",
      side: "follower",
      local: false,
      call: async (messages) => {
        const latest = [...messages].reverse().find((message) => message.role === "user")?.content ?? "";
        try {
          const response = await fetch(`https://text.pollinations.ai/${encodeURIComponent(latest.slice(0, 1500))}`);
          if (!response.ok) return emptyCall(response.status === 429 ? "429" : `http-${response.status}`);
          const text = scrubSecrets((await response.text()).trim());
          if (text.length < 8) return emptyCall("empty");
          return {
            text: text.slice(0, 1500),
            failed: /api key|quota|budget/i.test(text),
            reason: "",
            inputTokens: estimateTokens(latest),
            outputTokens: estimateTokens(text),
            estimated: true,
          };
        } catch (error) {
          return emptyCall(error instanceof Error ? error.message.slice(0, 80) : "network");
        }
      },
    },
    keyed("worker-xai", "https://api.x.ai/v1/chat/completions", "grok-4.5", "XAI_API_KEY", "chief"),
    keyed("worker-groq", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "GROQ_API_KEY", "follower"),
  ];
  const local = readSecret("LOCAL_OPENAI_URL") || readSecret("OPENAI_COMPAT_URL");
  if (local && /^https?:\/\//i.test(local)) {
    list.push({
      name: "worker-local",
      side: "follower",
      local: true,
      call: (messages) => complete(local, readSecret("LOCAL_OPENAI_MODEL") || "local", messages, readSecret("LOCAL_OPENAI_KEY")),
    });
  }
  return list;
}

export type FreeModel = { id: string; label: string; group: string; status: ModelStatus };

export function freeModels(): FreeModel[] {
  return allModels().map((row) => ({
    id: row.id,
    label: row.label,
    group: row.group,
    status: statusOf(row.id),
  }));
}

const pins = new Map<string, string>();

export function pinModel(job: string, model: string): void {
  const id = freeModels().some((row) => row.id === model) ? model : "";
  if (!id) pins.delete(job || "page");
  else pins.set(job || "page", id);
}

export function clearPin(job: string): void {
  pins.delete(job || "page");
}

export function pinnedModel(job: string): string {
  return pins.get(job || "page") ?? "";
}

export function followerKind(id: string): "VISION_BROWSER_FOLLOWER" | "TEXT_BROWSER_FOLLOWER" {
  return id === "worker-xai" || id === "worker-gemini" ? "VISION_BROWSER_FOLLOWER" : "TEXT_BROWSER_FOLLOWER";
}

export function outsideProviders(): Source[] {
  return sources().filter((source) => !source.local);
}

export function localProvider(): Source | null {
  return sources().find((source) => source.local) ?? null;
}

function remember(
  job: string,
  slot: string,
  source: Source,
  called: CallResult,
  started: number,
): void {
  recordUsage({
    at: new Date().toISOString(),
    job,
    slot,
    follower: source.name,
    provider: source.name,
    side: source.side,
    inputTokens: called.inputTokens,
    outputTokens: called.outputTokens,
    estimated: called.estimated,
    wallMs: Date.now() - started,
    modelCalls: 1,
    ok: Boolean(called.text) && !called.failed,
  });
}

export async function callCheap(job: string, messages: Message[]): Promise<string | null> {
  const pin = pinnedModel(job);
  if (pin) {
    if (!withinSpend(job, 0)) return null;
    const called = await runModel(job, "planner", pin, messages, false);
    if (called.reason === "no-key") return null;
    return called.text;
  }
  const all = outsideProviders();
  const chief = [
    ...all.filter((source) => source.name === "worker-xai"),
    ...all.filter((source) => source.name === "worker-gemini"),
    ...all.filter((source) => source.name.startsWith("worker-openrouter")),
    ...all.filter((source) => source.name.startsWith("worker-hf")),
  ];
  for (const source of chief) {
    if (!withinSpend(job, 0)) return null;
    const started = Date.now();
    const called = await source.call(messages);
    remember(job, "planner", source, called, started);
    markFromCall(source.name, called);
    if (called.reason === "no-key") continue;
    if (called.text) return called.text;
  }
  return null;
}

export function cannotDo(reason: string, text: string | null): boolean {
  if (/429|quota|http-401|http-402|http-403|http-5|network|no-key|down|unable|timeout/.test(reason)) return true;
  return Boolean(text && /^(i'?m sorry|i can'?t|i cannot|i do not have the ability)/i.test(text.trim()));
}

async function once(
  job: string,
  slot: string,
  source: Source,
  messages: Message[],
): Promise<{ called: CallResult; follower: string }> {
  if (!withinSpend(job, source.side === "chief" ? 1 : 0)) {
    return { called: emptyCall("spend"), follower: source.name };
  }
  const started = Date.now();
  const called = await source.call(messages);
  remember(job, slot, source, called, started);
  markFromCall(source.name, called);
  if (called.reason === "timeout") noteWorker(source.name, "timeout");
  else if (called.text && !called.failed) noteWorker(source.name, "ok");
  else if (called.reason && called.reason !== "no-key" && called.reason !== "spend") noteWorker(source.name, "fail");
  return { called, follower: source.name };
}

async function withPings(id: string, messages: Message[]): Promise<Message[]> {
  try {
    const text = await unreadFor(id);
    if (!text) return messages;
    return [...messages, { role: "user", content: `UNREAD PINGS\n${text}` }];
  } catch {
    return messages;
  }
}

export async function runModel(job: string, slot: string, id: string, messages: Message[], pings: boolean): Promise<CallResult> {
  const packed = pings ? await withPings(id, messages) : messages;
  const source = sources().find((item) => item.name === id);
  if (source) {
    const { called } = await once(job, slot, source, packed);
    return called;
  }
  if (id.startsWith("hf:")) {
    const called = await callSpace(id.slice(3), packed);
    const full: CallResult = { ...called, inputTokens: 0, outputTokens: 0, estimated: true };
    markFromCall(id, full);
    return full;
  }
  const missing = emptyCall("no-key");
  markFromCall(id, missing);
  return missing;
}

export async function callFollower(
  job: string,
  slot: string,
  messages: Message[],
  onSwitch?: (previous: string, next: string, reason: string) => Promise<void>,
  prefer?: string,
  skip: string[] = [],
): Promise<{ text: string | null; follower: string; reason: string; tried: string[] }> {
  const pin = pinnedModel(job);
  if (pin) {
    const called = await runModel(job, slot, pin, messages, true);
    return {
      text: called.text,
      follower: pin,
      reason: called.reason || (called.text ? "" : "empty"),
      tried: [pin],
    };
  }
  const cap = Number(process.env.QUAY_HIRE_FAILOVER_MAX ?? 3);
  const skipped = new Set(skip);
  const all = outsideProviders().filter((source) => !skipped.has(source.name));
  const alive = (source: Source) => routable(source.name, true, statusOf(source.name) !== "Key missing");
  const pool = [
    ...all.filter((source) => /xai|groq/.test(source.name)),
    ...all.filter((source) => /openrouter|hf/.test(source.name)),
    ...all.filter((source) => /ovh|airforce|pollinations/.test(source.name)),
    ...all.filter((source) => source.name === "worker-gemini"),
  ].filter(alive);
  const local = localProvider();
  const tried: string[] = [];
  let switches = 0;
  let lastReason = "empty";
  const held = prefer ? sources().find((source) => source.name === prefer && !skipped.has(source.name)) : undefined;
  if (held) {
    tried.push(held.name);
    const noted = await withPings(held.name, messages);
    const { called } = await once(job, slot, held, noted);
    if (called.reason === "no-key") {
      lastReason = "no-key";
    } else if (!cannotDo(called.reason, called.text)) {
      return { text: called.text, follower: held.name, reason: called.reason || (called.text ? "" : "empty"), tried };
    } else {
      lastReason = cannotDo("", called.text) ? "unable" : called.reason || "down";
      const next = pool.find((source) => source.name !== held.name) ?? (local && local.name !== held.name ? local : undefined);
      if (next && onSwitch) await onSwitch(held.name, next.name, lastReason);
    }
  }
  for (let index = 0; index < pool.length; index += 1) {
    const source = pool[index];
    if (source.name === held?.name) continue;
    tried.push(source.name);
    const noted = await withPings(source.name, messages);
    const { called } = await once(job, slot, source, noted);
    if (called.reason === "no-key") continue;
    if (called.text && !called.failed && !cannotDo("", called.text)) return { text: called.text, follower: source.name, reason: "", tried };
    const limited = cannotDo(called.reason, called.text);
    if (!limited) return { text: called.text, follower: source.name, reason: called.reason || "empty", tried };
    lastReason = cannotDo("", called.text) ? "unable" : called.reason;
    const next = pool[index + 1];
    if (!next || switches >= cap) {
      if (local && local.name !== source.name && onSwitch) await onSwitch(source.name, local.name, lastReason);
      break;
    }
    switches += 1;
    if (onSwitch) await onSwitch(source.name, next.name, lastReason);
  }
  if (!local || skipped.has(local.name) || local.name === held?.name) {
    return { text: null, follower: "", reason: tried.length ? "repository-empty" : lastReason, tried };
  }
  if (!withinSpend(job, 0)) return { text: null, follower: local.name, reason: "spend", tried };
  tried.push(local.name);
  const noted = await withPings(local.name, messages);
  const { called } = await once(job, slot, local, noted);
  if (called.text && !called.failed && !cannotDo(called.reason, called.text)) return { text: called.text, follower: local.name, reason: "", tried };
  return { text: called.text, follower: local.name, reason: called.reason || lastReason, tried };
}
