import { createServerFn } from "@tanstack/react-start";
import { absorbAccounts } from "@/lib/quay/account-book";
import { chiefById, latestView, openChief } from "@/lib/quay/job-state";
import { toUrl } from "@/lib/quay/engine";
import { rememberJob, recentJobs } from "@/lib/quay/job-memory";
import { readTrace, readWorking } from "@/lib/quay/progress";
import { bindPageTask, noteTask, openTask, pageTaskId, taskIdFor, updateTask } from "@/lib/quay/task-ledger";
import { taskKind } from "@/lib/quay/web-task";
import { freeModels, pinModel, clearPin } from "@/lib/quay/providers";
import { clearAudit, sandboxFailed } from "@/lib/quay/job-audit";
import { readLive } from "@/lib/quay/browser-session";
import { beginTrace, finishTrace } from "@/lib/quay/test-trace";
import { postBotText } from "@/lib/quay/veil-bot";
import { registerMissing } from "@/lib/quay/veil-register";
import { runPlan } from "@/lib/quay/plan";
import { readPublicDocument } from "@/lib/quay/read-page";
import { scrubSecrets } from "@/lib/quay/secrets";
import { putStanding, standingShared, beginJobShared } from "@/lib/quay/shared";
import { statusBoard } from "@/lib/quay/slots";

export type PageLink = { text: string; url: string };

export type PageRead = {
  url: string;
  title: string;
  transcript: string;
  links: PageLink[];
};

export type PageStep = {
  id: string;
  step: number;
  fn: string;
  status: string;
  follower: string;
  page: string;
  detail: string;
};

export type PageBoard = {
  steps: PageStep[];
  note: string;
  shot: string;
  page: string;
  crew: string;
  sandbox: {
    active: boolean;
    follower: string;
    step: number;
    action: string;
    actions: number;
    url: string;
    typing: string;
    scrolling: string;
    clickX: number;
    clickY: number;
  } | null;
  trace: string[];
  taskId: string;
};

export type PageJob = {
  crew: string;
  result: string;
  status: number;
  reads: PageRead[];
  report: string;
};

function urlsIn(text: string): string[] {
  const found: string[] = [];
  for (const match of text.matchAll(/https?:\/\/[^\s<>"']+/gi)) {
    const url = toUrl(match[0].replace(/[),.;]+$/, ""));
    if (url && !found.includes(url)) found.push(url);
  }
  return found;
}

function asRead(page: Awaited<ReturnType<typeof readPublicDocument>>): PageRead {
  const detail = page.detail || page.error || "The page had no readable text.";
  return {
    url: page.address,
    title: page.title.slice(0, 180),
    transcript: detail.slice(0, 1800),
    links: page.links.slice(0, 48).map((link) => ({ text: link.text || link.url, url: link.url })),
  };
}

function plainAnswer(answer: string, accepted: boolean): string {
  if (!accepted) return "";
  const text = absorbAccounts(scrubSecrets(answer)).replace(/\s+/g, " ").trim();
  return text.slice(0, 2000);
}

export const readPageBoard = createServerFn({ method: "GET" }).handler(async (): Promise<PageBoard> => {
  const board = statusBoard();
  const view = latestView();
  const live = readLive("page");
  return {
    note: readWorking("page"),
    shot: live?.active ? view.shot : view.shot,
    page: live?.url || view.page,
    crew: view.crew || "page",
    sandbox: live,
    trace: readTrace("page"),
    taskId: pageTaskId(),
    steps: board.steps.slice(-12).map((row) => ({
      id: row.id,
      step: row.step,
      fn: row.fn,
      status: row.status,
      follower: row.follower,
      page: row.page ?? "",
      detail: (row.detail ?? "").slice(0, 240),
    })),
  };
});

export const listPageJobs = createServerFn({ method: "GET" }).handler(async () => recentJobs());

export const readPageLink = createServerFn({ method: "POST" })
  .validator((input: unknown): { url: string } => {
    const url = toUrl(typeof (input as { url?: unknown })?.url === "string" ? (input as { url: string }).url : "");
    if (!url) throw new Error("That address cannot be opened. Use a public http or https site.");
    return { url };
  })
  .handler(async ({ data }): Promise<PageRead> => {
    try {
      const page = await readPublicDocument(data.url);
      if (!page.ok && page.error) throw new Error(page.error);
      return asRead(page);
    } catch (error) {
      const message = error instanceof Error ? scrubSecrets(error.message) : "The page did not open.";
      throw new Error(message || "The page did not open.");
    }
  });

export const saveSharedSheet = createServerFn({ method: "POST" })
  .validator((input: unknown): { text: string } => {
    const text = typeof (input as { text?: unknown })?.text === "string" ? (input as { text: string }).text : "";
    return { text: text.slice(0, 200_000) };
  })
  .handler(async ({ data }): Promise<{ ok: true }> => {
    putStanding(data.text);
    return { ok: true };
  });

export const readSharedSheet = createServerFn({ method: "GET" }).handler(async (): Promise<{ text: string }> => {
  return { text: standingShared() };
});

export const listFreeModels = createServerFn({ method: "GET" }).handler(async (): Promise<{ id: string; label: string; group: string; status: string }[]> => {
  const rows = freeModels();
  void registerMissing(rows.map((row) => ({ id: row.id, label: row.label })));
  return rows;
});

export const runPageJob = createServerFn({ method: "POST" })
  .validator((input: unknown): { order: string; keep: number; shared: string; model: string } => {
    const raw = (input ?? {}) as { order?: unknown; keep?: unknown; shared?: unknown; model?: unknown };
    const order = typeof raw.order === "string" ? raw.order.trim().slice(0, 2000) : "";
    if (order.length < 2) throw new Error("Say the job in plain English.");
    const keep = raw.keep === 24 ? 24 : raw.keep === 0 ? 0 : 1;
    const shared = typeof raw.shared === "string" ? raw.shared.slice(0, 200_000) : "";
    const asked = typeof raw.model === "string" ? raw.model : "";
    const row = freeModels().find((item) => item.id === asked);
    if (asked && !row) throw new Error("That model is not in the repository.");
    if (row?.status === "Key missing") throw new Error("That model has no key.");
    return { order, keep, shared, model: row?.id ?? "" };
  })
  .handler(async ({ data }): Promise<PageJob> => {
    beginJobShared("page", data.shared);
    const taskId = taskIdFor("page", data.order);
    bindPageTask(taskId);
    openTask({ task_id: taskId, channel_id: "page", task: data.order, task_type: taskKind(data.order), source: "quay" });
    noteTask(taskId, "Task created");
    updateTask(taskId, { status: "ACKNOWLEDGED" });
    const chief = openChief("page", data.order);
    const label = freeModels().find((row) => row.id === data.model)?.label ?? "";
    if (data.model) {
      pinModel("page", data.model);
      beginTrace("page", label);
    }
    try {
      const run = await runPlan("page", data.order);
      const state = chiefById("page");
      const crew = typeof state?.crew === "string" && state.crew ? state.crew : chief.crew || "page";
      const blocked = sandboxFailed("page");
      const raw = blocked ? "" : plainAnswer(run?.answer || "", Boolean(run?.accepted));
      const stage = /^(working|pathway|research|workaround|workaround attempt|sandbox browser|another path)$/i.test(raw.trim());
      const web = taskKind(data.order) === "WEB_TASK" || /sandbox lab|sandbox-lab/i.test(data.order);
      const failedOpen = blocked || !raw || stage;
      const result = !failedOpen ? raw : web ? "Unable to complete the browser interaction: the page was not operated." : "";
      if (!failedOpen && result) {
        rememberJob(data.order, result, data.keep);
        updateTask(taskId, { status: "COMPLETED", final_result: result, lease_expires_at: "" });
        noteTask(taskId, "Completed");
      } else {
        updateTask(taskId, { status: blocked ? "SANDBOX_FAILED" : "EXHAUSTED", error: blocked ? "sandbox was not operated" : "no validated result" });
        noteTask(taskId, blocked ? "Sandbox failed" : "Exhausted");
      }
      const report = data.model ? finishTrace("page", Boolean(run?.accepted) && !blocked) : "";
      if (report) void postBotText("quay-jobs", `QUAY TEST REPORT: ${label}\n${report}`);
      const reads: PageRead[] = [];
      const blob = `${result}\n${(run?.steps ?? []).map((step) => step.text).join("\n")}`;
      const urls = urlsIn(blob).slice(0, 3);
      for (const url of urls) {
        try {
          const page = await readPublicDocument(url);
          if (page.ok || page.detail) reads.push(asRead(page));
        } catch (error) {
          reads.push({
            url,
            title: "Page",
            transcript: error instanceof Error ? scrubSecrets(error.message).slice(0, 300) : "The page did not open.",
            links: [],
          });
        }
      }
      return { crew, result, status: 200, reads, report };
    } catch {
      updateTask(taskId, { status: "WORKER_FAILED", error: "the job stopped" });
      noteTask(taskId, "Worker failed");
      const state = chiefById("page");
      const report = data.model ? finishTrace("page", false) : "";
      if (report) void postBotText("quay-jobs", `QUAY TEST REPORT: ${label}\n${report}`);
      return { crew: state?.crew || "page", result: "", status: 500, reads: [], report };
    } finally {
      clearPin("page");
      clearAudit("page");
    }
  });
