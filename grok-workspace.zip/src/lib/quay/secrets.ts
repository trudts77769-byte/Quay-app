import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

const ENV_ONLY = new Set(["E2B_API_KEY", "GEMINI_API_KEY", "OPENROUTER_API_KEY", "HF_TOKEN"]);

export function readServerOnly(name: string): string {
  if (!ENV_ONLY.has(name)) return "";
  return process.env[name]?.trim() ?? "";
}

export function readSecret(name: string): string {
  const fromEnv = process.env[name]?.trim();
  if (fromEnv) return fromEnv;
  if (ENV_ONLY.has(name)) return "";
  const dir = process.env.QUAY_SECRETS_DIR || join(process.cwd(), "secrets");
  const file = join(dir, name);
  if (!existsSync(file)) return "";
  return readFileSync(file, "utf8").trim();
}

export function readHfToken(): string {
  return readServerOnly("HF_TOKEN");
}

export function readE2bKey(): string {
  return readServerOnly("E2B_API_KEY");
}

export function scrubSecrets(text: string): string {
  let out = text;
  for (const name of ENV_ONLY) {
    const value = process.env[name]?.trim();
    if (value && value.length >= 8) out = out.split(value).join("[redacted]");
  }
  return out;
}
