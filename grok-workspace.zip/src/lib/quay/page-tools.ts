import { toUrl } from "@/lib/quay/engine";
import { rememberShot } from "@/lib/quay/job-state";
import { noteSandbox } from "@/lib/quay/job-audit";
import { readPublicDocument } from "@/lib/quay/read-page";

const TOOLS = new Set(["copy_text", "inspect", "click_and_screenshot", "length_check", "scroll"]);
const CAP = 1800;

export type ToolCall = {
  tool: "copy_text" | "inspect" | "click_and_screenshot" | "length_check" | "scroll";
  url: string;
  target: string;
  text: string;
};

export function sci(value: number): string {
  if (!Number.isFinite(value)) return "0";
  const n = Math.abs(Math.round(value));
  if (n < 100000) return String(Math.round(value));
  const exp = Math.floor(Math.log10(n));
  const man = n / 10 ** exp;
  return `${man.toFixed(2).replace(/\.?0+$/, "")}e${exp}`;
}

export function parseTool(raw: string): ToolCall | null {
  const start = raw.search(/"tool"\s*:/);
  if (start < 0) return null;
  const brace = raw.lastIndexOf("{", start);
  if (brace < 0) return null;
  let depth = 0;
  let end = -1;
  for (let index = brace; index < raw.length; index += 1) {
    const char = raw[index];
    if (char === "{") depth += 1;
    else if (char === "}") {
      depth -= 1;
      if (depth === 0) {
        end = index;
        break;
      }
    }
  }
  if (end < 0) return null;
  try {
    const json = JSON.parse(raw.slice(brace, end + 1)) as Record<string, unknown>;
    const tool = String(json.tool ?? "");
    const url = typeof json.url === "string" ? json.url.trim() : "";
    const target = typeof json.target === "string" ? json.target.trim().slice(0, 160) : "";
    const named = TOOLS.has(tool) ? (tool as ToolCall["tool"]) : url ? (target ? "click_and_screenshot" : "copy_text") : null;
    if (!named) return null;
    return { tool: named, url, target, text: typeof json.text === "string" ? json.text.slice(0, 4000) : "" };
  } catch {
    return null;
  }
}

function realUrl(raw: string): string {
  const cleaned = raw.split(`${String.fromCharCode(38)}amp;`).join(String.fromCharCode(38)).trim();
  try {
    const url = new URL(cleaned, "https://duckduckgo.com");
    const wrapped = url.searchParams.get("uddg");
    if (wrapped) return decodeURIComponent(wrapped);
  } catch {
    return cleaned;
  }
  return cleaned;
}

function shortPreview(body: string): string {
  const start = body.slice(0, 360);
  const tokens = body.match(/[A-Za-z]{15,}/g) ?? [];
  let longest = "";
  for (const token of tokens) {
    if (token.length > longest.length) longest = token;
  }
  if (!longest || start.includes(longest)) return start;
  const at = body.indexOf(longest);
  const window = body.slice(Math.max(0, at - 140), at + longest.length + 180).trim();
  return `${start} … ${window}`.slice(0, 900);
}

function hostOf(raw: string): string {
  try {
    return new URL(raw).host.replace(/^www\./, "").toLowerCase();
  } catch {
    return "";
  }
}

function thinPage(text: string): boolean {
  const body = text.replace(/\s+/g, " ").trim();
  return body.length < 500 || /having trouble accessing|enable javascript|unusual traffic|before you continue/i.test(body);
}

function usefulLinks(pageUrl: string, links: string[], thin: boolean): string[] {
  const host = hostOf(pageUrl);
  const cleaned = links.map((link) => link.split(`${String.fromCharCode(38)}amp;`).join(String.fromCharCode(38))).filter((link) => hostOf(link));
  const off = cleaned.filter((link) => {
    const next = hostOf(link);
    if (!next || next === host) return false;
    if (thin && /(^|\.)google\./.test(next)) return false;
    return true;
  });
  return (thin ? off : off.length > 0 ? off : cleaned).slice(0, 8);
}

function pack(url: string, title: string, text: string, links: string[]): string {
  const body = text.replace(/\s+/g, " ").trim();
  const thin = thinPage(body);
  const shown = usefulLinks(url, links, thin);
  const linkBlock = shown.join("\n");
  if (thin) {
    return [`No findings on this page. Open a different host.`, `source: ${url}`, body.slice(0, 280), linkBlock ? `links:\n${linkBlock}` : ""]
      .filter(Boolean)
      .join("\n");
  }
  const full = [`title: ${title}`, `source: ${url}`, body, linkBlock ? `links:\n${linkBlock}` : ""].filter(Boolean).join("\n");
  if (full.length <= CAP) return full;
  return [`length: ${sci(body.length)}`, `preview: ${shortPreview(body)}`, `source: ${url}`, linkBlock ? `links:\n${linkBlock}` : ""]
    .filter(Boolean)
    .join("\n");
}

async function open(raw: string): Promise<{ url: string; title: string; text: string; links: string[]; html: string } | { error: string }> {
  const url = toUrl(raw);
  if (!url) return { error: "That address cannot be opened." };
  const page = await readPublicDocument(url);
  const links = page.links
    .map((link) => realUrl(link.url))
    .map((link) => toUrl(link) || "")
    .filter((link, index, list) => link && list.indexOf(link) === index)
    .slice(0, 8);
  return {
    url: page.address || url,
    title: page.title || "Page",
    text: page.detail || page.error || "",
    links,
    html: page.html,
  };
}

async function shot(job: string, url: string): Promise<void> {
  try {
    const { capturePage } = await import("@/lib/quay/live-page");
    const viewed = await capturePage(url);
    if (viewed?.shot) rememberShot(job, viewed.shot, url);
  } catch {
    /* the text result still stands */
  }
}

export async function runPageTool(job: string, call: ToolCall): Promise<string> {
  if (call.tool === "length_check" && call.text && !call.url) {
    return `length: ${sci(call.text.length)}`;
  }
  if (call.tool === "scroll") {
    const url = toUrl(call.url);
    if (!url) return "That address cannot be opened.";
    const { walkSandbox } = await import("@/lib/quay/live-page");
    const walked = await walkSandbox(url);
    if (!walked) return `Sandbox did not open ${url}`;
    if (walked.shot) rememberShot(job, walked.shot, url);
    noteSandbox(job, { pages: walked.pages, clicks: walked.clicks, scrolls: walked.scrolls, shots: walked.shots });
    return walked.text || `source: ${url}\nSandbox opened the page and scrolled.`;
  }
  const page = await open(call.url);
  if ("error" in page) return page.error;
  if (call.tool === "length_check") {
    return `length: ${sci(page.text.length)}\nsource: ${page.url}`;
  }
  if (call.tool === "click_and_screenshot") {
    await shot(job, page.url);
    const target = call.target.toLowerCase();
    if (target) {
      const at = page.text.toLowerCase().indexOf(target);
      if (at < 0) return `source: ${page.url}\ntarget not on the page: ${call.target}\n${pack(page.url, page.title, page.text, page.links)}`;
      const window = page.text.slice(Math.max(0, at - 200), at + call.target.length + 500);
      return pack(page.url, page.title, window, page.links);
    }
    return pack(page.url, page.title, page.text, page.links);
  }
  if (call.tool === "inspect") {
    const heads = [...page.html.matchAll(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/gi)]
      .map((match) => match[1]?.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim() ?? "")
      .filter(Boolean)
      .slice(0, 12);
    const body = [heads.length ? `headings: ${heads.join(" | ")}` : "", page.text.slice(0, 700)].filter(Boolean).join("\n");
    return pack(page.url, page.title, body, page.links);
  }
  await shot(job, page.url);
  return pack(page.url, page.title, page.text, page.links);
}
