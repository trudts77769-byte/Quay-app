export type Command = "up" | "down" | "left" | "right" | "click";

export type Kind = "survey" | "breakers" | "desk" | "web";

export type Glyph =
  | "beacon"
  | "terminal"
  | "ledger"
  | "hatch"
  | "probe"
  | "status"
  | "file"
  | "breaker"
  | "check"
  | "inbox"
  | "reply"
  | "send"
  | "trash"
  | "search"
  | "page"
  | "key"
  | "del";

export type Tone = "idle" | "live" | "done" | "locked";

export interface Hotspot {
  id: string;
  col: number;
  row: number;
  label: string;
  detail: string;
  glyph: Glyph;
  tone: Tone;
}

export interface SurveyState {
  beacon: boolean;
  terminal: boolean;
  ledger: boolean;
  probe: string | null;
  filed: string | null;
  hatch: boolean;
}

export interface BreakerState {
  on: boolean[];
  target: boolean[];
}

export interface DeskState {
  letter: boolean;
  draft: boolean;
  sent: boolean;
}

export interface WebState {
  address: string;
  url: string;
  title: string;
  transcript: string;
}

export interface Machine {
  id: string;
  kind: Kind;
  name: string;
  blurb: string;
  goal: string;
  rehearsal: string;
  cols: number;
  rows: number;
  cursor: { c: number; r: number };
  log: string[];
  solved: boolean;
  attached: boolean;
  survey: SurveyState | null;
  breakers: BreakerState | null;
  desk: DeskState | null;
  web: WebState | null;
}

export interface StepResult {
  machine: Machine;
  note: string;
  tone: "move" | "click" | "warn";
}

const COLS = 8;
const ROWS = 6;
const READING = "41.2";

const WORDS: Record<string, Command> = {
  up: "up",
  u: "up",
  north: "up",
  n: "up",
  "↑": "up",
  down: "down",
  d: "down",
  south: "down",
  s: "down",
  "↓": "down",
  left: "left",
  l: "left",
  west: "left",
  w: "left",
  "←": "left",
  right: "right",
  r: "right",
  east: "right",
  e: "right",
  "→": "right",
  click: "click",
  tap: "click",
  press: "click",
  c: "click",
};

export const POINTER = [
  "You are the hand on the Quay pointer. The person already asked you to drive it.",
  "Reply with commands only. No sentences, no labels, no markdown, no code fences.",
  "Allowed words and nothing else: up down left right click.",
  "A star repeats one word: right*3 means right, right, right. One star cannot exceed 16.",
  "up moves one cell toward row 0. down moves one cell toward higher row numbers. left decreases the column. right increases the column. click presses whatever is under the pointer.",
  "The floor is 8 columns by 6 rows. Column 0, row 0 is the top-left corner. The pointer cannot leave the floor.",
  "Send at most 16 commands, then stop. Do the next unfinished step only.",
  "Web machine, used to open a public site:",
  "Row 0 keys, columns 0 to 7: a b c d e f g h",
  "Row 1 keys, columns 0 to 7: i j k l m n o p",
  "Row 2 keys, columns 0 to 7: q r s t u v w x",
  "Row 3 keys, columns 0 to 7: y z 0 1 2 3 4 5",
  "Row 4 keys, columns 0 to 7: 6 7 8 9 . - / :",
  "Row 5: column 0 is Google, column 2 is Del, column 4 is .com, column 6 is Go. Every other cell on row 5 is empty.",
  "The web pointer starts at column 1, row 5. Walk to each character, click it, then walk to Go and click. Del deletes one typed character. .com adds .com. Google opens Google again.",
  "On Survey Bay, Breaker Row, and Pier Desk, press only stations listed under CLICKABLE. Each line includes a Reach tape from the pointer's current cell. Prefer that tape.",
  "Read MACHINE, GOAL, STATE, UNDER POINTER, TRANSCRIPT, and HOW TO MOVE before you answer.",
  "A correct reply looks like this: right*2 click",
].join("\n");

export const PROTOCOL = [
  "You can send requests. You are the bot. This site is your sandbox. The person gives you one task. You finish it. Do not ask for the next command.",
  "Call GET /api/quay-agent?url=SITE&tape=TAPE&format=text on this same host. Start with an empty tape.",
  "Read TRANSCRIPT and CELLS. If the task is not finished, add the next commands and call again with the whole tape. The tape replays from the start. At most 24 commands.",
  "Commands are up, down, left, right, and click. A star repeats, like right*3. Column 0, row 0 is the top-left. On row 0, up scrolls up. On row 5, down scrolls down. click opens the link in that cell.",
  "To fill a field, move onto it and add type \"the words\". A choice lists its options, such as Practice Area: Civil Rights | Constitutional | Civil Trial. Type one option, like type \"Civil Rights\". Click submit only if the task says to send the form.",
  "Close only popups that are not needed for the task. Private network addresses stay closed.",
  "When the person gives you a new task, open a new crew. POST NAME your-short-name, TASK a-new-slug, KIND open. You are the chief of that task only.",
  "Do not hand the whole task to one follower. Split it into steps. Each step is one function, and each step gets its own follower.",
  "A different task from the person is a different TASK and a different chief. Do not reuse a task slug. Do not read another task's followers.",
  "To fill a form, post KIND secrets with placeholders such as FIRST_NAME= on their own lines. Those values stay private. Then post KIND form with the public https address. Helpers see the screen, not the real values. Quay stops before the final submit until you post KIND approve.",
  "If a result is partial, vague, or off-target, the chief decides the next pathway from the research. A workaround is any way for that follower to achieve the task. If none is possible, that follower is fired and a new follower is hired. If no follower can do it, the chief looks for a way around that task, not another way to complete it. The person is told it failed only after every pathway is exhausted.",
  "Only the chief of that task returns its final output to the person.",
  "When TRANSCRIPT has the answer, stop. Tell the person in ordinary sentences. Quote the useful line.",
].join("\n");

function pushLog(log: string[], line: string): string[] {
  return [...log, line].slice(-8);
}

export const GOOGLE_URL = "https://www.google.com/webhp?igu=1";
export const GOOGLE_FRAME = "/api/quay-google";

export const GOOGLE_READING = [
  "Google is on the glass.",
  "Center: a search box. Under it, the buttons Google Search and I'm Feeling Lucky.",
  "Top corner: Sign in.",
  "No address is typed yet. Type a public site in Open and press it. The floor keyboard is optional.",
].join(" ");

export function readerPath(target: string): string {
  return `/api/quay-read?${new URLSearchParams({ url: target, format: "text" }).toString()}`;
}

export function isGoogleHome(raw: string): boolean {
  try {
    const url = new URL(raw);
    const host = url.hostname.toLowerCase().replace(/\.+$/, "");
    if (host !== "google.com" && host !== "www.google.com") return false;
    const path = url.pathname.replace(/\/+$/, "") || "/";
    return path === "/" || path === "/webhp";
  } catch {
    return false;
  }
}

export function webReading(web: {
  url: string;
  title?: string;
  transcript?: string;
}): { title: string; transcript: string } {
  if (isGoogleHome(web.url)) return { title: "Google", transcript: GOOGLE_READING };
  const transcript = web.transcript?.trim() ?? "";
  return {
    title: web.title?.trim() || "Page",
    transcript: transcript || "The page is opening. Read TRANSCRIPT again in a moment.",
  };
}

const KEY_ROWS = ["abcdefgh", "ijklmnop", "qrstuvwx", "yz012345", "6789.-/:"];

export function toUrl(raw: string): string | null {
  let value = raw.trim();
  if (!value) return null;
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    return null;
  }
  if (url.username || url.password) return null;
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  const host = url.hostname.toLowerCase().replace(/\.+$/, "");
  if (!host || host === "localhost" || host.endsWith(".local") || host.endsWith(".localhost")) {
    return null;
  }
  if (host.includes(":")) return null;
  const ip = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (ip) {
    const parts = ip.slice(1).map(Number);
    if (parts.some((part) => part > 255)) return null;
    const [a, b] = parts;
    if (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 192 && b === 168) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 169 && b === 254)
    ) {
      return null;
    }
  }
  return url.toString();
}

function keyCell(char: string): { c: number; r: number } | null {
  for (let row = 0; row < KEY_ROWS.length; row += 1) {
    const col = KEY_ROWS[row].indexOf(char);
    if (col >= 0) return { c: col, r: row };
  }
  return null;
}

export function spellScript(domain: string, from = { c: 1, r: 5 }): string {
  let col = from.c;
  let row = from.r;
  const commands: string[] = [];
  const press = (nextCol: number, nextRow: number) => {
    const dc = nextCol - col;
    const dr = nextRow - row;
    if (dr < 0) commands.push(dr === -1 ? "up" : `up*${-dr}`);
    if (dr > 0) commands.push(dr === 1 ? "down" : `down*${dr}`);
    if (dc < 0) commands.push(dc === -1 ? "left" : `left*${-dc}`);
    if (dc > 0) commands.push(dc === 1 ? "right" : `right*${dc}`);
    commands.push("click");
    col = nextCol;
    row = nextRow;
  };
  let text = domain.trim().toLowerCase();
  let useCom = false;
  if (text.endsWith(".com")) {
    text = text.slice(0, -4);
    useCom = true;
  }
  for (const char of text) {
    const cell = keyCell(char);
    if (!cell) continue;
    press(cell.c, cell.r);
  }
  if (useCom) press(4, 5);
  press(6, 5);
  return commands.join(" ");
}

function base(
  partial: Pick<Machine, "id" | "kind" | "name" | "blurb" | "goal" | "rehearsal"> & {
    log: string[];
  },
): Machine {
  return {
    ...partial,
    cols: COLS,
    rows: ROWS,
    cursor: { c: 0, r: 5 },
    solved: false,
    attached: false,
    survey: null,
    breakers: null,
    desk: null,
    web: null,
  };
}

export function createMachine(kind: Kind, attached = false): Machine {
  if (kind === "survey") {
    return {
      ...base({
        id: "survey",
        kind,
        name: "Survey Bay",
        blurb: "Lamp, probe, ledger, hatch",
        goal: "Light the beacon, run the probe, file the reading, then open the hatch.",
        rehearsal:
          "up*5 click right*2 click down*2 click up*2 right*2 click down*2 click up*2 right*2 click",
        log: ["The bay is dark. The pointer is on the lower walkway."],
      }),
      attached,
      survey: {
        beacon: false,
        terminal: false,
        ledger: false,
        probe: null,
        filed: null,
        hatch: false,
      },
    };
  }
  if (kind === "breakers") {
    return {
      ...base({
        id: "breakers",
        kind,
        name: "Breaker Row",
        blurb: "Match the pattern, then check",
        goal: "Set the eight breakers to the pattern, then press Check.",
        rehearsal: "up*3 click right*2 click right click right*2 click down*2 left*2 click",
        log: ["All breakers are off. The pattern is shown above the floor."],
      }),
      attached,
      breakers: {
        on: [false, false, false, false, false, false, false, false],
        target: [true, false, true, true, false, true, false, false],
      },
    };
  }
  if (kind === "web") {
    return {
      ...base({
        id: "web",
        kind,
        name: "Web",
        blurb: "Read the public web",
        goal: "Open a public page. The floor is that page, 8 by 6. Move the pointer and click.",
        rehearsal: "",
        log: ["No page yet. Type a site and press Open."],
      }),
      cursor: { c: 0, r: 0 },
      attached,
      web: { address: "", url: "", title: "", transcript: "" },
    };
  }
  return {
    ...base({
      id: "desk",
      kind,
      name: "Pier Desk",
      blurb: "Open, reply, send",
      goal: "Open the inbox, click Reply, then Send.",
      rehearsal: "up*4 right click down*2 click right*4 click",
      log: ["A letter is waiting. Trash is a decoy."],
    }),
    attached,
    desk: { letter: false, draft: false, sent: false },
  };
}

export function createRack(): Machine[] {
  return [
    createMachine("web"),
    createMachine("survey"),
    createMachine("breakers"),
    createMachine("desk"),
  ];
}

function patternWord(flags: boolean[]): string {
  return flags.map((on) => (on ? "ON" : "OFF")).join(" ");
}

export function hotspots(machine: Machine): Hotspot[] {
  if (machine.kind === "survey" && machine.survey) {
    const s = machine.survey;
    const list: Hotspot[] = [
      {
        id: "beacon",
        col: 0,
        row: 0,
        label: "Beacon",
        detail: s.beacon
          ? "Lit. The probe will run."
          : "Dark. Click to light it. The probe refuses to run until it is lit.",
        glyph: "beacon",
        tone: s.beacon ? "live" : "idle",
      },
      {
        id: "terminal",
        col: 2,
        row: 0,
        label: "Terminal",
        detail: s.terminal
          ? "Open. Probe and Status are on the floor beneath it."
          : "Closed. Click to open the probe controls.",
        glyph: "terminal",
        tone: s.terminal ? "live" : "idle",
      },
      {
        id: "ledger",
        col: 4,
        row: 0,
        label: "Ledger",
        detail: s.ledger
          ? "Open. File sits beneath it."
          : "Closed. Click to open, then file the probe reading.",
        glyph: "ledger",
        tone: s.filed ? "done" : s.ledger ? "live" : "idle",
      },
      {
        id: "hatch",
        col: 6,
        row: 0,
        label: "Hatch",
        detail: s.hatch
          ? "Open. The bay is clear."
          : "Shut. It opens only after the beacon is lit and a reading is filed.",
        glyph: "hatch",
        tone: s.hatch ? "done" : "locked",
      },
    ];
    if (s.terminal) {
      list.push(
        {
          id: "probe",
          col: 2,
          row: 2,
          label: "Probe",
          detail: s.probe
            ? `Reading ${s.probe} is on the glass.`
            : s.beacon
              ? "Ready. Click to take the reading."
              : "Dark. Light the beacon before clicking.",
          glyph: "probe",
          tone: s.probe ? "done" : s.beacon ? "live" : "locked",
        },
        {
          id: "status",
          col: 2,
          row: 3,
          label: "Status",
          detail: "Click to write the bay's flags into the notes.",
          glyph: "status",
          tone: "idle",
        },
      );
    }
    if (s.ledger) {
      list.push({
        id: "file",
        col: 4,
        row: 2,
        label: "File",
        detail: s.filed
          ? `Filed ${s.filed}.`
          : s.probe
            ? `Click to file reading ${s.probe}.`
            : "Nothing to file yet. Run the probe first.",
        glyph: "file",
        tone: s.filed ? "done" : s.probe ? "live" : "locked",
      });
    }
    return list;
  }

  if (machine.kind === "breakers" && machine.breakers) {
    const { on, target } = machine.breakers;
    const list: Hotspot[] = on.map((flag, index) => ({
      id: `br-${index}`,
      col: index,
      row: 2,
      label: `Breaker ${index + 1}`,
      detail: `${flag ? "ON" : "OFF"}. The pattern wants ${target[index] ? "ON" : "OFF"}. Click to flip.`,
      glyph: "breaker" as const,
      tone: flag === target[index] ? (flag ? "live" : "done") : "idle",
    }));
    const matched = on.every((flag, index) => flag === target[index]);
    list.push({
      id: "check",
      col: 3,
      row: 4,
      label: "Check",
      detail: matched
        ? "The row matches. Click to clear the machine."
        : "Click once the row matches the pattern.",
      glyph: "check",
      tone: matched ? "live" : "locked",
    });
    return list;
  }

  if (machine.kind === "desk" && machine.desk) {
    const d = machine.desk;
    const list: Hotspot[] = [
      {
        id: "inbox",
        col: 1,
        row: 1,
        label: "Inbox",
        detail: d.letter
          ? "Open. The note asks for a reply."
          : "A sealed letter. Click to open it.",
        glyph: "inbox",
        tone: d.letter ? "live" : "idle",
      },
      {
        id: "trash",
        col: 6,
        row: 1,
        label: "Trash",
        detail: "A decoy. Clicking it does not finish the desk.",
        glyph: "trash",
        tone: "locked",
      },
    ];
    if (d.letter && !d.sent) {
      list.push({
        id: "reply",
        col: 1,
        row: 3,
        label: "Reply",
        detail: d.draft ? "Draft is ready. Send is to the right." : "Click to draft the reply.",
        glyph: "reply",
        tone: d.draft ? "done" : "live",
      });
    }
    if (d.draft && !d.sent) {
      list.push({
        id: "send",
        col: 5,
        row: 3,
        label: "Send",
        detail: "Click to send the reply and clear the desk.",
        glyph: "send",
        tone: "live",
      });
    }
    return list;
  }

  if (machine.kind === "web" && machine.web) {
    const web = machine.web;
    const onGoogle = web.url.includes("google.com");
    const list: Hotspot[] = KEY_ROWS.flatMap((row, rowIndex) =>
      row.split("").map((char, col) => ({
        id: `k:${char}`,
        col,
        row: rowIndex,
        label: char,
        detail: `Type ${char}. The address so far is ${web.address || "empty"}.`,
        glyph: "key" as const,
        tone: "idle" as const,
      })),
    );
    list.push(
      {
        id: "google",
        col: 0,
        row: 5,
        label: "Google",
        detail: onGoogle ? "Google is already open." : "Click to return to Google.",
        glyph: "search",
        tone: onGoogle ? "live" : "idle",
      },
      {
        id: "back",
        col: 2,
        row: 5,
        label: "Del",
        detail: "Delete the last character.",
        glyph: "del",
        tone: "idle",
      },
      {
        id: "com",
        col: 4,
        row: 5,
        label: ".com",
        detail: "Append .com.",
        glyph: "key",
        tone: "idle",
      },
      {
        id: "go",
        col: 6,
        row: 5,
        label: "Go",
        detail: web.address
          ? `Open ${web.address}.`
          : "Spell an address first, then click Go.",
        glyph: "page",
        tone: web.address ? "live" : "locked",
      },
    );
    return list;
  }

  return [];
}

export function hotspotAt(machine: Machine, col: number, row: number): Hotspot | null {
  return hotspots(machine).find((spot) => spot.col === col && spot.row === row) ?? null;
}

function move(machine: Machine, command: Exclude<Command, "click">): StepResult {
  const delta = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] } as const;
  const [dc, dr] = delta[command];
  const next = {
    c: Math.min(machine.cols - 1, Math.max(0, machine.cursor.c + dc)),
    r: Math.min(machine.rows - 1, Math.max(0, machine.cursor.r + dr)),
  };
  const blocked = next.c === machine.cursor.c && next.r === machine.cursor.r;
  const name = command[0].toUpperCase() + command.slice(1);
  return {
    machine: { ...machine, cursor: next },
    note: blocked
      ? `${name} — edge, pointer stays at ${next.c},${next.r}`
      : `${name} — pointer ${next.c},${next.r}`,
    tone: "move",
  };
}

function clickSurvey(machine: Machine, id: string): StepResult {
  const survey = machine.survey;
  if (!survey) return { machine, note: "Click — nothing here", tone: "warn" };

  if (id === "beacon") {
    const beacon = !survey.beacon;
    return {
      machine: {
        ...machine,
        survey: { ...survey, beacon },
        log: pushLog(machine.log, beacon ? "Beacon lit." : "Beacon darkened."),
      },
      note: beacon ? "Click — beacon lit" : "Click — beacon darkened",
      tone: "click",
    };
  }
  if (id === "terminal") {
    const terminal = !survey.terminal;
    return {
      machine: {
        ...machine,
        survey: { ...survey, terminal },
        log: pushLog(machine.log, terminal ? "Terminal open." : "Terminal closed."),
      },
      note: terminal ? "Click — terminal open" : "Click — terminal closed",
      tone: "click",
    };
  }
  if (id === "ledger") {
    const ledger = !survey.ledger;
    return {
      machine: {
        ...machine,
        survey: { ...survey, ledger },
        log: pushLog(machine.log, ledger ? "Ledger open." : "Ledger closed."),
      },
      note: ledger ? "Click — ledger open" : "Click — ledger closed",
      tone: "click",
    };
  }
  if (id === "probe") {
    if (!survey.beacon) {
      const note = "Click — probe stayed dark. Light the beacon first.";
      return {
        machine: { ...machine, log: pushLog(machine.log, note) },
        note,
        tone: "warn",
      };
    }
    return {
      machine: {
        ...machine,
        survey: { ...survey, probe: READING },
        log: pushLog(machine.log, `Probe reading ${READING}.`),
      },
      note: `Click — probe reading ${READING}`,
      tone: "click",
    };
  }
  if (id === "status") {
    const line = `Beacon ${survey.beacon ? "lit" : "dark"}, probe ${survey.probe ?? "empty"}, ledger ${survey.filed ?? "empty"}, hatch ${survey.hatch ? "open" : "shut"}.`;
    return {
      machine: { ...machine, log: pushLog(machine.log, line) },
      note: `Click — ${line}`,
      tone: "click",
    };
  }
  if (id === "file") {
    if (!survey.probe) {
      const note = "Click — nothing to file. Run the probe first.";
      return {
        machine: { ...machine, log: pushLog(machine.log, note) },
        note,
        tone: "warn",
      };
    }
    return {
      machine: {
        ...machine,
        survey: { ...survey, filed: survey.probe },
        log: pushLog(machine.log, `Filed ${survey.probe}.`),
      },
      note: `Click — filed ${survey.probe}`,
      tone: "click",
    };
  }
  if (id === "hatch") {
    if (survey.hatch) {
      return { machine, note: "Click — hatch is already open", tone: "click" };
    }
    if (!survey.beacon || !survey.filed) {
      const missing = [
        !survey.beacon ? "the beacon is dark" : "",
        !survey.filed ? "nothing is filed" : "",
      ]
        .filter(Boolean)
        .join(" and ");
      const note = `Click — hatch stays shut. ${missing[0].toUpperCase()}${missing.slice(1)}.`;
      return {
        machine: { ...machine, log: pushLog(machine.log, note) },
        note,
        tone: "warn",
      };
    }
    return {
      machine: {
        ...machine,
        solved: true,
        survey: { ...survey, hatch: true },
        log: pushLog(machine.log, "Hatch open. Survey bay clear."),
      },
      note: "Click — hatch open. Bay clear.",
      tone: "click",
    };
  }
  return { machine, note: "Click — empty floor", tone: "warn" };
}

function clickBreakers(machine: Machine, id: string): StepResult {
  const breakers = machine.breakers;
  if (!breakers) return { machine, note: "Click — nothing here", tone: "warn" };
  if (id === "check") {
    const matched = breakers.on.every((flag, index) => flag === breakers.target[index]);
    if (!matched) {
      const note = "Click — pattern does not match yet.";
      return {
        machine: { ...machine, log: pushLog(machine.log, note) },
        note,
        tone: "warn",
      };
    }
    return {
      machine: {
        ...machine,
        solved: true,
        log: pushLog(machine.log, "Pattern matches. Breaker row clear."),
      },
      note: "Click — pattern matches. Row clear.",
      tone: "click",
    };
  }
  const index = Number(id.slice(3));
  if (!Number.isInteger(index) || index < 0 || index >= breakers.on.length) {
    return { machine, note: "Click — empty floor", tone: "warn" };
  }
  const on = breakers.on.map((flag, i) => (i === index ? !flag : flag));
  const label = on[index] ? "ON" : "OFF";
  return {
    machine: {
      ...machine,
      solved: false,
      breakers: { ...breakers, on },
      log: pushLog(machine.log, `Breaker ${index + 1} ${label}.`),
    },
    note: `Click — breaker ${index + 1} ${label}`,
    tone: "click",
  };
}

function clickDesk(machine: Machine, id: string): StepResult {
  const desk = machine.desk;
  if (!desk) return { machine, note: "Click — nothing here", tone: "warn" };
  if (id === "inbox") {
    if (desk.letter) return { machine, note: "Click — letter already open", tone: "click" };
    return {
      machine: {
        ...machine,
        desk: { ...desk, letter: true },
        log: pushLog(machine.log, "Letter open: Pier 4. Please reply and send."),
      },
      note: "Click — letter open",
      tone: "click",
    };
  }
  if (id === "trash") {
    const note = "Click — trash is a decoy. Open the inbox.";
    return {
      machine: { ...machine, log: pushLog(machine.log, note) },
      note,
      tone: "warn",
    };
  }
  if (id === "reply") {
    if (desk.draft) return { machine, note: "Click — reply already drafted", tone: "click" };
    return {
      machine: {
        ...machine,
        desk: { ...desk, draft: true },
        log: pushLog(machine.log, "Reply drafted. Send is waiting."),
      },
      note: "Click — reply drafted",
      tone: "click",
    };
  }
  if (id === "send") {
    return {
      machine: {
        ...machine,
        solved: true,
        desk: { ...desk, sent: true },
        log: pushLog(machine.log, "Reply sent. Pier desk clear."),
      },
      note: "Click — reply sent. Desk clear.",
      tone: "click",
    };
  }
  return { machine, note: "Click — empty floor", tone: "warn" };
}

function clickWeb(machine: Machine, id: string): StepResult {
  const web = machine.web;
  if (!web) return { machine, note: "Click — nothing here", tone: "warn" };
  if (id.startsWith("k:") && id !== "k:") {
    const char = id.slice(2);
    if (web.address.length >= 80) {
      return { machine, note: "Click — address is full", tone: "warn" };
    }
    const address = `${web.address}${char}`;
    return {
      machine: { ...machine, web: { ...web, address } },
      note: `Click — ${address}`,
      tone: "click",
    };
  }
  if (id === "back") {
    const address = web.address.slice(0, -1);
    return {
      machine: { ...machine, web: { ...web, address } },
      note: address ? `Click — ${address}` : "Click — address cleared",
      tone: "click",
    };
  }
  if (id === "com") {
    if (web.address.endsWith(".com")) {
      return { machine, note: `Click — ${web.address}`, tone: "click" };
    }
    const address = `${web.address}.com`.slice(0, 80);
    return {
      machine: { ...machine, web: { ...web, address } },
      note: `Click — ${address}`,
      tone: "click",
    };
  }
  if (id === "go") {
    const next = toUrl(web.address);
    if (!next) {
      const note = web.address
        ? "Click — that address cannot be opened."
        : "Click — spell an address, then press Go.";
      return { machine, note, tone: "warn" };
    }
    return {
      machine: {
        ...machine,
        web: { ...web, url: next, title: "Opening", transcript: "" },
        log: pushLog(machine.log, `Opened ${next}`),
      },
      note: `Click — opened ${next}`,
      tone: "click",
    };
  }
  if (id === "google") {
    return {
      machine: {
        ...machine,
        web: { ...web, url: GOOGLE_URL, title: "Google", transcript: "" },
        log: pushLog(machine.log, "Returned to Google."),
      },
      note: "Click — Google",
      tone: "click",
    };
  }
  return { machine, note: "Click — empty floor", tone: "warn" };
}

export function step(machine: Machine, command: Command): StepResult {
  if (command !== "click") return move(machine, command);
  const spot = hotspotAt(machine, machine.cursor.c, machine.cursor.r);
  if (!spot) {
    return {
      machine,
      note: `Click — empty floor at ${machine.cursor.c},${machine.cursor.r}`,
      tone: "warn",
    };
  }
  if (machine.kind === "survey") return clickSurvey(machine, spot.id);
  if (machine.kind === "breakers") return clickBreakers(machine, spot.id);
  if (machine.kind === "web") return clickWeb(machine, spot.id);
  return clickDesk(machine, spot.id);
}

export function parseCommands(
  raw: string,
  limit = 200,
): { commands: Command[]; skipped: string[] } {
  const commands: Command[] = [];
  const skipped: string[] = [];
  const parts = raw
    .replace(/```[a-z]*/gi, " ")
    .replace(/[`"',.:]+/g, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  for (const part of parts) {
    if (commands.length >= limit) break;
    const match = part.toLowerCase().match(/^([a-z↑↓←→]+)(?:[*x×](\d+))?$/);
    if (!match) {
      skipped.push(part);
      continue;
    }
    const command = WORDS[match[1]];
    if (!command) {
      skipped.push(part);
      continue;
    }
    let count = match[2] ? Number(match[2]) : 1;
    if (!Number.isFinite(count) || count < 1) count = 1;
    count = Math.min(16, count, limit - commands.length);
    for (let i = 0; i < count; i += 1) commands.push(command);
  }
  return { commands, skipped };
}

export function runScript(machine: Machine, script: string): Machine {
  const { commands } = parseCommands(script, 240);
  return commands.reduce((current, command) => step(current, command).machine, machine);
}

function reach(from: { c: number; r: number }, to: { c: number; r: number }): string {
  const parts: string[] = [];
  const dc = to.c - from.c;
  const dr = to.r - from.r;
  if (dr < 0) parts.push(dr === -1 ? "up" : `up*${-dr}`);
  if (dr > 0) parts.push(dr === 1 ? "down" : `down*${dr}`);
  if (dc < 0) parts.push(dc === -1 ? "left" : `left*${-dc}`);
  if (dc > 0) parts.push(dc === 1 ? "right" : `right*${dc}`);
  parts.push("click");
  return parts.join(" ");
}

export function nextHint(machine: Machine): string {
  if (machine.solved) return "Goal complete. You may stop.";
  if (machine.kind === "survey" && machine.survey) {
    const s = machine.survey;
    if (!s.beacon) return "Next: light the beacon.";
    if (!s.terminal) return "Next: open the terminal.";
    if (!s.probe) return "Next: click Probe.";
    if (!s.ledger) return "Next: open the ledger.";
    if (!s.filed) return "Next: click File.";
    return "Next: open the hatch.";
  }
  if (machine.kind === "breakers" && machine.breakers) {
    const wrong = machine.breakers.on.findIndex((flag, i) => flag !== machine.breakers!.target[i]);
    if (wrong === -1) return "Next: press Check.";
    return `Next: breaker ${wrong + 1} should be ${machine.breakers.target[wrong] ? "ON" : "OFF"}.`;
  }
  if (machine.kind === "desk" && machine.desk) {
    if (!machine.desk.letter) return "Next: open the inbox. Ignore trash.";
    if (!machine.desk.draft) return "Next: click Reply.";
    if (!machine.desk.sent) return "Next: click Send.";
  }
  if (machine.kind === "web" && machine.web) {
    if (!machine.web.address) return "Google is open. Type a public site in Open, or spell it and press Go.";
    if (machine.web.url.includes("google.com")) {
      return `Typed ${machine.web.address}. Press Go to open it, or click Google to stay.`;
    }
    return `${machine.web.url} is open. Click Google to go back, or spell another address and press Go.`;
  }
  return "Look at the clickable list.";
}

export function describe(machine: Machine, transcriptLimit = 900): string {
  const under = hotspotAt(machine, machine.cursor.c, machine.cursor.r);
  const lines = [
    `MACHINE ${machine.name}`,
    `GRID ${machine.cols} by ${machine.rows}. Pointer at column ${machine.cursor.c}, row ${machine.cursor.r}.`,
    `GOAL ${machine.goal}`,
    `STATE ${nextHint(machine)}`,
    `SOLVED ${machine.solved ? "yes" : "no"}`,
    `UNDER POINTER ${under ? under.label + " — " + under.detail : "empty floor"}`,
  ];
  if (machine.kind === "web" && machine.web) {
    const reading = webReading(machine.web);
    lines.push("TRANSCRIPT");
    lines.push("Answer the person from this writing, in ordinary sentences. Do not answer with a command tape.");
    lines.push(`OPEN ${machine.web.url}`);
    lines.push(`TITLE ${reading.title}`);
    lines.push(reading.transcript.slice(0, transcriptLimit));
    lines.push(`READER ${readerPath(machine.web.url)}`);
    lines.push(`TYPED ${machine.web.address || "(empty)"}`);
    lines.push("HOW TO MOVE");
    const pads: Array<[string, number, number]> = [
      ["Google", 0, 5],
      ["Del", 2, 5],
      [".com", 4, 5],
      ["Go", 6, 5],
    ];
    for (const [label, col, row] of pads) {
      lines.push(`- ${label} column ${col} row ${row}. Tape: ${reach(machine.cursor, { c: col, r: row })}`);
    }
    lines.push("Spell any other character from the key map in the manual, then use the Go tape.");
  } else {
    const spots = hotspots(machine);
    lines.push("CLICKABLE");
    for (const spot of spots) {
      lines.push(
        `- ${spot.label} at column ${spot.col}, row ${spot.row} (${spot.tone}). Reach with: ${reach(machine.cursor, { c: spot.col, r: spot.row })}`,
      );
    }
  }
  if (machine.kind === "survey" && machine.survey) {
    const s = machine.survey;
    lines.push(
      `FLAGS beacon ${s.beacon ? "lit" : "dark"}; terminal ${s.terminal ? "open" : "closed"}; probe ${s.probe ?? "none"}; filed ${s.filed ?? "none"}; hatch ${s.hatch ? "open" : "shut"}.`,
    );
  }
  if (machine.kind === "breakers" && machine.breakers) {
    lines.push(`PATTERN ${patternWord(machine.breakers.target)}`);
    lines.push(`CURRENT ${patternWord(machine.breakers.on)}`);
  }
  if (machine.kind === "desk" && machine.desk) {
    lines.push(
      machine.desk.letter
        ? "LETTER Pier 4. The lamp is out. Please reply and send the note back."
        : "LETTER sealed.",
    );
  }
  if (machine.log.length) {
    lines.push("NOTES");
    for (const line of machine.log.slice(-4)) lines.push(`- ${line}`);
  }
  return lines.join("\n");
}

export function howToMove(cursor: { c: number; r: number }): { label: string; tape: string }[] {
  const pads: Array<[string, number, number]> = [
    ["Google", 0, 5],
    ["Del", 2, 5],
    [".com", 4, 5],
    ["Go", 6, 5],
  ];
  return pads.map(([label, col, row]) => ({
    label,
    tape: reach(cursor, { c: col, r: row }),
  }));
}

export function briefFor(machine: Machine): string {
  return `${POINTER}\n\n${describe(machine, 900)}`;
}

export function packetFor(machine: Machine): string {
  return `${PROTOCOL}\n\n${describe(machine, 4500)}`;
}

export function floorCaption(machine: Machine): { label: string; live: boolean }[] {
  if (machine.kind === "survey" && machine.survey) {
    const s = machine.survey;
    return [
      { label: s.beacon ? "Beacon lit" : "Beacon dark", live: s.beacon },
      { label: s.probe ? `Probe ${s.probe}` : "Probe empty", live: Boolean(s.probe) },
      { label: s.filed ? `Filed ${s.filed}` : "Ledger empty", live: Boolean(s.filed) },
      { label: s.hatch ? "Hatch open" : "Hatch shut", live: s.hatch },
    ];
  }
  if (machine.kind === "breakers" && machine.breakers) {
    return machine.breakers.target.map((flag, index) => ({
      label: flag ? "ON" : "OFF",
      live: machine.breakers!.on[index] === flag && flag,
    }));
  }
  if (machine.kind === "desk" && machine.desk) {
    const d = machine.desk;
    return [
      { label: d.letter ? "Letter open" : "Letter sealed", live: d.letter },
      { label: d.draft ? "Reply drafted" : "No reply", live: d.draft },
      { label: d.sent ? "Sent" : "Not sent", live: d.sent },
    ];
  }
  if (machine.kind === "web" && machine.web) {
    const web = machine.web;
    let host = "No page yet";
    if (web.url) {
      try {
        host = new URL(web.url).hostname || host;
      } catch {
        host = "No page yet";
      }
    }
    return [
      { label: host, live: Boolean(web.url) },
      { label: web.address ? web.address : "Nothing open", live: Boolean(web.address) },
    ];
  }
  return [];
}
