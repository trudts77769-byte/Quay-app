import { createServerFn } from "@tanstack/react-start";

const ORIGIN = "https://infoveil.grok.me";
const READER = "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)";

export type VeilNote = {
  from: "chief" | "follower";
  job: string;
  run: string;
  line: string;
};

type VeilRow = { id: string; envelope: string; expiresAt: number };

export function quayChannel(job: string): string {
  const clean = (job || "job").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 40);
  return `quay-${clean || "job"}`;
}

function forVeil(line: string): string {
  const text = line.replace(/\s+/g, " ").trim();
  if (!text) return "";
  if (/password|passcode|\bssn\b|social security|\bcvv\b|card number|KIND\s+(type|values)/i.test(text)) return "";
  return text
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "{EMAIL}")
    .replace(/\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/g, "{PHONE}")
    .slice(0, 3500);
}

export async function postBotMessage(channel: string, envelope: VeilNote): Promise<string> {
  const line = forVeil(envelope.line);
  if (!line) return "";
  try {
    const response = await fetch(`${ORIGIN}/api/bot/post`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json", "User-Agent": READER },
      body: JSON.stringify({ channel, envelope: { ...envelope, line } }),
      signal: AbortSignal.timeout(12000),
    });
    if (!response.ok) return "";
    const data = (await response.json()) as { ok?: boolean; id?: string };
    return data.ok ? String(data.id ?? "") : "";
  } catch {
    return "";
  }
}

export async function postBotText(channel: string, text: string): Promise<string> {
  const sent = await deliverBotText(channel, text);
  return sent.ok ? sent.id : "";
}

export async function deliverBotText(channel: string, text: string): Promise<{ ok: boolean; id: string; error: string; status: number }> {
  const line = forVeil(text);
  if (!line) return { ok: false, id: "", error: "empty", status: 0 };
  const started = Date.now();
  try {
    const response = await fetch(`${ORIGIN}/api/bot/post`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json", "User-Agent": READER },
      body: JSON.stringify({ channel, envelope: line }),
      signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) return { ok: false, id: "", error: `http-${response.status}`, status: response.status };
    const data = (await response.json()) as { ok?: boolean; id?: string };
    if (!data.ok) return { ok: false, id: "", error: "rejected", status: response.status };
    return { ok: true, id: String(data.id ?? ""), error: "", status: response.status };
  } catch (error) {
    const message = error instanceof Error ? error.name || error.message : "network";
    return { ok: false, id: "", error: `${message} ${Date.now() - started}ms`.slice(0, 80), status: 0 };
  }
}

export async function readChannel(channel: string): Promise<{ ok: boolean; error: string; messages: VeilRow[] }> {
  try {
    const url = new URL("/api/bot/read", ORIGIN);
    url.searchParams.set("channel", channel);
    const response = await fetch(url, {
      headers: { Accept: "application/json", "User-Agent": READER },
      signal: AbortSignal.timeout(12000),
    });
    if (!response.ok) {
      const detail = (await response.text()).replace(/\s+/g, " ").trim().slice(0, 180);
      return { ok: false, error: detail || "Veil did not answer.", messages: [] };
    }
    const data = (await response.json()) as { messages?: { id?: string; envelope?: string; expiresAt?: number }[] };
    const messages = (data.messages ?? []).map((row) => ({
      id: String(row.id ?? ""),
      envelope: typeof row.envelope === "string" ? row.envelope : "",
      expiresAt: Number(row.expiresAt ?? 0),
    }));
    return { ok: true, error: "", messages };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Veil did not answer.";
    return { ok: false, error: message.slice(0, 180), messages: [] };
  }
}

export async function readBotMessages(channel: string): Promise<VeilRow[]> {
  const read = await readChannel(channel);
  return read.ok ? read.messages : [];
}

export async function sendChiefLine(job: string, run: string, line: string, from: VeilNote["from"]): Promise<void> {
  const text = forVeil(line);
  if (!text) return;
  await postBotMessage(quayChannel(job), { from, job, run, line: text });
}

export function linesFromRead(messages: { envelope: string }[], run: string): string[] {
  const lines: string[] = [];
  for (const message of messages) {
    try {
      const parsed = JSON.parse(message.envelope) as { run?: string; line?: string };
      if (parsed.run !== run || typeof parsed.line !== "string" || !parsed.line) continue;
      if (/"method":"follower_changed"/.test(parsed.line)) continue;
      lines.push(parsed.line);
    } catch {
      /* a row that is not ours */
    }
  }
  return lines;
}

export const deliverChiefPacket = createServerFn({ method: "POST" })
  .validator((input: unknown): { packet: string } => {
    const packet = typeof (input as { packet?: unknown })?.packet === "string" ? (input as { packet: string }).packet.trim().slice(0, 4000) : "";
    if (packet.length < 2) throw new Error("Nothing to send.");
    return { packet };
  })
  .handler(async ({ data }): Promise<string> => {
    const { scrubSecrets } = await import("@/lib/quay/secrets");
    const line = forVeil(scrubSecrets(data.packet));
    if (!line) return "Not sent. Quay does not post private values, and it keeps no Veil copy.";
    const channel = quayChannel("chief");
    const id = await postBotMessage(channel, { from: "chief", job: "chief", run: "packet", line });
    if (!id) return "Veil did not take that packet.";
    const seen = (await readBotMessages(channel)).some((row) => row.id === id);
    return seen ? "Sent on Veil. Quay kept no copy." : "Veil did not show that message back. Quay kept no copy.";
  });
