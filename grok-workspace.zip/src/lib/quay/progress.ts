const notes = new Map<string, string>();
const traces = new Map<string, string[]>();

function stamp(): string {
  return new Date().toISOString().slice(11, 19);
}

export function pushTrace(job: string, line: string): void {
  const key = job || "page";
  const rows = traces.get(key) ?? [];
  rows.push(`${stamp()} ${line}`.replace(/\s+/g, " ").trim().slice(0, 180));
  traces.set(key, rows.slice(-16));
}

export function readTrace(job: string): string[] {
  return traces.get(job || "page") ?? [];
}

export function setWorking(job: string, cycle: number, stage: string): void {
  const key = job || "page";
  const text = stage && stage !== "Working" ? stage : "Working";
  notes.set(key, text);
  pushTrace(key, text);
}

export function readWorking(job: string): string {
  return notes.get(job || "page") ?? "";
}

export function clearWorking(job: string): void {
  notes.delete(job || "page");
}
