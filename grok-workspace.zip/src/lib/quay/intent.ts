export function intentMiss(task: string, answer: string): string {
  const text = answer.replace(/\s+/g, " ").trim();
  if (!text) return "";
  const dictionary = /\bdictionary\b/i.test(task) && !/\bliterature\b/i.test(task);
  const literature = /aristophanes|literature|pneumonoultramicroscopicsilicovolcanoconiosis/i.test(text);
  if (dictionary && literature && !/\bdictionary\b/i.test(text)) return "that word is from literature, not an English dictionary";
  if (/example\.com/i.test(task) && /\b(title|heading)\b/i.test(task) && !/example domain/i.test(text)) return "the homepage title was not Example Domain";
  return "";
}

export function followerPacket(input: { task: string; goal: string; url: string; transcript: string; actions: string }): string {
  return [
    `TASK\n${input.task.slice(0, 400)}`,
    `GOAL\n${input.goal.slice(0, 300)}`,
    `URL\n${input.url}`,
    `TRANSCRIPT\n${input.transcript.slice(0, 900)}`,
    `ACTIONS\n${input.actions.slice(0, 400)}`,
    "Return the result and the evidence only.",
  ].join("\n\n");
}
