import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

export type TaskStatus =
  | "QUEUED"
  | "ACKNOWLEDGED"
  | "ASSIGNED"
  | "WORKER_RUNNING"
  | "SANDBOX_STARTING"
  | "SANDBOX_RUNNING"
  | "RESULT_PENDING"
  | "RESULT_RECEIVED"
  | "VALIDATING"
  | "COMPLETED"
  | "WORKER_TIMEOUT"
  | "WORKER_FAILED"
  | "SANDBOX_FAILED"
  | "PROVIDER_FAILED"
  | "VALIDATION_FAILED"
  | "RETRYING"
  | "EXHAUSTED"
  | "CANCELLED";

export type TaskRecord = {
  task_id: string;
  parent_task_id: string;
  channel_id: string;
  source: string;
  created_at: string;
  updated_at: string;
  status: TaskStatus;
  task: string;
  task_type: string;
  assigned_worker: string;
  attempt: number;
  max_attempts: number;
  sandbox_required: boolean;
  sandbox_started: boolean;
  sandbox_completed: boolean;
  worker_result: string;
  final_result: string;
  error: string;
  lease_expires_at: string;
  delivery_pending: boolean;
  events: string[];
};

const file = join(process.cwd(), "data", "tasks.json");
const book = new Map<string, TaskRecord>();
let loaded = false;

const CLOSED = new Set<TaskStatus>(["COMPLETED", "CANCELLED", "EXHAUSTED"]);

export const DELIVERY_BACKOFF_MS = [0, 2000, 5000, 15000];

export function nextDeliveryDelay(attempt: number): number | null {
  if (attempt < 0 || attempt >= DELIVERY_BACKOFF_MS.length) return null;
  return DELIVERY_BACKOFF_MS[attempt] ?? null;
}

function load(): void {
  if (loaded) return;
  loaded = true;
  try {
    if (!existsSync(file)) return;
    const rows = JSON.parse(readFileSync(file, "utf8")) as TaskRecord[];
    if (!Array.isArray(rows)) return;
    for (const row of rows) {
      if (row?.task_id) book.set(row.task_id, row);
    }
  } catch {
    /* keep the empty book */
  }
}

function save(): void {
  try {
    mkdirSync(join(process.cwd(), "data"), { recursive: true });
    const rows = [...book.values()].slice(-80);
    writeFileSync(file, JSON.stringify(rows));
  } catch {
    /* the in-memory task still stands */
  }
}

export function taskIdFor(channel: string, task: string): string {
  const base = `${channel}|${task}`.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 64);
  return base || "task";
}

export function readTask(taskId: string): TaskRecord | null {
  load();
  return book.get(taskId) ?? null;
}

export function isClosed(status: TaskStatus): boolean {
  return CLOSED.has(status);
}

export function openTask(input: { task_id: string; channel_id: string; task: string; task_type: string; source?: string }): TaskRecord {
  load();
  const existing = book.get(input.task_id);
  if (existing) return existing;
  const now = new Date().toISOString();
  const created: TaskRecord = {
    task_id: input.task_id,
    parent_task_id: "",
    channel_id: input.channel_id,
    source: input.source || "veil",
    created_at: now,
    updated_at: now,
    status: "QUEUED",
    task: input.task.slice(0, 2000),
    task_type: input.task_type,
    assigned_worker: "",
    attempt: 0,
    max_attempts: 2,
    sandbox_required: input.task_type === "WEB_TASK",
    sandbox_started: false,
    sandbox_completed: false,
    worker_result: "",
    final_result: "",
    error: "",
    lease_expires_at: "",
    delivery_pending: false,
    events: [],
  };
  book.set(created.task_id, created);
  save();
  return created;
}

export function updateTask(taskId: string, patch: Partial<TaskRecord>): TaskRecord | null {
  load();
  const row = book.get(taskId);
  if (!row) return null;
  Object.assign(row, patch, { updated_at: new Date().toISOString(), task_id: row.task_id });
  save();
  return row;
}

export function noteTask(taskId: string, line: string): void {
  const row = readTask(taskId);
  if (!row) return;
  const stamp = new Date().toISOString().slice(11, 19);
  row.events.push(`${stamp} ${line}`.slice(0, 180));
  row.events = row.events.slice(-24);
  row.updated_at = new Date().toISOString();
  save();
}

let pageTask = "";

export function bindPageTask(taskId: string): void {
  pageTask = taskId;
}

export function pageTaskId(): string {
  return pageTask;
}

export function activeTasks(): TaskRecord[] {
  load();
  return [...book.values()].filter((row) => !isClosed(row.status));
}
