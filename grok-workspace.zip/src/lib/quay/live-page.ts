import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { locateSandboxScript } from "@/lib/quay/sandbox-script.server";

const scriptPath = fileURLToPath(new URL("../../../scripts/render-page.mjs", import.meta.url));

function renderWithBrowser(url: string, mode: "page" | "shot" | "walk" = "page"): Promise<Record<string, unknown> | null> {
  if (!existsSync(scriptPath)) return Promise.resolve(null);
  return new Promise((resolve) => {
    const args = [scriptPath, url];
    if (mode === "shot") args.push("--shot");
    if (mode === "walk") args.push("--walk");
    const child = spawn(process.execPath, args, { stdio: ["ignore", "pipe", "ignore"] });
    const chunks: Buffer[] = [];
    child.stdout.on("data", (chunk: Buffer) => chunks.push(chunk));
    child.on("error", () => resolve(null));
    child.on("close", () => {
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8")) as Record<string, unknown>;
        if (!parsed.shot && !parsed.html && !parsed.text) {
          resolve(null);
          return;
        }
        resolve(parsed);
      } catch {
        resolve(null);
      }
    });
  });
}

export async function capturePage(url: string): Promise<{ text: string; shot: string } | null> {
  const opened = await renderWithBrowser(url, "shot");
  if (!opened) return null;
  return { text: String(opened.html ?? ""), shot: String(opened.shot ?? "") };
}

export async function walkSandbox(url: string): Promise<{ text: string; pages: number; clicks: number; scrolls: number; shots: number; shot: string } | null> {
  const opened = await renderWithBrowser(url, "walk");
  if (!opened) return null;
  return {
    text: String(opened.text ?? ""),
    pages: Number(opened.pages ?? 0),
    clicks: Number(opened.clicks ?? 0),
    scrolls: Number(opened.scrolls ?? 0),
    shots: Number(opened.shots ?? 0),
    shot: String(opened.shot ?? ""),
  };
}

export async function renderLive(url: string, tape = ""): Promise<{ html: string; shot: string; helper: string } | null> {
  const opened = await renderWithBrowser(url, "page");
  if (!opened) return null;
  let html = String(opened.html ?? "");
  const widgets = Number(opened.widgets ?? 0);
  const optionsCount = Number(opened.options ?? 0);
  const shot = String(opened.shot ?? "");
  const nativeOptions = (html.match(/<option\b/gi) ?? []).length;
  if (nativeOptions > 0 || optionsCount > 0 || widgets === 0 || !shot) {
    return { html, shot, helper: "" };
  }
  const { askMenu } = await import("./menu-help");
  const help = await askMenu(shot, tape);
  const options = help.options.map((option) => `<option>${option.replace(/[<>]/g, "")}</option>`).join("");
  if (options) html += `<label>Menu</label><select aria-label="Menu" name="menu">${options}</select>`;
  return {
    html,
    shot,
    helper: `${help.source} OPTIONS: ${help.options.join(" | ") || "(none)"}. TAPE: ${help.tape}`,
  };
}

export type SandboxScreen = {
  url: string;
  title: string;
  text: string;
  moreBelow: boolean;
  moreAbove: boolean;
  options: { id: string; kind: string; label: string }[];
  shot: string;
};

export type SandboxAct = { cmd: "click" | "scroll" | "type" | "back"; id?: string; text?: string };

type Session = {
  screen: SandboxScreen;
  act(input: SandboxAct): Promise<SandboxScreen | null>;
  close(): void;
};

function asScreen(value: unknown): SandboxScreen | null {
  if (!value || typeof value !== "object") return null;
  const row = value as Record<string, unknown>;
  const options = Array.isArray(row.options)
    ? row.options
        .map((item) => {
          const option = item as Record<string, unknown>;
          return { id: String(option.id ?? ""), kind: String(option.kind ?? "link"), label: String(option.label ?? "") };
        })
        .filter((option) => option.id && option.label)
    : [];
  return {
    url: String(row.url ?? ""),
    title: String(row.title ?? "Page"),
    text: String(row.text ?? ""),
    moreBelow: Boolean(row.moreBelow),
    moreAbove: Boolean(row.moreAbove),
    options,
    shot: String(row.shot ?? ""),
  };
}

export function openSandboxSession(url: string): Promise<Session | null> {
  const sessionPath = locateSandboxScript().path;
  if (!sessionPath || !existsSync(sessionPath)) return Promise.resolve(null);
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [sessionPath], { stdio: ["pipe", "pipe", "ignore"] });
    const waiters: Array<(value: Record<string, unknown> | null) => void> = [];
    let buffer = "";
    let settled = false;
    const finish = (value: Session | null) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    const deliver = (line: string) => {
      let parsed: Record<string, unknown> | null = null;
      try {
        parsed = JSON.parse(line) as Record<string, unknown>;
      } catch {
        parsed = null;
      }
      const waiter = waiters.shift();
      if (waiter) waiter(parsed);
    };
    child.stdout.on("data", (chunk: Buffer) => {
      buffer += chunk.toString("utf8");
      let cut = buffer.indexOf("\n");
      while (cut >= 0) {
        const line = buffer.slice(0, cut);
        buffer = buffer.slice(cut + 1);
        deliver(line);
        cut = buffer.indexOf("\n");
      }
    });
    child.on("error", () => finish(null));
    child.on("close", () => {
      while (waiters.length > 0) waiters.shift()?.(null);
    });
    const send = (cmd: Record<string, unknown>) =>
      new Promise<Record<string, unknown> | null>((done) => {
        waiters.push(done);
        child.stdin.write(`${JSON.stringify(cmd)}\n`);
      });
    void send({ cmd: "open", url }).then((reply) => {
      const screen = reply && reply.ok !== false ? asScreen(reply.screen) : null;
      if (!screen) {
        child.kill();
        finish(null);
        return;
      }
      finish({
        screen,
        async act(input) {
          const reply = await send({ cmd: input.cmd, id: input.id ?? "", text: input.text ?? "" });
          if (!reply || reply.ok === false) return null;
          return asScreen(reply.screen);
        },
        close() {
          try {
            child.stdin.write(`${JSON.stringify({ cmd: "close" })}\n`);
          } catch {
            /* already closed */
          }
          child.kill();
        },
      });
    });
  });
}
