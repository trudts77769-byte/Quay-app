import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { after, test } from "node:test";
import { parseBrowserCommand, releaseBrowser, runBrowserFollower, type BrowserAsk } from "@/lib/quay/browser-session";
import { shapeUserAnswer } from "@/lib/quay/exact-output";
import { auditLines } from "@/lib/quay/job-audit";
import { browserPlan } from "@/lib/quay/plan";
import { pursueGoal } from "@/lib/quay/pursue";
import { clearPin, pinModel } from "@/lib/quay/providers";
import { startUrl, taskKind } from "@/lib/quay/web-task";

const jobs: Array<[string, number]> = [];

after(async () => {
  for (const [job, step] of jobs) await releaseBrowser(job, step);
});

function track(job: string, step: number): void {
  jobs.push([job, step]);
}

test("parse keeps a bad line invalid and accepts one action", () => {
  assert.equal(parseBrowserCommand("please look around"), null);
  assert.deepEqual(parseBrowserCommand("CLICK 4"), { kind: "click", id: "4" });
  assert.deepEqual(parseBrowserCommand('TYPE Florida IN 2'), { kind: "type", id: "2", text: "Florida" });
  assert.equal(parseBrowserCommand("SCROLL DOWN")?.kind, "scroll");
  assert.equal(parseBrowserCommand("DONE Example Domain")?.kind, "done");
});

test("web task without a written url still enters the sandbox", async () => {
  const task = "Search for the City of Tampa official website";
  assert.equal(taskKind(task), "WEB_TASK");
  const url = startUrl(task);
  assert.match(url, /^https:\/\//);
  const job = "t5";
  track(job, 1);
  const result = await runBrowserFollower({
    job,
    step: 1,
    task,
    goal: task,
    url,
    follower: "worker-hf",
    ask: async ({ screen }) => ({ text: `DONE ${screen.title || screen.url}` }),
  });
  assert.ok(result.sessionId);
  assert.match(result.url, /^https:\/\//);
  assert.notEqual(result.verdict, "SANDBOX_NOT_USED");
});

test("example.com returns the heading from the sandbox", async () => {
  const job = "t1";
  track(job, 1);
  const asks: string[] = [];
  const ask: BrowserAsk = async ({ screen, prompt, image }) => {
    asks.push(prompt);
    assert.equal(image, undefined);
    assert.match(prompt, /TEXT_BROWSER_FOLLOWER/);
    assert.match(prompt, /not receiving a screenshot/);
    assert.match(screen.url, /example\.com/);
    assert.match(`${screen.title} ${screen.text}`, /Example Domain/);
    return { text: "DONE Example Domain" };
  };
  const result = await runBrowserFollower({
    job,
    step: 1,
    task: "Open example.com and return the heading.",
    goal: "Return the heading.",
    url: "https://example.com",
    follower: "worker-hf",
    ask,
  });
  assert.equal(result.verdict, "PASS");
  assert.match(result.answer, /Example Domain/);
  assert.ok(result.sessionId);
  assert.equal(asks.length, 1);
});

test("invalid syntax keeps the same sandbox open", async () => {
  const job = "t3";
  track(job, 1);
  let n = 0;
  let session = "";
  const ask: BrowserAsk = async ({ screen }) => {
    n += 1;
    if (!session) session = screen.url;
    else assert.equal(screen.url, session);
    if (n < 3) return { text: "not a browser command" };
    return { text: "DONE Example Domain" };
  };
  const result = await runBrowserFollower({
    job,
    step: 1,
    task: "Open example.com and return the heading.",
    goal: "Return the heading.",
    url: "https://example.com",
    follower: "worker-hf",
    ask,
  });
  assert.equal(result.verdict, "PASS");
  assert.equal(n, 3);
  assert.equal(result.sessionId.length > 0, true);
});

test("a second follower continues the same page", async () => {
  const job = "t4";
  track(job, 1);
  const first = await runBrowserFollower({
    job,
    step: 1,
    task: "Open a page and continue.",
    goal: "Leave the browser on Wikipedia.",
    url: "https://example.com",
    follower: "worker-a",
    ask: async ({ screen }) => {
      if (!/wikipedia\.org/.test(screen.url)) return { text: "OPEN https://www.wikipedia.org" };
      return { text: "FAIL stuck after navigation" };
    },
  });
  assert.notEqual(first.verdict, "PASS");
  const seen = await runBrowserFollower({
    job,
    step: 1,
    task: "Continue.",
    goal: "Read the page.",
    url: "https://example.com",
    follower: "worker-b",
    continueSession: true,
    ask: async ({ screen, prompt }) => {
      assert.match(screen.url, /wikipedia\.org/);
      assert.match(prompt, /wikipedia\.org/);
      assert.match(prompt, /previous follower/i);
      return { text: `DONE ${screen.title || "Wikipedia"}` };
    },
  });
  assert.equal(seen.sessionId, first.sessionId);
  assert.match(seen.url, /wikipedia\.org/);
  assert.equal(seen.verdict, "PASS");
});

test("wikipedia search is driven inside one sandbox", { timeout: 120000 }, async () => {
  const job = "t2";
  track(job, 1);
  let typed = false;
  const ask: BrowserAsk = async ({ screen }) => {
    const florida = screen.options.find((option) => /florida/i.test(option.label));
    const form = screen.options.find((option) => option.kind === "form");
    const search = screen.options.find((option) => /search/i.test(option.label) && option.kind !== "form");
    if (!typed && form) {
      typed = true;
      return { text: `TYPE Florida IN ${form.id}` };
    }
    if (typed && search && !/florida/i.test(screen.url)) return { text: `CLICK ${search.id}` };
    if (florida && !/\/Florida/i.test(screen.url)) return { text: `CLICK ${florida.id}` };
    if (/florida/i.test(`${screen.url} ${screen.text}`)) {
      const sentence = screen.text.split(/(?<=\.)\s/).find((line) => /florida/i.test(line) && line.length > 40) ?? screen.text.slice(0, 180);
      return { text: `DONE ${sentence}` };
    }
    if (screen.moreBelow) return { text: "SCROLL DOWN" };
    return { text: "FAIL the Florida page was not found" };
  };
  const result = await runBrowserFollower({
    job,
    step: 1,
    task: "Open Wikipedia, search for Florida, and return the first introductory sentence.",
    goal: "Return the first visible introductory sentence about Florida.",
    url: startUrl("Open Wikipedia, search for Florida"),
    follower: "worker-hf",
    ask,
  });
  assert.equal(startUrl("Open Wikipedia, search for Florida"), "https://www.wikipedia.org");
  assert.equal(result.verdict, "PASS");
  assert.match(result.url, /wikipedia\.org/i);
  assert.match(result.answer, /Florida/i);
  const report = auditLines(job).join("\n");
  assert.match(report, /Sandbox created: YES/);
  assert.match(report, /Chief verdict: PASS/);
  assert.match(report, /DONE received: YES/);
});

const labUrl = `data:text/html,${encodeURIComponent(readFileSync("public/sandbox-lab.html", "utf8"))}`;

test("strict title output is the title and nothing else", () => {
  const task = "Look up the current homepage title of https://example.com and return ONLY the exact title. No other text.";
  assert.equal(shapeUserAnswer(task, "Example Domain", "Example Domain", "https://example.com/"), "Example Domain");
  assert.equal(shapeUserAnswer(task, "Found: Example Domain\nWhere: https://example.com/", "Example Domain", "https://example.com/"), "Example Domain");
});

test("sandbox lab types and clicks for real", { timeout: 60000 }, async () => {
  const job = "lab1";
  track(job, 1);
  const task = 'Open the interaction test page. Type "Quay works" into the text field. Click Submit. Report the exact success message.';
  const result = await runBrowserFollower({
    job,
    step: 1,
    task,
    goal: task,
    url: labUrl,
    follower: "worker-hf",
    ask: async () => ({ text: "FAIL should have used the field" }),
  });
  assert.equal(result.verdict, "PASS");
  assert.equal(result.answer, "SUCCESS: Quay works");
  const report = auditLines(job).join("\n");
  assert.match(report, /Interactive actions: [1-9]/);
  assert.match(report, /Types: [1-9]/);
  assert.match(report, /Clicks: [1-9]/);
  assert.equal(shapeUserAnswer(task, result.answer, result.title, result.url), "SUCCESS: Quay works");
});

test("sandbox lab keeps state across a second click", { timeout: 60000 }, async () => {
  const job = "lab2";
  track(job, 1);
  const task = 'Type "Quay works" into the text field. Click Submit. Then click Second.';
  const result = await runBrowserFollower({
    job,
    step: 1,
    task,
    goal: task,
    url: labUrl,
    follower: "worker-hf",
    ask: async () => ({ text: "WAIT" }),
  });
  assert.equal(result.verdict, "PASS");
  assert.match(result.answer, /SUCCESS: Quay works/);
  assert.match(result.answer, /SECOND: ready/);
  assert.match(auditLines(job).join("\n"), /Clicks: [2-9]/);
});

test("a second worker resumes the same sandbox", { timeout: 60000 }, async () => {
  const job = "lab3";
  track(job, 1);
  const task = "Read the sandbox lab page title.";
  const first = await runBrowserFollower({
    job,
    step: 1,
    task,
    goal: task,
    url: labUrl,
    follower: "worker-one",
    ask: async () => ({ text: "not a command" }),
  });
  assert.equal(first.verdict, "FOLLOWER_PROTOCOL_FAILURE");
  const second = await runBrowserFollower({
    job,
    step: 1,
    task,
    goal: task,
    url: labUrl,
    follower: "worker-two",
    continueSession: true,
    ask: async ({ screen }) => ({ text: `DONE ${screen.title}` }),
  });
  assert.equal(second.sessionId, first.sessionId);
  assert.equal(second.url, first.url);
  assert.equal(second.verdict, "PASS");
  assert.match(second.answer, /Quay sandbox lab/);
});

test("normal job opens the lab even if pollinations is pinned", { timeout: 90000 }, async () => {
  process.env.QUAY_LAB_URL = "https://llmsandy.grok.me/sandbox-lab.html";
  const order = 'Open the sandbox lab page. Type "Quay works" into the field, click Submit, then report ONLY the exact success message.';
  const steps = browserPlan(order);
  assert.ok(steps);
  assert.match(steps[0].brief, /https:\/\/llmsandy\.grok\.me\/sandbox-lab\.html/);
  assert.equal(taskKind(order), "WEB_TASK");
  const job = "ui-lab";
  pinModel(job, "worker-pollinations");
  try {
    const record = await pursueGoal({ job, step: steps[0], task: order, done: new Map(), run: "ui", last: true });
    assert.equal(record.ok, true);
    assert.equal(record.text, "SUCCESS: Quay works");
    assert.notEqual(record.follower, "worker-pollinations");
    assert.doesNotMatch(record.text, /Workaround/);
  } finally {
    clearPin(job);
  }
});

test("normal job returns only the example.com title", { timeout: 90000 }, async () => {
  const order = "Look up the current homepage title of https://example.com and return ONLY the exact title. No other text.";
  const steps = browserPlan(order);
  assert.ok(steps);
  assert.match(steps[0].brief, /https:\/\/example\.com/);
  const record = await pursueGoal({ job: "ui-example", step: steps[0], task: order, done: new Map(), run: "ex", last: true });
  assert.equal(record.text, "Example Domain");
});

test("a search without a url is not forced into the lab", () => {
  assert.equal(browserPlan("Search for the City of Tampa official website"), null);
});


