import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { getSql } from "@/lib/db";
import { toUrl } from "@/lib/quay/engine";
import { buildPlan, tellChief } from "@/lib/quay/plan";
import { callFollower } from "@/lib/quay/providers";
import { noteStep } from "@/lib/quay/slots";

const scriptPath = fileURLToPath(new URL("../../../scripts/form-hands.mjs", import.meta.url));
const PAY = /\b(pay|purchase|buy|checkout|place order)\b/i;

interface Box {
  label: string;
  kind: string;
  x: number;
  y: number;
  value: string;
  options: string[];
}

interface Screen {
  ok: boolean;
  url: string;
  title: string;
  shot: string;
  elements: Box[];
  error: string;
}

export async function saveSecrets(task: string, body: string): Promise<void> {
  const sql = await getSql();
  await ensure();
  for (const line of body.split("\n")) {
    const match = line.match(/^([A-Z0-9_]{2,40})\s*=\s*(.*)$/);
    if (!match) continue;
    await sql`
      insert into crew_secret (task, key, value) values (${task}, ${match[1]}, ${match[2].trim()})
      on conflict (task, key) do update set value = ${match[2].trim()}
    `;
  }
}

export async function formLine(task: string): Promise<string> {
  const sql = await getSql();
  await ensure();
  const rows = await sql<Record<string, string>>`
    select status, shot from crew_form where task = ${task}
  `;
  const row = rows[0];
  const shot = row?.shot ? `/api/crew/shot/${row.shot}.png` : "(none)";
  return `STATUS ${row?.status || "(none)"}\nSHOT ${shot}`;
}

export async function readShot(id: string): Promise<string | null> {
  const sql = await getSql();
  await ensure();
  const rows = await sql<Record<string, string>>`select png from crew_shot where id = ${id}`;
  return rows[0]?.png ? String(rows[0].png) : null;
}

async function ensure(): Promise<void> {
  const sql = await getSql();
  await sql.query("create table if not exists crew_secret (task text not null, key text not null, value text not null, primary key (task, key))");
  await sql.query("create table if not exists crew_shot (id text primary key, task text not null, png text not null)");
  await sql.query("create table if not exists crew_form (task text primary key, status text not null, shot text not null default '', pending text not null default '')");
}

async function secretsFor(task: string): Promise<Record<string, string>> {
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`select key, value from crew_secret where task = ${task}`;
  const secrets: Record<string, string> = {};
  for (const row of rows) secrets[String(row.key)] = String(row.value);
  return secrets;
}

function hide(text: string, secrets: Record<string, string>): string {
  let out = text;
  for (const value of Object.values(secrets)) {
    if (value.length > 2) out = out.split(value).join("{hidden}");
  }
  return out;
}

function isPayment(label: string): boolean {
  return PAY.test(label.trim());
}

function fallback(elements: Box[]): string {
  const empty = elements.find((item) => item.kind === "field" && !item.value);
  if (empty) {
    const label = empty.label.toLowerCase();
    const token = /last/.test(label)
      ? "{LAST_NAME}"
      : /email/.test(label)
        ? "{EMAIL}"
        : /phone/.test(label)
          ? "{PHONE}"
          : /city/.test(label)
            ? "{CITY}"
            : /zip|postal/.test(label)
              ? "{ZIP}"
              : /county/.test(label)
                ? "{COUNTY}"
                : /address/.test(label)
                  ? "{ADDRESS}"
                  : /case|summary|describe|legal|problem/.test(label)
                    ? "{CASE_SUMMARY}"
                    : "{FIRST_NAME}";
    return `TYPE "${empty.label}" = ${token}`;
  }
  const menu = elements.find((item) => item.kind === "select" && item.options.length);
  if (menu) {
    const option = menu.options.find((item) => /civil rights|constitutional/i.test(item)) || menu.options[0];
    return `SELECT "${menu.label}" = ${option}`;
  }
  const button = elements.find((item) => item.kind === "button" && !isPayment(item.label) && !/login|sign in|password/i.test(item.label));
  if (button) return `CLICK "${button.label}"`;
  return "SCROLL down";
}

async function ask(task: string, prompt: string): Promise<string | null> {
  const called = await callFollower(
    task,
    "form",
    [
      { role: "system", content: "You are one follower. Do only the one function in the user message. One line. Do not take the next step." },
      { role: "user", content: prompt },
    ],
    (previous, next, reason) => tellChief(task, previous, next, reason),
  );
  const text = called.text?.split("\n")[0]?.trim() ?? "";
  if (!text || /^(i'?m sorry|i can'?t|i cannot)/i.test(text)) return null;
  return text.slice(0, 240);
}

function parseMove(line: string): { cmd: string; label: string; text: string; x: number; y: number } | null {
  const clickAt = line.match(/^CLICK\s+(-?\d+)\s*,\s*(-?\d+)/i);
  if (clickAt) return { cmd: "click", label: "", text: "", x: Number(clickAt[1]), y: Number(clickAt[2]) };
  const click = line.match(/^CLICK\s+"([^"]+)"/i);
  if (click) return { cmd: "click", label: click[1], text: "", x: 0, y: 0 };
  const typed = line.match(/^TYPE\s+"([^"]+)"\s*=\s*(.+)$/i);
  if (typed) return { cmd: "type", label: typed[1], text: typed[2].trim(), x: 0, y: 0 };
  const selected = line.match(/^SELECT\s+"([^"]+)"\s*=\s*(.+)$/i);
  if (selected) return { cmd: "select", label: selected[1], text: selected[2].trim(), x: 0, y: 0 };
  if (/^SCROLL/i.test(line)) return { cmd: "scroll", label: "", text: "", x: 0, y: 0 };
  return null;
}

export async function runFormCrew(task: string, order: string): Promise<string> {
  const found = order.match(/https?:\/\/[^\s<>"']+/i)?.[0]?.replace(/[),.;]+$/, "") ?? "";
  const url = toUrl(found);
  if (!url) return "The form order needs a public https address.";
  if (!existsSync(scriptPath)) return "The screen is not available on this host.";
  const planned = await buildPlan(task, order);
  await ensure();
  const secrets = await secretsFor(task);
  const sql = await getSql();
  const child = spawn(process.execPath, [scriptPath], { stdio: ["pipe", "pipe", "ignore"] });
  const lines = createInterface({ input: child.stdout });
  const queue: string[] = [];
  let pending: ((line: string) => void) | null = null;
  lines.on("line", (line) => {
    if (pending) {
      const resolve = pending;
      pending = null;
      resolve(line);
    } else queue.push(line);
  });
  const readLine = () =>
    new Promise<string>((resolve, reject) => {
      if (queue.length) {
        resolve(queue.shift() as string);
        return;
      }
      const timer = setTimeout(() => reject(new Error("timeout")), 30000);
      pending = (line) => {
        clearTimeout(timer);
        resolve(line);
      };
    });
  const stop = () => {
    child.stdin.write(`${JSON.stringify({ cmd: "stop" })}\n`);
    child.kill();
  };
  child.stdin.write(`${JSON.stringify({ url, secrets })}\n`);
  let cursor = 0;
  let same = "";
  let repeats = 0;
  let lastShot = "";
  let step = 0;
  const started = Date.now();
  const maxMillis = Number(process.env.QUAY_MAX_MILLIS ?? 15 * 60 * 1000) || 15 * 60 * 1000;
  try {
    while (Date.now() - started < maxMillis) {
      step += 1;
      const raw = await readLine();
      const screen = JSON.parse(raw) as Screen;
      if (!screen.ok) return "The screen did not open.";
      const id = crypto.randomUUID();
      await sql`insert into crew_shot (id, task, png) values (${id}, ${task}, ${screen.shot})`;
      lastShot = id;
      await sql`
        insert into crew_form (task, status, shot, pending) values (${task}, ${"working"}, ${id}, ${""})
        on conflict (task) do update set status = ${"working"}, shot = ${id}
      `;
      await sql`
        insert into crew_task_note (id, task, name, role, kind, body)
        values (${crypto.randomUUID()}, ${task}, ${"screen"}, ${"FOLLOWER"}, ${"PICTURE"}, ${`/api/crew/shot/${id}.png`})
      `;
      const listed = (screen.elements ?? [])
        .map((item) => `- ${item.kind} "${item.label}" at ${item.x},${item.y}${item.options.length ? ` options ${item.options.join(" | ")}` : ""}`)
        .join("\n");
      const signature = `${screen.url}|${listed}`;
      repeats = signature === same ? repeats + 1 : 0;
      same = signature;
      if (repeats >= 3) {
        await finish(task, id, "stopped: the same screen came up 3 times");
        return "stopped: the same screen came up 3 times";
      }
      if (screen.elements.some((item) => /captcha|password/i.test(item.label))) {
        await finish(task, id, "stopped: password or captcha");
        return "stopped: password or captcha. Nothing was sent.";
      }
      const current = planned[Math.min(cursor, Math.max(planned.length - 1, 0))];
      noteStep({
        id: `${task}:form:${current?.n ?? step}`,
        slot: "form",
        step: current?.n ?? step,
        fn: current?.fn ?? "write",
        status: "running",
        follower: "form-step",
        tries: step,
      });
      const decision = await ask(
        task,
        hide(
          `You are one follower. One function only.\nSTEP ${current?.n ?? step} ${current?.fn ?? "write"}\n${current?.brief ?? "Use this screen."}\nElements:\n${listed}\nReply with one line only: CLICK "label" or TYPE "label" = {PLACEHOLDER} or SELECT "label" = option or SCROLL down or DONE: what the screen says. Never use a real name. Do not pay or buy. The chief decides when the step is complete.`,
          secrets,
        ),
      );
      const command = decision && /^(CLICK|TYPE|SELECT|SCROLL|DONE:)/i.test(decision) ? decision : fallback(screen.elements);
      await sql`
        insert into crew_task_note (id, task, name, role, kind, body)
        values (${crypto.randomUUID()}, ${task}, ${current?.fn || "step"}, ${"FOLLOWER"}, ${"STEP"}, ${hide(command, secrets).slice(0, 240)})
      `;
      if (/^DONE:/i.test(command)) {
        await finish(task, id, command);
        return command;
      }
      const move = parseMove(command);
      const label = move?.label || "";
      const county = (screen.elements ?? []).find((item) => /county/i.test(item.label) && (!item.value || /select|choose/i.test(item.value)));
      const openingMenu = move && move.cmd === "click" && /county|select/i.test(label);
      const guarded = openingMenu
        ? { cmd: "select", label, text: "{COUNTY}", x: 0, y: 0 }
        : move && county && move.cmd === "click" && /search/i.test(label)
          ? { cmd: "select", label: county.label, text: "{COUNTY}", x: 0, y: 0 }
          : move;
      if (!guarded) continue;
      if (isPayment(guarded.label)) {
        await finish(task, id, "Not sent. Quay does not pay or buy.");
        return "Not sent. Quay does not pay or buy.";
      }
      child.stdin.write(`${JSON.stringify(guarded)}\n`);
      cursor += 1;
    }
    await finish(task, lastShot, "Stopped: time limit.");
    return "Stopped: time limit.";
  } catch {
    return "The screen timed out.";
  } finally {
    stop();
  }
}

async function finish(task: string, shot: string, status: string): Promise<void> {
  const sql = await getSql();
  await sql`
    insert into crew_form (task, status, shot, pending) values (${task}, ${status}, ${shot}, ${""})
    on conflict (task) do update set status = ${status}, shot = ${shot}
  `;
  await sql`
    insert into crew_task_note (id, task, name, role, kind, body)
    values (${crypto.randomUUID()}, ${task}, ${"screen"}, ${"FOLLOWER"}, ${"ANSWER"}, ${status.slice(0, 500)})
  `;
}

export async function approveForm(task: string): Promise<string> {
  await ensure();
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`select status from crew_form where task = ${task}`;
  const status = String(rows[0]?.status ?? "");
  if (!status.includes("READY TO SUBMIT")) return "There is no final button waiting.";
  await sql`
    update crew_form set status = ${"approved, not sent"} where task = ${task}
  `;
  return "Approved. The screen was already closed, so the final button was not pressed and nothing was sent.";
}
