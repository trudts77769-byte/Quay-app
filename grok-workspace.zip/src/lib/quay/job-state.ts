export type JobChief = {
  id: string;
  order: string;
  crew: string;
  answer: string;
  shot: string;
  page: string;
};

const byId = new Map<string, JobChief>();

export function openChief(id: string, order = ""): JobChief {
  const key = id || "page";
  const existing = byId.get(key);
  if (existing) {
    if (order && !existing.order) existing.order = order.slice(0, 2000);
    if (typeof existing.crew !== "string" || !existing.crew) existing.crew = key;
    return existing;
  }
  const created: JobChief = { id: key, order: order.slice(0, 2000), crew: key, answer: "", shot: "", page: "" };
  byId.set(key, created);
  return created;
}

export function chiefById(id: string): JobChief {
  return openChief(id || "page", "");
}

export function crewOf(state: JobChief | undefined, id: string): string {
  if (state && typeof state.crew === "string" && state.crew) return state.crew;
  return chiefById(id).crew || id || "page";
}

export function rememberShot(id: string, shot: string, page: string): void {
  const chief = chiefById(id);
  if (shot) chief.shot = shot.slice(0, 1_500_000);
  if (page) chief.page = page.slice(0, 300);
}

export function setChiefAnswer(id: string, answer: string): void {
  chiefById(id).answer = answer.slice(0, 2000);
}

export function latestView(): { shot: string; page: string; crew: string } {
  const chief = byId.get("page") ?? [...byId.values()].at(-1);
  return { shot: chief?.shot ?? "", page: chief?.page ?? "", crew: chief?.crew ?? "page" };
}
