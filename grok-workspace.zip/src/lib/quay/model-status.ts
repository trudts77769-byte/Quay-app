import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { allModels, type KeyName } from "@/lib/quay/catalog";
import { readSecret } from "@/lib/quay/secrets";

export type ModelStatus = "Ready" | "Untested" | "Key missing" | "Quota hit" | "Failed";

const file = join(process.cwd(), "data", "model-status.json");
const saved = new Map<string, ModelStatus>();
let loaded = false;

function load(): void {
  if (loaded) return;
  loaded = true;
  try {
    if (!existsSync(file)) return;
    const json = JSON.parse(readFileSync(file, "utf8")) as Record<string, ModelStatus>;
    for (const [id, status] of Object.entries(json)) {
      if (status === "Ready" || status === "Quota hit" || status === "Failed") saved.set(id, status);
    }
  } catch {
    /* keep the empty book */
  }
}

function persist(): void {
  try {
    mkdirSync(join(process.cwd(), "data"), { recursive: true });
    writeFileSync(file, JSON.stringify(Object.fromEntries(saved)));
  } catch {
    /* the label still updates in memory */
  }
}

function keyed(key: KeyName): boolean {
  if (key === "none") return true;
  if (key === "LOCAL") return Boolean(readSecret("LOCAL_OPENAI_URL") || readSecret("OPENAI_COMPAT_URL"));
  return Boolean(readSecret(key));
}

export function statusOf(id: string): ModelStatus {
  load();
  const row = allModels().find((item) => item.id === id);
  if (!row) return "Failed";
  if (!keyed(row.key)) return "Key missing";
  return saved.get(id) ?? "Untested";
}

export function markFromCall(id: string, called: { text: string | null; failed: boolean; reason: string }): void {
  load();
  if (!id || called.reason === "spend" || called.reason === "waiting") return;
  if (called.reason === "no-key" || /no-key/.test(called.reason)) return;
  const next: ModelStatus = /429|quota/i.test(called.reason) ? "Quota hit" : called.text && !called.failed ? "Ready" : "Failed";
  saved.set(id, next);
  persist();
}
