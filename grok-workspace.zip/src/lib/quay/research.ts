import { createServerFn } from "@tanstack/react-start";
import { runPlan } from "@/lib/quay/plan";

export interface ResearchResult {
  ok: boolean;
  text: string;
  sources: string[];
  error: string;
  spent: boolean;
}

function addUrl(urls: Set<string>, value: unknown) {
  if (typeof value !== "string") return;
  if (!/^https?:\/\//i.test(value)) return;
  urls.add(value);
}

export function readAnswer(body: unknown): { text: string; sources: string[] } {
  const root = (body ?? {}) as {
    output_text?: unknown;
    citations?: unknown;
    output?: unknown;
  };
  const sources = new Set<string>();
  if (Array.isArray(root.citations)) {
    for (const item of root.citations) {
      if (typeof item === "string") addUrl(sources, item);
      else if (item && typeof item === "object") addUrl(sources, (item as { url?: unknown }).url);
    }
  }
  const chunks: string[] = [];
  if (Array.isArray(root.output)) {
    for (const item of root.output) {
      if (!item || typeof item !== "object") continue;
      const content = (item as { content?: unknown }).content;
      if (!Array.isArray(content)) continue;
      for (const block of content) {
        if (!block || typeof block !== "object") continue;
        const piece = block as { text?: unknown; annotations?: unknown };
        if (typeof piece.text === "string") chunks.push(piece.text);
        if (!Array.isArray(piece.annotations)) continue;
        for (const note of piece.annotations) {
          if (note && typeof note === "object") addUrl(sources, (note as { url?: unknown }).url);
        }
      }
    }
  }
  const text = (typeof root.output_text === "string" ? root.output_text : chunks.join("\n\n")).trim();
  return { text: text.slice(0, 8000), sources: [...sources].slice(0, 12) };
}

export const researchWeb = createServerFn({ method: "POST" })
  .validator((input: unknown): { task: string } => {
    const task = (input as { task?: unknown })?.task;
    if (typeof task !== "string") throw new Error("Missing task");
    const trimmed = task.trim();
    if (trimmed.length < 2 || trimmed.length > 400) throw new Error("Say the task in a sentence or two.");
    return { task: trimmed };
  })
  .handler(async ({ data }): Promise<ResearchResult> => {
    const run = await runPlan("research", data.task);
    if (!run.accepted) {
      return {
        ok: false,
        text: "",
        sources: run.sources,
        error: "",
        spent: run.spent,
      };
    }
    return { ok: true, text: run.answer, sources: run.sources, error: "", spent: run.spent };
  });
