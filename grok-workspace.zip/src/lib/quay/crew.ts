import { getSql } from "@/lib/db";
import { approveForm, formLine, runFormCrew, saveSecrets } from "@/lib/quay/form-crew";
import { hireFollowers } from "@/lib/quay/hire";

const SECRET =
  /(password|passcode|social security|\bssn\b|account number|license number|api[_ -]?key|\bsecret\b|\blogin\b)/i;

export interface Seat {
  name: string;
  role: string;
}

export interface Note {
  name: string;
  role: string;
  kind: string;
  body: string;
}

export interface TaskRow {
  task: string;
  chief: string;
}

function cleanSlug(raw: string): string | null {
  const name = raw.trim().toLowerCase().replace(/\s+/g, "-");
  return /^[a-z0-9-]{2,40}$/.test(name) ? name : null;
}

export function parseCrew(raw: string): { name: string; task: string; kind: string; body: string } | { error: string } {
  const lines = raw.replace(/\r/g, "").split("\n");
  let name = "";
  let task = "";
  let kind = "";
  const body: string[] = [];
  let inBody = false;
  for (const line of lines) {
    if (!inBody) {
      const match = line.trim().match(/^(NAME|TASK|KIND)\s+(.+)$/i);
      if (match) {
        const key = match[1].toUpperCase();
        if (key === "NAME") name = match[2];
        else if (key === "TASK") task = match[2];
        else kind = match[2].toLowerCase();
        continue;
      }
      if (line.trim().toUpperCase() === "BODY") {
        inBody = true;
        continue;
      }
      if (!line.trim()) continue;
    }
    if (line.trim()) body.push(line.trim());
  }
  const who = cleanSlug(name);
  const job = cleanSlug(task);
  if (!who) return { error: "NAME must be a short name, like north-wind." };
  if (!job) return { error: "TASK must be a short name for this cue only, like records-form." };
  if (!["open", "join", "instruct", "answer", "step", "hire", "secrets", "form", "approve"].includes(kind)) {
    return { error: "KIND must be open, join, instruct, answer, step, hire, secrets, form, or approve." };
  }
  const text = body.join("\n").trim().slice(0, kind === "secrets" ? 2000 : 800);
  if (kind !== "open" && kind !== "join" && kind !== "hire" && kind !== "approve" && text.length < 2) {
    return { error: "BODY is empty." };
  }
  if (kind !== "secrets" && SECRET.test(text)) return { error: "Do not put logins or secrets on the crew line." };
  return { name: who, task: job, kind, body: text };
}

async function ready(): Promise<void> {
  const sql = await getSql();
  await sql.query(
    "create table if not exists crew_task (task text primary key, chief text not null, created_at timestamptz not null default now())",
  );
  await sql.query(
    "create table if not exists crew_member (task text not null, name text not null, role text not null, joined_at timestamptz not null default now(), primary key (task, name))",
  );
  await sql.query(
    "create table if not exists crew_task_note (id text primary key, task text not null, name text not null, role text not null, kind text not null, body text not null, created_at timestamptz not null default now())",
  );
}

async function tasks(): Promise<TaskRow[]> {
  await ready();
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`
    select task, chief from crew_task order by created_at asc
  `;
  return rows.map((row) => ({ task: String(row.task), chief: String(row.chief) }));
}

async function seats(task: string): Promise<Seat[]> {
  await ready();
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`
    select name, role from crew_member where task = ${task} order by joined_at asc
  `;
  return rows.map((row) => ({ name: String(row.name), role: String(row.role) }));
}

async function notes(task: string): Promise<Note[]> {
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`
    select name, role, kind, body from crew_task_note where task = ${task} order by created_at asc
  `;
  return rows.map((row) => ({
    name: String(row.name),
    role: String(row.role),
    kind: String(row.kind),
    body: String(row.body),
  }));
}

export function formatTaskList(list: TaskRow[]): string {
  const lines = [
    "TASKS",
    "Each cue from the person is its own task. A new task gets a new chief. Followers stay on that task only.",
    "The AI the person just sent opens it: NAME your-name, TASK a-new-slug, KIND open.",
    "Helpers for that same cue join it: KIND join and the same TASK. Do not open it again. Do not read another task.",
  ];
  if (list.length === 0) lines.push("(none)");
  else for (const row of list) lines.push(`${row.task} chief ${row.chief}`);
  return lines.join("\n");
}

export function formatCrew(task: string, list: Seat[], board: Note[], you = ""): string {
  const chief = list.find((seat) => seat.role === "CHIEF");
  const followers = list.filter((seat) => seat.role !== "CHIEF").map((seat) => seat.name);
  const latest = [...board].reverse().find((note) => note.kind === "INSTRUCT" || note.kind === "STEP");
  const answers = board.filter((note) => note.kind === "ANSWER");
  const lines = [
    `TASK ${task}`,
    "This crew is only for this task. Another cue from the person is a different task and a different chief.",
    "The chief splits the order into steps. Each step gets its own follower. The chief never hands the whole job to one follower.",
    "A reader step uses the page reader. A writer step uses a chat model. The reviewer must pass before the chief accepts the answer.",
    "A follower may lead a step of this order. Post KIND step, do that step, then post KIND answer for this chief.",
    "Only this chief returns the final output for this task to the person.",
    you ? `YOU ARE ${you}` : "Post NAME, TASK, and KIND join.",
    `CHIEF ${chief ? chief.name : "(none)"}`,
    `FOLLOWERS ${followers.length ? followers.join(", ") : "(none)"}`,
    "LATEST ORDER",
    latest ? `${latest.name}: ${latest.body}` : "(none)",
    "ANSWERS FOR THIS CHIEF",
  ];
  if (answers.length === 0) lines.push("(none)");
  else for (const note of answers) lines.push(`${note.name}: ${note.body}`);
  lines.push("NOTES");
  if (board.length === 0) lines.push("(none)");
  else for (const note of board) lines.push(`${note.role} ${note.name} ${note.kind}: ${note.body}`);
  return lines.join("\n");
}

export async function readCrew(task = ""): Promise<string> {
  const job = cleanSlug(task);
  if (!job) return formatTaskList(await tasks());
  const board = formatCrew(job, await seats(job), await notes(job));
  return `${board}\n${await formLine(job)}`;
}

async function pullWorkers(task: string, order: string): Promise<string> {
  const rows = await hireFollowers(task, order);
  const sql = await getSql();
  const seated: string[] = [];
  for (const row of rows) {
    if (!row.accepted || !row.name || !row.body) continue;
    await sql`
      insert into crew_member (task, name, role) values (${task}, ${row.name}, 'FOLLOWER')
      on conflict (task, name) do nothing
    `;
    await sql`
      insert into crew_task_note (id, task, name, role, kind, body)
      values (${crypto.randomUUID()}, ${task}, ${row.name}, 'FOLLOWER', 'ANSWER', ${row.body})
    `;
    seated.push(`${row.fn} ${row.name}`);
  }
  if (!rows.some((row) => row.accepted)) return "Working. The task is not complete.";
  const answer = rows.find((row) => row.accepted)?.body ?? "";
  return `One follower per step. ${seated.join(", ")}. ACCEPTED ${answer}`;
}

export async function postCrew(raw: string): Promise<{ status: number; text: string }> {
  const parsed = parseCrew(raw);
  if ("error" in parsed) return { status: 400, text: parsed.error };
  await ready();
  const sql = await getSql();
  const existing = (await tasks()).find((row) => row.task === parsed.task);

  if (parsed.kind === "open") {
    if (existing) {
      const list = await seats(parsed.task);
      return {
        status: 409,
        text: `${formatCrew(parsed.task, list, await notes(parsed.task))}\nThis task already has chief ${existing.chief}. A new cue needs a new TASK. Do not join this one unless the person sent you to help it.`,
      };
    }
    await sql`insert into crew_task (task, chief) values (${parsed.task}, ${parsed.name})`;
    await sql`
      insert into crew_member (task, name, role) values (${parsed.task}, ${parsed.name}, 'CHIEF')
    `;
    return {
      status: 200,
      text: `${formatCrew(parsed.task, await seats(parsed.task), [], "CHIEF")}\nYou are the chief of ${parsed.task} only. Find the public https address yourself and post KIND instruct with it. The person does not type addresses. Do not ask them.`,
    };
  }

  if (!existing) {
    return {
      status: 404,
      text: `No chief has opened ${parsed.task}. The AI the person just sent must open it with KIND open. Do not invent a chief.`,
    };
  }

  if (parsed.kind === "secrets" || parsed.kind === "form" || parsed.kind === "approve") {
    const list = await seats(parsed.task);
    const role = list.find((seat) => seat.name === parsed.name)?.role;
    if (role !== "CHIEF") return { status: 403, text: "Only the chief of this task can post secrets, form, or approve." };
    if (parsed.kind === "secrets") {
      await saveSecrets(parsed.task, parsed.body);
      return {
        status: 200,
        text: `${formatCrew(parsed.task, list, await notes(parsed.task), "CHIEF")}\n${await formLine(parsed.task)}\nSecrets stored for this task only. They are not shown and are not sent to helpers.`,
      };
    }
    if (parsed.kind === "approve") {
      const result = await approveForm(parsed.task);
      return { status: 200, text: `${formatCrew(parsed.task, await seats(parsed.task), await notes(parsed.task), "CHIEF")}\n${await formLine(parsed.task)}\n${result}` };
    }
    const result = await runFormCrew(parsed.task, parsed.body);
    return {
      status: 200,
      text: `${formatCrew(parsed.task, await seats(parsed.task), await notes(parsed.task), "CHIEF")}\n${await formLine(parsed.task)}\n${result}`,
    };
  }

  await sql`
    insert into crew_member (task, name, role) values (${parsed.task}, ${parsed.name}, 'FOLLOWER')
    on conflict (task, name) do nothing
  `;
  const list = await seats(parsed.task);
  const role = list.find((seat) => seat.name === parsed.name)?.role ?? "FOLLOWER";
  if (parsed.kind === "instruct" && role !== "CHIEF") {
    return {
      status: 403,
      text: `${formatCrew(parsed.task, list, await notes(parsed.task), "FOLLOWER")}\nOnly the chief of this task writes the order.`,
    };
  }
  if (parsed.kind !== "join" && parsed.kind !== "hire") {
    await sql`
      insert into crew_task_note (id, task, name, role, kind, body)
      values (${crypto.randomUUID()}, ${parsed.task}, ${parsed.name}, ${role}, ${parsed.kind.toUpperCase()}, ${parsed.body})
    `;
  }
  let hiring = "";
  if (role === "CHIEF" && (parsed.kind === "instruct" || parsed.kind === "hire")) {
    const order =
      parsed.kind === "instruct"
        ? parsed.body
        : [...(await notes(parsed.task))].reverse().find((note) => note.kind === "INSTRUCT")?.body ?? "";
    hiring = order
      ? await pullWorkers(parsed.task, order)
      : "Chief: post KIND instruct with the public https address you found. The person does not type it. Quay hires followers after that.";
  }
  const shown = formatCrew(parsed.task, await seats(parsed.task), await notes(parsed.task), role);
  if (role === "CHIEF") {
    return {
      status: 200,
      text: `${shown}\nYou are the chief of this task only. You return its final output to the person.\n${hiring}`,
    };
  }
  return {
    status: 200,
    text: `${shown}\nYou follow the chief of ${parsed.task} only. Use /api/quay-agent for this order. Post KIND answer here. Do not answer for another task.`,
  };
}
