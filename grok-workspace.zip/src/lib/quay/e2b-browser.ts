import { readFileSync } from "node:fs";
import { scrubSecrets } from "@/lib/quay/secrets";

const TEMPLATE = () => process.env.QUAY_E2B_BROWSER_TEMPLATE || "quay-reader-chromium";

export type RemoteBrowser = {
  send: (cmd: Record<string, unknown>) => Promise<Record<string, unknown> | null>;
  close: () => Promise<void>;
};

function scriptText(path: string): string {
  return readFileSync(path, "utf8");
}

export async function openRemoteBrowser(scriptPath: string, url: string, source = ""): Promise<{ browser: RemoteBrowser; screen: Record<string, unknown> } | { error: string }> {
  if (import.meta.env?.SSR === false) return { error: "E2B_API_KEY missing" };
  const { resolveE2bKey } = await import("./e2b-key.server");
  const apiKey = await resolveE2bKey();
  if (!apiKey) return { error: "E2B_API_KEY missing" };
  let text = source;
  if (!text && scriptPath) {
    try {
      text = scriptText(scriptPath);
    } catch {
      text = "";
    }
  }
  if (!text) return { error: "sandbox script missing" };
  const started = Date.now();
  try {
    const { Sandbox } = await import("e2b");
    const sandbox = await Sandbox.create(TEMPLATE(), { apiKey, timeoutMs: 180_000, allowInternetAccess: true });
    const installed = await sandbox.commands.run("npm install --prefix /tmp/pw playwright-core@1.55.0 --silent", { timeoutMs: 40_000 });
    if (installed.exitCode) {
      await sandbox.kill().catch(() => undefined);
      return { error: scrubSecrets(installed.stderr || "playwright-core install failed").slice(0, 180) };
    }
    await sandbox.files.write("/tmp/sandbox-session.mjs", text);
    const waiters: Array<(value: Record<string, unknown> | null) => void> = [];
    let buffer = "";
    let stderr = "";
    const take = (chunk: string) => {
      buffer += chunk;
      let cut = buffer.indexOf("\n");
      while (cut >= 0) {
        const line = buffer.slice(0, cut);
        buffer = buffer.slice(cut + 1);
        let parsed: Record<string, unknown> | null = null;
        try {
          parsed = JSON.parse(line) as Record<string, unknown>;
        } catch {
          parsed = null;
        }
        waiters.shift()?.(parsed);
        cut = buffer.indexOf("\n");
      }
    };
    const handle = await sandbox.commands.run(
      "NODE_PATH=/tmp/pw/node_modules QUAY_CHROMIUM=/usr/local/bin/chromium node /tmp/sandbox-session.mjs",
      {
        background: true,
        stdin: true,
        timeoutMs: 300_000,
        onStdout: (data) => take(data),
        onStderr: (data) => {
          stderr = `${stderr}${data}`.slice(-400);
        },
      },
    );
    const send = (cmd: Record<string, unknown>) =>
      new Promise<Record<string, unknown> | null>((resolve) => {
        const timer = setTimeout(() => resolve(null), 20_000);
        waiters.push((value) => {
          clearTimeout(timer);
          resolve(value);
        });
        void handle.sendStdin(`${JSON.stringify(cmd)}\n`).catch(() => {
          clearTimeout(timer);
          resolve(null);
        });
      });
    const reply = await send({ cmd: "open", url });
    const screen = reply && reply.ok !== false && reply.screen && typeof reply.screen === "object" ? (reply.screen as Record<string, unknown>) : null;
    if (!screen) {
      await sandbox.kill().catch(() => undefined);
      return { error: scrubSecrets(stderr || "remote browser did not return a screen").slice(0, 180) };
    }
    return {
      screen,
      browser: {
        send,
        close: async () => {
          try {
            await handle.sendStdin(`${JSON.stringify({ cmd: "close" })}\n`);
          } catch {
            /* already closed */
          }
          await sandbox.kill().catch(() => undefined);
        },
      },
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "e2b failed";
    return { error: `${scrubSecrets(message).slice(0, 160)} ${Date.now() - started}ms` };
  }
}
