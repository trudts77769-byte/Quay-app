import { toUrl } from "@/lib/quay/engine";
import { scrubSecrets } from "@/lib/quay/secrets";

export const READER_UA = "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)";

const TEMPLATE = () => process.env.QUAY_E2B_BROWSER_TEMPLATE || "quay-reader-chromium";

export type SandboxLike = {
  kill: () => Promise<unknown>;
  commands: {
    run: (cmd: string, opts?: { timeoutMs?: number }) => Promise<{ stdout?: string; stderr?: string; exitCode?: number }>;
  };
};

function shQuote(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function clean(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}

export async function withE2B<T>(work: (sandbox: SandboxLike) => Promise<T>): Promise<T | null> {
  if (import.meta.env?.SSR === false) return null;
  const { resolveE2bKey } = await import("./e2b-key.server");
  const apiKey = await resolveE2bKey();
  if (!apiKey) return null;
  try {
    const { Sandbox } = await import("e2b");
    const sandbox = await Sandbox.create(TEMPLATE(), { apiKey, timeoutMs: 180_000, allowInternetAccess: true });
    try {
      return await work(sandbox as unknown as SandboxLike);
    } finally {
      await sandbox.kill().catch(() => undefined);
    }
  } catch {
    return null;
  }
}

async function run(sandbox: SandboxLike, cmd: string, timeoutMs: number): Promise<string> {
  try {
    const result = await sandbox.commands.run(cmd, { timeoutMs });
    if (result.exitCode && result.exitCode !== 0) return "";
    return scrubSecrets(result.stdout ?? "");
  } catch {
    return "";
  }
}

export async function readInSandbox(url: string): Promise<{ text: string; via: "e2b-chromium" | "e2b-curl" } | null> {
  const safe = toUrl(url);
  if (!safe) return null;
  return withE2B(async (sandbox) => {
    const chromium = [
      "chromium",
      "--headless",
      "--no-sandbox",
      "--disable-dev-shm-usage",
      `--user-agent=${shQuote(READER_UA)}`,
      "--virtual-time-budget=20000",
      "--dump-dom",
      shQuote(safe),
    ].join(" ");
    const dom = await run(sandbox, chromium, 40_000);
    if (dom.trim().length >= 40 && !/^error\b/i.test(dom.trim())) {
      return { text: dom.slice(0, 20_000), via: "e2b-chromium" as const };
    }
    const curled = await run(sandbox, `curl -fsSL -A ${shQuote(READER_UA)} --max-time 20 ${shQuote(safe)}`, 25_000);
    if (curled.trim().length >= 40 && !/^error\b/i.test(curled.trim())) {
      return { text: curled.slice(0, 20_000), via: "e2b-curl" as const };
    }
    return null;
  });
}

export async function curlInSandbox(url: string): Promise<string> {
  const safe = toUrl(url);
  if (!safe) return "";
  const text = await withE2B(async (sandbox) => run(sandbox, `curl -fsSL -A ${shQuote(READER_UA)} --max-time 20 ${shQuote(safe)}`, 25_000));
  return text ?? "";
}

export function looksLikeError(text: string): boolean {
  const sample = clean(text).slice(0, 500);
  if (!sample) return true;
  return /^(error|forbidden|access denied|unauthorized)\b/i.test(sample) || /captcha|unusual traffic|just a moment|enable javascript/i.test(sample);
}
