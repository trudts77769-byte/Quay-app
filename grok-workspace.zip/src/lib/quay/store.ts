import { create } from "zustand";
import { persist } from "zustand/middleware";
import { createMachine, createRack, step, type Command, type Machine } from "@/lib/quay/engine";

export interface Paper {
  id: number;
  task: string;
  text: string;
  sources: string[];
}
export interface TraceLine {
  id: number;
  text: string;
  tone: "move" | "click" | "warn" | "model";
}

interface QuayState {
  machines: Machine[];
  activeId: string;
  tape: string;
  trace: TraceLine[];
  seq: number;
  papers: Paper[];
  setActive: (id: string) => void;
  setTape: (tape: string) => void;
  toggleLink: (id: string) => void;
  link: (id: string) => void;
  resetMachine: (id: string) => void;
  applyTo: (id: string, command: Command) => void;
  placeCursor: (id: string, col: number, row: number) => void;
  pushTrace: (text: string, tone: TraceLine["tone"]) => void;
  savePaper: (paper: Omit<Paper, "id">) => void;
  clearPapers: () => void;
  noteReading: (id: string, url: string, title: string, transcript: string) => void;
  openAddress: (id: string, url: string) => void;
}

const rack = createRack();

export const useQuay = create<QuayState>()(
  persist(
    (set, get) => ({
      machines: rack,
      activeId: "web",
      tape: rack[0]?.rehearsal ?? "",
      trace: [],
      seq: 1,
      papers: [],
      setActive: (id) => set({ activeId: id }),
      setTape: (tape) => set({ tape }),
      toggleLink: (id) =>
        set((state) => ({
          machines: state.machines.map((machine) =>
            machine.id === id ? { ...machine, attached: !machine.attached } : machine,
          ),
        })),
      link: (id) =>
        set((state) => ({
          machines: state.machines.map((machine) =>
            machine.id === id ? { ...machine, attached: true } : machine,
          ),
        })),
      resetMachine: (id) =>
        set((state) => ({
          machines: state.machines.map((machine) =>
            machine.id === id ? createMachine(machine.kind, machine.attached) : machine,
          ),
        })),
      applyTo: (id, command) => {
        const current = get().machines.find((machine) => machine.id === id);
        if (!current) return;
        const result = step(current, command);
        const seq = get().seq + 1;
        set((state) => ({
          seq,
          machines: state.machines.map((machine) => (machine.id === id ? result.machine : machine)),
          trace: [...state.trace, { id: seq, text: result.note, tone: result.tone }].slice(-40),
        }));
      },
      placeCursor: (id, col, row) => {
        const current = get().machines.find((machine) => machine.id === id);
        if (!current) return;
        if (current.cursor.c === col && current.cursor.r === row) return;
        const seq = get().seq + 1;
        set((state) => ({
          seq,
          machines: state.machines.map((machine) =>
            machine.id === id ? { ...machine, cursor: { c: col, r: row } } : machine,
          ),
          trace: [
            ...state.trace,
            { id: seq, text: `Pointer placed at ${col},${row}`, tone: "move" as const },
          ].slice(-40),
        }));
      },
      pushTrace: (text, tone) => {
        const seq = get().seq + 1;
        set((state) => ({
          seq,
          trace: [...state.trace, { id: seq, text, tone }].slice(-40),
        }));
      },
      savePaper: (paper) => {
        const seq = get().seq + 1;
        set((state) => ({
          seq,
          papers: [{ ...paper, id: seq }, ...state.papers].slice(0, 8),
        }));
      },
      clearPapers: () => set({ papers: [] }),
      noteReading: (id, url, title, transcript) =>
        set((state) => ({
          machines: state.machines.map((machine) => {
            if (machine.id !== id || !machine.web || machine.web.url !== url) return machine;
            return {
              ...machine,
              web: {
                ...machine.web,
                title,
                transcript: transcript.slice(0, 5000),
              },
            };
          }),
        })),
      openAddress: (id, url) =>
        set((state) => ({
          machines: state.machines.map((machine) => {
            if (machine.id !== id || !machine.web) return machine;
            let host = url;
            try {
              host = new URL(url).hostname;
            } catch {
              host = url;
            }
            return {
              ...machine,
              web: { address: host, url, title: "Page", transcript: "" },
            };
          }),
        })),
    }),
    {
      name: "quay-v3",
      skipHydration: true,
      partialize: (state) => ({
        machines: state.machines,
        activeId: state.activeId,
        tape: state.tape,
        trace: state.trace,
        seq: state.seq,
        papers: state.papers,
      }),
      merge: (persisted, current) => {
        const saved = persisted as Partial<QuayState>;
        return {
          ...current,
          ...saved,
          papers: Array.isArray(saved.papers) ? saved.papers.slice(0, 8) : [],
        };
      },
    },
  ),
);
