import assert from "node:assert/strict";
import test from "node:test";
import { chiefGrant, workerEscalate, workerHas } from "@/lib/quay/capabilities";
import { memoryCapture, memoryDefrag, memorySearch } from "@/lib/quay/task-memory";
import { noteSupervision, openSupervision } from "@/lib/quay/supervisor";

test("the chief grants browser use and a worker cannot escalate", () => {
  const caps = chiefGrant("cap-job", "Open the sandbox lab page and click Submit");
  assert.ok(caps.includes("browser"));
  assert.equal(workerHas("cap-job", "browser"), true);
  assert.equal(workerHas("cap-job", "shell"), false);
  assert.equal(workerEscalate("cap-job", "shell"), false);
  assert.equal(workerHas("cap-job", "shell"), false);
});

test("memory stores the task and drops secrets", () => {
  const id = memoryCapture("checkpoint for the lab. api_key=supersecretvalue");
  const found = memorySearch("lab");
  assert.ok(found.some((row) => row.id === id));
  assert.equal(found.some((row) => /supersecretvalue/.test(row.text)), false);
  memoryDefrag();
});

test("completion without evidence stays open", () => {
  openSupervision("sup-job", "Look up the title", 1, "Open the page");
  const blocked = noteSupervision("sup-job", { complete: true, decision: "done" });
  assert.equal(blocked?.complete, false);
  assert.match(blocked?.blocker ?? "", /evidence/);
  const done = noteSupervision("sup-job", { complete: true, evidence: "https://example.com/", decision: "title read" });
  assert.equal(done?.complete, true);
  assert.equal(done?.evidenceLabel, "real-screenshot");
});
