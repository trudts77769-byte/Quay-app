import { createServerFn } from "@tanstack/react-start";
import { runAgent, movesFromReply } from "@/lib/quay/agent";
import { emptyAgent, formatAgent, type AgentState } from "@/lib/quay/agent-view";
import { toUrl } from "@/lib/quay/engine";
import { readSecret } from "@/lib/quay/secrets";

const STEPS = 6;
const HAND = [
  "The person gave you one task. They will not type another command. You keep moving until that task is finished.",
  "Reply with commands only: up down left right click. A star repeats: right*2. At most 4 commands.",
  "click opens the link in the current cell.",
  "If TRANSCRIPT already finishes the task, reply with the single word done.",
  "Close only a popup that is not needed for the task. Do not stop to ask the person.",
  "To fill a field, move onto it and reply type \"the words\". Then click the submit button.",
].join(" ");

const ANSWER = [
  "The pointer already moved. Answer the person in one or two ordinary sentences.",
  "Use only the transcript. Quote the useful line. Do not reply with only up, down, left, right, or click.",
].join(" ");

export interface HandResult {
  ok: boolean;
  tape: string;
  answer: string;
  error: string;
  spent: boolean;
  state: AgentState;
}

async function askModel(apiKey: string, system: string, user: string, tokens: number): Promise<string> {
  const response = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    signal: AbortSignal.timeout(25000),
    body: JSON.stringify({
      model: "grok-4.5",
      temperature: 0,
      max_tokens: tokens,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  });
  if (!response.ok) throw new Error(`The model link failed (${response.status}).`);
  const body = (await response.json()) as {
    choices?: { message?: { content?: string | null } }[];
  };
  return body.choices?.[0]?.message?.content?.trim() ?? "";
}

function asTape(reply: string): string {
  return movesFromReply(reply, 4);
}

function saidDone(reply: string): boolean {
  return /\bdone\b/i.test(reply) && movesFromReply(reply, 4).length === 0;
}

export async function runHand(url: string, goal: string, apiKey: string): Promise<HandResult> {
  const safe = toUrl(url);
  if (!safe) {
    return {
      ok: false,
      tape: "",
      answer: "",
      error: "That address cannot be opened. Use a public site.",
      spent: false,
      state: emptyAgent(),
    };
  }

  let state = await runAgent({ url: safe, tape: "" });
  if (state.error && !state.transcript) {
    return { ok: false, tape: "", answer: "", error: state.error, spent: false, state };
  }

  const opened = state.url;
  let tape = "";
  let settled = false;
  for (let step = 0; step < STEPS; step += 1) {
    if (tape.split(/\s+/).filter(Boolean).length >= 24) break;
    const brief = formatAgent({
      ...state,
      transcript: state.transcript.slice(0, 900),
      cells: state.cells.slice(0, 16),
    });
    let reply = "";
    try {
      reply = await askModel(
        apiKey,
        HAND,
        `GOAL ${goal}\n\n${brief}\n\nTAPE SO FAR ${tape || "(none yet)"}`,
        24,
      );
    } catch (err) {
      return {
        ok: false,
        tape,
        answer: "",
        error: err instanceof Error ? err.message : "The model did not finish the task.",
        spent: true,
        state,
      };
    }
    if (saidDone(reply)) {
      settled = true;
      break;
    }
    const piece = asTape(reply);
    if (!piece) break;
    tape = `${tape} ${piece}`.trim();
    state = await runAgent({ url: safe, tape });
    if (state.url && state.url !== opened && /\bdone\b/i.test(reply)) break;
  }

  if (!tape && !settled) {
    return {
      ok: false,
      tape: "",
      answer: "",
      error: "The model did not finish the task.",
      spent: true,
      state,
    };
  }

  let answer = "";
  try {
    answer = await askModel(
      apiKey,
      ANSWER,
      `GOAL ${goal}\nThe pointer ran: ${tape}\n\n${formatAgent({
        ...state,
        transcript: state.transcript.slice(0, 1200),
        cells: state.cells.slice(0, 8),
      })}`,
      120,
    );
  } catch {
    answer = state.transcript.slice(0, 400);
  }

  return { ok: true, tape, answer, error: "", spent: true, state };
}

export const steerWeb = createServerFn({ method: "POST" })
  .validator((input: unknown): { url: string; goal: string } => {
    const raw = (input ?? {}) as { url?: unknown; goal?: unknown };
    const url = typeof raw.url === "string" ? raw.url.trim().slice(0, 500) : "";
    const goal = typeof raw.goal === "string" ? raw.goal.trim().slice(0, 400) : "";
    if (!toUrl(url)) throw new Error("That address cannot be opened.");
    if (goal.length < 2) throw new Error("Tell the model what to open.");
    return { url, goal };
  })
  .handler(async ({ data }): Promise<HandResult> => {
    const apiKey = readSecret("XAI_API_KEY");
    if (!apiKey) {
      return {
        ok: false,
        tape: "",
        answer: "",
        error: "No model is wired into this sandbox. Paste a tape and press Run.",
        spent: false,
        state: emptyAgent(),
      };
    }
    return runHand(data.url, data.goal, apiKey);
  });
