export type KeyName = "none" | "GEMINI_API_KEY" | "OPENROUTER_API_KEY" | "HF_TOKEN" | "XAI_API_KEY" | "GROQ_API_KEY" | "LOCAL";

export type CatalogRow = {
  id: string;
  label: string;
  group: string;
  key: KeyName;
  space?: string;
  web?: boolean;
};

const CHAT = [
  "huggingface-projects/llama-2-13b-chat",
  "huggingface-projects/llama-2-7b-chat",
  "ysharma/Chat_with_Meta_llama3_8b",
  "huggingface-projects/gemma-4-12b-it",
  "sambanovasystems/Llama3.1-Instruct-O1",
  "gokaygokay/Gemma-2-llamacpp",
  "huggingface-projects/llama-3.2-3B-Instruct",
  "Qwen/Qwen3-Demo",
  "ehristoforu/mistral-7b-chat",
  "Be-Bo/llama-3-chatbot_70b",
  "DarwinAnim8or/Mistral-Chat",
  "ehristoforu/mixtral-46.7b-chat",
  "Harley-ml/SmolLM2_Chat",
  "ysharma/Chat_with_Meta_llama3_1_8b",
  "chheplo/DeepSeek-R1-Distill-Llama-8B",
];

const SUMMARY = [
  "pszemraj/summarize-long-text",
  "pszemraj/document-summarization",
  "razakhan/text-summarizer",
  "Tulika2000/ai-pdf-summarizer",
  "Walid-Ahmed/Advanced_Text_Summarization",
  "adarshzolekar/Website-Summarizer",
  "anishde/SIMPLIFY_text_summarizer",
  "AmK1304/Document_Summarizer",
];

const OCR = [
  "PaddlePaddle/PP-OCRv5_Online_Demo",
  "pragnakalp/OCR-image-to-text",
  "yonigozlan/GOT-OCR-Transformers",
  "gokaygokay/Florence-2",
  "merterbak/DeepSeek-OCR-Demo",
  "baidu/Unlimited-OCR",
  "khang119966/DeepSeek-OCR-DEMO",
  "prithivMLmods/Multimodal-OCR",
  "prithivMLmods/core-OCR",
  "pszemraj/pdf-ocr",
  "MohamedRashad/Dots-OCR",
  "prithivMLmods/Multimodal-OCR2",
  "prithivMLmods/GLM-OCR-Demo",
  "Ayaan-Sharif/ocr-layout-detection-poc",
];

const WEB = [
  "Agents-MCP-Hackathon/web-scraper",
  "Frantz103/html-to-markdown",
  "deep-div/MCP-Web-Search",
  "AkshayStark3000/webScraper",
  "Agents-MCP-Hackathon/web-search-mcp",
  "siam3310/web-scraper",
  "Ifeanyi/Web-Search-MCP",
  "nelsondiasandre/web-search-mcp",
];

const SHOT = [
  "HuggingFaceM4/screenshot2html",
  "dhuynh95/screenshot_to_html",
  "jiseki/selenium-screenshot-gradio",
  "rafael1994s/Playwright",
];

const TRANSLATE = [
  "avans06/whisper-webui-translate",
  "gundeep/open-translate",
  "Helsinki-NLP/opus-translate",
  "hysts/translategemma-27b-it",
  "CohereLabs/command-a-translate",
];

const SPEECH = [
  "openai/whisper",
  "hf-audio/whisper-large-v3",
  "KingNish/Realtime-whisper-large-v3-turbo",
  "nvidia/parakeet-tdt-0.6b-v3",
];

const IMAGE = [
  "black-forest-labs/FLUX.1-schnell",
  "black-forest-labs/FLUX.1-dev",
  "yanze/PuLID-FLUX",
  "stabilityai/stable-diffusion-3.5-large",
  "stabilityai/stable-diffusion-3-medium",
];

function spaces(kind: string, group: string, list: string[], web = false): CatalogRow[] {
  return list.map((space) => ({
    id: `hf:${space}`,
    label: `${kind} · ${space.split("/")[1] ?? space}`,
    group,
    key: "HF_TOKEN" as const,
    space,
    web,
  }));
}

const ROWS: CatalogRow[] = [
  { id: "worker-xai", label: "Grok 4.5", group: "xAI", key: "XAI_API_KEY" },
  { id: "worker-gemini", label: "Gemini 2.0 Flash", group: "Google", key: "GEMINI_API_KEY" },
  { id: "worker-openrouter", label: "Gemma 4 26B", group: "OpenRouter", key: "OPENROUTER_API_KEY" },
  { id: "worker-openrouter-2", label: "Ling 3.0 Flash", group: "OpenRouter", key: "OPENROUTER_API_KEY" },
  { id: "worker-groq", label: "Llama 3.3 70B", group: "Groq", key: "GROQ_API_KEY" },
  { id: "worker-ovh", label: "gpt-oss-20b", group: "OVH", key: "none" },
  { id: "worker-airforce", label: "rnj-1", group: "Airforce", key: "none" },
  { id: "worker-airforce-2", label: "Llama Instant", group: "Airforce", key: "none" },
  { id: "worker-pollinations", label: "Pollinations", group: "Pollinations", key: "none" },
  { id: "worker-local", label: "Local", group: "Local", key: "LOCAL" },
  { id: "worker-hf", label: "Qwen 2.5 7B", group: "Hugging Face", key: "HF_TOKEN" },
  ...spaces("Chat", "Hugging Face — Chat", CHAT),
  ...spaces("Summarization", "Hugging Face — Summarization", SUMMARY),
  ...spaces("OCR", "Hugging Face — OCR", OCR),
  ...spaces("Web reading", "Hugging Face — Web reading", WEB, true),
  ...spaces("Screenshot", "Hugging Face — Screenshot", SHOT),
  ...spaces("Translation", "Hugging Face — Translation", TRANSLATE),
  ...spaces("Speech to text", "Hugging Face — Speech to text", SPEECH),
  ...spaces("Image", "Hugging Face — Image", IMAGE),
];

export function allModels(): CatalogRow[] {
  return ROWS;
}

export function labelOf(id: string): string {
  return ROWS.find((row) => row.id === id)?.label ?? id;
}

export function webSpaces(): CatalogRow[] {
  return ROWS.filter((row) => row.web);
}

export const REASON_ORDER = ["worker-xai", "worker-gemini", "worker-openrouter", "worker-openrouter-2", "worker-hf"];
