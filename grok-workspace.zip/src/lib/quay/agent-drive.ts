import { createServerFn } from "@tanstack/react-start";
import { runAgent } from "@/lib/quay/agent";
import type { AgentState } from "@/lib/quay/agent-view";

export const driveAgent = createServerFn({ method: "POST" })
  .validator((input: unknown): { url: string; tape: string; column: number; row: number; scroll: number; closePopups: boolean; task: string } => {
    const raw = (input ?? {}) as {
      url?: unknown;
      tape?: unknown;
      column?: unknown;
      row?: unknown;
      scroll?: unknown;
      closePopups?: unknown;
      task?: unknown;
    };
    const url = typeof raw.url === "string" ? raw.url.trim().slice(0, 500) : "";
    const tape = typeof raw.tape === "string" ? raw.tape.trim().slice(0, 800) : "";
    const number = (value: unknown) => (typeof value === "number" && Number.isFinite(value) ? value : 0);
    if (!url && !tape) throw new Error("Say a site or a tape.");
    return {
      url,
      tape,
      column: number(raw.column),
      row: number(raw.row),
      scroll: number(raw.scroll),
      closePopups: raw.closePopups !== false,
      task: typeof raw.task === "string" ? raw.task.slice(0, 500) : "",
    };
  })
  .handler(async ({ data }): Promise<AgentState> => {
    return runAgent(data);
  });
