export function absorbAccounts(text: string): string {
  return text.replace(/(^|\n)([ \t]*PASSWORD:\s*)(\S+)/gi, (_match, lead: string, label: string, secret: string) =>
    secret ? `${lead}${label}[redacted]` : _match,
  );
}
