export const CAPABILITIES = [
  "SELECT",
  "INSERT",
  "UPDATE",
  "DELETE",
  "EXECUTE",
  "browser",
  "shell",
  "file",
  "repository",
  "plugin",
  "mail",
  "connector",
] as const;

export type Capability = (typeof CAPABILITIES)[number];

const grants = new Map<string, Set<Capability>>();
const denied = new Map<string, string[]>();

export function grantForTask(task: string): Capability[] {
  const caps = new Set<Capability>(["SELECT"]);
  if (/https?:\/\/|sandbox lab|click|browse|website|page|look up|visit/i.test(task)) caps.add("browser").add("EXECUTE");
  if (/\b(shell|terminal|command)\b/i.test(task)) caps.add("shell").add("EXECUTE");
  if (/\b(file|save|write|read the repo|repository|commit)\b/i.test(task)) caps.add("file");
  if (/\b(repository|commit|pull request|edit the code)\b/i.test(task)) caps.add("repository");
  if (/\b(plugin|tool)\b/i.test(task)) caps.add("plugin");
  if (/\b(email|mail|inbox)\b/i.test(task)) caps.add("mail");
  if (/\b(insert|add a row|create)\b/i.test(task)) caps.add("INSERT");
  if (/\b(update|change the record)\b/i.test(task)) caps.add("UPDATE");
  if (/\b(delete|remove the record)\b/i.test(task)) caps.add("DELETE");
  if (/\b(connector|drive|calendar)\b/i.test(task)) caps.add("connector");
  return [...caps];
}

export function chiefGrant(job: string, task: string): Capability[] {
  const caps = grantForTask(task);
  grants.set(job, new Set(caps));
  return caps;
}

export function granted(job: string): Capability[] {
  return [...(grants.get(job) ?? new Set<Capability>(["SELECT"]))];
}

export function workerHas(job: string, capability: Capability): boolean {
  return grants.get(job)?.has(capability) ?? capability === "SELECT";
}

export function workerEscalate(job: string, capability: Capability): false {
  const list = denied.get(job) ?? [];
  list.push(capability);
  denied.set(job, list.slice(-20));
  return false;
}

export function deniedEscalations(job: string): string[] {
  return [...(denied.get(job) ?? [])];
}
