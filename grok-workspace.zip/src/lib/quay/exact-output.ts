export type ExactMode = "" | "bare" | "yesno" | "json";

export function exactOutput(task: string): ExactMode {
  const text = task.toLowerCase();
  if (/\bjson only\b|\bonly json\b|\breturn json\b/.test(text)) return "json";
  if (/\byes or no only\b|\banswer yes or no\b/.test(text)) return "yesno";
  if (/\bonly the exact\b|\breturn only\b|\bno other text\b|\bexact title\b|\bonly the page title\b|\breport the exact\b|\bexact success message\b/.test(text)) return "bare";
  return "";
}

export function exactComplete(task: string, text: string): boolean {
  const mode = exactOutput(task);
  const clean = text.trim();
  if (!mode) return false;
  if (mode === "yesno") return /^(yes|no)$/i.test(clean);
  if (mode === "json") {
    try {
      JSON.parse(clean);
      return true;
    } catch {
      return false;
    }
  }
  if (!clean || clean.includes("\n") || /^(found|where):/i.test(clean)) return false;
  return clean.length > 0 && clean.length < 240;
}

export function shapeUserAnswer(task: string, answer: string, title = "", url = ""): string {
  const mode = exactOutput(task);
  const raw = answer.replace(/\r/g, "").trim();
  if (!mode) {
    if (!raw) return "";
    if (/^Found:/i.test(raw)) return raw;
    return `Found: ${raw}\nWhere: ${url}`;
  }
  if (mode === "yesno") return /\byes\b/i.test(raw) ? "Yes" : "No";
  if (mode === "json") {
    const objectStart = answer.indexOf("{");
    const objectEnd = answer.lastIndexOf("}");
    if (objectStart >= 0 && objectEnd > objectStart) return answer.slice(objectStart, objectEnd + 1).trim();
    const listStart = answer.indexOf("[");
    const listEnd = answer.lastIndexOf("]");
    if (listStart >= 0 && listEnd > listStart) return answer.slice(listStart, listEnd + 1).trim();
    return raw;
  }
  const success = raw.match(/SUCCESS:\s*[^.\n]+/i)?.[0]?.replace(/\s+/g, " ").trim() ?? "";
  if (/success message/i.test(task) && success) return success;
  if (/title/i.test(task) && title.trim()) return title.trim();
  const line = raw.split("\n").map((item) => item.trim()).find(Boolean) ?? "";
  return line.replace(/^found:\s*/i, "").replace(/^where:.*$/i, "").trim();
}
