import { runPlan } from "@/lib/quay/plan";

export interface HireRow {
  name: string;
  body: string;
  tried: string[];
  pages: string[];
  steps: string[];
  fn: string;
  accepted: boolean;
}

export function resolveHireAnswerFormat(order: string): "five-ws" | "plain" {
  return /format\s*=\s*(five-ws|report|monitor)|FORMAT:\s*five-ws|TYPE:\s*monitor/i.test(order) ? "five-ws" : "plain";
}

export async function hireFollowers(task: string, order: string, _need = 8): Promise<HireRow[]> {
  const run = await runPlan(task || "hire", order || task);
  const tried = run.tried;
  const pages = [...new Set(run.steps.flatMap((step) => step.pages))];
  const steps = run.steps.map((step) => `${step.follower || "none"} ${step.fn} ${step.n}`);
  const rows: HireRow[] = run.steps
    .filter((step) => step.text || step.follower)
    .map((step) => ({
      name: step.follower || step.fn,
      body: step.fn === "assemble" && run.accepted ? run.answer : step.text,
      tried,
      pages: step.pages.length > 0 ? step.pages : pages,
      steps,
      fn: step.fn,
      accepted: false,
    }));
  if (run.accepted) {
    rows.push({
      name: run.steps.find((step) => step.fn === "assemble")?.follower || "assembler",
      body: run.answer,
      tried,
      pages,
      steps,
      fn: "assemble",
      accepted: true,
    });
  }
  if (rows.length === 0) return [{ name: "", body: "", tried, pages, steps, fn: "", accepted: false }];
  return rows;
}