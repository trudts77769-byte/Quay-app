import { labelOf, REASON_ORDER, webSpaces } from "@/lib/quay/catalog";
import { lessonText, searchFailures, sourceOf, taskTypeOf } from "@/lib/quay/failures";
import { noteRepoMatches } from "@/lib/quay/job-audit";
import { statusOf } from "@/lib/quay/model-status";
import { pinnedModel, runModel } from "@/lib/quay/providers";
import { researchBundle } from "@/lib/quay/search";
import { noteHire } from "@/lib/quay/test-trace";

function chatCandidates(skip: string): string[] {
  return REASON_ORDER.filter((id) => id !== skip && statusOf(id) !== "Key missing");
}

export async function otherReasoning(job: string, step: number, user: string): Promise<string> {
  const system =
    "You are the Reasoning bot hired by the chief. You run this redundancy stage. Do not answer the user's task. Do not browse. Reply with a JSON array only. Each item has who, what, when, where, why, and how. One item per cause.";
  for (const id of chatCandidates(pinnedModel(job))) {
    const called = await runModel(
      job,
      "reasoning",
      id,
      [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
      true,
    );
    noteHire(job, step, labelOf(id), "reasoning", Boolean(called.text));
    if (called.text) return called.text;
  }
  return "";
}

export async function otherResearch(job: string, step: number, task: string, goal: string, causes: string): Promise<string> {
  const pin = pinnedModel(job);
  const found = searchFailures(taskTypeOf(`${task} ${goal}`), sourceOf(`${task} ${goal} ${causes}`), causes);
  noteRepoMatches(job, found.used.map((row) => row.id));
  const repo = lessonText(found);
  const chunks: string[] = [];
  if (repo) chunks.push(repo);
  const bundle = await researchBundle(job, `${goal} ${task}`.slice(0, 160));
  for (const row of bundle) {
    noteHire(job, step, row.name, "research", Boolean(row.text));
    if (row.text) chunks.push(`${row.name}\n${row.text}`);
  }
  if (statusOf("worker-hf") !== "Key missing") {
    const spaces = webSpaces().filter((space) => space.id !== pin);
    for (let index = 0; index < spaces.length; index += 4) {
      const batch = spaces.slice(index, index + 4);
      const results = await Promise.all(
        batch.map(async (space) => {
          const called = await runModel(job, "research", space.id, [{ role: "user", content: `${goal}\n${task}`.slice(0, 500) }], true);
          return { name: space.space ?? space.label, text: called.text ?? "" };
        }),
      );
      for (const row of results) {
        noteHire(job, step, row.name, "research", Boolean(row.text));
        if (row.text) chunks.push(`${row.name}\n${row.text}`);
      }
    }
  }
  const findings = chunks.join("\n\n").slice(0, 3500);
  const ranker = chatCandidates(pin)[0];
  if (ranker && findings) {
    const called = await runModel(
      job,
      "research-rank",
      ranker,
      [
        {
          role: "system",
          content: "You rank research findings for the chief. Do not answer the user's task. Reply with the useful findings and one workaround per cause.",
        },
        { role: "user", content: `TASK\n${task}\n\nGOAL\n${goal}\n\nCAUSES\n${causes}\n\nFINDINGS\n${findings}` },
      ],
      true,
    );
    noteHire(job, step, labelOf(ranker), "research", Boolean(called.text));
    if (called.text) chunks.push(called.text);
  }
  return chunks.join("\n").slice(0, 1200);
}