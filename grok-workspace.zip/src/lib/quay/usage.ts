import { appendFileSync, existsSync, mkdirSync, statSync } from "node:fs";
import { join } from "node:path";

export type UsageRow = {
  at: string;
  job: string;
  slot: string;
  follower: string;
  provider: string;
  side: "chief" | "follower";
  inputTokens: number;
  outputTokens: number;
  estimated: boolean;
  wallMs: number;
  modelCalls: number;
  ok: boolean;
};

function dir(): string {
  return join(process.env.QUAY_DATA_DIR || join(process.cwd(), "data"), "usage");
}

const spent = new Map<string, number>();

export function withinSpend(job: string, cents: number): boolean {
  const cap = Number(process.env.QUAY_MAX_SPEND_CENTS ?? 500);
  if (!Number.isFinite(cap)) return true;
  const next = (spent.get(job) ?? 0) + Math.max(0, cents);
  if (next > cap) return false;
  spent.set(job, next);
  return true;
}

export function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.length / 4));
}

export function recordUsage(row: UsageRow): void {
  try {
    const folder = dir();
    mkdirSync(folder, { recursive: true });
    const safe = (row.job || "none").replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80) || "none";
    const base = join(folder, safe);
    const line = JSON.stringify(row);
    appendFileSync(`${base}.jsonl`, `${line}\n`);
    const csv = `${base}.csv`;
    const header = "at,job,slot,follower,provider,side,inputTokens,outputTokens,estimated,wallMs,modelCalls,ok\n";
    if (!existsSync(csv) || statSync(csv).size === 0) appendFileSync(csv, header);
    const cell = (value: string | number | boolean) => `"${String(value).replace(/"/g, '""')}"`;
    appendFileSync(
      csv,
      [row.at, row.job, row.slot, row.follower, row.provider, row.side, row.inputTokens, row.outputTokens, row.estimated, row.wallMs, row.modelCalls, row.ok].map(cell).join(",") + "\n",
    );
  } catch {
    /* disk may be read-only on the host; the job still continues */
  }
}
