import { GOOGLE_URL } from "@/lib/quay/engine";

const TTL_MS = 5 * 60 * 1000;

let cached: { html: string; at: number } | null = null;

const FALLBACK = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Google</title>
<base href="https://www.google.com/" target="_self">
<style>
  html,body{margin:0;height:100%;background:#fff;color:#202124}
  body{display:flex;align-items:center;justify-content:center;font-family:Arial,sans-serif}
  main{width:min(584px,92vw);text-align:center}
  p{margin:0 0 22px;font-size:54px;letter-spacing:-1px;font-weight:500}
  p span:nth-child(1){color:#4285f4}p span:nth-child(2){color:#ea4335}
  p span:nth-child(3){color:#fbbc05}p span:nth-child(4){color:#4285f4}
  p span:nth-child(5){color:#34a853}p span:nth-child(6){color:#ea4335}
  input{width:100%;box-sizing:border-box;border:1px solid #dfe1e5;border-radius:24px;padding:12px 16px;font-size:16px}
  button{margin-top:16px;border:1px solid #f8f9fa;background:#f8f9fa;border-radius:4px;padding:10px 16px;color:#3c4043}
</style></head>
<body><main>
<p aria-label="Google"><span>G</span><span>o</span><span>o</span><span>g</span><span>l</span><span>e</span></p>
<form action="https://www.google.com/search" method="get">
<input name="q" aria-label="Search" placeholder="Search">
<div><button type="submit">Google Search</button></div>
</form>
</main></body></html>`;

function tame(html: string): string {
  let out = html.replace(/<script\b[\s\S]*?<\/script>/gi, "");
  out = out.replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "");
  out = out.replace(/<object\b[\s\S]*?<\/object>/gi, "");
  out = out.replace(/<embed\b[^>]*>/gi, "");
  out = out.replace(/<meta\b[^>]*http-equiv\s*=\s*["']refresh["'][^>]*>/gi, "");
  out = out.replace(/\sautofocus(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi, "");
  out = out.replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "");
  out = out.replace(/\s(href|src|action)\s*=\s*(["'])\s*javascript:[\s\S]*?\2/gi, " $1=$2#$2");
  out = out.replace(/\starget\s*=\s*(["'])(?:_top|_parent)\1/gi, ' target="_self"');
  if (!/<base\b/i.test(out)) {
    out = out.replace(
      /<head([^>]*)>/i,
      '<head$1><base href="https://www.google.com/" target="_self">',
    );
  }
  return out;
}

export async function googleHomeHtml(): Promise<string> {
  if (cached && Date.now() - cached.at < TTL_MS) return cached.html;
  try {
    const response = await fetch(GOOGLE_URL, {
      redirect: "follow",
      signal: AbortSignal.timeout(8000),
      headers: {
        Accept: "text/html",
        "Accept-Language": "en",
        "User-Agent":
          "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
      },
    });
    if (!response.ok) return cached?.html ?? FALLBACK;
    const raw = (await response.text()).slice(0, 500_000);
    const html = tame(raw);
    if (!/aria-label="Google"|<title>\s*Google\s*<\/title>/i.test(html)) {
      return cached?.html ?? FALLBACK;
    }
    cached = { html, at: Date.now() };
    return html;
  } catch {
    return cached?.html ?? FALLBACK;
  }
}
