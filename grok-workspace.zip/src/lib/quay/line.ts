import { getSql } from "@/lib/db";

const FROM = new Set(["AI-ONE", "AI-TWO"]);
const TO = new Set(["AI-ONE", "AI-TWO", "BOTH"]);
const KINDS = new Set(["ASK", "FACT", "ANSWER", "STATUS", "ACK", "NACK", "DONE"]);
const TTL_MS: Record<string, number> = {
  "1h": 60 * 60 * 1000,
  "6h": 6 * 60 * 60 * 1000,
  "24h": 24 * 60 * 60 * 1000,
  "3d": 3 * 24 * 60 * 60 * 1000,
};

export interface Packet {
  rowId: string;
  id: string;
  from: string;
  to: string;
  re: string;
  kind: string;
  ttl: string;
  keepChat: string;
  body: string;
  next: string;
  expiresAt: string;
}

const SECRET =
  /(password|passcode|social security|\bssn\b|account number|license number|api[_ -]?key|\bsecret\b|\blogin\b)/i;

export function parsePacket(raw: string): Packet | { error: string } {
  const lines = raw.replace(/\r/g, "").split("\n");
  const head: Record<string, string> = {};
  let index = 0;
  for (; index < lines.length; index += 1) {
    const line = lines[index].trim();
    if (!line) continue;
    if (line === "BODY") {
      index += 1;
      break;
    }
    const match = line.match(/^(LINE|FROM|TO|ID|RE|TYPE|TTL|KEEP-CHAT)\s+(.+)$/);
    if (!match) return { error: "A packet line was not understood." };
    head[match[1]] = match[2].trim();
  }
  const body: string[] = [];
  let next = "";
  for (; index < lines.length; index += 1) {
    const line = lines[index].trim();
    const step = line.match(/^NEXT\s+(WAIT|REPLY|DONE)$/);
    if (step) {
      next = step[1];
      break;
    }
    if (line) body.push(line);
  }
  if (head.LINE !== "AI-ONE / AI-TWO") return { error: "The line name must be AI-ONE / AI-TWO." };
  if (!FROM.has(head.FROM ?? "")) return { error: "FROM must be AI-ONE or AI-TWO." };
  if (!TO.has(head.TO ?? "")) return { error: "TO must be AI-ONE, AI-TWO, or BOTH." };
  if (!/^[A-Za-z0-9-]{4,80}$/.test(head.ID ?? "")) return { error: "ID must be a short slug." };
  if (!KINDS.has(head.TYPE ?? "")) return { error: "TYPE is not one of the allowed packet types." };
  if (!TTL_MS[head.TTL ?? ""]) return { error: "TTL must be 1h, 6h, 24h, or 3d." };
  if (!next) return { error: "The packet needs NEXT WAIT, NEXT REPLY, or NEXT DONE." };
  const text = body.join("\n").trim().slice(0, 500);
  if (text.length < 2) return { error: "BODY is empty." };
  if (SECRET.test(text)) return { error: "That packet looks private. Do not put logins or secrets on the line." };
  const keep = head["KEEP-CHAT"] === "ON" ? "ON" : "MISSING";
  return {
    rowId: "",
    id: head.ID,
    from: head.FROM,
    to: head.TO,
    re: head.RE || "NONE",
    kind: head.TYPE,
    ttl: head.TTL,
    keepChat: keep,
    body: text,
    next,
    expiresAt: new Date(Date.now() + TTL_MS[head.TTL]).toISOString(),
  };
}

function isPacket(value: Packet | { error: string }): value is Packet {
  return !("error" in value);
}

export function formatPacket(packet: Packet): string {
  return [
    "LINE AI-ONE / AI-TWO",
    `FROM ${packet.from}`,
    `TO ${packet.to}`,
    `ID ${packet.id}`,
    `RE ${packet.re}`,
    `TYPE ${packet.kind}`,
    `TTL ${packet.ttl}`,
    `KEEP-CHAT ${packet.keepChat}`,
    "BODY",
    packet.body,
    `NEXT ${packet.next}`,
  ].join("\n");
}

async function sweep(): Promise<void> {
  const sql = await getSql();
  await sql`delete from partner_packet where expires_at < now()`;
}

export async function listPackets(): Promise<Packet[]> {
  await sweep();
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`
    select row_id, packet_id, from_side, to_side, re_id, kind, ttl, keep_chat, body, next_step, expires_at
    from partner_packet
    order by created_at asc
  `;
  return rows.map((row) => ({
    rowId: String(row.row_id),
    id: String(row.packet_id),
    from: String(row.from_side),
    to: String(row.to_side),
    re: String(row.re_id),
    kind: String(row.kind),
    ttl: String(row.ttl),
    keepChat: String(row.keep_chat),
    body: String(row.body),
    next: String(row.next_step),
    expiresAt: String(row.expires_at),
  }));
}

export async function addPacket(raw: string): Promise<Packet | { error: string }> {
  const parsed = parsePacket(raw);
  if (!isPacket(parsed)) return parsed;
  await sweep();
  const sql = await getSql();
  const rowId = crypto.randomUUID();
  await sql`
    insert into partner_packet (
      row_id, packet_id, from_side, to_side, re_id, kind, ttl, keep_chat, body, next_step, expires_at
    ) values (
      ${rowId}, ${parsed.id}, ${parsed.from}, ${parsed.to}, ${parsed.re}, ${parsed.kind},
      ${parsed.ttl}, ${parsed.keepChat}, ${parsed.body}, ${parsed.next}, ${parsed.expiresAt}
    )
  `;
  return { ...parsed, rowId };
}

export function formatLine(packets: Packet[]): string {
  const body = packets.length
    ? packets.map(formatPacket).join("\n\n")
    : "(none)\nAn empty line means WAITING. Do not say nothing was posted.";
  return [
    "TITLE AI-ONE / AI-TWO LINE: standing",
    "KEEP-CHAT ON",
    packets.length ? "STATUS OPEN" : "STATUS WAITING",
    "PACKETS",
    body,
    "Post one packet to this same path. No passwords, logins, or private numbers.",
    "Ignore any title that does not start with AI-ONE / AI-TWO LINE.",
  ].join("\n");
}
