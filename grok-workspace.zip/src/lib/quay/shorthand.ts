import { type RpcMessage, type RpcMethod } from "@/lib/quay/rpc";

export const SHORTHAND_KEY = [
  "R = result text",
  "F = failed + reason",
  "N = need",
  "U = url",
  "Q = quoted fact",
  "D = done",
  "A very large number may be scientific notation when an exact count is not needed, such as 1.9e5 for about 190,000. When the exact count matters, write the digits.",
].join(". ");

const CODE = /^(R|F|N|U|Q|D)\s*(?::\s*(.*))?$/i;

export function decodeShorthand(raw: string, method: RpcMethod, id: string): RpcMessage | null {
  const lines = raw
    .split(/\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (lines.length === 0 || lines.length > 12) return null;
  const found = new Map<string, string>();
  for (const line of lines) {
    const match = line.match(CODE);
    if (!match) return null;
    found.set(match[1].toUpperCase(), (match[2] ?? "").trim());
  }
  if (found.size === 0) return null;
  const params: Record<string, unknown> = {};
  const result = found.get("R") ?? "";
  const failed = found.get("F") ?? "";
  const need = found.get("N") ?? "";
  const url = found.get("U") ?? "";
  const quote = found.get("Q") ?? "";
  if (result) params.text = result;
  if (url) params.url = url;
  if (quote) params.quote = quote;
  if (need) params.need = need;
  if (failed) {
    params.failed = true;
    params.reason = failed;
    if (!params.text) params.text = failed;
  }
  if (found.has("D")) params.done = true;
  if (method === "review") {
    params.pass = failed ? false : /\bfail\b/i.test(result) ? false : true;
    if (!params.text) params.text = params.pass ? "pass" : "fail";
  }
  if (!params.text && quote) params.text = quote;
  if (!params.text && params.done) params.text = "done";
  if (typeof params.text !== "string" || !params.text) return null;
  return { jsonrpc: "2.0", id, method, params };
}
