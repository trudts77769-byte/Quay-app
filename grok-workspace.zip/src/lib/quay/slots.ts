type Runner = () => Promise<void>;

type Waiter = { id: string; grant: (slot: string) => void };

const waiters: Waiter[] = [];
const running = new Map<string, string>();
let busy = 0;
let browsers = 0;
let ticket = 0;
const browserWaiters: Array<() => void> = [];

export type StepNote = {
  id: string;
  slot: string;
  step: number;
  fn: string;
  status: "queued" | "running" | "retry" | "done" | "failed" | "released" | "waiting";
  follower: string;
  tries: number;
  page?: string;
  detail?: string;
};

const history: StepNote[] = [];

function slotCount(): number {
  const parsed = Number(process.env.QUAY_SLOT_COUNT ?? 20);
  return Number.isFinite(parsed) && parsed > 0 ? Math.min(parsed, 40) : 20;
}

function leaseCount(): number {
  const parsed = Number(process.env.QUAY_BROWSER_LEASES ?? 2);
  return Number.isFinite(parsed) && parsed > 0 ? Math.min(parsed, 2) : 2;
}

function grantNext(): void {
  while (busy < slotCount() && waiters.length > 0) {
    const waiter = waiters.shift();
    if (!waiter) return;
    busy += 1;
    ticket += 1;
    const slot = `slot-${((ticket - 1) % slotCount()) + 1}`;
    running.set(waiter.id, slot);
    waiter.grant(slot);
  }
}

function acquire(id: string): Promise<string> {
  return new Promise((resolve) => {
    waiters.push({ id, grant: resolve });
    grantNext();
  });
}

function release(id: string): void {
  running.delete(id);
  busy = Math.max(0, busy - 1);
  grantNext();
}

export function noteStep(note: StepNote): void {
  const row: StepNote = { page: "", detail: "", ...note };
  const index = history.findIndex((item) => item.id === row.id);
  if (index >= 0) history[index] = row;
  else history.push(row);
  if (history.length > 80) history.splice(0, history.length - 80);
}

export async function withSlot<T>(id: string, work: (slot: string) => Promise<T>): Promise<T> {
  const slot = await acquire(id);
  try {
    return await work(slot);
  } finally {
    release(id);
  }
}

export function enqueueJob(id: string, run: Runner): void {
  noteStep({ id, slot: "", step: 0, fn: "job", status: "queued", follower: "", tries: 0 });
  void withSlot(id, async (slot) => {
    noteStep({ id, slot, step: 0, fn: "job", status: "running", follower: "", tries: 0 });
    await run();
    noteStep({ id, slot, step: 0, fn: "job", status: "done", follower: "", tries: 0 });
  });
}

export async function leaseBrowser<T>(work: () => Promise<T>): Promise<T> {
  while (browsers >= leaseCount()) {
    await new Promise<void>((resolve) => browserWaiters.push(resolve));
  }
  browsers += 1;
  try {
    return await work();
  } finally {
    browsers -= 1;
    const wake = browserWaiters.shift();
    if (wake) wake();
  }
}

export function statusBoard(): {
  slots: number;
  busy: number;
  queued: number;
  browserLeases: number;
  browsersInUse: number;
  jobs: { id: string; slot: string }[];
  steps: StepNote[];
} {
  return {
    slots: slotCount(),
    busy,
    queued: waiters.length,
    browserLeases: leaseCount(),
    browsersInUse: browsers,
    jobs: [...running.entries()].map(([id, slot]) => ({ id, slot })),
    steps: history.map((row) => ({ ...row })),
  };
}
