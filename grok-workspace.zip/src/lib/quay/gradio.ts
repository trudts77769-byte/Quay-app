import type { Message } from "@/lib/quay/providers";
import { readHfToken, scrubSecrets } from "@/lib/quay/secrets";

export type SpaceCall = { text: string | null; failed: boolean; reason: string };

const endpoints = new Map<string, string>();

function hosts(space: string): string[] {
  const [owner, repo] = space.split("/");
  if (!owner || !repo) return [];
  const raw = `${owner}-${repo}`.toLowerCase();
  const dashed = raw.replace(/\./g, "-");
  const list = [`https://${raw}.hf.space`];
  if (dashed !== raw) list.push(`https://${dashed}.hf.space`);
  return list;
}

function promptOf(messages: Message[]): string {
  return messages
    .filter((message) => message.role !== "system")
    .map((message) => message.content)
    .join("\n")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 4000);
}

function flatten(value: unknown): string {
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) return value.map(flatten).filter(Boolean).join("\n");
  if (value && typeof value === "object") {
    const row = value as Record<string, unknown>;
    const url = typeof row.url === "string" ? row.url : "";
    if (/^https?:\/\//i.test(url)) return url;
    return Object.values(row).map(flatten).filter(Boolean).join("\n");
  }
  return "";
}

function fromBody(raw: string): { text: string; quota: boolean; failed: boolean } {
  const quota = /quota|zerogpu|rate limit/i.test(raw);
  const blocks = raw.split(/\n\n/);
  for (const block of [...blocks].reverse()) {
    const dataLine = block
      .split("\n")
      .map((line) => line.trim())
      .find((line) => line.startsWith("data:"));
    if (!dataLine) continue;
    const json = dataLine.slice(5).trim();
    if (/event:\s*error/i.test(block)) return { text: "", quota: quota || /quota/i.test(json), failed: true };
    try {
      return { text: flatten(JSON.parse(json)), quota, failed: false };
    } catch {
      return { text: json, quota, failed: false };
    }
  }
  try {
    const parsed = JSON.parse(raw) as { data?: unknown; error?: unknown };
    if (parsed.error) return { text: "", quota, failed: true };
    if (parsed.data !== undefined) return { text: flatten(parsed.data), quota, failed: false };
  } catch {
    /* plain text */
  }
  return { text: raw, quota, failed: false };
}

async function endpoint(host: string, headers: Record<string, string>): Promise<string> {
  const cached = endpoints.get(host);
  if (cached) return cached;
  try {
    const response = await fetch(`${host}/gradio_api/info`, { headers });
    if (response.ok) {
      const body = (await response.json()) as { named_endpoints?: Record<string, unknown> };
      const names = Object.keys(body.named_endpoints ?? {});
      const picked = names.find((name) => /predict|chat|generate|translate|summar/i.test(name)) ?? names[0] ?? "/predict";
      const name = picked.replace(/^\//, "") || "predict";
      endpoints.set(host, name);
      return name;
    }
  } catch {
    /* predict is the fallback */
  }
  return "predict";
}

function pack(text: string, quota: boolean, failed: boolean): SpaceCall {
  const clean = scrubSecrets(text).replace(/\s+/g, " ").trim();
  if (quota || /quota|zerogpu|rate limit/i.test(clean)) return { text: null, failed: true, reason: "quota" };
  if (failed || clean.length < 8) return { text: null, failed: true, reason: failed ? "down" : "empty" };
  return { text: clean.slice(0, 1500), failed: false, reason: "" };
}

async function once(host: string, headers: Record<string, string>, text: string): Promise<SpaceCall | null> {
  const name = await endpoint(host, headers);
  const posted = await fetch(`${host}/gradio_api/call/${name}`, {
    method: "POST",
    headers,
    body: JSON.stringify({ data: [text] }),
  });
  const raw = await posted.text();
  if (posted.status === 404) {
    const legacy = await fetch(`${host}/api/predict`, {
      method: "POST",
      headers,
      body: JSON.stringify({ data: [text] }),
      signal: AbortSignal.timeout(20000),
    });
    const body = await legacy.text();
    if (!legacy.ok && legacy.status !== 404) return pack("", legacy.status === 429, true);
    if (legacy.status === 404) return null;
    const parsed = fromBody(body);
    return pack(parsed.text, parsed.quota || legacy.status === 429, parsed.failed);
  }
  if (!posted.ok) return pack("", posted.status === 429, true);
  let event = "";
  try {
    event = String((JSON.parse(raw) as { event_id?: string }).event_id ?? "");
  } catch {
    event = "";
  }
  if (!event) {
    const parsed = fromBody(raw);
    return pack(parsed.text, parsed.quota, parsed.failed);
  }
  const stream = await fetch(`${host}/gradio_api/call/${name}/${event}`, {
    headers,
  });
  const body = await stream.text();
  if (!stream.ok) return pack("", stream.status === 429, true);
  const parsed = fromBody(body);
  return pack(parsed.text, parsed.quota, parsed.failed);
}

export async function callSpace(space: string, messages: Message[]): Promise<SpaceCall> {
  const token = readHfToken();
  if (!token) return { text: null, failed: true, reason: "no-key" };
  const text = promptOf(messages);
  if (text.length < 2) return { text: null, failed: true, reason: "empty" };
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json",
    Authorization: `Bearer ${token}`,
  };
  for (const host of hosts(space)) {
    try {
      const called = await once(host, headers, text);
      if (called) return called;
    } catch {
      /* try the dotted host */
    }
  }
  return { text: null, failed: true, reason: "down" };
}
