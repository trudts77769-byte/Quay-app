import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { existsSync } from "node:fs";
import { labelOf } from "@/lib/quay/catalog";
import { openRemoteBrowser } from "@/lib/quay/e2b-browser";
import { exactOutput } from "@/lib/quay/exact-output";
import { setSandboxReport } from "@/lib/quay/job-audit";
import { rememberShot } from "@/lib/quay/job-state";
import { pushTrace } from "@/lib/quay/progress";
import { followerKind } from "@/lib/quay/providers";
import { locateSandboxScript, type ScriptDiagnostic } from "@/lib/quay/sandbox-script.server";

export type ScreenOption = { id: string; kind: string; label: string; x: number; y: number };

export type BrowserScreen = {
  url: string;
  title: string;
  text: string;
  moreBelow: boolean;
  moreAbove: boolean;
  options: ScreenOption[];
  shot: string;
};

export type BrowserCommand =
  | { kind: "open"; url: string }
  | { kind: "click"; id: string }
  | { kind: "type"; id: string; text: string }
  | { kind: "scroll"; dir: "up" | "down" }
  | { kind: "back" }
  | { kind: "wait" }
  | { kind: "done"; text: string }
  | { kind: "fail"; reason: string };

export type BrowserVerdict =
  | "PASS"
  | "INCOMPLETE"
  | "WRONG_ANSWER"
  | "FOLLOWER_PROTOCOL_FAILURE"
  | "SANDBOX_TECHNICAL_FAILURE"
  | "SANDBOX_NOT_USED";

export type LivePanel = {
  active: boolean;
  follower: string;
  step: number;
  action: string;
  actions: number;
  url: string;
  typing: string;
  scrolling: string;
  clickX: number;
  clickY: number;
  sessionId: string;
};

type Receipt = {
  n: number;
  at: string;
  follower: string;
  command: string;
  urlBefore: string;
  urlAfter: string;
  ok: boolean;
  reason: string;
  shotBefore: boolean;
  shotAfter: boolean;
};

type Held = {
  id: string;
  job: string;
  step: number;
  send: (cmd: Record<string, unknown>) => Promise<Record<string, unknown> | null>;
  end: () => void;
  runtime: string;
  screen: BrowserScreen;
  crashed: boolean;
  closing: boolean;
  follower: string;
  kind: "VISION_BROWSER_FOLLOWER" | "TEXT_BROWSER_FOLLOWER";
  action: string;
  typing: string;
  scrolling: string;
  clickX: number;
  clickY: number;
  initialUrl: string;
  pages: number;
  interactive: number;
  clicks: number;
  types: number;
  scrolls: number;
  backs: number;
  waits: number;
  shots: number;
  replacements: number;
  protocol: number;
  done: boolean;
  operated: boolean;
  verdict: BrowserVerdict;
  answer: string;
  history: string[];
  receipts: Receipt[];
  notice: string;
};

const held = new Map<string, Held>();
const panels = new Map<string, LivePanel>();

export type SandboxFault = {
  taskId: string;
  attempt: number;
  endpoint: string;
  errorClass: string;
  message: string;
  durationMs: number;
  sessionId: string;
  url: string;
};

let fault: SandboxFault | null = null;

export function lastSandboxFault(): SandboxFault | null {
  return fault;
}

function scriptFile(): string {
  return locateSandboxScript().path;
}

export function sandboxScriptDiagnostic(): ScriptDiagnostic {
  return locateSandboxScript().diagnostic;
}

function rememberFault(row: Omit<SandboxFault, "attempt"> & { attempt?: number }): void {
  fault = { attempt: row.attempt ?? 1, ...row, message: row.message.slice(0, 180) };
}

let localGate: { ok: boolean; until: number; error: string } | null = null;

function rememberLocal(ok: boolean, error = ""): void {
  localGate = { ok, until: Date.now() + 10 * 60 * 1000, error };
}

async function localBrowser(): Promise<{ ok: boolean; error: string }> {
  if (localGate && Date.now() < localGate.until) return { ok: localGate.ok, error: localGate.error };
  try {
    const { chromium } = await import("playwright");
    const bin = chromium.executablePath();
    if (!bin || !existsSync(bin)) {
      rememberLocal(false, "local browser binary missing");
      return { ok: false, error: "local browser binary missing" };
    }
    rememberLocal(true, "");
    return { ok: true, error: "" };
  } catch (error) {
    const message = error instanceof Error ? error.message.slice(0, 160) : "playwright missing";
    rememberLocal(false, message);
    return { ok: false, error: message };
  }
}

export function parseBrowserCommand(raw: string): BrowserCommand | null {
  const clean = raw.replace(/```[a-z]*|```/gi, " ").trim();
  const line =
    clean
      .split(/\n/)
      .map((item) => item.trim())
      .find((item) => /^(open|click|type|scroll|back|wait|done|fail)\b/i.test(item)) ?? clean;
  const open = line.match(/^open\s+(https?:\/\/\S+)/i);
  if (open?.[1]) return { kind: "open", url: open[1].replace(/[.,]+$/, "") };
  const click = line.match(/^click\s+(\d+)/i);
  if (click?.[1]) return { kind: "click", id: click[1] };
  const typed = line.match(/^type\s+(.+?)\s+in\s+(\d+)\s*$/i);
  if (typed?.[1] && typed[2]) return { kind: "type", id: typed[2], text: typed[1].replace(/^["']|["']$/g, "").slice(0, 160) };
  if (/^scroll\s+up\b/i.test(line)) return { kind: "scroll", dir: "up" };
  if (/^scroll(\s+down)?\b/i.test(line)) return { kind: "scroll", dir: "down" };
  if (/^back\b/i.test(line)) return { kind: "back" };
  if (/^wait\b/i.test(line)) return { kind: "wait" };
  const done = line.match(/^done\b[:\s-]*(.*)$/i);
  if (done) return { kind: "done", text: (done[1] ?? "").trim().slice(0, 500) };
  const fail = line.match(/^fail\b[:\s-]*(.*)$/i);
  if (fail) return { kind: "fail", reason: (fail[1] ?? "").trim().slice(0, 240) };
  const start = clean.indexOf("{");
  const end = clean.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const json = JSON.parse(clean.slice(start, end + 1)) as Record<string, unknown>;
    const act = String(json.act ?? json.cmd ?? "").toLowerCase();
    if (act === "open") return { kind: "open", url: String(json.url ?? "") };
    if (act === "click") return { kind: "click", id: String(json.id ?? "") };
    if (act === "type") return { kind: "type", id: String(json.id ?? ""), text: String(json.text ?? "").slice(0, 160) };
    if (act === "scroll") return { kind: "scroll", dir: String(json.dir ?? "down") === "up" ? "up" : "down" };
    if (act === "back") return { kind: "back" };
    if (act === "wait") return { kind: "wait" };
    if (act === "found" || act === "done") return { kind: "done", text: String(json.found ?? json.text ?? "").slice(0, 500) };
    if (act === "fail" || act === "none") return { kind: "fail", reason: String(json.reason ?? "none") };
    return null;
  } catch {
    return null;
  }
}

const STOP = new Set(["that", "this", "with", "from", "have", "were", "been", "your", "about", "there", "their", "which", "what", "when", "where"]);

export function answerOnScreen(answer: string, screen: BrowserScreen, history: string): boolean {
  const hay = `${screen.text} ${screen.title} ${screen.url} ${history}`.toLowerCase();
  const tokens = (answer.toLowerCase().match(/[a-z0-9]{4,}/g) ?? []).filter((token) => !STOP.has(token));
  if (tokens.length === 0) return answer.trim().length > 8 && hay.includes(answer.trim().toLowerCase().slice(0, 24));
  const hits = tokens.filter((token) => hay.includes(token));
  return hits.length >= Math.min(2, tokens.length);
}

function asScreen(value: unknown): BrowserScreen | null {
  if (!value || typeof value !== "object") return null;
  const row = value as Record<string, unknown>;
  const options = Array.isArray(row.options)
    ? row.options
        .map((item) => {
          const option = item as Record<string, unknown>;
          return {
            id: String(option.id ?? ""),
            kind: String(option.kind ?? "link"),
            label: String(option.label ?? ""),
            x: Number(option.x ?? 0),
            y: Number(option.y ?? 0),
          };
        })
        .filter((option) => option.id && option.label)
    : [];
  if (!row.url && !row.shot && !row.text) return null;
  return {
    url: String(row.url ?? ""),
    title: String(row.title ?? "Page"),
    text: String(row.text ?? ""),
    moreBelow: Boolean(row.moreBelow),
    moreAbove: Boolean(row.moreAbove),
    options,
    shot: String(row.shot ?? ""),
  };
}

function keyOf(job: string, step: number): string {
  return `${job || "page"}:${step}`;
}

function commandLabel(cmd: BrowserCommand): string {
  if (cmd.kind === "open") return `OPEN ${cmd.url}`;
  if (cmd.kind === "click") return `CLICK ${cmd.id}`;
  if (cmd.kind === "type") return `TYPE ${cmd.text} IN ${cmd.id}`;
  if (cmd.kind === "scroll") return cmd.dir === "up" ? "SCROLL UP" : "SCROLL DOWN";
  if (cmd.kind === "back") return "BACK";
  if (cmd.kind === "wait") return "WAIT";
  if (cmd.kind === "done") return `DONE ${cmd.text}`;
  return `FAIL ${cmd.reason}`;
}

function fingerprint(screen: BrowserScreen): string {
  return `${screen.url}|${screen.text.slice(0, 180)}|${screen.options.map((option) => option.label).join(",")}`;
}

function publish(row: Held): void {
  const panel: LivePanel = {
    active: !row.closing && !row.crashed,
    follower: labelOf(row.follower),
    step: row.step,
    action: row.action,
    actions: row.interactive,
    url: row.screen.url,
    typing: row.typing,
    scrolling: row.scrolling,
    clickX: row.clickX,
    clickY: row.clickY,
    sessionId: row.id,
  };
  panels.set(row.job || "page", panel);
  if (row.screen.shot) rememberShot(row.job, row.screen.shot, row.screen.url);
}

function syncReport(row: Held): void {
  setSandboxReport(row.job, {
    created: true,
    operated: row.operated,
    vision: row.kind === "VISION_BROWSER_FOLLOWER",
    done: row.done,
    sessionId: row.id,
    follower: labelOf(row.follower),
    initialUrl: row.initialUrl,
    finalUrl: row.screen.url,
    pages: row.pages,
    interactive: row.interactive,
    clicks: row.clicks,
    types: row.types,
    scrolls: row.scrolls,
    shots: row.shots,
    replacements: row.replacements,
    protocol: row.protocol,
    verdict: row.verdict,
    trace: row.receipts.map(
      (item) =>
        `${item.n} ${item.command} ${item.ok ? "ok" : "failed"} ${item.urlBefore || "?"} -> ${item.urlAfter || "?"} ${item.reason}`.replace(/\s+/g, " ").trim(),
    ),
  });
}

export function readLive(job: string): LivePanel | null {
  return panels.get(job || "page") ?? null;
}

function attach(child: ChildProcessWithoutNullStreams): Held["send"] {
  const waiters: Array<(value: Record<string, unknown> | null) => void> = [];
  let buffer = "";
  child.stdout.on("data", (chunk: Buffer) => {
    buffer += chunk.toString("utf8");
    let cut = buffer.indexOf("\n");
    while (cut >= 0) {
      const line = buffer.slice(0, cut);
      buffer = buffer.slice(cut + 1);
      let parsed: Record<string, unknown> | null = null;
      try {
        parsed = JSON.parse(line) as Record<string, unknown>;
      } catch {
        parsed = null;
      }
      waiters.shift()?.(parsed);
      cut = buffer.indexOf("\n");
    }
  });
  child.on("close", () => {
    while (waiters.length > 0) waiters.shift()?.(null);
  });
  return (cmd) =>
    new Promise((done) => {
      waiters.push(done);
      child.stdin.write(`${JSON.stringify(cmd)}\n`);
    });
}

async function openLocal(url: string): Promise<{ send: Held["send"]; end: () => void; screen: BrowserScreen; note: string } | { error: string }> {
  const script = scriptFile();
  if (!script) return { error: "sandbox script missing" };
  const ready = await localBrowser();
  if (!ready.ok) return { error: ready.error };
  const started = Date.now();
  let stderr = "";
  const child = spawn(process.execPath, [script], { stdio: ["pipe", "pipe", "pipe"] });
  child.stderr.on("data", (chunk: Buffer) => {
    stderr = `${stderr}${chunk.toString("utf8")}`.slice(-400);
  });
  const send = attach(child);
  const reply = await Promise.race([
    send({ cmd: "open", url }),
    new Promise<null>((resolve) => setTimeout(() => resolve(null), 15000)),
  ]);
  const screen = reply && reply.ok !== false ? asScreen(reply.screen) : null;
  if (!screen) {
    child.kill();
    const message = stderr.trim() || (reply ? String((reply as { error?: string }).error || "local browser returned no screen") : "local browser timed out");
    rememberLocal(false, message.slice(0, 160));
    return { error: `${message.slice(0, 160)} ${Date.now() - started}ms` };
  }
  child.on("close", () => undefined);
  return {
    send,
    screen,
    note: "",
    end: () => {
      try {
        child.stdin.write(`${JSON.stringify({ cmd: "close" })}\n`);
      } catch {
        /* already closed */
      }
      child.kill();
    },
  };
}

function adopt(job: string, step: number, follower: string, runtime: string, opened: { send: Held["send"]; end: () => void; screen: BrowserScreen }): Held {
  const row: Held = {
    id: `${Date.now().toString(36)}-${step}`,
    job: job || "page",
    step,
    send: opened.send,
    end: opened.end,
    runtime,
    screen: opened.screen,
    crashed: false,
    closing: false,
    follower,
    kind: followerKind(follower),
    action: "OPEN",
    typing: "",
    scrolling: "",
    clickX: 0,
    clickY: 0,
    initialUrl: opened.screen.url,
    pages: 1,
    interactive: 0,
    clicks: 0,
    types: 0,
    scrolls: 0,
    backs: 0,
    waits: 0,
    shots: opened.screen.shot ? 1 : 0,
    replacements: 0,
    protocol: 0,
    done: false,
    operated: false,
    verdict: "INCOMPLETE",
    answer: "",
    history: [],
    receipts: [],
    notice: "",
  };
  held.set(keyOf(job, step), row);
  publish(row);
  syncReport(row);
  pushTrace(job, `Sandbox ready ${opened.screen.url}`);
  return row;
}

async function openHeld(job: string, step: number, url: string, follower: string): Promise<Held | null> {
  const started = Date.now();
  pushTrace(job, "Sandbox starting");
  if (preferRuntime !== "e2b") {
    const local = await openLocal(url);
    if (!("error" in local)) return adopt(job, step, follower, "local", local);
    rememberFault({
      taskId: job,
      endpoint: "local-chromium",
      errorClass: "LOCAL_BROWSER",
      message: local.error,
      durationMs: Date.now() - started,
      sessionId: "",
      url,
    });
    pushTrace(job, `Local sandbox failed: ${local.error}`);
  }
  const remote = await openRemoteBrowser(scriptFile(), url, locateSandboxScript().source);
  if ("error" in remote) {
    rememberFault({
      taskId: job,
      attempt: 2,
      endpoint: "e2b",
      errorClass: "E2B_BROWSER",
      message: remote.error,
      durationMs: Date.now() - started,
      sessionId: "",
      url,
    });
    pushTrace(job, `SANDBOX FAILED ${remote.error}`);
    return null;
  }
  const screen = asScreen(remote.screen);
  if (!screen) {
    await remote.browser.close();
    rememberFault({
      taskId: job,
      attempt: 2,
      endpoint: "e2b",
      errorClass: "E2B_SCREEN",
      message: "remote browser returned no screen",
      durationMs: Date.now() - started,
      sessionId: "",
      url,
    });
    return null;
  }
  return adopt(job, step, follower, "e2b", { send: remote.browser.send, end: () => void remote.browser.close(), screen });
}

export async function releaseBrowser(job: string, step: number): Promise<void> {
  const row = held.get(keyOf(job, step));
  if (!row) return;
  row.closing = true;
  publish(row);
  syncReport(row);
  row.end();
  held.delete(keyOf(job, step));
}

function screenPrompt(task: string, goal: string, row: Held): string {
  const options = row.screen.options.map((option) => `${option.id}. ${option.kind}: ${option.label}`).join("\n");
  const extras = [row.screen.moreBelow ? "scroll: more of this page is below" : "", row.screen.moreAbove ? "back: leave this screen" : ""].filter(Boolean);
  const shotLine =
    row.kind === "VISION_BROWSER_FOLLOWER"
      ? "Current screenshot: attached."
      : "TEXT_BROWSER_FOLLOWER. You are not receiving a screenshot. Use the structured screen below.";
  return [
    `TASK\n${task}`,
    `GOAL\n${goal}`,
    shotLine,
    `Current URL:\n${row.screen.url}`,
    `Title: ${row.screen.title}`,
    `VISIBLE\n${row.screen.text.slice(0, 900) || "(no text on this screen)"}`,
    `Current available elements:\n${options || "(none)"}`,
    extras.join("\n"),
    `Action history:\n${row.history.join("\n") || "none"}`,
    row.notice,
    "Reply with exactly one action: OPEN [url], CLICK [id], TYPE [text] IN [id], SCROLL DOWN, SCROLL UP, BACK, WAIT, DONE [answer], or FAIL [reason].",
  ]
    .filter(Boolean)
    .join("\n\n");
}

async function perform(row: Held, cmd: BrowserCommand): Promise<{ ok: boolean; reason: string }> {
  const before = row.screen.url;
  const shotBefore = Boolean(row.screen.shot);
  row.typing = "";
  row.scrolling = "";
  if (cmd.kind === "click") {
    const option = row.screen.options.find((item) => item.id === cmd.id);
    if (!option) return { ok: false, reason: `element ${cmd.id} is no longer available` };
    row.clickX = option.x;
    row.clickY = option.y;
  }
  if (cmd.kind === "type") {
    const option = row.screen.options.find((item) => item.id === cmd.id);
    if (!option || option.kind !== "form") return { ok: false, reason: `element ${cmd.id} is not a field` };
    row.typing = option.label;
  }
  if (cmd.kind === "scroll") {
    if (cmd.dir === "down" && !row.screen.moreBelow) return { ok: false, reason: "no more page below" };
    if (cmd.dir === "up" && !row.screen.moreAbove) return { ok: false, reason: "no more page above" };
    row.scrolling = cmd.dir === "up" ? "Scrolling up" : "Scrolling down";
  }
  const packet =
    cmd.kind === "open"
      ? { cmd: "open", url: cmd.url }
      : cmd.kind === "click"
        ? { cmd: "click", id: cmd.id }
        : cmd.kind === "type"
          ? { cmd: "type", id: cmd.id, text: cmd.text }
          : cmd.kind === "scroll"
            ? { cmd: "scroll", dir: cmd.dir }
            : cmd.kind === "back"
              ? { cmd: "back" }
              : { cmd: "wait" };
  const reply = await row.send(packet);
  if (!reply) {
    row.crashed = true;
    return { ok: false, reason: "sandbox stopped" };
  }
  const next = asScreen(reply.screen);
  if (next) {
    row.screen = next;
    row.shots += next.shot ? 1 : 0;
  }
  const click = reply.click as { x?: number; y?: number } | undefined;
  if (cmd.kind === "click" && click) {
    row.clickX = Number(click.x ?? row.clickX);
    row.clickY = Number(click.y ?? row.clickY);
  }
  const ok = reply.ok !== false;
  const reason = ok ? "" : String(reply.error ?? "action failed").slice(0, 160);
  row.interactive += 1;
  row.operated = true;
  if (cmd.kind === "click") row.clicks += 1;
  if (cmd.kind === "type") row.types += 1;
  if (cmd.kind === "scroll") row.scrolls += 1;
  if (cmd.kind === "back") row.backs += 1;
  if (cmd.kind === "wait") row.waits += 1;
  if (cmd.kind === "open") row.pages += 1;
  const label = commandLabel(cmd);
  row.action = label;
  row.history.push(`${label} ${ok ? "ok" : "failed"}`.slice(0, 180));
  row.history = row.history.slice(-12);
  pushTrace(row.job, cmd.kind === "click" ? `${label} at ${row.clickX},${row.clickY}` : label);
  if (ok) pushTrace(row.job, "Page updated");
  row.receipts.push({
    n: row.receipts.length + 1,
    at: new Date().toISOString(),
    follower: row.follower,
    command: label,
    urlBefore: before,
    urlAfter: row.screen.url,
    ok,
    reason,
    shotBefore,
    shotAfter: Boolean(row.screen.shot),
  });
  publish(row);
  syncReport(row);
  return { ok, reason };
}

function directAction(task: string, screen: BrowserScreen, history: string[]): BrowserCommand | null {
  const quoted = [...task.matchAll(/[“"]([^”"]{1,80})[”"]/g)].map((match) => match[1]?.trim() ?? "").filter((value) => value && !/^https?:/i.test(value));
  const text = quoted.find((value) => /quay works/i.test(value)) || quoted[0] || "";
  if (!text || !/type/i.test(task)) return null;
  const field = screen.options.find((option) => option.kind === "form");
  const submit = screen.options.find((option) => option.kind === "button" && /submit/i.test(option.label));
  const second = screen.options.find((option) => option.kind === "button" && /second/i.test(option.label));
  const typed = history.some((line) => line.startsWith("TYPE ") && line.endsWith("ok"));
  const clicks = history.filter((line) => line.startsWith("CLICK ") && line.endsWith("ok")).length;
  if (field && !typed) return { kind: "type", id: field.id, text };
  if (submit && typed && clicks < 1) return { kind: "click", id: submit.id };
  if (second && /second/i.test(task) && clicks < 2 && /SUCCESS:/i.test(screen.text)) return { kind: "click", id: second.id };
  return null;
}

function readyClaim(task: string, screen: BrowserScreen): string {
  const success = screen.text.match(/SUCCESS:\s*Quay works/i)?.[0]?.replace(/\s+/g, " ").trim() ?? "";
  if (success && /second/i.test(task) && /SECOND:\s*ready/i.test(screen.text)) return `${success} SECOND: ready`;
  if (success && !/second/i.test(task)) return success;
  if (exactOutput(task) === "bare" && /\btitle\b/i.test(task) && !/success message/i.test(task) && screen.title.trim()) return screen.title.trim();
  return "";
}

export type BrowserAsk = (input: { follower: string; kind: Held["kind"]; prompt: string; image?: string; screen: BrowserScreen }) => Promise<{ text: string; follower?: string }>;

export type BrowserOutcome = {
  verdict: BrowserVerdict;
  answer: string;
  follower: string;
  sessionId: string;
  url: string;
  title: string;
  operated: boolean;
};

export async function runBrowserFollower(input: {
  job: string;
  step: number;
  task: string;
  goal: string;
  url: string;
  follower: string;
  ask: BrowserAsk;
  continueSession?: boolean;
}): Promise<BrowserOutcome> {
  const slot = keyOf(input.job, input.step);
  const existing = held.get(slot);
  let row = input.continueSession && existing && !existing.crashed && !existing.closing ? existing : undefined;
  if (!row) {
    if (existing) await releaseBrowser(input.job, input.step);
    row = (await openHeld(input.job, input.step, input.url, input.follower)) ?? undefined;
  }
  if (!row) {
    return { verdict: "SANDBOX_TECHNICAL_FAILURE", answer: "", follower: input.follower, sessionId: "", url: "", title: "", operated: false };
  }
  row.follower = input.follower || row.follower;
  row.kind = followerKind(row.follower);
  row.verdict = "INCOMPLETE";
  row.notice = input.continueSession ? "A previous follower stopped. Continue this same page. Do not restart unless you must OPEN a url." : "";
  pushTrace(input.job, `Worker ${labelOf(row.follower)} assigned`);
  let protocol = 0;
  let stagnant = 0;
  let lastState = "";
  let lastCommand = "";
  const missed = new Set<string>();
  for (let safety = 0; safety < 30; safety += 1) {
    if (row.crashed) {
      row.verdict = "SANDBOX_TECHNICAL_FAILURE";
      break;
    }
    publish(row);
    const claim = readyClaim(input.task, row.screen);
    if (claim) {
      row.done = true;
      row.operated = true;
      row.answer = claim;
      row.action = `DONE ${claim}`.slice(0, 180);
      row.verdict = "PASS";
      row.notice = "";
      pushTrace(input.job, "Validation passed");
      pushTrace(input.job, "Completed");
      publish(row);
      syncReport(row);
      break;
    }
    const direct = directAction(input.task, row.screen, row.history);
    if (direct) {
      const result = await perform(row, direct);
      if (row.crashed) {
        row.verdict = "SANDBOX_TECHNICAL_FAILURE";
        break;
      }
      if (!result.ok) row.notice = `ACTION FAILED\nReason: ${result.reason}\nChoose another action.`;
      continue;
    }
    const prompt = screenPrompt(input.task, input.goal, row);
    const asked = await input.ask({
      follower: row.follower,
      kind: row.kind,
      prompt,
      image: row.kind === "VISION_BROWSER_FOLLOWER" ? row.screen.shot : undefined,
      screen: row.screen,
    });
    if (asked.follower) row.follower = asked.follower;
    const cmd = parseBrowserCommand(asked.text || "");
    if (!cmd) {
      protocol += 1;
      row.protocol += 1;
      row.notice = "INVALID BROWSER COMMAND. You are controlling an active Quay sandbox. Reply with exactly ONE valid action. Do not explain. Choose one action.";
      syncReport(row);
      if (protocol >= 3) {
        row.verdict = "FOLLOWER_PROTOCOL_FAILURE";
        break;
      }
      continue;
    }
    protocol = 0;
    if (cmd.kind === "done") {
      const claim = exactOutput(input.task) === "bare" && /title/i.test(input.task) ? row.screen.title : cmd.text || row.screen.title;
      if (!answerOnScreen(claim, row.screen, row.history.join(" "))) {
        row.notice = "The claimed evidence was not found on this screen. Stay on this page and choose another action, or DONE only with words that are visible.";
        row.verdict = "WRONG_ANSWER";
        continue;
      }
      row.done = true;
      row.operated = true;
      row.answer = claim;
      row.action = `DONE ${claim}`.slice(0, 180);
      row.verdict = "PASS";
      row.notice = "";
      row.receipts.push({
        n: row.receipts.length + 1,
        at: new Date().toISOString(),
        follower: row.follower,
        command: row.action,
        urlBefore: row.screen.url,
        urlAfter: row.screen.url,
        ok: true,
        reason: "",
        shotBefore: Boolean(row.screen.shot),
        shotAfter: Boolean(row.screen.shot),
      });
      publish(row);
      syncReport(row);
      break;
    }
    if (cmd.kind === "fail") {
      row.notice = cmd.reason || "follower stopped";
      row.verdict = "INCOMPLETE";
      row.action = commandLabel(cmd);
      publish(row);
      break;
    }
    const state = fingerprint(row.screen);
    const label = commandLabel(cmd);
    if (state === lastState && label === lastCommand) {
      stagnant += 1;
      row.notice = "That action did not change the screen. Choose a different action.";
      if (stagnant >= 3) {
        row.verdict = "INCOMPLETE";
        break;
      }
    } else {
      stagnant = 0;
    }
    lastState = state;
    lastCommand = label;
    if (missed.has(label) && cmd.kind !== "wait") {
      row.notice = `ACTION FAILED. ${label} already failed. Choose another action.`;
      continue;
    }
    const result = await perform(row, cmd);
    if (row.crashed) {
      row.verdict = "SANDBOX_TECHNICAL_FAILURE";
      break;
    }
    if (!result.ok) {
      missed.add(label);
      row.notice = `ACTION FAILED\nReason: ${result.reason}\nChoose another action.`;
      continue;
    }
    row.notice = "";
    row.verdict = "INCOMPLETE";
  }
  syncReport(row);
  publish(row);
  return {
    verdict: row.verdict,
    answer: row.answer,
    follower: row.follower,
    sessionId: row.id,
    url: row.screen.url,
    title: row.screen.title,
    operated: row.operated,
  };
}

export function markReplacement(job: string, step: number): void {
  const row = held.get(keyOf(job, step));
  if (!row) return;
  row.replacements += 1;
  syncReport(row);
}

let preferRuntime: "auto" | "e2b" = "auto";

export function preferSandbox(mode: "auto" | "e2b"): void {
  preferRuntime = mode;
}

export async function probeSandbox(): Promise<{
  ok: boolean;
  browserAvailable: boolean;
  canCreateSession: boolean;
  runtime: string;
  url: string;
  title: string;
  text: string;
  sessionId: string;
  error: string;
  script: ScriptDiagnostic;
}> {
  const script = sandboxScriptDiagnostic();
  const job = `probe-${Date.now()}`;
  const row = await openHeld(job, 1, "https://example.com", "probe");
  if (!row) {
    const missing = !script.exists;
    return {
      ok: false,
      browserAvailable: false,
      canCreateSession: false,
      runtime: "",
      url: "",
      title: "",
      text: "",
      sessionId: "",
      error: missing ? `sandbox script missing path=${script.path || "(none)"} exists=false cwd=${script.cwd} runtime=${script.runtime}` : fault?.message || "sandbox did not start",
      script,
    };
  }
  const result = {
    ok: /example domain/i.test(row.screen.title),
    browserAvailable: true,
    canCreateSession: true,
    runtime: row.runtime,
    url: row.screen.url,
    title: row.screen.title,
    text: row.screen.text.slice(0, 400),
    sessionId: row.id,
    error: "",
    script,
  };
  await releaseBrowser(job, 1);
  return result;
}
