import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { getSql } from "@/lib/db";
import { toUrl } from "@/lib/quay/engine";
import { buildPlan, tellChief, type PlannedStep } from "@/lib/quay/plan";
import { callFollower } from "@/lib/quay/providers";
import { enqueueJob, leaseBrowser, noteStep } from "@/lib/quay/slots";

const handsPath = fileURLToPath(new URL("../../../scripts/form-hands.mjs", import.meta.url));
const PAY = /\b(pay|purchase|buy|checkout|place order)\b/i;

interface Box {
  label: string;
  kind: string;
  x: number;
  y: number;
  value: string;
  options: string[];
}

interface Screen {
  ok: boolean;
  url: string;
  title: string;
  shot: string;
  text: string;
  elements: Box[];
  error: string;
}

interface Move {
  cmd: string;
  label: string;
  text: string;
  url: string;
  x: number;
  y: number;
}

export interface JobView {
  id: string;
  status: string;
  url: string;
  order: string;
  steps: { step: number; command: string; shot: string }[];
  shot: string;
  answer: string;
}

async function ensure(): Promise<void> {
  const sql = await getSql();
  await sql.query(
    "create table if not exists quay_job (id text primary key, url text not null, job_order text not null, status text not null, answer text not null default '', pending text not null default '', shot text not null default '', created_at timestamptz not null default now())",
  );
  await sql.query(
    "create table if not exists quay_job_secret (job text not null, key text not null, value text not null, primary key (job, key))",
  );
  await sql.query("create table if not exists quay_job_shot (id text primary key, job text not null, png text not null)");
  await sql.query(
    "create table if not exists quay_job_step (id text primary key, job text not null, n int not null, command text not null, shot text not null default '')",
  );
}

function cleanValues(values: Record<string, unknown>): Record<string, string> | { error: string } {
  const secrets: Record<string, string> = {};
  for (const [key, value] of Object.entries(values)) {
    const name = key.trim().toUpperCase().replace(/[^A-Z0-9_]/g, "");
    if (!name) continue;
    if (/PASSWORD|PASSCODE|SSN|CARD|CVV|SECRET/.test(name)) return { error: "Do not store passwords or card numbers." };
    if (typeof value !== "string") continue;
    secrets[name] = value.trim().slice(0, 400);
  }
  return secrets;
}

export async function createJob(input: { url: string; order: string; values?: Record<string, unknown> }): Promise<{ id: string } | { error: string }> {
  const url = toUrl(input.url || "");
  const order = input.order?.trim() ?? "";
  if (!url) return { error: "Use a public https address." };
  if (order.length < 2) return { error: "Say the order in a sentence." };
  const values = cleanValues(input.values ?? {});
  if ("error" in values && typeof values.error === "string" && Object.keys(values).length === 1) return { error: values.error };
  await ensure();
  const id = crypto.randomUUID();
  const sql = await getSql();
  await sql`insert into quay_job (id, url, job_order, status) values (${id}, ${url}, ${order.slice(0, 800)}, ${"running"})`;
  for (const [key, value] of Object.entries(values)) {
    await sql`insert into quay_job_secret (job, key, value) values (${id}, ${key}, ${value})`;
  }
  enqueueJob(id, () =>
    runJob(id).catch(async () => {
      const db = await getSql();
      await db`update quay_job set status = ${"error"}, answer = ${"The screen stopped."} where id = ${id}`;
    }),
  );
  return { id };
}

export async function readJob(id: string): Promise<JobView | null> {
  await ensure();
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`
    select id, url, job_order, status, answer, shot from quay_job where id = ${id}
  `;
  const job = rows[0];
  if (!job) return null;
  const steps = await sql<Record<string, string | number>>`
    select n, command, shot from quay_job_step where job = ${id} order by n asc
  `;
  return {
    id: String(job.id),
    status: String(job.status),
    url: String(job.url),
    order: String(job.job_order),
    steps: steps.map((step) => ({
      step: Number(step.n),
      command: String(step.command),
      shot: step.shot ? `/api/job/shot/${step.shot}.png` : "",
    })),
    shot: job.shot ? `/api/job/shot/${job.shot}.png` : "",
    answer: String(job.answer || ""),
  };
}

export async function readJobShot(id: string): Promise<string | null> {
  await ensure();
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`select png from quay_job_shot where id = ${id}`;
  return rows[0]?.png ? String(rows[0].png) : null;
}

function hide(text: string, secrets: Record<string, string>): string {
  let out = text;
  for (const value of Object.values(secrets)) {
    if (value.length > 2) out = out.split(value).join("{hidden}");
  }
  return out;
}

function wantsSteps(order: string): boolean {
  return /\bfill\b|\bform\b|click through|\bclick\b|\btype\b|\bselect\b/i.test(order);
}

function earlyAnswer(order: string, answer: string): boolean {
  if (!wantsSteps(order)) return false;
  return !/ready to submit|no results|nothing found|not found|\berror\b|unavailable/i.test(answer);
}

function parseMove(line: string): Move | { answer: string } | null {
  const text = line.trim();
  if (/^ANSWER:/i.test(text)) return { answer: text };
  const read = text.match(/^READ\s+(https?:\/\/\S+)/i);
  if (read) return { cmd: "read", label: "", text: "", url: read[1].replace(/[),.;]+$/, ""), x: 0, y: 0 };
  const click = text.match(/^CLICK\s+"([^"]+)"/i);
  if (click) return { cmd: "click", label: click[1], text: "", url: "", x: 0, y: 0 };
  const typed = text.match(/^TYPE\s+"([^"]+)"\s*=\s*(.+)$/i);
  if (typed) return { cmd: "type", label: typed[1], text: typed[2].trim(), url: "", x: 0, y: 0 };
  const selected = text.match(/^SELECT\s+"([^"]+)"\s*=\s*(.+)$/i);
  if (selected) return { cmd: "select", label: selected[1], text: selected[2].trim(), url: "", x: 0, y: 0 };
  if (/^SCROLL/i.test(text)) return { cmd: "scroll", label: "", text: "", url: "", x: 0, y: 0 };
  return null;
}

function isPayment(label: string): boolean {
  return PAY.test(label.trim());
}

async function askHelper(prompt: string, job: string): Promise<string | null> {
  const called = await callFollower(
    job,
    "browser",
    [
      { role: "system", content: "You are one follower. Do only the one function in the user message. Reply with one line. Do not take the next step." },
      { role: "user", content: prompt },
    ],
    (previous, next, reason) => tellChief(job, previous, next, reason),
  );
  const reply = called.text?.split("\n")[0]?.trim() ?? "";
  if (!reply || /^(i'?m sorry|i can'?t|i cannot)/i.test(reply)) return null;
  return reply.slice(0, 300);
}

function fallback(order: string, screen: Screen): string {
  const text = `${screen.title}. ${screen.text}`.replace(/\s+/g, " ").trim();
  if (text.length > 40 && /what|say|page|report|read/i.test(order)) return `ANSWER: ${text.slice(0, 400)}`;
  const field = screen.elements.find((item) => item.kind === "field" && !item.value);
  if (field) {
    const label = field.label.toLowerCase();
    const token = /mail/.test(label) ? "{EMAIL}" : /phone/.test(label) ? "{PHONE}" : "{NAME}";
    return `TYPE "${field.label}" = ${token}`;
  }
  const button = screen.elements.find((item) => item.kind === "button" && !isPayment(item.label) && !/login|password|sign in/i.test(item.label));
  if (button) return `CLICK "${button.label}"`;
  return "SCROLL";
}

async function secretsFor(id: string): Promise<Record<string, string>> {
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`select key, value from quay_job_secret where job = ${id}`;
  const secrets: Record<string, string> = {};
  for (const row of rows) secrets[String(row.key)] = String(row.value);
  return secrets;
}

function openHands(url: string, secrets: Record<string, string>) {
  const child = spawn(process.execPath, [handsPath], { stdio: ["pipe", "pipe", "ignore"] });
  const lines = createInterface({ input: child.stdout });
  const queue: string[] = [];
  let pending: ((line: string) => void) | null = null;
  lines.on("line", (line) => {
    if (pending) {
      const resolve = pending;
      pending = null;
      resolve(line);
    } else queue.push(line);
  });
  const read = () =>
    new Promise<string>((resolve, reject) => {
      if (queue.length) {
        resolve(queue.shift() as string);
        return;
      }
      const timer = setTimeout(() => reject(new Error("timeout")), 30000);
      pending = (line) => {
        clearTimeout(timer);
        resolve(line);
      };
    });
  child.stdin.write(`${JSON.stringify({ url, secrets })}\n`);
  return {
    read,
    send(move: Move) {
      child.stdin.write(`${JSON.stringify(move)}\n`);
    },
    close() {
      child.stdin.write(`${JSON.stringify({ cmd: "stop" })}\n`);
      child.kill();
    },
  };
}

async function runJob(id: string): Promise<void> {
  if (!existsSync(handsPath)) {
    const sql = await getSql();
    await sql`update quay_job set status = ${"error"}, answer = ${"The screen is not on this host."} where id = ${id}`;
    return;
  }
  const view = await readJob(id);
  if (!view) return;
  const secrets = await secretsFor(id);
  const sql = await getSql();
  const maxMillis = Number(process.env.QUAY_MAX_MILLIS ?? 15 * 60 * 1000) || 15 * 60 * 1000;
  const started = Date.now();
  const planned: PlannedStep[] = await buildPlan(id, view.order);
  let cursor = 0;
  let same = "";
  let repeats = 0;
  await leaseBrowser(async () => {
  const hands = openHands(view.url, secrets);
  try {
    while (true) {
      if (Date.now() - started >= maxMillis) {
        await sql`update quay_job set status = ${"stopped"}, answer = ${"Stopped: time limit."} where id = ${id}`;
        return;
      }
      const screen = JSON.parse(await hands.read()) as Screen;
      if (!screen.ok) throw new Error(screen.title || "The screen did not open.");
      const shotId = crypto.randomUUID();
      await sql`insert into quay_job_shot (id, job, png) values (${shotId}, ${id}, ${screen.shot})`;
      await sql`update quay_job set shot = ${shotId} where id = ${id}`;
      if ((screen.elements ?? []).some((item) => /captcha|password/i.test(item.label))) {
        await sql`update quay_job set status = ${"stopped"}, answer = ${"Stopped: password or captcha. Nothing was sent."} where id = ${id}`;
        return;
      }
      const listed = (screen.elements ?? [])
        .map((item) => `- ${item.kind} "${item.label}"${item.options.length ? ` [${item.options.join(" | ")}]` : ""}`)
        .join("\n");
      const signature = `${screen.url}|${listed}`;
      repeats = signature === same ? repeats + 1 : 0;
      same = signature;
      if (repeats >= 3) {
        await sql`update quay_job set status = ${"stopped"}, answer = ${"Stopped: the same screen came up 3 times."} where id = ${id}`;
        return;
      }
      const current = planned[Math.min(cursor, Math.max(planned.length - 1, 0))];
      noteStep({
        id: `${id}:step:${current?.n ?? cursor}`,
        slot: "browser",
        step: current?.n ?? cursor,
        fn: current?.fn ?? "read",
        status: "running",
        follower: "browser-step",
        tries: cursor + 1,
      });
      const prompt = hide(
        `You are one follower. One function only.\nSTEP ${current?.n ?? cursor} ${current?.fn ?? "read"}\n${current?.brief ?? "Read this screen."}\nControls:\n${listed}\nPage text:\n${(screen.text || "").slice(0, 700)}\nReply with ONE line for this step only: CLICK "<label>" or TYPE "<box label>" = {NAME} or SELECT "<dropdown>" = <option> or SCROLL or ANSWER: <this step only>. Do not do the next step. Do not pay or buy.`,
        secrets,
      );
      const reply = (await askHelper(prompt, id)) ?? fallback(view.order, screen);
      let parsed = parseMove(reply) ?? parseMove(fallback(view.order, screen));
      if (parsed && "answer" in parsed && earlyAnswer(view.order, parsed.answer)) {
        parsed = parseMove(fallback("", screen));
      }
      if (!parsed || ("answer" in parsed && earlyAnswer(view.order, parsed.answer))) {
        cursor += 1;
        continue;
      }
      if ("answer" in parsed) {
        const answer = hide(parsed.answer, secrets).slice(0, 800);
        await sql`insert into quay_job_step (id, job, n, command, shot) values (${crypto.randomUUID()}, ${id}, ${cursor}, ${answer}, ${shotId})`;
        await sql`update quay_job set status = ${"done"}, answer = ${answer} where id = ${id}`;
        return;
      }
      if (isPayment(parsed.label)) {
        await sql`update quay_job set status = ${"done"}, answer = ${"Not sent. Quay does not pay or buy."} where id = ${id}`;
        return;
      }
      const command = reply.slice(0, 240);
      await sql`insert into quay_job_step (id, job, n, command, shot) values (${crypto.randomUUID()}, ${id}, ${cursor}, ${hide(command, secrets)}, ${shotId})`;
      hands.send(parsed);
      cursor += 1;
    }
    await sql`update quay_job set status = ${"done"}, answer = ${"The steps are finished."} where id = ${id}`;
  } finally {
    hands.close();
  }
  });
}

export async function approveJob(id: string): Promise<{ status: string; answer: string }> {
  await ensure();
  const view = await readJob(id);
  if (!view) return { status: "missing", answer: "No such job." };
  if (view.status !== "waiting") return { status: view.status, answer: "This job is not waiting on a final button." };
  const sql = await getSql();
  const rows = await sql<Record<string, string>>`select pending from quay_job where id = ${id}`;
  const pending = String(rows[0]?.pending ?? "");
  const secrets = await secretsFor(id);
  return leaseBrowser(async () => {
  const hands = openHands(view.url, secrets);
  try {
    let lastUrl = view.url;
    const first = JSON.parse(await hands.read()) as { url?: string };
    if (first.url) lastUrl = first.url;
    for (const step of view.steps) {
      const move = parseMove(step.command);
      if (!move || "answer" in move) continue;
      hands.send(move);
      const seen = JSON.parse(await hands.read()) as { url?: string };
      if (seen.url) lastUrl = seen.url;
    }
    const jobHost = new URL(view.url).hostname;
    if (new URL(lastUrl).hostname !== jobHost) {
      return { status: "waiting", answer: "Not pressed. The page is not on the job host. Nothing was sent." };
    }
    hands.send({ cmd: "click", label: pending, text: "", url: "", x: 0, y: 0 });
    await hands.read();
    const answer = `Approved. Pressed "${pending}" on ${jobHost}.`;
    await sql`update quay_job set status = ${"approved"}, answer = ${answer} where id = ${id}`;
    return { status: "approved", answer };
  } catch {
    return { status: "waiting", answer: "The final button was not pressed. Nothing was sent." };
  } finally {
    hands.close();
  }
  });
}
