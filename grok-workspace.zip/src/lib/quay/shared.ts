import { scrubSecrets } from "@/lib/quay/secrets";

const DAY = 24 * 60 * 60 * 1000;
const CAP = 200_000;
const STANDING = "standing";

type Sheet = { text: string; at: number };

const sheets = new Map<string, Sheet>();

function clip(text: string): string {
  return scrubSecrets(text).replace(/\u0000/g, "").trim().slice(0, CAP);
}

function sweep(now = Date.now()): void {
  for (const [key, row] of sheets) {
    if (now - row.at >= DAY) sheets.delete(key);
  }
}

export function putShared(job: string, text: string): void {
  sweep();
  const clean = clip(text);
  const key = job || "page";
  if (!clean) {
    sheets.delete(key);
    return;
  }
  sheets.set(key, { text: clean, at: Date.now() });
}

export function readShared(job: string): string {
  sweep();
  return sheets.get(job || "page")?.text ?? "";
}

export function wipeShared(job: string): void {
  sheets.delete(job || "page");
}

export function putStanding(text: string): void {
  putShared(STANDING, text);
}

export function standingShared(): string {
  return readShared(STANDING);
}

export function beginJobShared(job: string, text: string): void {
  const clean = clip(text);
  putStanding(clean);
  if (clean) putShared(job, clean);
  else wipeShared(job);
}
