import { absorbAccounts } from "@/lib/quay/account-book";
import { runPlan } from "@/lib/quay/plan";
import { pushTrace } from "@/lib/quay/progress";
import { scrubSecrets } from "@/lib/quay/secrets";
import { isClosed, nextDeliveryDelay, noteTask, openTask, readTask, taskIdFor, updateTask } from "@/lib/quay/task-ledger";
import { taskKind } from "@/lib/quay/web-task";
import { deliverBotText, postBotText, readChannel } from "@/lib/quay/veil-bot";

const busy = new Set<string>();

export function cleanChannel(raw: string): string {
  const channel = raw.trim();
  if (!/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}$/.test(channel)) return "";
  return channel;
}

export async function channelFromPing(request: Request): Promise<string> {
  const url = new URL(request.url);
  const fromQuery = url.searchParams.get("channel") || url.searchParams.get("channelId") || url.searchParams.get("channel_id") || "";
  let fromBody = "";
  const raw = (await request.text()).trim();
  if (raw.startsWith("{")) {
    try {
      const json = JSON.parse(raw) as Record<string, unknown>;
      const pick = json.channel ?? json.channelId ?? json.channel_id ?? json.id;
      if (typeof pick === "string") fromBody = pick;
    } catch {
      fromBody = "";
    }
  } else if (raw && !raw.includes("\n")) {
    fromBody = raw;
  }
  return cleanChannel(fromBody || fromQuery);
}

function flatten(value: unknown): string {
  if (typeof value === "string") {
    const trimmed = value.trim();
    if ((trimmed.startsWith("{") && trimmed.endsWith("}")) || (trimmed.startsWith("[") && trimmed.endsWith("]"))) {
      try {
        return flatten(JSON.parse(trimmed));
      } catch {
        return trimmed;
      }
    }
    return trimmed;
  }
  if (!value || typeof value !== "object") return "";
  const row = value as Record<string, unknown>;
  return ["title", "kind", "name", "label", "line", "text", "body", "order", "description", "prompt"]
    .map((key) => row[key])
    .filter((item): item is string => typeof item === "string" && item.trim().length > 0)
    .join("\n");
}

export function markOf(envelope: string): { kind: "JOB" | "RESULT"; body: string } | null {
  let text = envelope.trim();
  if (!text) return null;
  try {
    text = flatten(JSON.parse(text));
  } catch {
    /* the envelope is already plain text */
  }
  const match = text.match(/QUAY\s+(JOB|RESULT)\b[:\-\s]*([\s\S]*)$/i);
  if (!match) return null;
  return {
    kind: match[1].toUpperCase() === "JOB" ? "JOB" : "RESULT",
    body: match[2].replace(/\s+/g, " ").trim(),
  };
}

export function latestJob(messages: { envelope: string; expiresAt?: number; id?: string }[]): { order: string; done: boolean } | null {
  const ordered = [...messages].sort(
    (left, right) => (left.expiresAt ?? 0) - (right.expiresAt ?? 0) || String(left.id ?? "").localeCompare(String(right.id ?? "")),
  );
  let jobAt = -1;
  let order = "";
  let done = false;
  ordered.forEach((row, index) => {
    const mark = markOf(row.envelope);
    if (!mark) return;
    if (mark.kind === "JOB") {
      jobAt = index;
      order = mark.body;
      done = false;
      return;
    }
    if (index > jobAt && jobAt >= 0) done = true;
  });
  if (jobAt < 0) return null;
  return { order, done };
}

export async function wakeVeilChannel(channel: string): Promise<{ status: number; body: Record<string, unknown> }> {
  if (busy.has(channel)) {
    return { status: 200, body: { ok: true, channel, running: true } };
  }
  const read = await readChannel(channel);
  if (!read.ok) {
    return { status: 502, body: { ok: false, error: scrubSecrets(read.error) || "Veil did not answer.", delivery_pending: true } };
  }
  const job = latestJob(read.messages);
  if (!job) return { status: 404, body: { ok: false, error: "No QUAY JOB on that channel." } };
  if (job.order.length < 2) return { status: 400, body: { ok: false, error: "The QUAY JOB had no prompt." } };
  const taskId = taskIdFor(channel, job.order);
  const existing = readTask(taskId);
  if (job.done && (!existing || isClosed(existing.status))) {
    return { status: 200, body: { ok: true, channel, task_id: taskId, status: existing?.status || "COMPLETED", already: true, result: existing?.final_result || "" } };
  }
  if (existing && isClosed(existing.status)) {
    return { status: 200, body: { ok: true, channel, task_id: taskId, status: existing.status, already: true, result: existing.final_result } };
  }
  if (existing && existing.status !== "QUEUED" && existing.status !== "RETRYING" && existing.lease_expires_at && Date.parse(existing.lease_expires_at) > Date.now()) {
    return { status: 200, body: { ok: true, channel, task_id: taskId, status: existing.status, running: true } };
  }
  if (job.done && existing?.status === "COMPLETED") {
    return { status: 200, body: { ok: true, channel, task_id: taskId, already: true } };
  }
  busy.add(channel);
  const task = openTask({ task_id: taskId, channel_id: channel, task: job.order, task_type: taskKind(job.order), source: "veil" });
  noteTask(taskId, "Veil queued");
  pushTrace(taskId, "Veil queued");
  try {
    const ack = await deliverBotText(channel, `QUAY STATUS ${taskId} ACKNOWLEDGED`);
    if (!ack.ok) {
      updateTask(taskId, { status: "QUEUED", delivery_pending: true, error: ack.error || "ack failed" });
      noteTask(taskId, `Quay ack failed ${ack.error || "delivery"}`);
      return {
        status: 502,
        body: { ok: false, channel, task_id: taskId, status: "QUEUED", delivery_pending: true, retry_ms: nextDeliveryDelay(1), error: ack.error || "Quay could not acknowledge." },
      };
    }
    await postBotText(channel, `QUAY JOB ${job.order.slice(0, 1500)}`);
    updateTask(taskId, { status: "ACKNOWLEDGED", delivery_pending: false, attempt: task.attempt + 1, lease_expires_at: new Date(Date.now() + 45_000).toISOString() });
    noteTask(taskId, "Quay acknowledged");
    pushTrace(taskId, "Quay acknowledged");
    updateTask(taskId, { status: "WORKER_RUNNING" });
    noteTask(taskId, "Worker running");
    let answer = "";
    let accepted = false;
    try {
      const run = await runPlan(`veil-${taskId}`.slice(0, 48), job.order.slice(0, 2000));
      accepted = Boolean(run.accepted);
      answer = absorbAccounts(scrubSecrets(run.answer || "")).replace(/\s+/g, " ").trim().slice(0, 1800);
    } catch (error) {
      accepted = false;
      const message = error instanceof Error ? error.message.slice(0, 120) : "run failed";
      updateTask(taskId, { status: "WORKER_FAILED", error: message });
      noteTask(taskId, `Worker failed ${message}`);
    }
    if (!accepted || !answer) {
      const row = readTask(taskId);
      const exhausted = (row?.attempt ?? 1) >= (row?.max_attempts ?? 2);
      updateTask(taskId, { status: exhausted ? "EXHAUSTED" : "RETRYING", error: "no validated result", lease_expires_at: "" });
      noteTask(taskId, exhausted ? "Exhausted" : "Retrying");
      await deliverBotText(channel, `QUAY STATUS ${taskId} ${exhausted ? "EXHAUSTED" : "RETRYING"}`);
      return { status: 200, body: { ok: true, channel, task_id: taskId, pending: !exhausted, status: exhausted ? "EXHAUSTED" : "RETRYING" } };
    }
    updateTask(taskId, { status: "RESULT_RECEIVED", worker_result: answer });
    updateTask(taskId, { status: "VALIDATING" });
    const posted = await deliverBotText(channel, `QUAY RESULT ${answer}`);
    if (!posted.ok) {
      updateTask(taskId, { status: "RESULT_PENDING", delivery_pending: true, final_result: answer, error: posted.error });
      noteTask(taskId, `Result held ${posted.error || "delivery"}`);
      return { status: 502, body: { ok: false, channel, task_id: taskId, status: "RESULT_PENDING", delivery_pending: true, error: posted.error || "Veil did not take the result." } };
    }
    updateTask(taskId, { status: "COMPLETED", final_result: answer, delivery_pending: false, lease_expires_at: "" });
    noteTask(taskId, "Completed");
    pushTrace(taskId, "Result posted to Veil");
    return { status: 200, body: { ok: true, channel, task_id: taskId, status: "COMPLETED", posted: posted.id } };
  } finally {
    busy.delete(channel);
  }
}
