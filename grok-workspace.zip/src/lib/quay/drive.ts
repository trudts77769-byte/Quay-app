import { createServerFn } from "@tanstack/react-start";
import { readSecret } from "@/lib/quay/secrets";

const SYSTEM = [
  "You drive the pointer on Quay.",
  "The user message is the manual plus the live floor. Obey that manual.",
  "Reply with commands only. No sentences, no labels, no markdown.",
  "Allowed tokens: up down left right click. A star repeats: up*4.",
  "At most 16 commands. Never invent any other command.",
].join(" ");

export interface DriveResult {
  ok: boolean;
  commands: string;
  error: string;
  spent: boolean;
}

export const driveMachine = createServerFn({ method: "POST" })
  .validator((input: unknown): { brief: string } => {
    if (!input || typeof input !== "object") throw new Error("Missing brief");
    const brief = (input as { brief?: unknown }).brief;
    if (typeof brief !== "string" || brief.trim().length < 1 || brief.length > 8000) {
      throw new Error("Missing brief");
    }
    return { brief };
  })
  .handler(async ({ data }): Promise<DriveResult> => {
    const apiKey = readSecret("XAI_API_KEY");
    if (!apiKey) {
      return {
        ok: false,
        commands: "",
        error: "No model is wired into this sandbox. Paste commands from any language model.",
        spent: false,
      };
    }

    let response: Response;
    try {
      response = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.2,
          max_tokens: 80,
          messages: [
            { role: "system", content: SYSTEM },
            { role: "user", content: data.brief },
          ],
        }),
      });
    } catch {
      return {
        ok: false,
        commands: "",
        error: "The model link did not answer. Try again.",
        spent: true,
      };
    }

    if (!response.ok) {
      return {
        ok: false,
        commands: "",
        error: `The model link failed (${response.status}). The tape still works.`,
        spent: true,
      };
    }

    const body = (await response.json()) as {
      choices?: { message?: { content?: string | null } }[];
    };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) {
      return {
        ok: false,
        commands: "",
        error: "The model returned an empty hand.",
        spent: true,
      };
    }
    return { ok: true, commands: text, error: "", spent: true };
  });
