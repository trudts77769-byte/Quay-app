import { chiefGrant, deniedEscalations, granted, type Capability, workerHas } from "@/lib/quay/capabilities";
import { memoryCapture, memoryCreateTask, memoryUpdateTask, type MemoryTask } from "@/lib/quay/task-memory";

export type EvidenceLabel = "real-screenshot" | "synthetic-preview" | "model-claim" | "verified-result" | "none";

export type SupervisorState = {
  job: string;
  task: string;
  step: number;
  decision: string;
  evidence: string;
  evidenceLabel: EvidenceLabel;
  blocker: string;
  next: string;
  complete: boolean;
  capabilities: Capability[];
  memoryId: string;
  architecture: "decision";
  execution: "separate";
};

const states = new Map<string, SupervisorState>();

function labelFor(evidence: string, complete: boolean): EvidenceLabel {
  if (!evidence) return "none";
  if (/^https?:\/\//i.test(evidence)) return "real-screenshot";
  if (complete) return "verified-result";
  return "model-claim";
}

export function openSupervision(job: string, task: string, step: number, brief: string): SupervisorState {
  const capabilities = chiefGrant(job, `${task}\n${brief}`);
  const memory = memoryCreateTask(task);
  memoryCapture(brief);
  const state: SupervisorState = {
    job,
    task: task.slice(0, 400),
    step,
    decision: "Chief granted task-scoped capabilities",
    evidence: "",
    evidenceLabel: "none",
    blocker: "",
    next: capabilities.includes("browser") ? "Open the page, then assign a follower" : "Assign a follower",
    complete: false,
    capabilities,
    memoryId: memory.id,
    architecture: "decision",
    execution: "separate",
  };
  states.set(job, state);
  return state;
}

export function noteSupervision(
  job: string,
  patch: { step?: number; decision?: string; evidence?: string; blocker?: string; next?: string; complete?: boolean },
): SupervisorState | null {
  const state = states.get(job);
  if (!state) return null;
  if (patch.complete && !patch.evidence && !state.evidence) {
    state.complete = false;
    state.blocker = "Completion needs evidence";
    state.next = "Collect evidence";
    state.evidenceLabel = "none";
    return state;
  }
  if (patch.step) state.step = patch.step;
  if (patch.decision) state.decision = patch.decision.slice(0, 240);
  if (patch.evidence) {
    state.evidence = patch.evidence.slice(0, 400);
    state.evidenceLabel = labelFor(state.evidence, Boolean(patch.complete));
  }
  if (patch.blocker) state.blocker = patch.blocker.slice(0, 240);
  if (patch.next) state.next = patch.next.slice(0, 180);
  if (patch.complete && (state.evidence || patch.evidence)) state.complete = true;
  const memory: Partial<MemoryTask> = {
    checkpoint: state.next,
    note: state.decision,
    status: state.complete ? "done" : "open",
  };
  memoryUpdateTask(state.memoryId, memory);
  return state;
}

export function quaySupervisorStatus(job = "page"): SupervisorState & { denied: string[]; allowed: Record<string, boolean> } {
  const state = states.get(job) ?? {
    job,
    task: "",
    step: 0,
    decision: "No task yet",
    evidence: "",
    evidenceLabel: "none" as const,
    blocker: "",
    next: "Wait for a task",
    complete: false,
    capabilities: granted(job),
    memoryId: "",
    architecture: "decision" as const,
    execution: "separate" as const,
  };
  return {
    ...state,
    denied: deniedEscalations(job),
    allowed: { browser: workerHas(job, "browser"), shell: workerHas(job, "shell"), file: workerHas(job, "file") },
  };
}

export function quaySupervisorPlan(task: string): { architecture: "decision"; execution: "separate"; steps: { n: number; action: string }[] } {
  const caps = granted("plan") ;
  const browser = /https?:\/\/|sandbox lab|click|page/i.test(task) || caps.includes("browser");
  return {
    architecture: "decision",
    execution: "separate",
    steps: [
      { n: 1, action: "Chief grants least-privilege capabilities for this task" },
      { n: 2, action: browser ? "Open the sandbox page before a follower acts" : "Assign one follower to the step" },
      { n: 3, action: "Keep the checkpoint: step, decision, evidence, blocker, next" },
      { n: 4, action: "Complete only after evidence is present" },
    ],
  };
}
