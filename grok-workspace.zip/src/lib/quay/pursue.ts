// @ts-nocheck
// Recovered from the last server build after an accidental overwrite, then updated for exact answers.
import { absorbAccounts } from "@/lib/quay/account-book";
import { labelOf, REASON_ORDER } from "@/lib/quay/catalog";
import { exactComplete, exactOutput, shapeUserAnswer } from "@/lib/quay/exact-output";
import { addFix, lessonText, markWorked, recordFailure, rememberOpen, searchFailures, sourceOf, taskTypeOf } from "@/lib/quay/failures";
import { otherReasoning, otherResearch } from "@/lib/quay/hire-roles";
import { intentMiss } from "@/lib/quay/intent";
import { clearFailed, markFailedStep, markWebsite, noteRepoMatches } from "@/lib/quay/job-audit";
import { chiefById, crewOf } from "@/lib/quay/job-state";
import { parseTool, runPageTool } from "@/lib/quay/page-tools";
import type { PlannedStep, StepRecord } from "@/lib/quay/plan";
import { noteCycle, noteFix, noteLoop, noteMiss, passHires } from "@/lib/quay/test-trace";
import { setWorking, pushTrace } from "@/lib/quay/progress";
import { statusOf } from "@/lib/quay/model-status";
import { callCheap, callFollower, pinnedModel, sources } from "@/lib/quay/providers";
import { extractRpc } from "@/lib/quay/rpc";
import { scrubSecrets } from "@/lib/quay/secrets";
import { readShared } from "@/lib/quay/shared";
import { SHORTHAND_KEY, decodeShorthand } from "@/lib/quay/shorthand";
import { noteStep, withSlot } from "@/lib/quay/slots";
import { lastSandboxFault, markReplacement, releaseBrowser, runBrowserFollower } from "@/lib/quay/browser-session";
import { startUrl, taskKind } from "@/lib/quay/web-task";
import { noteSupervision, openSupervision } from "@/lib/quay/supervisor";

var RULES = [
	"You are one follower. Do only the assignment in the final input.",
	"The chief does not browse and does not relay. You do the browsing and the work.",
	"Read the rules, then the shared instructions, then the final input.",
	"Any method may be used first, except on a website. A website task starts in the sandbox browser.",
	"After the sandbox, a later fix may use other methods. Do not open the sandbox again.",
	"Tools: {\"tool\":\"copy_text\",\"url\":\"https://...\"} {\"tool\":\"inspect\",\"url\":\"https://...\"} {\"tool\":\"click_and_screenshot\",\"url\":\"https://...\",\"target\":\"visible text\"} {\"tool\":\"length_check\",\"url\":\"https://...\"} {\"tool\":\"scroll\",\"url\":\"https://...\"}",
	"After a tool result, either call one more tool or answer. Use the shorthand key or one JSON-RPC 2.0 object.",
	`Key: ${SHORTHAND_KEY}`,
	"If a tool result says no findings, the next tool must use a different host. Do not retry that host.",
	"Do not invent a source you did not open. Very large numbers use scientific notation."
].join("\n");
function withWait(work) {
	return work;
}
function pinSkip(name, extra) {
	const others = sources().map((source) => source.name).filter((item) => item !== name);
	return [.../* @__PURE__ */ new Set([...extra, ...others])];
}
function hire(brief, job) {
	const shared = readShared(job);
	const user = [shared ? `SHARED INSTRUCTIONS\n${shared}` : "", `FINAL INPUT\n${brief}`].filter(Boolean).join("\n\n");
	return [{
		role: "system",
		content: RULES
	}, {
		role: "user",
		content: user
	}];
}
function plainResult(text) {
	return text.replace(/\b[RFNUQD]\s*:\s*/gi, " ").replace(/^\s*D\.?\s*/i, "").replace(/\s+/g, " ").trim();
}
function spoken(raw, method, id) {
	const rpc = extractRpc(raw) ?? decodeShorthand(raw, method, id);
	const text = rpc ? String(rpc.params.text ?? rpc.params.quote ?? rpc.params.answer ?? "") : raw;
	const url = rpc && typeof rpc.params.url === "string" ? rpc.params.url : "";
	const merged = url && !text.includes(url) ? `${text} ${url}` : text;
	return plainResult(absorbAccounts(scrubSecrets(merged || raw))).slice(0, 1500);
}
function vague(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (clean.length < 24) return true;
	if (/^(pass|fail|done|ok|yes|no|error)\b[.!]?$/i.test(clean)) return true;
	if (/^(i don't know|i do not know|not found|no results|nothing found|unable)\b/i.test(clean)) return true;
	return false;
}
function errorText(text) {
	return /^(error|forbidden)\b|\b(403|429|quota|timed out|timeout|rate limit)\b/i.test(text.trim().slice(0, 240));
}
function hostOf(url) {
	try {
		return new URL(url).host.replace(/^www\./, "").toLowerCase();
	} catch {
		return "";
	}
}
function needsFacts(finish) {
	return /\bword\b/i.test(finish) && /\b(letter|count|number)\b/i.test(finish);
}
function completes(finish, text, evidence) {
	if (exactComplete(finish, text)) return true;
	if (vague(text) || errorText(text)) return false;
	const link = text.match(/https?:\/\/[^\s)>\]]+/i)?.[0]?.replace(/[.,]+$/, "") ?? "";
	const host = link ? hostOf(link) : "";
	if (needsFacts(finish)) {
		if (!host || !evidence.toLowerCase().includes(host)) return false;
		if (!(text.match(/[A-Za-z]{12,}/g) ?? []).some((word) => evidence.toLowerCase().includes(word.toLowerCase()))) return false;
		return (text.match(/\b\d{2,4}\b|\d+(?:\.\d+)?e\d+/gi) ?? []).some((num) => evidence.toLowerCase().includes(num.toLowerCase()));
	}
	if (/\blink\b|\bsource\b|\burl\b/i.test(finish)) {
		if (!host || evidence && !evidence.toLowerCase().includes(host)) return false;
	}
	return text.length >= 40;
}
function moves(text, evidence) {
	if (vague(text) || errorText(text) || evidence.trim().length < 40) return false;
	const tokens = evidence.match(/[A-Za-z]{8,}/g) ?? [];
	const lower = text.toLowerCase();
	return tokens.some((token) => lower.includes(token.toLowerCase())) || /https?:\/\//i.test(text);
}
var REASONING = "You are the Reasoning bot hired by the chief. You run this redundancy stage. Do not answer the user's task. Do not browse.";
var RESEARCH = "You are the Research bot hired by the chief. Research every cause. Do not answer the user's task. Reply with one workaround per cause.";
var orders = /* @__PURE__ */ new Map();
function weak(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (!clean) return true;
	if (/\bno answer\b/i.test(clean)) return true;
	return vague(clean) || errorText(clean);
}
async function pickedAsk(job, system, user) {
	try {
		return await withWait(callCheap(job, [{
			role: "system",
			content: system
		}, {
			role: "user",
			content: user
		}])) ?? "";
	} catch {
		return "";
	}
}
async function hireBots(job) {
	if (!pinnedModel(job)) {
		orders.set(job, {
			reasoning: false,
			research: false
		});
		return;
	}
	let reply = "";
	try {
		reply = await withWait(callCheap(job, [{
			role: "system",
			content: "You are the chief. You only hire. Reply with exactly: HIRE reasoning. HIRE research."
		}, {
			role: "user",
			content: "A step failed the threshold. Hire the Reasoning bot to run the redundancy loop and the Research bot to research causes. Do not answer the task."
		}])) ?? "";
	} catch {
		reply = "";
	}
	orders.set(job, {
		reasoning: /hire\s+reasoning/i.test(reply),
		research: /hire\s+research/i.test(reply)
	});
}
async function chiefYes(job, task, goal, text, evidence, responseOnly) {
	try {
		const reply = await withWait(callCheap(job, [{
			role: "system",
			content: "You are the chief. You only judge the follower's response against the goal. Do not browse. Do not recheck the sandbox or the screenshots. Reply with one word, yes or no. Pass only if the response is relevant AND moves closer to the goal AND to completing the task. Incomplete, partial, vague, or off-target is no."
		}, {
			role: "user",
			content: responseOnly ? `TASK\n${task}\n\nGOAL\n${goal}\n\nRESPONSE\n${text.slice(0, 1200)}` : `TASK\n${task}\n\nGOAL\n${goal}\n\nRESPONSE\n${text.slice(0, 900)}\n\nEVIDENCE\n${evidence.slice(0, 900)}`
		}]));
		if (!reply) return null;
		if (/^\s*no\b/i.test(reply)) return false;
		if (/^\s*yes\b/i.test(reply)) return true;
		return null;
	} catch {
		return null;
	}
}
async function judge(job, task, goal, text, evidence, strict, responseOnly = false) {
	const full = completes(task, text, responseOnly ? text : evidence);
	const closer = full || !strict && moves(text, responseOnly ? text : evidence);
	const missed = intentMiss(task, text);
	if (missed) return {
		pass: false,
		full: false,
		why: missed
	};
	if (exactComplete(task, text)) return {
		pass: true,
		full: true,
		why: ""
	};
	if (!closer) return {
		pass: false,
		full: false,
		why: "partial, vague, or off-target"
	};
	if (await chiefYes(job, task, goal, text, evidence, responseOnly) === false) return {
		pass: false,
		full: false,
		why: "the chief rejected it"
	};
	if (strict && !full) return {
		pass: false,
		full: false,
		why: "the task is not complete"
	};
	return {
		pass: true,
		full,
		why: ""
	};
}
async function attemptOnce(job, step, brief, prefer, skip, scrapersOnly = false) {
	const method = step.fn === "assemble" ? "assemble" : "step_result";
	const messages = hire(brief, job);
	let follower = prefer;
	let evidence = "";
	const pages = [];
	let reason = "";
	const skipped = prefer ? pinSkip(prefer, skip) : skip;
	for (let turn = 0; turn < 5; turn += 1) {
		let called;
		try {
			called = await withWait(callFollower(job, `goal-${step.n}`, messages, void 0, follower || void 0, skipped));
		} catch {
			return {
				text: "",
				follower,
				reason: "waiting",
				evidence,
				pages
			};
		}
		if (called.follower) follower = called.follower;
		reason = called.reason || (called.text ? "" : "empty");
		const raw = called.text ?? "";
		const tool = parseTool(raw);
		if (tool && scrapersOnly && (tool.tool === "scroll" || tool.tool === "click_and_screenshot")) {
			messages.push({
				role: "assistant",
				content: raw.slice(0, 400)
			});
			messages.push({
				role: "user",
				content: "The sandbox was already tried. Use copy_text, inspect, or length_check."
			});
			continue;
		}
		if (tool) {
			let output = "";
			try {
				output = await withWait(runPageTool(job, tool));
			} catch {
				return {
					text: "",
					follower,
					reason: "waiting",
					evidence,
					pages
				};
			}
			evidence = `${evidence}\n${output}`.trim().slice(-8e3);
			if (tool.url) pages.push(tool.url);
			const next = /no findings/i.test(output) ? "This page had no findings. Next reply must be one tool on a different host." : "If this completes the assignment, reply with the shorthand key or one JSON-RPC object. Otherwise one page tool.";
			messages.push({
				role: "assistant",
				content: raw.slice(0, 400)
			});
			messages.push({
				role: "user",
				content: `TOOL RESULT\n${output.slice(0, 1800)}\n\n${next}`
			});
			continue;
		}
		return {
			text: spoken(raw, method, `${job}:${step.n}`),
			follower,
			reason,
			evidence,
			pages
		};
	}
	return {
		text: "",
		follower,
		reason: "no result",
		evidence,
		pages
	};
}
function oneCause(reason, text, goal) {
	return {
		who: reason || "the follower",
		what: "the result did not pass the threshold",
		when: "on this attempt",
		where: goal.slice(0, 160),
		why: (text || reason || "off target").slice(0, 220),
		how: "Open a different public https page with a page tool and use only facts from that page."
	};
}
function parseCauses(raw, fallback) {
	const start = raw.indexOf("[");
	const end = raw.lastIndexOf("]");
	if (start < 0 || end <= start) return [fallback];
	try {
		const value = JSON.parse(raw.slice(start, end + 1));
		if (!Array.isArray(value)) return [fallback];
		const causes = value.map((item) => {
			const row = item;
			return {
				who: String(row.who ?? fallback.who).slice(0, 160),
				what: String(row.what ?? fallback.what).slice(0, 200),
				when: String(row.when ?? fallback.when).slice(0, 120),
				where: String(row.where ?? fallback.where).slice(0, 160),
				why: String(row.why ?? fallback.why).slice(0, 240),
				how: String(row.how ?? fallback.how).slice(0, 240)
			};
		}).filter((cause) => cause.why || cause.how);
		return causes.length > 0 ? causes.slice(0, 4) : [fallback];
	} catch {
		return [fallback];
	}
}
async function analyze(job, task, goal, text, reason, evidence, step) {
	const fallback = oneCause(reason, text, goal);
	const user = `TASK\n${task}\n\nGOAL\n${goal}\n\nWHY IT FAILED\n${reason}\n\nRESULT\n${text.slice(0, 600)}\n\nEVIDENCE\n${evidence.slice(0, 800)}`;
	if (pinnedModel(job)) {
		const order = orders.get(job) ?? {
			reasoning: false,
			research: false
		};
		const prompt = `${REASONING} Reply with a JSON array only. Each item has who, what, when, where, why, and how. One item per cause.`;
		if (!order.reasoning) {
			const own = await pickedAsk(job, prompt, user);
			if (!weak(own)) return parseCauses(own, fallback);
		}
		const hired = await otherReasoning(job, step, user);
		return hired ? parseCauses(hired, fallback) : [fallback];
	}
	try {
		const reply = await withWait(callCheap(job, [{
			role: "system",
			content: "You are the chief. Do not answer the task. Reply with a JSON array only. Each item has who, what, when, where, why, and how. One item per cause."
		}, {
			role: "user",
			content: user
		}]));
		return reply ? parseCauses(reply, fallback) : [fallback];
	} catch {
		return [fallback];
	}
}
async function research(job, task, goal, causes, follower, skip, step) {
	const list = causes.map((cause, index) => `${index + 1}. who ${cause.who}; what ${cause.what}; when ${cause.when}; where ${cause.where}; why ${cause.why}; how ${cause.how}`).join("\n");
	const found = searchFailures(taskTypeOf(`${task} ${goal}`), sourceOf(`${task} ${goal}`), list);
	noteRepoMatches(job, found.used.map((row) => row.id));
	const repo = lessonText(found);
	if (pinnedModel(job)) {
		if (!(orders.get(job) ?? {
			reasoning: false,
			research: false
		}).research) {
			const own = await pickedAsk(job, RESEARCH, `TASK\n${task}\n\nGOAL\n${goal}\n\nFAILURE REPOSITORY\n${repo || "No saved match."}\n\nCAUSES\n${list}`);
			if (!weak(own)) return [repo, own].filter(Boolean).join("\n");
		}
		return [repo, await otherResearch(job, step, task, goal, list)].filter(Boolean).join("\n") || causes.map((cause) => cause.how).join(" ");
	}
	let chiefNote = "";
	try {
		chiefNote = await withWait(callCheap(job, [{
			role: "system",
			content: "You are the chief. Research every cause. Do not answer the task. Reply with one short workaround per cause."
		}, {
			role: "user",
			content: `FAILURE REPOSITORY\n${repo || "No saved match."}\n\nTASK\n${task}\n\nGOAL\n${goal}\n\nCAUSES\n${list}`
		}])) ?? "";
	} catch {
		chiefNote = "";
	}
	if (!(causes.length > 1 || /\band\b/i.test(task))) return [repo, chiefNote].filter(Boolean).join("\n") || causes.map((cause) => cause.how).join(" ");
	const extra = spoken((await callFollower(job, "reason", [{
		role: "system",
		content: "You are a reasoning follower hired only for this check. Do not answer the user's task. Make sure the assignment lines up with completing the task. Research every cause. Reply with the shorthand key or one JSON object whose text is the fix, not the answer."
	}, {
		role: "user",
		content: `TASK\n${task}\n\nASSIGNMENT\n${goal}\n\nCAUSES\n${list}`
	}], void 0, void 0, follower ? [follower, ...skip] : skip)).text ?? "", "step_result", `${job}:reason`);
	return [
		repo,
		chiefNote,
		extra
	].filter(Boolean).join("\n").slice(0, 1200);
}
function capableFollower(skip) {
	const skipped = new Set(skip);
	return [...REASON_ORDER, ...sources().map((source) => source.name)].find((id) => !skipped.has(id) && !id.startsWith("hf:") && statusOf(id) !== "Key missing" && statusOf(id) !== "Failed" && statusOf(id) !== "Quota hit") ?? "";
}
async function chiefWorkaround(job, task, goal, response, notes, mode) {
	const system = mode === "complete" ? "You are the chief. Decide the pathway forward for this same follower. Research is every source below. A workaround is any possible way to achieve the task. Do not browse. Do not recheck the sandbox or the screenshots. Reply with one short assignment, or NONE if no workaround can achieve the task. Do not state the answer." : "You are the chief. No follower can complete this task. Look for a workaround to this particular task, not a way to complete it. Use the research. Do not browse. Do not recheck the sandbox or the screenshots. Reply with one short pathway around the task, or NONE if every option is exhausted. Do not state the answer.";
	const user = `TASK\n${task}\n\nFAILED ASSIGNMENT\n${goal}\n\nRESPONSE\n${response.slice(0, 800)}\n\nRESEARCH\n${notes.slice(0, 800) || "No saved research."}`;
	let reply = "";
	if (pinnedModel(job)) reply = await pickedAsk(job, system, user);
	else try {
		reply = await withWait(callCheap(job, [{
			role: "system",
			content: system
		}, {
			role: "user",
			content: user
		}])) ?? "";
	} catch {
		reply = "";
	}
	const clean = reply.replace(/\s+/g, " ").trim();
	if (!clean || /^none\b/i.test(clean)) return "";
	return clean.slice(0, 700);
}
function priorText(needs, done) {
	return needs.map((n) => done.get(n)).filter((row) => Boolean(row?.ok && row.text)).map((row) => `STEP ${row.n} RESULT:\n${row.text.slice(0, 800)}`).join("\n\n").slice(0, 2e3);
}
function nextBrowser(job, skip) {
	const pin = pinnedModel(job);
	const blocked = new Set(["worker-pollinations", ...skip]);
	if (pin && !blocked.has(pin)) return pin;
	const ranked = [
		"worker-xai",
		"worker-gemini",
		"worker-groq",
		"worker-hf",
		"worker-airforce",
		"worker-ovh",
		...REASON_ORDER,
		...sources().map((source) => source.name)
	];
	return ranked.find((id, index) => ranked.indexOf(id) === index && !blocked.has(id) && !id.startsWith("hf:") && statusOf(id) !== "Key missing" && statusOf(id) !== "Failed" && statusOf(id) !== "Quota hit") ?? "";
}
async function runWebAttempt(input) {
	const { job, step, task, brief, prefer, skip } = input;
	const url = startUrl(`${task}\n${brief}`);
	pushTrace(job, "Task classified: WEB_INTERACTION");
	pushTrace(job, `Target resolved: ${url}`);
	let follower = prefer && prefer !== "worker-pollinations" ? prefer : nextBrowser(job, skip);
	let continued = false;
	let outcome = await runBrowserFollower({
		job,
		step: step.n,
		task,
		goal: brief,
		url,
		follower,
		continueSession: false,
		ask: async ({ prompt, image, follower: who, kind }) => {
			const called = await callFollower(job, `goal-${step.n}`, [{
				role: "system",
				content: kind === "VISION_BROWSER_FOLLOWER" ? "You are a VISION_BROWSER_FOLLOWER. The current screenshot is attached. Reply with exactly one browser action." : "You are a TEXT_BROWSER_FOLLOWER. No screenshot is attached. Use the structured screen. Reply with exactly one browser action."
			}, {
				role: "user",
				content: prompt,
				image
			}], void 0, who || void 0, who ? pinSkip(who, skip) : skip);
			return {
				text: called.text ?? "",
				follower: called.follower || who
			};
		}
	});
	for (let seat = 1; seat < 3 && outcome.verdict !== "PASS" && !pinnedModel(job); seat += 1) {
		if (outcome.verdict === "SANDBOX_TECHNICAL_FAILURE") {
			const reason = lastSandboxFault()?.message || "browser did not start";
			setWorking(job, 0, `SANDBOX FAILED — trying fallback: ${reason}`);
			noteStep({
				id: `${job}:step:${step.n}`,
				slot: follower || "open",
				step: step.n,
				fn: step.fn,
				status: "failed",
				follower,
				tries: seat,
				detail: reason.slice(0, 180)
			});
			await releaseBrowser(job, step.n);
			await new Promise((resolve) => setTimeout(resolve, 1e3));
			continued = false;
		} else {
			continued = true;
			markReplacement(job, step.n);
			const next = nextBrowser(job, [
				...skip,
				follower,
				outcome.follower
			]);
			if (!next) break;
			follower = next;
		}
		outcome = await runBrowserFollower({
			job,
			step: step.n,
			task,
			goal: brief,
			url,
			follower,
			continueSession: continued,
			ask: async ({ prompt, image, follower: who, kind }) => {
				const called = await callFollower(job, `goal-${step.n}`, [{
					role: "system",
					content: kind === "VISION_BROWSER_FOLLOWER" ? "You are a VISION_BROWSER_FOLLOWER. The current screenshot is attached. Continue the same sandbox. Reply with exactly one browser action." : "You are a TEXT_BROWSER_FOLLOWER. No screenshot is attached. Continue the same sandbox. Reply with exactly one browser action."
				}, {
					role: "user",
					content: prompt,
					image
				}], void 0, who || void 0, who ? pinSkip(who, skip) : skip);
				return {
					text: called.text ?? "",
					follower: called.follower || who
				};
			}
		});
	}
	const text = shapeUserAnswer(task, outcome.answer || "", outcome.title || "", outcome.url || "");
	const attempt = {
		text,
		follower: outcome.follower || follower,
		reason: outcome.verdict === "PASS" ? "" : outcome.verdict,
		evidence: text,
		pages: outcome.url ? [outcome.url] : []
	};
	if (outcome.verdict === "PASS") return {
		pass: true,
		full: true,
		why: "",
		attempt
	};
	return {
		pass: false,
		full: false,
		why: outcome.verdict,
		attempt
	};
}
export async function pursueGoal(input: {
  job: string;
  step: PlannedStep;
  task: string;
  done: Map<number, StepRecord>;
  run: string;
  last: boolean;
}): Promise<StepRecord> {
	const { job, step, task, done, last: lastGoal } = input;
	try {
		const prior = priorText(step.needs, done);
		let follower = pinnedModel(job);
		const skip = [];
		let learned = "";
		let prompt = prior ? `${step.brief}\n\nEARLIER RESULTS\n${prior}` : step.brief;
		const website = taskKind(`${task}\n${step.brief}`) === "WEB_TASK";
		openSupervision(job, task, step.n, step.brief);
		if (website) markWebsite(job);
		const known = searchFailures(taskTypeOf(`${task} ${step.brief}`), sourceOf(`${task} ${step.brief} ${prompt}`), "");
		noteRepoMatches(job, known.used.map((row) => row.id));
		const lesson0 = lessonText(known);
		if (lesson0) prompt = `${prompt}\n\n${lesson0}`.slice(0, 1500);
		let swaps = 0;
		let last = {
			text: "",
			follower: "",
			reason: "",
			evidence: "",
			pages: []
		};
		const runAttempt = async (brief, prefer, strict, scrapersOnly = false) => {
			noteStep({
				id: `${job}:step:${step.n}`,
				slot: prefer || "open",
				step: step.n,
				fn: step.fn,
				status: "waiting",
				follower: prefer,
				tries: swaps + 1,
				detail: "waiting"
			});
			noteCycle(job);
			try {
				last = await attemptOnce(job, step, brief, prefer, skip, scrapersOnly);
			} catch {
				last = {
					...last,
					text: "",
					reason: "empty"
				};
			}
			if (last.follower) follower = last.follower;
			if (last.reason === "waiting") return {
				pass: false,
				full: false,
				why: "the model returned nothing"
			};
			return judge(job, task, step.brief, last.text, last.evidence, strict);
		};
		const passed = (full) => {
			clearFailed(job);
			noteSupervision(job, {
				step: step.n,
				decision: full ? "task passed" : "goal passed",
				evidence: last.pages?.[0] || last.text || "",
				next: "return the result",
				complete: true
			});
			return {
				n: step.n,
				fn: step.fn,
				follower,
				slot: follower || crewOf(chiefById(job), job),
				text: exactOutput(task) ? shapeUserAnswer(task, last.text) : last.text,
				pages: last.pages,
				tries: swaps + 1,
				ok: true,
				reason: full ? "task" : "goal"
			};
		};
		while (swaps < 6) {
			setWorking(job, 0, website ? "Sandbox browser" : "Working");
			const first = await withSlot(`${job}:step:${step.n}`, async () => {
				if (website) {
					noteStep({
						id: `${job}:step:${step.n}`,
						slot: follower || "open",
						step: step.n,
						fn: step.fn,
						status: "waiting",
						follower,
						tries: swaps + 1,
						detail: "sandbox"
					});
					noteCycle(job);
					const run = await runWebAttempt({
						job,
						step,
						task,
						brief: prompt,
						prefer: follower,
						skip
					});
					last = run.attempt;
					if (last.follower) follower = last.follower;
					return {
						pass: run.pass,
						full: run.full,
						why: run.why
					};
				}
				return runAttempt(prompt, follower, lastGoal);
			});
			if (first.pass) {
				noteStep({
					id: `${job}:step:${step.n}`,
					slot: follower,
					step: step.n,
					fn: step.fn,
					status: "done",
					follower,
					tries: swaps + 1,
					page: last.pages[0] ?? "",
					detail: first.full ? "task" : "goal"
				});
				return passed(first.full);
			}
			markFailedStep(job);
			const model = labelOf(follower || pinnedModel(job) || "follower");
			rememberOpen(job, step.n, recordFailure({
				taskType: taskTypeOf(`${task} ${step.brief}`),
				source: sourceOf(`${task} ${step.brief} ${last.pages.join(" ")}`),
				step: step.n,
				model,
				wrong: first.why || last.reason || "threshold"
			}));
			noteMiss(job, step.n, first.why || last.reason || "threshold");
			await hireBots(job);
			for (let cycle = 1; cycle <= 3; cycle += 1) {
				noteLoop(job);
				setWorking(job, cycle, "Pathway");
				const causes = await analyze(job, task, step.brief, last.text, last.reason || first.why, last.evidence, step.n);
				setWorking(job, cycle, "Research");
				const notes = await research(job, task, step.brief, causes, follower, skip, step.n);
				setWorking(job, cycle, "Workaround");
				const way = await chiefWorkaround(job, task, step.brief, `${last.text}\n${learned}`, notes, "complete");
				if (!way) break;
				addFix(job, step.n, way);
				prompt = way;
				learned = [learned, notes].filter(Boolean).join("\n").slice(-2e3);
				setWorking(job, cycle, "Workaround attempt");
				const again = await runAttempt(website ? `${way}\nThe sandbox was already tried. Use another method.` : way, follower, true, website);
				if (again.pass && again.full) {
					markWorked(job, step.n, way);
					passHires(job, step.n);
					noteStep({
						id: `${job}:step:${step.n}`,
						slot: follower,
						step: step.n,
						fn: step.fn,
						status: "done",
						follower,
						tries: cycle,
						page: last.pages[0] ?? "",
						detail: "workaround"
					});
					noteFix(job, step.n, way);
					return passed(true);
				}
				learned = `${learned}\nWorkaround failed: ${again.why || "no"}`.slice(-2e3);
				last = {
					...last,
					reason: again.why || last.reason
				};
			}
			if (pinnedModel(job)) break;
			if (follower && !skip.includes(follower)) skip.push(follower);
			const hired = capableFollower(skip);
			if (!hired) break;
			follower = hired;
			swaps += 1;
			prompt = `${prior ? `${step.brief}\n\nEARLIER RESULTS\n${prior}` : step.brief}\n${learned}`.slice(0, 1500);
			learned = `${learned}\nFired the follower. Hired ${labelOf(hired)}.`.slice(-2e3);
		}
		setWorking(job, 0, "Another path");
		const aroundCauses = await analyze(job, task, step.brief, last.text, last.reason || "no follower", last.evidence, step.n);
		const aroundNotes = await research(job, task, step.brief, aroundCauses, follower, skip, step.n);
		const around = await chiefWorkaround(job, task, step.brief, last.text, aroundNotes, "around");
		if (around) {
			addFix(job, step.n, around);
			noteLoop(job);
			const again = await runAttempt(around, follower, false, false);
			if (again.pass) {
				markWorked(job, step.n, around);
				passHires(job, step.n);
				noteFix(job, step.n, around);
				noteStep({
					id: `${job}:step:${step.n}`,
					slot: follower,
					step: step.n,
					fn: step.fn,
					status: "done",
					follower,
					tries: swaps + 1,
					page: last.pages[0] ?? "",
					detail: "path around the task"
				});
				return passed(true);
			}
			last = {
				...last,
				reason: again.why || last.reason
			};
		}
		noteStep({
			id: `${job}:step:${step.n}`,
			slot: follower,
			step: step.n,
			fn: step.fn,
			status: "failed",
			follower,
			tries: swaps,
			detail: "failed"
		});
		noteSupervision(job, { step: step.n, decision: "failed", blocker: last.reason || "failed", next: "stopped", complete: false });
		return {
			n: step.n,
			fn: step.fn,
			follower,
			slot: follower,
			text: "",
			pages: last.pages,
			tries: swaps,
			ok: false,
			reason: last.reason || "failed"
		};
	} finally {
		await releaseBrowser(job, step.n);
	}
}
