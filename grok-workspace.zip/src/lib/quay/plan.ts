import { toUrl } from "@/lib/quay/engine";
import { crewOf, openChief, setChiefAnswer } from "@/lib/quay/job-state";
import { lessonText, searchFailures, sourceOf, taskTypeOf } from "@/lib/quay/failures";
import { noteRepoMatches } from "@/lib/quay/job-audit";
import { callCheap } from "@/lib/quay/providers";
import { clearWorking } from "@/lib/quay/progress";
import { pursueGoal } from "@/lib/quay/pursue";
import { extractRpc, rpcLine, type RpcMethod } from "@/lib/quay/rpc";
import { putShared, readShared, standingShared, wipeShared } from "@/lib/quay/shared";
import { linesFromRead, quayChannel, readBotMessages, sendChiefLine } from "@/lib/quay/veil-bot";
import { startUrl, taskKind } from "@/lib/quay/web-task";

export type StepFn = "read" | "find" | "extract" | "write" | "assemble" | "review";

export type PlannedStep = {
  n: number;
  fn: StepFn;
  brief: string;
  needs: number[];
};

export type StepRecord = {
  n: number;
  fn: StepFn;
  follower: string;
  slot: string;
  text: string;
  pages: string[];
  tries: number;
  ok: boolean;
  reason: string;
};

export type PlanRun = {
  accepted: boolean;
  answer: string;
  sources: string[];
  plan: PlannedStep[];
  steps: StepRecord[];
  tried: string[];
  rpc: string[];
  spent: boolean;
};

const RETRIES = 4;
const FNS = new Set<StepFn>(["read", "find", "extract", "write", "assemble", "review"]);

function urlsIn(text: string): string[] {
  const found: string[] = [];
  for (const match of text.matchAll(/https?:\/\/[^\s<>"']+/gi)) {
    const url = toUrl(match[0].replace(/[),.;]+$/, ""));
    if (url && !found.includes(url)) found.push(url);
  }
  return found;
}

function asFn(value: string): StepFn | null {
  const name = value.toLowerCase();
  if (name === "open" || name === "read") return "read";
  if (name === "find" || name === "link") return "find";
  if (name === "extract") return "extract";
  if (name === "write") return "write";
  if (name === "assemble") return "assemble";
  if (name === "review") return "review";
  return FNS.has(name as StepFn) ? (name as StepFn) : null;
}

function fnOf(text: string): StepFn {
  if (/\breview\b|\bpass criteria\b|\bjudge\b/i.test(text)) return "review";
  if (/\bassembl/i.test(text)) return "assemble";
  if (/\bwrite\b|\bdraft\b/i.test(text)) return "write";
  if (/\bextract\b|\btitles?\b|\bfirst sentence\b|\blist the\b/i.test(text)) return "extract";
  if (/\bfind\b|\blink\b/i.test(text) && !/\bopen\b|\bread\b/i.test(text)) return "find";
  if (/\bopen\b|\bread\b|\bbrowse\b/i.test(text)) return "read";
  if (/\bfind\b|\blink\b/i.test(text)) return "find";
  return "extract";
}

function numberedPlan(order: string): PlannedStep[] | null {
  const matches = [...order.matchAll(/(?:^|\n)\s*(?:step\s*)?(\d{1,2})\s*[.)\-:\]]\s*([^\n]+)/gi)];
  if (matches.length < 2) return null;
  const steps: PlannedStep[] = [];
  const seen = new Set<number>();
  for (const match of matches) {
    const n = Number(match[1]);
    const brief = match[2]?.trim().slice(0, 240) ?? "";
    if (!n || seen.has(n) || brief.length < 2) continue;
    seen.add(n);
    steps.push({ n, fn: fnOf(brief), brief, needs: [] });
  }
  return steps.length >= 2 ? steps.sort((left, right) => left.n - right.n) : null;
}

function directedPlan(order: string): PlannedStep[] | null {
  const quoted = order.match(/['"]([^'"]{3,160})['"]/)?.[1]?.trim();
  if (!quoted || !/\bgoogle\b/i.test(order)) return null;
  const url = `https://www.google.com/search?q=${encodeURIComponent(quoted)}&hl=en`;
  return [
    {
      n: 1,
      fn: "read",
      brief: `Open ${url} and report the findings. The task is complete only when the actual word, its letter count, and the source link are stated.`,
      needs: [],
    },
  ];
}

function fallbackPlan(order: string): PlannedStep[] {
  const urls = urlsIn(order).slice(0, 3);
  const ask = order.replace(/https?:\/\/\S+/g, " ").replace(/\s+/g, " ").trim().slice(0, 180);
  const steps: PlannedStep[] = [];
  if (urls.length === 0) {
    steps.push({ n: 1, fn: "find", brief: `Return one public https URL and nothing else for: ${ask || "the question"}`, needs: [] });
    steps.push({ n: 2, fn: "read", brief: "Open and read only the URL from the find step.", needs: [] });
  } else {
    for (const url of urls) steps.push({ n: steps.length + 1, fn: "read", brief: `Open and read only ${url}`, needs: [] });
  }
  steps.push({ n: steps.length + 1, fn: "extract", brief: `Extract only these facts: ${ask || "the requested facts"}`, needs: [] });
  steps.push({ n: steps.length + 1, fn: "write", brief: "Write a draft from the extracted facts only.", needs: [] });
  return steps;
}

function linkNeeds(steps: PlannedStep[]): PlannedStep[] {
  return steps.map((step, index) => {
    const n = index + 1;
    const prior = steps.slice(0, index);
    let needs: number[] = [];
    if (index === 0) needs = [];
    else if (step.fn === "assemble") needs = prior.map((_, i) => i + 1);
    else if (step.fn === "review") needs = [n - 1];
    else if ((step.fn === "read" || step.fn === "find") && !/\b(then|after|using|from the|previous|that page)\b/i.test(step.brief)) needs = [];
    else if (step.fn === "extract" || step.fn === "write") {
      const inputs = prior
        .map((item, itemIndex) => ({ item, n: itemIndex + 1 }))
        .filter((row) => row.item.fn === "read" || row.item.fn === "find" || row.item.fn === "extract" || row.item.fn === "write");
      needs = inputs.length > 0 ? inputs.map((row) => row.n) : [n - 1];
    } else needs = [n - 1];
    return { ...step, n, needs };
  });
}

function concreteFinish(order: string): string {
  if (/\blongest word\b/i.test(order)) return "State the actual word, its letter count, and the source link.";
  const ask = order.replace(/\s+/g, " ").trim().slice(0, 220);
  return `State the result of this task: ${ask}`;
}

function finish(steps: PlannedStep[], order: string): PlannedStep[] {
  const core = steps.filter((step) => step.fn !== "review");
  if (core.length === 0) return linkNeeds(fallbackPlan(order));
  return linkNeeds(core);
}

function parseFinish(raw: string): string {
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end <= start) return "";
  try {
    const parsed = JSON.parse(raw.slice(start, end + 1)) as { finish?: unknown; params?: { finish?: unknown } };
    const finish = parsed.finish ?? parsed.params?.finish;
    return typeof finish === "string" ? finish.trim().slice(0, 400) : "";
  } catch {
    return "";
  }
}

function parsePlan(raw: string): PlannedStep[] | null {
  const rpc = extractRpc(raw);
  let value: unknown = rpc?.method === "plan" ? rpc.params.steps : undefined;
  if (!value) {
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start < 0 || end <= start) return null;
    try {
      const parsed = JSON.parse(raw.slice(start, end + 1)) as { steps?: unknown; params?: { steps?: unknown } };
      value = parsed.steps ?? parsed.params?.steps;
    } catch {
      return null;
    }
  }
  if (!Array.isArray(value)) return null;
  const steps: PlannedStep[] = [];
  for (const item of value) {
    if (!item || typeof item !== "object") continue;
    const row = item as { fn?: unknown; function?: unknown; brief?: unknown };
    const fn = asFn(String(row.fn ?? row.function ?? ""));
    const brief = String(row.brief ?? "").trim().slice(0, 240);
    if (!fn || brief.length < 2) continue;
    steps.push({ n: steps.length + 1, fn, brief, needs: [] });
  }
  return steps.length >= 2 ? steps : null;
}

export function browserPlan(order: string): PlannedStep[] | null {
  const lab = /sandbox-lab|sandbox lab|interaction test page/i.test(order);
  const explicit = /https?:\/\/\S+/i.test(order);
  const hands = /\b(type|click|submit)\b/i.test(order);
  if (!lab && !explicit && !hands) return null;
  if (!lab && !explicit && taskKind(order) !== "WEB_TASK") return null;
  const url = startUrl(order);
  const ask = order.replace(/\s+/g, " ").trim().slice(0, 220);
  return [{ n: 1, fn: "read", brief: `Open ${url}. ${ask}`, needs: [] }];
}

async function preparePlan(job: string, order: string): Promise<{ steps: PlannedStep[]; spent: boolean; finish: string }> {
  const direct = browserPlan(order);
  if (direct) return { steps: direct, spent: false, finish: order };
  const base = concreteFinish(order);
  const numbered = numberedPlan(order);
  if (numbered) return { steps: finish(numbered, order), spent: false, finish: base };
  const directed = directedPlan(order);
  if (directed) return { steps: finish(directed, order), spent: false, finish: base };
  const text = await callCheap(job, [
    {
      role: "system",
      content:
        "You are the chief. You only plan. Do not answer the task and do not browse. Define the finish line in concrete terms, then split the work into goals. Each goal is one assignment for one follower. Reply with one JSON object {\"finish\":\"what must be stated\",\"steps\":[{\"fn\":\"read\",\"brief\":\"one short assignment\"}]}. Use 2 to 4 goals. A brief is only the short final input, such as one site or one target. Do not copy shared instructions into a brief. Do not add a review goal. Do not state the answer. Try saved fixes that already worked. Do not repeat a fix that already failed.",
    },
    {
      role: "user",
      content: `${readShared(job) ? `SHARED INSTRUCTIONS\n${readShared(job)}\n\n` : ""}${(() => {
        const found = searchFailures(taskTypeOf(order), sourceOf(order), order);
        noteRepoMatches(job, found.used.map((row) => row.id));
        const lesson = lessonText(found);
        return lesson ? `FAILURE REPOSITORY\n${lesson}\n\n` : "";
      })()}FINAL INPUT\n${order.slice(0, 1200)}`,
    },
  ]);
  return {
    steps: finish((text ? parsePlan(text) : null) ?? fallbackPlan(order), order),
    spent: true,
    finish: (text ? parseFinish(text) : "") || base,
  };
}

export async function buildPlan(job: string, order: string): Promise<PlannedStep[]> {
  return (await preparePlan(job, order)).steps;
}

function hideShared(job: string, value: unknown): unknown {
  const shared = readShared(job);
  const flat = shared.replace(/\s+/g, " ").trim();
  const walk = (item: unknown): unknown => {
    if (typeof item === "string") {
      let next = item;
      if (shared.length >= 8) next = next.split(shared).join("");
      if (flat.length >= 8) next = next.split(flat).join("");
      return next.replace(/[ \t]+\n/g, "\n").trim();
    }
    if (Array.isArray(item)) return item.map(walk);
    if (item && typeof item === "object") {
      const out: Record<string, unknown> = {};
      for (const [key, child] of Object.entries(item as Record<string, unknown>)) out[key] = walk(child);
      return out;
    }
    return item;
  };
  return walk(value);
}

async function logRpc(job: string, method: RpcMethod, params: Record<string, unknown>, rpc: string[], run: string): Promise<void> {
  const line = rpcLine(job || "step", method, hideShared(job, params) as Record<string, unknown>);
  rpc.push(line);
  const from = method === "step_result" || method === "assemble" || method === "review" ? "follower" : "chief";
  await sendChiefLine(job || "step", run, line, from);
}

export async function tellChief(job: string, previous: string, next: string, reason: string, run = ""): Promise<void> {
  const line = rpcLine(job || "step", "follower_changed", { old: previous, new: next, reason, job });
  await sendChiefLine(job || "step", run || job || "step", line, "chief");
}

export async function runPlan(job: string, order: string): Promise<PlanRun> {
  if (!readShared(job)) {
    const standing = standingShared();
    if (standing) putShared(job, standing);
  }
  try {
    return await runPlanBody(job, order);
  } finally {
    wipeShared(job);
    clearWorking(job);
  }
}

async function runPlanBody(job: string, order: string): Promise<PlanRun> {
  const chief = openChief(job, order);
  const prepared = await preparePlan(job, order);
  const plan = prepared.steps;
  const rpc: string[] = [];
  const run = crypto.randomUUID().replace(/-/g, "").slice(0, 16);
  const done = new Map<number, StepRecord>();
  const tried = new Set<string>();
  await logRpc(
    job,
    "plan",
    { finish: prepared.finish, steps: plan.map((step) => ({ n: step.n, fn: step.fn, needs: step.needs, brief: step.brief })), crew: crewOf(chief, job) },
    rpc,
    run,
  );
  const pending = [...plan];
  let answer = "";
  let accepted = false;
  while (pending.length > 0 && !accepted) {
    const readyIndex = pending.findIndex((step) => step.needs.every((n) => done.get(n)?.ok));
    if (readyIndex < 0) break;
    const [step] = pending.splice(readyIndex, 1);
    if (!step) break;
    const record = await pursueGoal({ job, step, task: order, done, run, last: pending.length === 0 });
    done.set(record.n, record);
    if (record.follower) tried.add(record.follower);
    const method: RpcMethod = record.fn === "assemble" ? "assemble" : "step_result";
    await logRpc(job, method, { n: record.n, fn: record.fn, follower: record.follower, ok: record.ok, reason: record.reason }, rpc, run);
    if (record.ok && record.reason === "task") {
      answer = record.text;
      accepted = true;
    } else if (!record.ok) break;
  }
  setChiefAnswer(job, accepted ? answer : "");
  const steps = [...done.values()].sort((left, right) => left.n - right.n);
  const sources = [...new Set(steps.flatMap((step) => step.pages))].slice(0, 12);
  const heard = linesFromRead(await readBotMessages(quayChannel(job)), run);
  return {
    accepted,
    answer: accepted ? answer : "",
    sources,
    plan,
    steps,
    tried: [...tried],
    rpc: heard.length === rpc.length && heard.length > 0 ? heard : rpc,
    spent: prepared.spent || tried.size > 0,
  };
}

export function formatPlanRun(run: PlanRun): string {
  const lines = ["ONE FOLLOWER PER STEP", "PLAN"];
  for (const step of run.plan) lines.push(`${step.n} ${step.fn} needs ${step.needs.join(",") || "-"} ${step.brief}`);
  lines.push("STEPS");
  if (run.steps.length === 0) lines.push("(none)");
  for (const step of run.steps) {
    lines.push(`${step.n} ${step.fn} ${step.follower || "(none)"} slot ${step.slot || "-"} tries ${step.tries} ${step.ok ? "ok" : "failed"}`);
  }
  lines.push(run.accepted ? "ACCEPTED" : "NOT ACCEPTED");
  if (run.accepted && run.answer) lines.push(run.answer);
  lines.push("RPC");
  lines.push(...run.rpc);
  return lines.join("\n");
}
