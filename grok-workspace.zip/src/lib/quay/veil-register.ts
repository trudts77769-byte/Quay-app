import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { labelOf } from "@/lib/quay/catalog";

const ORIGIN = "https://infoveil.grok.me";
const file = join(process.cwd(), "data", "veil-pings.json");
const pings = new Map<string, string>();
let loaded = false;
let flight: Promise<void> | null = null;

function load(): void {
  if (loaded) return;
  loaded = true;
  try {
    if (!existsSync(file)) return;
    const json = JSON.parse(readFileSync(file, "utf8")) as Record<string, string>;
    for (const [id, ping] of Object.entries(json)) {
      if (typeof ping === "string" && /^https:\/\//i.test(ping)) pings.set(id, ping);
    }
  } catch {
    /* register again */
  }
}

function persist(): void {
  try {
    mkdirSync(join(process.cwd(), "data"), { recursive: true });
    writeFileSync(file, JSON.stringify(Object.fromEntries(pings)));
  } catch {
    /* memory still has the address */
  }
}

function absolute(ping: string): string {
  if (/^https?:\/\//i.test(ping)) return ping;
  if (ping.startsWith("/")) return `${ORIGIN}${ping}`;
  return "";
}

async function registerOne(id: string, label: string): Promise<void> {
  load();
  if (!id || pings.get(id)) return;
  try {
    const response = await fetch(`${ORIGIN}/api/bot/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "User-Agent": "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)",
      },
      body: JSON.stringify({ source: "quay", name: id, label }),
      signal: AbortSignal.timeout(12000),
    });
    if (!response.ok) return;
    const data = (await response.json()) as { ping?: unknown };
    const ping = typeof data.ping === "string" ? absolute(data.ping) : "";
    if (!ping) return;
    pings.set(id, ping);
    persist();
  } catch {
    /* the next pass retries */
  }
}

export function registerMissing(rows: { id: string; label: string }[]): Promise<void> {
  load();
  const missing = rows.filter((row) => row.id && !pings.get(row.id));
  if (missing.length === 0) return Promise.resolve();
  if (flight) return flight;
  flight = (async () => {
    for (let index = 0; index < missing.length; index += 4) {
      await Promise.all(missing.slice(index, index + 4).map((row) => registerOne(row.id, row.label)));
    }
  })().finally(() => {
    flight = null;
  });
  return flight;
}

export async function unreadFor(id: string): Promise<string> {
  load();
  if (!id) return "";
  if (!pings.get(id)) await registerOne(id, labelOf(id));
  const ping = pings.get(id) ?? "";
  if (!ping) return "";
  try {
    const response = await fetch(ping, {
      headers: { Accept: "application/json, text/plain", "User-Agent": "QuayReader/4 (read-only public pages; +https://selfdefenseartllc.com)" },
      signal: AbortSignal.timeout(4000),
    });
    if (!response.ok) return "";
    const text = (await response.text()).replace(/\s+/g, " ").trim();
    if (!text || /^no pings\.?$/i.test(text)) return "";
    return text.slice(0, 1500);
  } catch {
    return "";
  }
}
