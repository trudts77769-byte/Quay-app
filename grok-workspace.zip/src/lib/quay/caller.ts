import { createHash, timingSafeEqual } from "node:crypto";
import { readSecret } from "@/lib/quay/secrets";

const HEADERS = {
  "Cache-Control": "no-store",
  "Content-Type": "text/plain; charset=utf-8",
  "X-Content-Type-Options": "nosniff",
};

export function callerDenied(request: Request): Response | null {
  const expected = readSecret("QUAY_CALLER_TOKEN");
  if (!expected) {
    return new Response("QUAY_CALLER_TOKEN is not set. This live route is closed.\n", { status: 503, headers: HEADERS });
  }
  const header = request.headers.get("authorization") ?? "";
  const token = header.replace(/^Bearer\s+/i, "").trim();
  const left = createHash("sha256").update(token).digest();
  const right = createHash("sha256").update(expected).digest();
  if (!timingSafeEqual(left, right)) {
    return new Response("Unauthorized. Send Authorization: Bearer and the caller token.\n", { status: 401, headers: HEADERS });
  }
  return null;
}
