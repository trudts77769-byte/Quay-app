import { toUrl } from "@/lib/quay/engine";
import { READER_UA } from "@/lib/quay/e2b-box";
import { scrubSecrets } from "@/lib/quay/secrets";

export async function jinaRead(url: string): Promise<string | null> {
  const safe = toUrl(url);
  if (!safe) return null;
  try {
    const response = await fetch(`https://r.jina.ai/${safe}`, {
      headers: { Accept: "text/plain", "User-Agent": READER_UA },
      signal: AbortSignal.timeout(20000),
    });
    if (!response.ok) return null;
    const text = scrubSecrets((await response.text()).trim());
    if (text.length < 40 || /^error\b/i.test(text)) return null;
    return text.slice(0, 8000);
  } catch {
    return null;
  }
}
