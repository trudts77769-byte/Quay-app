import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { scrubSecrets } from "@/lib/quay/secrets";

export type MemoryTask = {
  id: string;
  title: string;
  status: "open" | "done" | "archived";
  checkpoint: string;
  note: string;
  at: string;
};

type MemoryFile = { tasks: MemoryTask[]; notes: { id: string; text: string; at: string; archived?: boolean }[] };

const file = join(process.cwd(), "data", "quay-memory.json");
let store: MemoryFile = { tasks: [], notes: [] };
let loaded = false;

function clean(text: string): string {
  return scrubSecrets(text)
    .replace(/(api[_-]?key|token|password|secret)\s*[:=]\s*\S+/gi, "[secret]")
    .replace(/\b(sk-|e2b_|hf_|xai-)[A-Za-z0-9_-]{8,}\b/g, "[secret]")
    .slice(0, 800);
}

function load(): void {
  if (loaded) return;
  loaded = true;
  try {
    if (!existsSync(file)) return;
    const parsed = JSON.parse(readFileSync(file, "utf8")) as MemoryFile;
    if (Array.isArray(parsed.tasks) && Array.isArray(parsed.notes)) store = parsed;
  } catch {
    store = { tasks: [], notes: [] };
  }
}

function persist(): void {
  try {
    mkdirSync(join(process.cwd(), "data"), { recursive: true });
    writeFileSync(file, JSON.stringify(store));
  } catch {
    /* memory still lives in process */
  }
}

export function memorySchemas(): string[] {
  return ["task:id,title,status,checkpoint,note", "note:id,text"];
}

export function memoryCapture(text: string): string {
  load();
  const id = `n${store.notes.length + 1}`;
  store.notes.push({ id, text: clean(text), at: new Date().toISOString() });
  persist();
  return id;
}

export function memorySearch(query: string): { id: string; text: string }[] {
  load();
  const needle = query.trim().toLowerCase();
  return store.notes
    .filter((row) => !row.archived && row.text.toLowerCase().includes(needle))
    .slice(-8)
    .map((row) => ({ id: row.id, text: row.text }));
}

export function memoryCreateTask(title: string): MemoryTask {
  load();
  const task: MemoryTask = {
    id: `t${store.tasks.length + 1}`,
    title: clean(title).slice(0, 180),
    status: "open",
    checkpoint: "started",
    note: "",
    at: new Date().toISOString(),
  };
  store.tasks.push(task);
  persist();
  return task;
}

export function memoryUpdateTask(id: string, patch: Partial<Pick<MemoryTask, "status" | "checkpoint" | "note">>): MemoryTask | null {
  load();
  const task = store.tasks.find((row) => row.id === id);
  if (!task) return null;
  if (patch.status) task.status = patch.status;
  if (patch.checkpoint) task.checkpoint = clean(patch.checkpoint);
  if (patch.note) task.note = clean(patch.note);
  task.at = new Date().toISOString();
  persist();
  return task;
}

export function memoryListTasks(): MemoryTask[] {
  load();
  return store.tasks.filter((row) => row.status !== "archived").slice(-20);
}

export function memoryContinue(id: string): MemoryTask | null {
  load();
  const task = store.tasks.find((row) => row.id === id && row.status !== "archived");
  return task ?? null;
}

export function memoryIngest(text: string): { notes: number; tasks: number } {
  const parts = text.split(/\n{2,}/).map((part) => part.trim()).filter(Boolean).slice(0, 12);
  for (const part of parts) {
    if (/^TASK:/i.test(part)) memoryCreateTask(part.replace(/^TASK:\s*/i, ""));
    else memoryCapture(part);
  }
  return { notes: store.notes.length, tasks: store.tasks.length };
}

export function memoryReflect(): string {
  load();
  const open = store.tasks.filter((row) => row.status === "open").length;
  return `${open} open tasks, ${store.notes.length} notes`;
}

export function memoryCurate(): number {
  load();
  const seen = new Set<string>();
  let dropped = 0;
  store.notes = store.notes.filter((row) => {
    if (seen.has(row.text)) {
      dropped += 1;
      return false;
    }
    seen.add(row.text);
    return true;
  });
  persist();
  return dropped;
}

export function memoryArchive(id: string): boolean {
  load();
  const task = store.tasks.find((row) => row.id === id);
  if (task) task.status = "archived";
  const note = store.notes.find((row) => row.id === id);
  if (note) note.archived = true;
  persist();
  return Boolean(task || note);
}

export function memoryDefrag(): { notes: number; tasks: number } {
  load();
  memoryCurate();
  store.notes = store.notes.filter((row) => !row.archived).slice(-80);
  store.tasks = store.tasks.filter((row) => row.status !== "archived").slice(-40);
  persist();
  return { notes: store.notes.length, tasks: store.tasks.length };
}
