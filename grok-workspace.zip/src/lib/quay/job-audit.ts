type Audit = {
  pages: number;
  clicks: number;
  scrolls: number;
  shots: number;
  types: number;
  backs: number;
  waits: number;
  interactive: number;
  replacements: number;
  protocol: number;
  repo: number;
  failed: boolean;
  website: boolean;
  created: boolean;
  operated: boolean;
  vision: boolean;
  done: boolean;
  sessionId: string;
  follower: string;
  initialUrl: string;
  finalUrl: string;
  verdict: string;
  trace: string[];
};

const audits = new Map<string, Audit>();
const seenRepo = new Set<string>();

function empty(): Audit {
  return {
    pages: 0,
    clicks: 0,
    scrolls: 0,
    shots: 0,
    types: 0,
    backs: 0,
    waits: 0,
    interactive: 0,
    replacements: 0,
    protocol: 0,
    repo: 0,
    failed: false,
    website: false,
    created: false,
    operated: false,
    vision: false,
    done: false,
    sessionId: "",
    follower: "",
    initialUrl: "",
    finalUrl: "",
    verdict: "",
    trace: [],
  };
}

function bag(job: string): Audit {
  const key = job || "page";
  const existing = audits.get(key);
  if (existing) return existing;
  const created = empty();
  audits.set(key, created);
  return created;
}

export function noteSandbox(job: string, change: { pages?: number; clicks?: number; scrolls?: number; shots?: number }): void {
  const row = bag(job);
  row.pages += change.pages ?? 0;
  row.clicks += change.clicks ?? 0;
  row.scrolls += change.scrolls ?? 0;
  row.shots += change.shots ?? 0;
}

export type SandboxReport = {
  created: boolean;
  operated: boolean;
  vision: boolean;
  done: boolean;
  sessionId: string;
  follower: string;
  initialUrl: string;
  finalUrl: string;
  pages: number;
  interactive: number;
  clicks: number;
  types: number;
  scrolls: number;
  shots: number;
  replacements: number;
  protocol: number;
  verdict: string;
  trace: string[];
};

export function setSandboxReport(job: string, report: SandboxReport): void {
  const row = bag(job);
  row.created = report.created;
  row.operated = report.operated;
  row.vision = report.vision;
  row.done = report.done;
  row.sessionId = report.sessionId;
  row.follower = report.follower;
  row.initialUrl = report.initialUrl;
  row.finalUrl = report.finalUrl;
  row.pages = report.pages;
  row.interactive = report.interactive;
  row.clicks = report.clicks;
  row.types = report.types;
  row.scrolls = report.scrolls;
  row.shots = report.shots;
  row.replacements = report.replacements;
  row.protocol = report.protocol;
  row.verdict = report.verdict;
  row.trace = report.trace.slice(0, 24);
  if (report.created) row.website = true;
}

export function noteRepoMatches(job: string, ids: string[]): void {
  const row = bag(job);
  for (const id of ids) {
    const key = `${job}:${id}`;
    if (!id || seenRepo.has(key)) continue;
    seenRepo.add(key);
    row.repo += 1;
  }
}

export function markFailedStep(job: string): void {
  bag(job).failed = true;
}

export function clearFailed(job: string): void {
  bag(job).failed = false;
}

export function markWebsite(job: string): void {
  bag(job).website = true;
}

export function sandboxActions(job: string): number {
  return bag(job).interactive;
}

export function sandboxFailed(job: string): boolean {
  const row = bag(job);
  return row.website && row.failed && !row.operated && row.verdict !== "PASS";
}

export function auditLines(job: string): string[] {
  const row = bag(job);
  const lines = [`Task type: ${row.website ? "WEB_TASK" : "NON_WEB_TASK"}`];
  if (!row.created) {
    lines.push("Sandbox created: NO");
  } else {
    lines.push("Sandbox created: YES");
    lines.push(`Sandbox session: ${row.sessionId || "none"}`);
    lines.push(`Browser follower: ${row.follower || "none"}`);
    lines.push(`Vision input: ${row.vision ? "YES" : "NO"}`);
    lines.push(`Initial URL: ${row.initialUrl || "none"}`);
    lines.push(`Final URL: ${row.finalUrl || "none"}`);
    lines.push(`Pages opened: ${row.pages}`);
    lines.push(`Interactive actions: ${row.interactive}`);
    lines.push(`Clicks: ${row.clicks}`);
    lines.push(`Types: ${row.types}`);
    lines.push(`Scrolls: ${row.scrolls}`);
    lines.push(`Screenshots: ${row.shots}`);
    lines.push(`Follower replacements: ${row.replacements}`);
    lines.push(`Protocol corrections: ${row.protocol}`);
    lines.push(`DONE received: ${row.done ? "YES" : "NO"}`);
    lines.push(`Chief verdict: ${row.verdict || "INCOMPLETE"}`);
    if (row.operated && row.trace.length > 0) {
      lines.push("Browser trace:");
      lines.push(...row.trace);
    } else if (!row.operated) {
      lines.push("No follower-operated sandbox trace.");
    }
  }
  lines.push(`Failure repository: ${row.repo} matches used.`);
  return lines;
}

export function clearAudit(job: string): void {
  audits.delete(job || "page");
}
