const NAMED: Array<[RegExp, string]> = [
  [/\bwikipedia\b/i, "https://www.wikipedia.org"],
  [/\bduckduckgo\b/i, "https://duckduckgo.com"],
  [/\bgoogle\b/i, "https://www.google.com"],
  [/\bbing\b/i, "https://www.bing.com"],
  [/\bexample\.com\b/i, "https://example.com"],
];

export type TaskKind = "WEB_TASK" | "NON_WEB_TASK";

export function taskKind(text: string): TaskKind {
  if (/https?:\/\/|\b[a-z0-9-]+\.(com|org|net|io|me|edu|gov)\b/i.test(text)) return "WEB_TASK";
  if (/\b(website|web\s?page|browse|browser|click|scroll|menu|form|navigate|wikipedia|homepage|online|look\s+up|visit\s+\w+|search\s+(the\s+)?(web|for|google))\b/i.test(text)) {
    return "WEB_TASK";
  }
  return "NON_WEB_TASK";
}

export function labPage(): string {
  if (process.env.QUAY_LAB_URL) return process.env.QUAY_LAB_URL;
  if (process.env.VERCEL) return "https://llmsandy.grok.me/sandbox-lab.html";
  return "http://127.0.0.1:8080/sandbox-lab.html";
}

export function startUrl(text: string): string {
  if (/sandbox-lab|sandbox lab|interaction test page/i.test(text)) return labPage();
  const explicit = text.match(/https?:\/\/[^\s)>\]]+/i)?.[0]?.replace(/[.,]+$/, "") ?? "";
  if (explicit) return explicit;
  const host = text.match(/\b((?:[a-z0-9-]+\.)+[a-z]{2,})\b/i)?.[1] ?? "";
  if (host && !/^(step|task)\./i.test(host)) return `https://${host.replace(/^www\./, "").toLowerCase()}`;
  for (const [pattern, url] of NAMED) {
    if (pattern.test(text)) return url;
  }
  const named = text.match(/\b(?:open|visit)\s+(?:the\s+)?([a-z0-9-]{2,})\b/i)?.[1] ?? "";
  if (named && !/^(the|a|an|page|site|website)$/i.test(named)) return `https://www.${named.toLowerCase()}.com`;
  const query = text.match(/\bsearch(?:\s+for)?\s+(.{2,80})/i)?.[1]?.replace(/\s+/g, " ").trim() ?? "";
  if (query) return `https://duckduckgo.com/?q=${encodeURIComponent(query.slice(0, 80))}`;
  return "https://duckduckgo.com";
}
