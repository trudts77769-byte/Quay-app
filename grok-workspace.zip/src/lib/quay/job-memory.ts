type Kept = { at: number; order: string; answer: string; ttl: number };

const jobs: Kept[] = [];

function sweep(now = Date.now()): void {
  for (let index = jobs.length - 1; index >= 0; index -= 1) {
    const row = jobs[index];
    if (!row || now - row.at >= row.ttl) jobs.splice(index, 1);
  }
}

function fromVeil(text: string): boolean {
  return /infoveil|KIND\s+(open|hire|form|approve)/i.test(text);
}

export function rememberJob(order: string, answer: string, hours: number): void {
  sweep();
  if (hours <= 0) return;
  const ttlHours = Math.min(24, hours);
  if (fromVeil(order) || fromVeil(answer)) return;
  jobs.push({ at: Date.now(), order: order.slice(0, 500), answer: answer.slice(0, 2000), ttl: ttlHours * 60 * 60 * 1000 });
  if (jobs.length > 40) jobs.splice(0, jobs.length - 40);
}

export function recentJobs(): { order: string; answer: string; at: number }[] {
  sweep();
  return jobs.map((row) => ({ order: row.order, answer: row.answer, at: row.at }));
}
