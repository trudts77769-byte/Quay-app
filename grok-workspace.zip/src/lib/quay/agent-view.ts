export const GRID_COLS = 8;
export const GRID_ROWS = 32;

export interface AgentItem {
  label: string;
  kind: string;
}

export interface AgentCell {
  c: number;
  r: number;
  items: AgentItem[];
}

export interface AgentState {
  ok: boolean;
  error: string;
  url: string;
  title: string;
  transcript: string;
  pointer: { c: number; r: number };
  scroll: number;
  cols: number;
  rows: number;
  cells: AgentCell[];
  shot: string;
  note: string;
}

export function emptyAgent(): AgentState {
  return {
    ok: false,
    error: "",
    url: "",
    title: "",
    transcript: "",
    pointer: { c: 0, r: 0 },
    scroll: 0,
    cols: GRID_COLS,
    rows: GRID_ROWS,
    cells: [],
    shot: "",
    note: "",
  };
}

export function agentPath(target: string): string {
  return `/api/quay-agent?${new URLSearchParams({ url: target, format: "text" }).toString()}`;
}

export function tapeBetween(from: { c: number; r: number }, to: { c: number; r: number }): string {
  const parts: string[] = [];
  const dc = to.c - from.c;
  const dr = to.r - from.r;
  if (dr < 0) parts.push(dr === -1 ? "up" : `up*${-dr}`);
  if (dr > 0) parts.push(dr === 1 ? "down" : `down*${dr}`);
  if (dc < 0) parts.push(dc === -1 ? "left" : `left*${-dc}`);
  if (dc > 0) parts.push(dc === 1 ? "right" : `right*${dc}`);
  parts.push("click");
  return parts.join(" ");
}

export function cellOf(x: number, y: number, width: number, height: number): { c: number; r: number } {
  const w = width > 0 ? width : 1;
  const h = height > 0 ? height : 1;
  return {
    c: Math.min(GRID_COLS - 1, Math.max(0, Math.floor((x / w) * GRID_COLS))),
    r: Math.min(GRID_ROWS - 1, Math.max(0, Math.floor((y / h) * GRID_ROWS))),
  };
}

export const AGENT_HAND = [
  "You drive a real browser pointer. The person already asked you to drive it.",
  "Reply with commands only. No sentences, no labels, no markdown, no code fences.",
  "Allowed words: up down left right click. A star repeats: right*3. One star cannot exceed 16. Send at most 16 commands.",
  "The page is 8 columns by 6 rows. Column 0, row 0 is the top-left. The pointer is listed under POINTER.",
  "up, down, left, and right move one cell. On row 0, up scrolls the controls up. On row 5, down scrolls them down. click opens the link in that cell.",
  "Read CELLS. Move onto the cell you need, then click. Do the next useful click only.",
  "A correct reply looks like this: right*2 down click",
].join("\n");

export function formatAgent(state: AgentState): string {
  const lines = [
    "You are the bot. Call this same address again with the same url and the whole tape. Commands: up down left right click, and type \"words\". On a choice, type one listed option. At most 24. Do not ask the person for the next command.",
    state.error ? `ERROR ${state.error}` : "OK",
    `PAGE ${state.url || "(none)"}`,
    `TITLE ${state.title || "(none)"}`,
    `POINTER column ${state.pointer.c}, row ${state.pointer.r}`,
    "TRANSCRIPT",
    state.transcript || "(The page has no readable text yet. Open a public site.)",
    "CELLS",
  ];
  if (state.cells.length === 0) {
    lines.push("(No links, buttons, or fields are on screen.)");
  } else {
    for (const cell of state.cells) {
      const items = cell.items.map((item) => `${item.kind} "${item.label}"`).join("; ");
      lines.push(`- column ${cell.c}, row ${cell.r}: ${items}`);
    }
  }
  if (state.note) lines.push(`NOTE ${state.note}`);
  lines.push(
    "If a HELPER line lists options, type one of those options. Do not stop because the menu was drawn late.",
    "If TRANSCRIPT finishes the task, stop and answer the person in ordinary sentences. If it does not, send the next tape. The person will not type another command.",
  );
  return lines.join("\n");
}
